const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_101";
const BOB_UID = "bob_uid_202";
const OWNER_EMAIL = "anoopshakya0563@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated caller cannot read public_profiles or posts", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("public_profiles").get());
  await assertFails(unauthDb.collection("posts").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("private").doc("account").get());
});

test("User cannot self-assign admin role or inflate walletBalance on create", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@example.com",
    email_verified: true,
  }).firestore();

  const now = new Date();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("account").set({
      userId: ALICE_UID,
      fullName: "Alice",
      role: "admin",
      termsAccepted: true,
      isCreator: false,
      monetizationStatus: "none",
      walletBalance: 0,
      totalEarnings: 0,
      isBanned: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("account").set({
      userId: ALICE_UID,
      fullName: "Alice",
      role: "user",
      termsAccepted: true,
      isCreator: false,
      monetizationStatus: "none",
      walletBalance: 99999,
      totalEarnings: 0,
      isBanned: false,
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("User can create own valid account and cannot read another user's private PII", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@example.com",
    email_verified: true,
  }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, {
    email: "bob@example.com",
    email_verified: true,
  }).firestore();

  const now = new Date();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("account").get()
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("account").set({
      userId: ALICE_UID,
      fullName: "Alice Sharma",
      email: "alice@example.com",
      role: "user",
      termsAccepted: true,
      isCreator: false,
      monetizationStatus: "none",
      walletBalance: 0,
      totalEarnings: 0,
      isBanned: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("private").doc("account").get()
  );

  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("account").update({
      monetizationStatus: "approved",
      walletBalance: 5000,
    })
  );
});

test("Posts require moderationStatus filter and AI approval", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();

  await assertSucceeds(
    aliceDb.collection("posts").doc("post_1").set({
      authorUid: ALICE_UID,
      authorName: "Alice",
      postType: "news",
      caption: "Local park cleaned today!",
      likesCount: 0,
      loveCount: 0,
      hahaCount: 0,
      sadCount: 0,
      angryCount: 0,
      commentsCount: 0,
      viewsCount: 0,
      aiSafetyStatus: "approved",
      moderationStatus: "active",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertFails(aliceDb.collection("posts").get());
  await assertSucceeds(aliceDb.collection("posts").where("moderationStatus", "==", "active").get());
});

test("Super Admin with verified owner email can update app_config and approve monetization", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@example.com",
    email_verified: true,
  }).firestore();
  const ownerDb = testEnv.authenticatedContext("owner_uid", {
    email: OWNER_EMAIL,
    email_verified: true,
  }).firestore();
  const now = new Date();

  await assertFails(
    aliceDb.collection("app_config").doc("settings").set({
      dilSeCallRateInr: 10,
      viewBonusPer1000Inr: 50,
      globalMonetizationEnabled: true,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    ownerDb.collection("app_config").doc("settings").set({
      dilSeCallRateInr: 150,
      viewBonusPer1000Inr: 30,
      globalMonetizationEnabled: true,
      upiId: "dilsuno@okaxis",
      upiReceiverName: "Dil Suno Official",
      gatewayProvider: "razorpay",
      gatewayKeyId: "rzp_live_1234",
      gatewayAutomatedEnabled: true,
      supportEmail: "support@dilsuno.app",
      announcementBannerEn: "Welcome to Dil Suno!",
      announcementBannerHi: "दिल सुनो में आपका स्वागत है!",
      announcementActive: true,
      updatedAt: now,
    })
  );
});

test("Strict paid-only Dil Se Call, UPI payment, Staff Rating, Support Ticket, Admin Secrets & Account Deletion rules work", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@example.com",
    email_verified: true,
  }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, {
    email: "bob@example.com",
    email_verified: true,
  }).firestore();
  const ownerDb = testEnv.authenticatedContext("owner_uid", {
    email: OWNER_EMAIL,
    email_verified: true,
  }).firestore();
  const now = new Date();

  // Admin secrets isolated strictly to owner/admin
  await assertSucceeds(
    ownerDb.collection("admin_secrets").doc("gateway").set({
      gatewayProvider: "razorpay",
      gatewayKeyId: "rzp_live_123",
      gatewayKeySecret: "secret_xyz",
      updatedAt: now,
    })
  );
  await assertFails(aliceDb.collection("admin_secrets").doc("gateway").get());

  // Free Dil Se Call (feeInr = 0) MUST FAIL
  await assertFails(
    aliceDb.collection("dil_se_calls").doc("call_free").set({
      callerUid: ALICE_UID,
      callerAlias: "Anonymous-1",
      feeInr: 0,
      paymentId: "pay_1",
      status: "waiting",
      refunded: false,
      agreedToWarning: true,
      durationSeconds: 0,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Paid UPI payment + Paid Dil Se Call succeeds
  await assertSucceeds(
    aliceDb.collection("upi_payments").doc("pay_1").set({
      payerUid: ALICE_UID,
      payerName: "Alice",
      purpose: "dil_se_call",
      amountInr: 100,
      paymentMode: "direct_utr",
      gatewayProvider: "Direct UPI",
      utrNumber: "123456789012",
      status: "verified",
      createdAt: now,
    })
  );
  await assertSucceeds(
    aliceDb.collection("dil_se_calls").doc("call_paid").set({
      callerUid: ALICE_UID,
      callerAlias: "Anonymous-1",
      feeInr: 100,
      paymentId: "pay_1",
      status: "waiting",
      refunded: false,
      agreedToWarning: true,
      durationSeconds: 0,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Staff rating by caller succeeds, invalid 6 stars fails
  await assertFails(
    aliceDb.collection("staff_ratings").doc("rate_bad").set({
      callId: "call_paid",
      callerUid: ALICE_UID,
      staffUsername: "priya01",
      stars: 6,
      durationSeconds: 120,
      createdAt: now,
    })
  );
  await assertSucceeds(
    aliceDb.collection("staff_ratings").doc("rate_ok").set({
      callId: "call_paid",
      callerUid: ALICE_UID,
      staffUsername: "priya01",
      stars: 5,
      comment: "Very supportive",
      durationSeconds: 185,
      createdAt: now,
    })
  );

  // Support ticket isolated to owner of ticket & Admin
  await assertSucceeds(
    aliceDb.collection("support_tickets").doc("tkt_1").set({
      userUid: ALICE_UID,
      userName: "Alice",
      userEmail: "alice@example.com",
      category: "Payment Issue",
      message: "Need receipt copy",
      status: "open",
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(bobDb.collection("support_tickets").doc("tkt_1").get());
  await assertSucceeds(
    ownerDb.collection("support_tickets").doc("tkt_1").update({
      status: "resolved",
      adminReply: "Sent to your email.",
      updatedAt: now,
    })
  );

  // User can self-delete their own account for Play Store policy
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("account").set({
      userId: ALICE_UID,
      fullName: "Alice",
      role: "user",
      termsAccepted: true,
      isCreator: false,
      monetizationStatus: "none",
      walletBalance: 0,
      totalEarnings: 0,
      isBanned: false,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("private").doc("account").delete());
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("account").delete());
});

test("Active staff can moderate posts & write audit logs; suspended staff & normal users are denied; WebRTC signals isolated to participants", async () => {
  const STAFF_UID = "staff_uid_303";
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();
  const staffDb = testEnv.authenticatedContext(STAFF_UID, { email: "staff@example.com", email_verified: true }).firestore();
  const ownerDb = testEnv.authenticatedContext("owner_uid", { email: OWNER_EMAIL, email_verified: true }).firestore();
  const now = new Date();

  // Owner enables call pickup and Agora App ID
  await assertSucceeds(
    ownerDb.collection("app_config").doc("settings").set({
      dilSeCallRateInr: 100,
      viewBonusPer1000Inr: 25,
      globalMonetizationEnabled: true,
      adminCallPickupOnline: true,
      agoraAppId: "agora_prod_12345678",
      ownerCallEarningsInr: 100,
      ownerCallsCompleted: 1,
      updatedAt: now,
    })
  );

  // Alice creates a post & a paid call
  await assertSucceeds(
    aliceDb.collection("posts").doc("p_mod_1").set({
      authorUid: ALICE_UID,
      authorName: "Alice",
      postType: "reel",
      caption: "My Reel video",
      likesCount: 0,
      loveCount: 0,
      hahaCount: 0,
      sadCount: 0,
      angryCount: 0,
      commentsCount: 0,
      viewsCount: 1,
      aiSafetyStatus: "approved",
      moderationStatus: "active",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("dil_se_calls").doc("call_webrtc_1").set({
      callerUid: ALICE_UID,
      callerAlias: "Anonymous-1",
      listenerStaffId: "priya01",
      listenerUid: STAFF_UID,
      listenerRole: "staff",
      feeInr: 100,
      paymentId: "pay_rtc_1",
      status: "waiting",
      refunded: false,
      agreedToWarning: true,
      durationSeconds: 0,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Outsider Bob cannot send or read WebRTC signals on Alice's call
  await assertFails(bobDb.collection("dil_se_calls").doc("call_webrtc_1").collection("signals").get());
  await assertFails(
    bobDb.collection("dil_se_calls").doc("call_webrtc_1").collection("signals").doc("sig_bob").set({
      senderUid: BOB_UID,
      senderRole: "listener",
      signalType: "offer",
      payload: "fake_sdp",
      createdAt: now,
    })
  );

  // Caller Alice can send & read WebRTC signals
  await assertSucceeds(
    aliceDb.collection("dil_se_calls").doc("call_webrtc_1").collection("signals").doc("sig_offer_1").set({
      senderUid: ALICE_UID,
      senderRole: "caller",
      signalType: "offer",
      payload: "{\"type\":\"offer\",\"sdp\":\"v=0...\"}",
      createdAt: now,
    })
  );
  await assertSucceeds(aliceDb.collection("dil_se_calls").doc("call_webrtc_1").collection("signals").get());

  // Seed active staff directory + staff_uids claim
  await assertSucceeds(
    ownerDb.collection("staff_directory").doc("priya01").set({
      staffUsername: "priya01",
      displayName: "Priya Listener",
      assignedUid: STAFF_UID,
      isOnline: true,
      isActive: true,
      totalCalls: 0,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    staffDb.collection("staff_uids").doc(STAFF_UID).set({
      uid: STAFF_UID,
      staffUsername: "priya01",
      displayName: "Priya Listener",
      isActive: true,
      updatedAt: now,
    })
  );

  // Active staff can remove inappropriate post and create audit log, but CANNOT read audit logs
  await assertSucceeds(
    staffDb.collection("posts").doc("p_mod_1").update({
      moderationStatus: "removed",
      updatedAt: now,
    })
  );
  await assertSucceeds(
    staffDb.collection("staff_audit_logs").doc("audit_1").set({
      staffUsername: "priya01",
      staffDisplayName: "Priya Listener",
      actorUid: STAFF_UID,
      actionType: "reel_deleted",
      targetId: "p_mod_1",
      targetAuthorName: "Alice",
      contentPreview: "My Reel video",
      createdAt: now,
    })
  );
  await assertFails(staffDb.collection("staff_audit_logs").get());
  await assertSucceeds(ownerDb.collection("staff_audit_logs").get());

  // Normal user Bob cannot delete Alice's post or write audit logs
  await assertFails(
    bobDb.collection("staff_audit_logs").doc("audit_bob").set({
      staffUsername: "bob",
      staffDisplayName: "Bob",
      actorUid: BOB_UID,
      actionType: "post_deleted",
      createdAt: now,
    })
  );

  // Super Admin suspends staff -> staff immediately loses moderation & audit write permission
  await assertSucceeds(
    ownerDb.collection("staff_directory").doc("priya01").update({
      isActive: false,
      updatedAt: now,
    })
  );
  await assertFails(
    staffDb.collection("staff_audit_logs").doc("audit_after_suspend").set({
      staffUsername: "priya01",
      staffDisplayName: "Priya Listener",
      actorUid: STAFF_UID,
      actionType: "post_deleted",
      createdAt: now,
    })
  );
});

test("Virus & Malware Protection: block dangerous media URIs and XSS/malicious link text across Firestore collections", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@example.com",
    email_verified: true,
  }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, {
    email: "bob@example.com",
    email_verified: true,
  }).firestore();
  const now = new Date();

  const dangerousExtensions = ["apk", "exe", "sh", "bat", "js", "html", "zip", "rar"];
  for (const ext of dangerousExtensions) {
    await assertFails(
      aliceDb.collection("posts").doc(`bad_post_${ext}`).set({
        authorUid: ALICE_UID,
        authorName: "Alice",
        postType: "news",
        caption: "Check this out",
        mediaUri: `https://cdn.example.com/files/payload.${ext}`,
        likesCount: 0,
        loveCount: 0,
        hahaCount: 0,
        sadCount: 0,
        angryCount: 0,
        commentsCount: 0,
        viewsCount: 0,
        aiSafetyStatus: "approved",
        moderationStatus: "active",
        createdAt: now,
        updatedAt: now,
      })
    );
  }

  // Video in image-only profile avatar or story photo MUST FAIL, valid .jpg/.mp4 succeeds
  await assertFails(
    aliceDb.collection("public_profiles").doc(ALICE_UID).set({
      uid: ALICE_UID,
      fullName: "Alice",
      avatarUri: "https://cdn.example.com/clip.mp4",
      isProfileLocked: false,
      isCreator: false,
      monetizationApproved: false,
      visibility: "community",
      isBanned: false,
      followersCount: 0,
      friendsCount: 0,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("public_profiles").doc(ALICE_UID).set({
      uid: ALICE_UID,
      fullName: "Alice",
      avatarUri: "https://cdn.example.com/avatar.webp",
      isProfileLocked: false,
      isCreator: false,
      monetizationApproved: false,
      visibility: "community",
      isBanned: false,
      followersCount: 0,
      friendsCount: 0,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("posts").doc("safe_video_post").set({
      authorUid: ALICE_UID,
      authorName: "Alice",
      postType: "reel",
      caption: "Sunset reel",
      mediaUri: "https://cdn.example.com/video/sunset.mp4",
      likesCount: 0,
      loveCount: 0,
      hahaCount: 0,
      sadCount: 0,
      angryCount: 0,
      commentsCount: 0,
      viewsCount: 0,
      aiSafetyStatus: "approved",
      moderationStatus: "active",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Script tags, javascript: scheme, onerror=, and .apk links MUST FAIL in posts/comments/messages
  await assertFails(
    aliceDb.collection("posts").doc("xss_post").set({
      authorUid: ALICE_UID,
      authorName: "Alice",
      postType: "news",
      caption: "<script>alert(1)</script> Hello",
      likesCount: 0,
      loveCount: 0,
      hahaCount: 0,
      sadCount: 0,
      angryCount: 0,
      commentsCount: 0,
      viewsCount: 0,
      aiSafetyStatus: "approved",
      moderationStatus: "active",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertFails(
    aliceDb.collection("posts").doc("malicious_link_post").set({
      authorUid: ALICE_UID,
      authorName: "Alice",
      postType: "news",
      caption: "Download update https://evil.example.com/trojan.apk",
      likesCount: 0,
      loveCount: 0,
      hahaCount: 0,
      sadCount: 0,
      angryCount: 0,
      commentsCount: 0,
      viewsCount: 0,
      aiSafetyStatus: "approved",
      moderationStatus: "active",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertFails(
    bobDb.collection("posts").doc("safe_video_post").collection("comments").doc("bad_cmt").set({
      authorUid: BOB_UID,
      authorName: "Bob",
      text: "<img src=x onerror=steal()>",
      aiSafetyStatus: "approved",
      moderationStatus: "active",
      createdAt: now,
    })
  );

  // Chat attachment blocks .zip/.apk and permits .m4a voice notes & .png images
  const convId = "conv_alice_bob";
  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).set({
      participantUids: [ALICE_UID, BOB_UID],
      lastMessage: "Hi",
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("msg_zip").set({
      senderUid: ALICE_UID,
      senderName: "Alice",
      participantUids: [ALICE_UID, BOB_UID],
      messageType: "image",
      text: "Here is archive",
      mediaUri: "file:///storage/emulated/0/Download/malware.zip",
      createdAt: now,
    })
  );
  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("msg_voice").set({
      senderUid: ALICE_UID,
      senderName: "Alice",
      participantUids: [ALICE_UID, BOB_UID],
      messageType: "voice_note",
      text: "",
      mediaUri: "/data/user/0/com.example/cache/voice_123.m4a",
      voiceDurationSec: 5,
      createdAt: now,
    })
  );
});

test("Permanent Single-Owner Lock: prevent role hijacking, owner impersonation, and admin registry tampering", async () => {
  const ATTACKER_UID = "attacker_uid_999";
  const OWNER_UID = "owner_uid_anoop";

  // Unverified owner email MUST BE DENIED admin powers
  const spoofedUnverifiedOwnerDb = testEnv.authenticatedContext(ATTACKER_UID, {
    email: OWNER_EMAIL,
    email_verified: false,
  }).firestore();

  const attackerDb = testEnv.authenticatedContext(ATTACKER_UID, {
    email: "hacker@example.com",
    email_verified: true,
  }).firestore();

  const ownerDb = testEnv.authenticatedContext(OWNER_UID, {
    email: OWNER_EMAIL,
    email_verified: true,
  }).firestore();

  const now = new Date();

  // Owner creates their own private account
  await assertSucceeds(
    ownerDb.collection("users").doc(OWNER_UID).collection("private").doc("account").set({
      userId: OWNER_UID,
      fullName: "Anoop Kumar",
      email: OWNER_EMAIL,
      role: "admin",
      termsAccepted: true,
      isCreator: false,
      monetizationStatus: "none",
      walletBalance: 0,
      totalEarnings: 0,
      isBanned: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Attacker cannot add themselves to /admins registry or modify owner secrets
  await assertFails(
    attackerDb.collection("admins").doc(ATTACKER_UID).set({
      email: "hacker@example.com",
      role: "admin",
    })
  );
  await assertFails(
    spoofedUnverifiedOwnerDb.collection("admins").doc(ATTACKER_UID).set({
      email: OWNER_EMAIL,
      role: "admin",
    })
  );

  // Attacker cannot read or write admin_secrets/owner_auth
  await assertSucceeds(
    ownerDb.collection("admin_secrets").doc("owner_auth").set({
      ownerPasswordHash: "hashed_secret",
      ownerSalt: "salt_123",
      updatedAt: now,
    })
  );
  await assertFails(attackerDb.collection("admin_secrets").doc("owner_auth").get());
  await assertFails(
    attackerDb.collection("admin_secrets").doc("owner_auth").set({
      ownerPasswordHash: "hijacked",
      ownerSalt: "hijacked",
      updatedAt: now,
    })
  );

  // Attacker cannot create an account claiming staff role or owner email, nor read/delete owner account
  await assertFails(
    attackerDb.collection("users").doc(ATTACKER_UID).collection("private").doc("account").set({
      userId: ATTACKER_UID,
      fullName: "Fake Staff",
      role: "staff",
      termsAccepted: true,
      isCreator: false,
      monetizationStatus: "none",
      walletBalance: 0,
      totalEarnings: 0,
      isBanned: false,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(
    attackerDb.collection("users").doc(ATTACKER_UID).collection("private").doc("account").set({
      userId: ATTACKER_UID,
      fullName: "Fake Owner",
      email: OWNER_EMAIL,
      role: "user",
      termsAccepted: true,
      isCreator: false,
      monetizationStatus: "none",
      walletBalance: 0,
      totalEarnings: 0,
      isBanned: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertFails(attackerDb.collection("users").doc(OWNER_UID).collection("private").doc("account").get());
  await assertFails(attackerDb.collection("users").doc(OWNER_UID).collection("private").doc("account").delete());
  await assertFails(
    attackerDb.collection("users").doc(OWNER_UID).collection("private").doc("account").update({
      role: "user",
      isBanned: true,
    })
  );

  // Legitimate user cannot escalate own role from user to staff/admin
  await assertSucceeds(
    attackerDb.collection("users").doc(ATTACKER_UID).collection("private").doc("account").set({
      userId: ATTACKER_UID,
      fullName: "Normal User",
      email: "hacker@example.com",
      role: "user",
      termsAccepted: true,
      isCreator: false,
      monetizationStatus: "none",
      walletBalance: 0,
      totalEarnings: 0,
      isBanned: false,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(
    attackerDb.collection("users").doc(ATTACKER_UID).collection("private").doc("account").update({
      role: "admin",
    })
  );
  await assertFails(
    attackerDb.collection("users").doc(ATTACKER_UID).collection("private").doc("account").update({
      role: "staff",
    })
  );
});

test("Customer account age/gender validation and Gmail-based Staff Listener rules", async () => {
  const OWNER_UID = "owner_uid_anoop";
  const STAFF_UID = "staff_uid_new";
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@gmail.com",
    email_verified: true,
  }).firestore();
  const staffDb = testEnv.authenticatedContext(STAFF_UID, {
    email: "priya.listener@gmail.com",
    email_verified: true,
  }).firestore();
  const ownerDb = testEnv.authenticatedContext(OWNER_UID, {
    email: OWNER_EMAIL,
    email_verified: true,
  }).firestore();
  const now = new Date();

  // Underage (< 13) account creation MUST FAIL
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("account").set({
      userId: ALICE_UID,
      fullName: "Alice Kid",
      email: "alice@gmail.com",
      age: 10,
      gender: "Female",
      role: "user",
      termsAccepted: true,
      isCreator: false,
      monetizationStatus: "none",
      walletBalance: 0,
      totalEarnings: 0,
      isBanned: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Passwordless customer signup with age (13..120), gender, and Gmail ID SUCCEEDS
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("account").set({
      userId: ALICE_UID,
      fullName: "Alice Sharma",
      email: "alice@gmail.com",
      age: 24,
      gender: "Female",
      role: "user",
      termsAccepted: true,
      isCreator: false,
      monetizationStatus: "none",
      walletBalance: 0,
      totalEarnings: 0,
      isBanned: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Regular user CANNOT add or remove Staff Listeners
  const staffDocId = "priya_listener_abc1234567";
  await assertFails(
    aliceDb.collection("staff_directory").doc(staffDocId).set({
      staffUsername: staffDocId,
      staffEmail: "priya.listener@gmail.com",
      displayName: "Priya",
      assignedUid: "",
      isOnline: false,
      isActive: true,
      totalCalls: 0,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Owner adds Staff Listener with Gmail ID + 6-digit PIN hash
  await assertSucceeds(
    ownerDb.collection("staff_accounts").doc(staffDocId).set({
      staffUsername: staffDocId,
      staffEmail: "priya.listener@gmail.com",
      displayName: "Priya",
      passwordHash: "pinhash_6digit",
      passwordSalt: "pinsalt_16bytes",
      assignedUid: "",
      isOnline: false,
      isActive: true,
      earningsInr: 0,
      totalCalls: 0,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    ownerDb.collection("staff_directory").doc(staffDocId).set({
      staffUsername: staffDocId,
      staffEmail: "priya.listener@gmail.com",
      displayName: "Priya",
      assignedUid: "",
      isOnline: false,
      isActive: true,
      totalCalls: 0,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Approved staff claims assignedUid and toggles online duty; regular user cannot hijack it
  await assertSucceeds(
    staffDb.collection("staff_directory").doc(staffDocId).update({
      assignedUid: STAFF_UID,
      isOnline: true,
      updatedAt: now,
    })
  );
  await assertFails(
    aliceDb.collection("staff_directory").doc(staffDocId).update({
      assignedUid: ALICE_UID,
      isOnline: true,
      updatedAt: now,
    })
  );
});

test("Phone lookup index: allows owner write and exact SHA-256 get, blocks list scraping and hijacking", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@example.com",
    email_verified: true,
  }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, {
    email: "bob@example.com",
    email_verified: true,
  }).firestore();
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const now = new Date();
  const validHash = "a".repeat(64);

  await assertSucceeds(
    aliceDb.collection("phone_lookup").doc(validHash).set({
      uid: ALICE_UID,
      email: "alice@example.com",
      phoneHash: validHash,
      updatedAt: now,
    })
  );

  // Unauthenticated pre-login exact-hash get succeeds; list MUST FAIL to prevent scraping
  await assertSucceeds(unauthDb.collection("phone_lookup").doc(validHash).get());
  await assertFails(unauthDb.collection("phone_lookup").get());
  await assertFails(aliceDb.collection("phone_lookup").get());

  // Non-64-hex doc ID MUST FAIL
  await assertFails(unauthDb.collection("phone_lookup").doc("9876543210").get());

  // Another user cannot overwrite or delete Alice's phone lookup
  await assertFails(
    bobDb.collection("phone_lookup").doc(validHash).set({
      uid: BOB_UID,
      email: "bob@example.com",
      phoneHash: validHash,
      updatedAt: now,
    })
  );
  await assertFails(bobDb.collection("phone_lookup").doc(validHash).delete());
  await assertSucceeds(aliceDb.collection("phone_lookup").doc(validHash).delete());
});

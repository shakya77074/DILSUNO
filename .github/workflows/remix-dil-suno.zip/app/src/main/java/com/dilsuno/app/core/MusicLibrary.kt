package com.dilsuno.app.core

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

data class MusicMoodCategory(
    val id: String,
    val labelEn: String,
    val labelHi: String,
    val combinedLabel: String
)

data class MusicTrackOption(
    val id: String,
    val titleEn: String,
    val titleHi: String,
    val mood: String,
    val baseFreqHz: Double,
    val scaleOffsets: List<Double>,
    val audioUrl: String? = null,
    val isBuiltinSafe: Boolean = true,
    val isAdminCurated: Boolean = false
)

object RoyaltyFreeMusicLibrary {
    const val COPYRIGHT_FREE_BADGE_EN = "100% Copyright-Free Safe Music"
    const val COPYRIGHT_FREE_BADGE_HI = "100% कॉपीराइट-फ़्री सुरक्षित संगीत"

    val moodCategories = listOf(
        MusicMoodCategory(
            id = "romantic",
            labelEn = "Romantic & Dil Se",
            labelHi = "रोमांटिक व दिल से",
            combinedLabel = "Romantic & Dil Se (रोमांटिक व दिल से)"
        ),
        MusicMoodCategory(
            id = "sad_shayari",
            labelEn = "Sad & Emotional Shayari",
            labelHi = "दर्द और शायरी",
            combinedLabel = "Sad & Emotional Shayari (दर्द और शायरी)"
        ),
        MusicMoodCategory(
            id = "lofi_chill",
            labelEn = "Lo-Fi & Chill Beats",
            labelHi = "लो-फ़ाई और सुकून",
            combinedLabel = "Lo-Fi & Chill Beats (लो-फ़ाई और सुकून)"
        ),
        MusicMoodCategory(
            id = "motivational_devotional",
            labelEn = "Motivational & Devotional",
            labelHi = "प्रेरणादायक और भक्ति",
            combinedLabel = "Motivational & Devotional (प्रेरणादायक और भक्ति)"
        ),
        MusicMoodCategory(
            id = "celebration_guitar",
            labelEn = "Celebration & Acoustic Guitar",
            labelHi = "खुशी और गिटार",
            combinedLabel = "Celebration & Acoustic Guitar (खुशी और गिटार)"
        )
    )

    val tracks = listOf(
        MusicTrackOption(
            id = "none",
            titleEn = "Original Audio (No Music)",
            titleHi = "मूल आवाज़ (बिना संगीत)",
            mood = "Natural",
            baseFreqHz = 0.0,
            scaleOffsets = emptyList(),
            isBuiltinSafe = true
        ),
        // 1. Romantic & Dil Se (रोमांटिक व दिल से)
        MusicTrackOption(
            id = "romantic_dil_se",
            titleEn = "Dil Se Mehfil (Soft Flute & Guitar)",
            titleHi = "दिल से महफ़िल (बांसुरी व गिटार)",
            mood = "Romantic & Dil Se (रोमांटिक व दिल से)",
            baseFreqHz = 261.63,
            scaleOffsets = listOf(1.0, 1.25, 1.5, 1.875, 1.5, 1.25, 1.125, 1.0)
        ),
        MusicTrackOption(
            id = "pyaar_ki_baarish",
            titleEn = "Pyaar Ki Baarish (Warm Piano)",
            titleHi = "प्यार की बारिश (सॉफ्ट पियानो)",
            mood = "Romantic & Dil Se (रोमांटिक व दिल से)",
            baseFreqHz = 293.66,
            scaleOffsets = listOf(1.0, 1.125, 1.333, 1.5, 1.667, 1.5, 1.25, 1.0)
        ),
        // 2. Sad & Emotional Shayari (दर्द और शायरी)
        MusicTrackOption(
            id = "shayari_dastaan",
            titleEn = "Shayari Dastaan (Flute & Strings)",
            titleHi = "शायरी दास्ताँ (भावपूर्ण धुन)",
            mood = "Sad & Emotional Shayari (दर्द और शायरी)",
            baseFreqHz = 246.94,
            scaleOffsets = listOf(1.0, 1.125, 1.2, 1.333, 1.5, 1.333, 1.2, 1.0)
        ),
        MusicTrackOption(
            id = "dard_bhari_shaam",
            titleEn = "Tanha Shaam (Violin & Piano)",
            titleHi = "तन्हा शाम (वायोलिन व दर्द धुन)",
            mood = "Sad & Emotional Shayari (दर्द और शायरी)",
            baseFreqHz = 220.0,
            scaleOffsets = listOf(1.0, 1.067, 1.2, 1.333, 1.5, 1.333, 1.125, 1.0)
        ),
        // 3. Lo-Fi & Chill Beats (लो-फ़ाई और सुकून)
        MusicTrackOption(
            id = "lofi_sukoon",
            titleEn = "Lo-Fi Sukoon (Midnight Chill)",
            titleHi = "लो-फ़ाई सुकून (सुकून बीट्स)",
            mood = "Lo-Fi & Chill Beats (लो-फ़ाई और सुकून)",
            baseFreqHz = 261.63,
            scaleOffsets = listOf(1.0, 1.125, 1.25, 1.5, 1.667, 1.5, 1.25, 1.125)
        ),
        MusicTrackOption(
            id = "ambient_raag",
            titleEn = "Ambient Evening Raag Lo-Fi",
            titleHi = "संध्या राग लो-फ़ाई",
            mood = "Lo-Fi & Chill Beats (लो-फ़ाई और सुकून)",
            baseFreqHz = 220.0,
            scaleOffsets = listOf(1.0, 1.067, 1.25, 1.333, 1.5, 1.6, 1.875, 2.0)
        ),
        // 4. Motivational & Devotional (प्रेरणादायक और भक्ति)
        MusicTrackOption(
            id = "uplifting_morning",
            titleEn = "Uplifting Morning Sun (Prerna)",
            titleHi = "प्रभात प्रेरणा (नई ऊर्जा)",
            mood = "Motivational & Devotional (प्रेरणादायक और भक्ति)",
            baseFreqHz = 329.63,
            scaleOffsets = listOf(1.0, 1.125, 1.25, 1.5, 2.0, 1.5, 1.25, 1.0)
        ),
        MusicTrackOption(
            id = "bhakti_sitar_meditation",
            titleEn = "Bhakti Santoor & Tanpura Calm",
            titleHi = "भक्ति संतूर व तानपुरा शांति",
            mood = "Motivational & Devotional (प्रेरणादायक और भक्ति)",
            baseFreqHz = 261.63,
            scaleOffsets = listOf(1.0, 1.25, 1.5, 1.667, 2.0, 1.667, 1.5, 1.0)
        ),
        // 5. Celebration & Acoustic Guitar (खुशी और गिटार)
        MusicTrackOption(
            id = "desi_folk",
            titleEn = "Desi Folk Celebration",
            titleHi = "देसी लोक उत्सव धुन",
            mood = "Celebration & Acoustic Guitar (खुशी और गिटार)",
            baseFreqHz = 293.66,
            scaleOffsets = listOf(1.0, 1.2, 1.333, 1.5, 1.778, 1.5, 1.333, 1.2)
        ),
        MusicTrackOption(
            id = "khushi_acoustic_guitar",
            titleEn = "Khushi Acoustic Guitar Strums",
            titleHi = "खुशी एकॉस्टिक गिटार",
            mood = "Celebration & Acoustic Guitar (खुशी और गिटार)",
            baseFreqHz = 349.23,
            scaleOffsets = listOf(1.0, 1.125, 1.25, 1.5, 1.667, 2.0, 1.5, 1.25)
        )
    )

    val sfxTracks = listOf(
        MusicTrackOption(
            id = "sfx_whoosh",
            titleEn = "Transition Whoosh",
            titleHi = "ट्रांज़िशन वूश",
            mood = "SFX",
            baseFreqHz = 392.0,
            scaleOffsets = listOf(1.0, 1.25, 1.5)
        ),
        MusicTrackOption(
            id = "sfx_news_alert",
            titleEn = "Breaking News Chime",
            titleHi = "ब्रेकिंग न्यूज़ अलर्ट",
            mood = "SFX",
            baseFreqHz = 523.25,
            scaleOffsets = listOf(1.0, 1.5, 1.0, 1.5)
        ),
        MusicTrackOption(
            id = "sfx_heart_spark",
            titleEn = "Heart Sparkle Pop",
            titleHi = "दिल स्पार्कल पॉप",
            mood = "SFX",
            baseFreqHz = 440.0,
            scaleOffsets = listOf(1.0, 1.25, 1.6, 2.0)
        )
    )

    private val jsonObjectRegex = Regex("""\{([^{}]*)\}""")
    private val jsonPairRegex = Regex(""""((?:\\.|[^"\\])*)"\s*:\s*"((?:\\.|[^"\\])*)"""")

    private fun escapeJsonString(value: String): String = buildString(value.length + 8) {
        value.forEach { ch ->
            when (ch) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> append(ch)
            }
        }
    }

    private fun unescapeJsonString(value: String): String = buildString(value.length) {
        var i = 0
        while (i < value.length) {
            val ch = value[i]
            if (ch == '\\' && i + 1 < value.length) {
                when (val next = value[i + 1]) {
                    '\\' -> { append('\\'); i += 2 }
                    '"' -> { append('"'); i += 2 }
                    'n' -> { append('\n'); i += 2 }
                    'r' -> { append('\r'); i += 2 }
                    't' -> { append('\t'); i += 2 }
                    '/' -> { append('/'); i += 2 }
                    'u' -> {
                        if (i + 5 < value.length) {
                            val code = value.substring(i + 2, i + 6).toIntOrNull(16)
                            if (code != null) {
                                append(code.toChar())
                                i += 6
                                continue
                            }
                        }
                        append(next)
                        i += 2
                    }
                    else -> { append(next); i += 2 }
                }
            } else {
                append(ch)
                i++
            }
        }
    }

    fun parseCustomTracks(rawJson: String?): List<MusicTrackOption> {
        val trimmed = rawJson?.trim().orEmpty()
        if (!trimmed.startsWith("[") || !trimmed.endsWith("]")) return emptyList()
        return runCatching {
            jsonObjectRegex.findAll(trimmed).mapNotNull { objMatch ->
                val fields = mutableMapOf<String, String>()
                jsonPairRegex.findAll(objMatch.groupValues[1]).forEach { pair ->
                    val k = unescapeJsonString(pair.groupValues[1])
                    val v = unescapeJsonString(pair.groupValues[2])
                    fields[k] = v
                }
                val id = fields["id"].orEmpty().trim()
                val titleEn = SecurityUtils.sanitizeInput(fields["titleEn"].orEmpty(), 80)
                val titleHi = SecurityUtils.sanitizeInput(fields["titleHi"].orEmpty(), 80).ifBlank { titleEn }
                val mood = SecurityUtils.sanitizeInput(fields["mood"].orEmpty(), 80)
                    .ifBlank { moodCategories.first().combinedLabel }
                val url = fields["audioUrl"].orEmpty().trim()
                if (id.isBlank() || titleEn.isBlank()) return@mapNotNull null
                MusicTrackOption(
                    id = id,
                    titleEn = titleEn,
                    titleHi = titleHi,
                    mood = mood,
                    baseFreqHz = 261.63,
                    scaleOffsets = listOf(1.0, 1.25, 1.5, 1.25, 1.0),
                    audioUrl = url.takeIf { it.startsWith("https://", ignoreCase = true) },
                    isBuiltinSafe = true,
                    isAdminCurated = true
                )
            }.toList()
        }.getOrDefault(emptyList())
    }

    fun serializeCustomTracks(list: List<MusicTrackOption>): String {
        return list.joinToString(prefix = "[", postfix = "]", separator = ",") { t ->
            buildString {
                append("{")
                append("\"id\":\"").append(escapeJsonString(t.id)).append("\",")
                append("\"titleEn\":\"").append(escapeJsonString(t.titleEn)).append("\",")
                append("\"titleHi\":\"").append(escapeJsonString(t.titleHi)).append("\",")
                append("\"mood\":\"").append(escapeJsonString(t.mood)).append("\",")
                append("\"audioUrl\":\"").append(escapeJsonString(t.audioUrl.orEmpty())).append("\"")
                append("}")
            }
        }
    }

    fun allTracksWithCustom(customJson: String?): List<MusicTrackOption> {
        val custom = parseCustomTracks(customJson)
        if (custom.isEmpty()) return tracks
        val existingIds = tracks.map { it.id }.toSet()
        return tracks + custom.filterNot { it.id in existingIds }
    }

    private var previewJob: Job? = null
    private var currentTrackId: String? = null
    private var activeAudioTrack: AudioTrack? = null
    private var activeMediaPlayer: MediaPlayer? = null
    private var currentVolume: Float = 0.8f

    fun setPreviewVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        currentVolume = clamped
        runCatching { activeAudioTrack?.setVolume(clamped) }
        runCatching { activeMediaPlayer?.setVolume(clamped, clamped) }
    }

    fun stopPreview() {
        previewJob?.cancel()
        previewJob = null
        currentTrackId = null
        runCatching {
            activeAudioTrack?.stop()
            activeAudioTrack?.release()
        }
        activeAudioTrack = null
        runCatching {
            activeMediaPlayer?.stop()
            activeMediaPlayer?.release()
        }
        activeMediaPlayer = null
    }

    fun playUriPreview(
        context: Context,
        uriString: String,
        trackKey: String,
        volume: Float = 0.8f,
        onFinished: () -> Unit
    ) {
        if (currentTrackId == trackKey && activeMediaPlayer != null) {
            stopPreview()
            onFinished()
            return
        }
        stopPreview()
        currentTrackId = trackKey
        currentVolume = volume.coerceIn(0f, 1f)
        try {
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(context, Uri.parse(uriString))
                setVolume(currentVolume, currentVolume)
                setOnPreparedListener { player ->
                    player.start()
                }
                setOnCompletionListener {
                    stopPreview()
                    onFinished()
                }
                setOnErrorListener { _, _, _ ->
                    stopPreview()
                    onFinished()
                    true
                }
                prepareAsync()
            }
            activeMediaPlayer = mp
        } catch (_: Exception) {
            stopPreview()
            onFinished()
        }
    }

    fun playPreview(
        scope: CoroutineScope,
        track: MusicTrackOption,
        context: Context? = null,
        volume: Float = 0.8f,
        onFinished: () -> Unit
    ) {
        if (track.id == "none" || (track.scaleOffsets.isEmpty() && track.audioUrl.isNullOrBlank())) {
            stopPreview()
            onFinished()
            return
        }
        if (currentTrackId == track.id && (previewJob?.isActive == true || activeMediaPlayer != null)) {
            stopPreview()
            onFinished()
            return
        }
        currentVolume = volume.coerceIn(0f, 1f)

        // If Owner added a remote HTTPS audio URL and Context is available, stream via MediaPlayer first
        val remoteUrl = track.audioUrl?.takeIf { it.startsWith("https://", ignoreCase = true) }
        if (remoteUrl != null && context != null) {
            stopPreview()
            currentTrackId = track.id
            try {
                val mp = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    setDataSource(remoteUrl)
                    setVolume(currentVolume, currentVolume)
                    setOnPreparedListener { it.start() }
                    setOnCompletionListener {
                        stopPreview()
                        onFinished()
                    }
                    setOnErrorListener { _, _, _ ->
                        stopPreview()
                        playSynthesizedFallback(scope, track, onFinished)
                        true
                    }
                    prepareAsync()
                }
                activeMediaPlayer = mp
                return
            } catch (_: Exception) {
                stopPreview()
            }
        }

        playSynthesizedFallback(scope, track, onFinished)
    }

    private fun playSynthesizedFallback(
        scope: CoroutineScope,
        track: MusicTrackOption,
        onFinished: () -> Unit
    ) {
        stopPreview()
        currentTrackId = track.id
        previewJob = scope.launch(Dispatchers.Default) {
            val sampleRate = 22050
            val noteDurationSamples = (sampleRate * 0.45).toInt()
            val ratios = track.scaleOffsets.ifEmpty { listOf(1.0, 1.25, 1.5, 1.25) }
            val totalSamples = noteDurationSamples * ratios.size
            val buffer = ShortArray(totalSamples)
            var idx = 0
            for (ratio in ratios) {
                val freq = track.baseFreqHz * ratio
                val fifthFreq = freq * 1.5
                for (i in 0 until noteDurationSamples) {
                    val env = if (i < 600) i / 600.0
                    else if (i > noteDurationSamples - 1500) (noteDurationSamples - i) / 1500.0
                    else 1.0
                    val fundamental = sin(2.0 * PI * freq * i / sampleRate) * 0.22
                    val warmPad = sin(2.0 * PI * (freq * 0.5) * i / sampleRate) * 0.12
                    val harmonicFifth = sin(2.0 * PI * fifthFreq * i / sampleRate) * 0.06
                    val sample = (fundamental + warmPad + harmonicFifth) * env
                    buffer[idx++] = (sample * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }
            }

            var audioTrack: AudioTrack? = null
            try {
                audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                activeAudioTrack = audioTrack
                audioTrack.write(buffer, 0, buffer.size)
                audioTrack.setVolume(currentVolume)
                audioTrack.play()
                val durationMs = (totalSamples * 1000L) / sampleRate
                val step = 100L
                var elapsed = 0L
                while (isActive && elapsed < durationMs) {
                    kotlinx.coroutines.delay(step)
                    elapsed += step
                }
            } catch (_: Exception) {
                // Graceful fallback on headless/emulator without audio hardware
            } finally {
                try {
                    audioTrack?.stop()
                    audioTrack?.release()
                } catch (_: Exception) {
                }
                if (activeAudioTrack === audioTrack) activeAudioTrack = null
                currentTrackId = null
                onFinished()
            }
        }
    }
}


package com.dilsuno.app.ui.screens

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.VoiceNoteHelper
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.PublicProfile
import com.dilsuno.app.viewmodel.MainAppViewModel

@Composable
fun FriendsAndMessengerScreen(
    viewModel: MainAppViewModel,
    lang: AppLang
) {
    val profiles by viewModel.communityProfiles.collectAsStateWithLifecycle()
    val links by viewModel.friendLinks.collectAsStateWithLifecycle()
    val suggestions by viewModel.smartFriendSuggestions.collectAsStateWithLifecycle()
    val groups by viewModel.groups.collectAsStateWithLifecycle()
    val pages by viewModel.pages.collectAsStateWithLifecycle()

    var subTab by remember { mutableIntStateOf(0) } // 0 = People, 1 = Messenger, 2 = Groups & Pages
    var searchQuery by remember { mutableStateOf("") }
    var activeChatPeer by remember { mutableStateOf<PublicProfile?>(null) }
    var inspectProfile by remember { mutableStateOf<PublicProfile?>(null) }
    var showCreateGroupDialog by remember { mutableStateOf(false) }
    var showCreatePageDialog by remember { mutableStateOf(false) }

    val profilesByUid = remember(profiles) { profiles.associateBy { it.uid } }
    val acceptedLinks = remember(links) { links.filter { it.status == "accepted" } }
    val incomingRequests = remember(links) {
        links.filter { it.status == "pending" && it.toUid == viewModel.currentUserId }
    }
    val pendingOutgoingUids = remember(links) {
        links.filter { it.status == "pending" && it.fromUid == viewModel.currentUserId }
            .map { it.toUid }
            .toSet()
    }
    val friendUids = remember(acceptedLinks) {
        acceptedLinks.flatMap { it.participantUids }.filter { it != viewModel.currentUserId }.toSet()
    }

    if (activeChatPeer != null) {
        val livePeer = profilesByUid[activeChatPeer!!.uid] ?: activeChatPeer!!
        FriendChatView(
            peer = livePeer,
            profilesByUid = profilesByUid,
            viewModel = viewModel,
            lang = lang,
            onBack = { activeChatPeer = null }
        )
        return
    }

    Column(
        modifier = Modifier
            .widthIn(max = 640.dp)
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = tr("Friends, Chat & Communities", "मित्र, चैट और समुदाय", lang),
            style = MaterialTheme.typography.headlineSmall
        )

        val tabs = listOf(
            tr("People", "लोग", lang),
            tr("Messenger", "चैट", lang),
            tr("Groups & Pages", "समूह और पेज", lang)
        )
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            tabs.forEachIndexed { idx, label ->
                SegmentedButton(
                    selected = subTab == idx,
                    onClick = { subTab = idx },
                    shape = SegmentedButtonDefaults.itemShape(index = idx, count = tabs.size),
                    modifier = Modifier.testTag("social_tab_$idx")
                ) {
                    Text(label, maxLines = 1)
                }
            }
        }

        when (subTab) {
            0 -> {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text(tr("Search by Name, City, Hometown, School/College", "नाम, शहर, गाँव या स्कूल/कॉलेज से खोजें", lang)) },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    modifier = Modifier.fillMaxWidth().testTag("smart_search_input"),
                    singleLine = true
                )

                val filteredProfiles = remember(searchQuery, profiles) {
                    if (searchQuery.isBlank()) emptyList()
                    else profiles.filter { p ->
                        p.uid != viewModel.currentUserId && (
                            p.fullName.contains(searchQuery, ignoreCase = true) ||
                                (p.currentCity ?: "").contains(searchQuery, ignoreCase = true) ||
                                (p.hometown ?: "").contains(searchQuery, ignoreCase = true) ||
                                (p.schoolCollege ?: "").contains(searchQuery, ignoreCase = true)
                            )
                    }
                }

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    if (searchQuery.isNotBlank()) {
                        item {
                            Text(tr("Search Results", "खोज परिणाम", lang), style = MaterialTheme.typography.titleMedium)
                        }
                        items(filteredProfiles, key = { "sr_${it.uid}" }) { person ->
                            val isFriend = person.uid in friendUids
                            val isPending = person.uid in pendingOutgoingUids
                            PersonCard(
                                profile = person,
                                subtitle = listOfNotNull(
                                    person.schoolCollege?.takeIf { it.isNotBlank() },
                                    person.hometown?.takeIf { it.isNotBlank() },
                                    person.currentCity?.takeIf { it.isNotBlank() }
                                ).joinToString(" • "),
                                isFriend = isFriend,
                                isPending = isPending,
                                lang = lang,
                                onView = { inspectProfile = person },
                                onAddOrChat = {
                                    if (isFriend) activeChatPeer = person else viewModel.sendFriendRequest(person.uid)
                                }
                            )
                        }
                    }

                    if (incomingRequests.isNotEmpty()) {
                        item {
                            Text(tr("Friend Requests", "मित्रता अनुरोध", lang), style = MaterialTheme.typography.titleMedium)
                        }
                        items(incomingRequests, key = { "req_${it.id}" }) { req ->
                            val sender = profilesByUid[req.fromUid]
                            val senderName = SecurityUtils.resolveDisplayName(sender?.fullName)
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(senderName, fontWeight = FontWeight.Bold)
                                        Text(
                                            listOfNotNull(
                                                sender?.schoolCollege?.takeIf { it.isNotBlank() },
                                                sender?.hometown?.takeIf { it.isNotBlank() }
                                            ).joinToString(" • "),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Button(onClick = { viewModel.acceptFriendRequest(req, req.fromUid) }) {
                                            Icon(Icons.Filled.Check, null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(tr("Accept", "स्वीकार", lang))
                                        }
                                        TextButton(onClick = { viewModel.unfriend(req.id) }) {
                                            Text(tr("Ignore", "हटाएं", lang))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Text(
                            text = tr("People You May Know • जिन्हें आप जानते होंगे", "जिन्हें आप जानते होंगे", lang),
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    if (suggestions.isEmpty()) {
                        item {
                            Text(
                                text = tr("Complete your City, Hometown, and School/College in Profile for smart matches!", "स्मार्ट सुझावों के लिए प्रोफ़ाइल में अपना शहर, गृहनगर और स्कूल/कॉलेज भरें!", lang),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        items(suggestions, key = { "sug_${it.profile.uid}" }) { sug ->
                            val reasons = if (lang == AppLang.HI) sug.matchReasonsHi else sug.matchReasonsEn
                            val isPending = sug.profile.uid in pendingOutgoingUids
                            PersonCard(
                                profile = sug.profile,
                                subtitle = reasons.firstOrNull()
                                    ?: listOfNotNull(
                                        sug.profile.currentCity?.takeIf { it.isNotBlank() },
                                        sug.profile.hometown?.takeIf { it.isNotBlank() }
                                    ).joinToString(" • "),
                                isFriend = false,
                                isPending = isPending,
                                lang = lang,
                                onView = { inspectProfile = sug.profile },
                                onAddOrChat = { viewModel.sendFriendRequest(sug.profile.uid) }
                            )
                        }
                    }

                    if (acceptedLinks.isNotEmpty()) {
                        item {
                            Text(tr("My Friends", "मेरे मित्र", lang), style = MaterialTheme.typography.titleMedium)
                        }
                        items(acceptedLinks, key = { "fr_${it.id}" }) { link ->
                            val otherUid = link.participantUids.firstOrNull { it != viewModel.currentUserId } ?: ""
                            val friend = profilesByUid[otherUid]
                            if (friend != null) {
                                val friendDisplayName = SecurityUtils.resolveDisplayName(friend.fullName)
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    Row(
                                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f).clickable { inspectProfile = friend }) {
                                            Text(friendDisplayName, fontWeight = FontWeight.Bold)
                                            Text(friend.currentCity?.takeIf { it.isNotBlank() } ?: "Friend", style = MaterialTheme.typography.labelSmall)
                                        }
                                        Row {
                                            IconButton(onClick = { activeChatPeer = friend }) {
                                                Icon(Icons.Filled.Chat, contentDescription = "Message Friend")
                                            }
                                            IconButton(onClick = { viewModel.unfriend(link.id) }) {
                                                Text(tr("Unfriend", "हटाएं", lang), style = MaterialTheme.typography.labelSmall)
                                            }
                                            IconButton(onClick = { viewModel.blockUser(friend.uid) }) {
                                                Icon(Icons.Filled.Block, contentDescription = "Block User", tint = MaterialTheme.colorScheme.error)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // MESSENGER THREADS (Accepted Friends)
                val friends = acceptedLinks.mapNotNull { link ->
                    val otherUid = link.participantUids.firstOrNull { it != viewModel.currentUserId }
                    profilesByUid[otherUid]
                }
                if (friends.isEmpty()) {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.Chat, null, modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(8.dp))
                            Text(tr("Accept or add friends to start private 1-on-1 chat & voice notes!", "निजी चैट और वॉइस नोट्स शुरू करने के लिए मित्र जोड़ें!", lang))
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(friends, key = { "chat_${it.uid}" }) { friend ->
                            val friendDisplayName = SecurityUtils.resolveDisplayName(friend.fullName)
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { activeChatPeer = friend }
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(friendDisplayName, style = MaterialTheme.typography.titleMedium)
                                        Text(tr("Tap to open private chat & voice notes", "चैट और वॉइस नोट खोलें", lang), style = MaterialTheme.typography.labelSmall)
                                    }
                                    Icon(Icons.Filled.Chat, null, tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // COMMUNITY GROUPS & PUBLIC PAGES
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(tr("Community Groups", "समुदाय समूह", lang), style = MaterialTheme.typography.titleLarge)
                            OutlinedButton(onClick = { showCreateGroupDialog = true }) {
                                Icon(Icons.Filled.Add, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(tr("New Group", "नया समूह", lang))
                            }
                        }
                    }
                    items(groups, key = { "grp_${it.id}" }) { group ->
                        val isMember = viewModel.currentUserId in group.memberUids
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(14.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Filled.Groups, null, tint = MaterialTheme.colorScheme.primary)
                                        Text(group.name, style = MaterialTheme.typography.titleMedium)
                                    }
                                    Text(group.description, style = MaterialTheme.typography.bodyMedium)
                                    Text("${group.category} • ${group.memberCount} members", style = MaterialTheme.typography.labelSmall)
                                }
                                Button(onClick = { viewModel.toggleJoinGroup(group) }) {
                                    Text(if (isMember) tr("Joined", "जुड़े हैं", lang) else tr("Join", "जुड़ें", lang))
                                }
                            }
                        }
                    }

                    item {
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(tr("Public Pages (Shops & News)", "पब्लिक पेज (दुकान व न्यूज़)", lang), style = MaterialTheme.typography.titleLarge)
                            OutlinedButton(onClick = { showCreatePageDialog = true }) {
                                Icon(Icons.Filled.Add, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(tr("New Page", "नया पेज", lang))
                            }
                        }
                    }
                    items(pages, key = { "pg_${it.id}" }) { page ->
                        val isFollowing = viewModel.currentUserId in page.followerUids
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(14.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Filled.Storefront, null, tint = MaterialTheme.colorScheme.secondary)
                                        Text(page.name, style = MaterialTheme.typography.titleMedium)
                                    }
                                    Text(page.description, style = MaterialTheme.typography.bodyMedium)
                                    Text("${page.category} • ${page.followerCount} followers", style = MaterialTheme.typography.labelSmall)
                                }
                                Button(onClick = { viewModel.toggleFollowPage(page) }) {
                                    Text(if (isFollowing) tr("Following", "फ़ॉलो किया", lang) else tr("Follow", "फ़ॉलो", lang))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Inspect Profile Dialog (Respects Profile Lock)
    inspectProfile?.let { rawPerson ->
        val person = profilesByUid[rawPerson.uid] ?: rawPerson
        val personDisplayName = SecurityUtils.resolveDisplayName(person.fullName)
        val isFriend = person.uid in friendUids || person.uid == viewModel.currentUserId
        val showDetails = !person.isProfileLocked || isFriend
        AlertDialog(
            onDismissRequest = { inspectProfile = null },
            title = { Text(personDisplayName) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!showDetails) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.Lock, null, tint = MaterialTheme.colorScheme.primary)
                            Text(tr("This profile is locked. Personal photos & details are visible only to accepted friends.", "यह प्रोफ़ाइल लॉक है। व्यक्तिगत विवरण केवल मित्रों को दिखाई देते हैं।", lang))
                        }
                    } else {
                        if (!person.avatarUri.isNullOrBlank()) {
                            AsyncImage(
                                model = person.avatarUri,
                                contentDescription = person.fullName,
                                modifier = Modifier.size(90.dp).clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        }
                        if (!person.bio.isNullOrBlank()) Text(person.bio)
                        if (!person.currentCity.isNullOrBlank()) Text("City: ${person.currentCity}")
                        if (!person.hometown.isNullOrBlank()) Text("Hometown: ${person.hometown}")
                        if (!person.schoolCollege.isNullOrBlank()) Text("School/College: ${person.schoolCollege}")
                        if (!person.workplace.isNullOrBlank()) Text("Workplace: ${person.workplace}")
                    }
                }
            },
            confirmButton = {
                if (!isFriend) {
                    Button(onClick = {
                        viewModel.sendFriendRequest(person.uid)
                        inspectProfile = null
                    }) { Text(tr("Add Friend", "मित्र बनाएं", lang)) }
                } else {
                    TextButton(onClick = { inspectProfile = null }) { Text(tr("Close", "बंद करें", lang)) }
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    viewModel.blockUser(person.uid)
                    inspectProfile = null
                }) { Text(tr("Block", "ब्लॉक", lang), color = MaterialTheme.colorScheme.error) }
            }
        )
    }

    if (showCreateGroupDialog) {
        var name by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var city by remember { mutableStateOf("") }
        var cat by remember { mutableStateOf("Local Community") }
        AlertDialog(
            onDismissRequest = { showCreateGroupDialog = false },
            title = { Text(tr("Create Community Group", "नया समुदाय समूह", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Group Name *") })
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") })
                    OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("City / Town") })
                    OutlinedTextField(value = cat, onValueChange = { cat = it }, label = { Text("Category") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.createGroup(name, desc, city, cat)
                    showCreateGroupDialog = false
                }) { Text(tr("Create", "बनाएं", lang)) }
            },
            dismissButton = { TextButton(onClick = { showCreateGroupDialog = false }) { Text(tr("Cancel", "रद्द", lang)) } }
        )
    }

    if (showCreatePageDialog) {
        var name by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var city by remember { mutableStateOf("") }
        var cat by remember { mutableStateOf("Local Business / News") }
        AlertDialog(
            onDismissRequest = { showCreatePageDialog = false },
            title = { Text(tr("Create Public Page", "नया पब्लिक पेज", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Page Name *") })
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") })
                    OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("City") })
                    OutlinedTextField(value = cat, onValueChange = { cat = it }, label = { Text("Category") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.createPage(name, desc, cat, city)
                    showCreatePageDialog = false
                }) { Text(tr("Create", "बनाएं", lang)) }
            },
            dismissButton = { TextButton(onClick = { showCreatePageDialog = false }) { Text(tr("Cancel", "रद्द", lang)) } }
        )
    }
}

@Composable
private fun PersonCard(
    profile: PublicProfile,
    subtitle: String,
    isFriend: Boolean,
    isPending: Boolean = false,
    lang: AppLang,
    onView: () -> Unit,
    onAddOrChat: () -> Unit
) {
    val displayName = SecurityUtils.resolveDisplayName(profile.fullName)
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onView)
    ) {
        Row(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    if (!profile.avatarUri.isNullOrBlank()) {
                        AsyncImage(
                            model = profile.avatarUri,
                            contentDescription = displayName,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Text(displayName.take(2).uppercase(), fontWeight = FontWeight.Bold)
                    }
                }
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(displayName, style = MaterialTheme.typography.titleMedium)
                        if (profile.isProfileLocked) {
                            Icon(Icons.Filled.Lock, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (subtitle.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.School, null, modifier = Modifier.size(13.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(4.dp))
                            Text(subtitle, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            Button(
                onClick = onAddOrChat,
                enabled = isFriend || !isPending,
                modifier = Modifier.testTag("add_friend_button_${profile.uid}")
            ) {
                Icon(
                    if (isFriend) Icons.Filled.Chat else if (isPending) Icons.Filled.Check else Icons.Filled.PersonAdd,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    when {
                        isFriend -> tr("Chat", "चैट", lang)
                        isPending -> tr("Pending", "प्रतीक्षारत", lang)
                        else -> tr("Add Friend", "मित्र जोड़ें", lang)
                    }
                )
            }
        }
    }
}

@Composable
private fun FriendChatView(
    peer: PublicProfile,
    profilesByUid: Map<String, PublicProfile>,
    viewModel: MainAppViewModel,
    lang: AppLang,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val currentPeer = profilesByUid[peer.uid] ?: peer
    val peerDisplayName = SecurityUtils.resolveDisplayName(currentPeer.fullName)
    val messages by viewModel.observeChatMessages(currentPeer.uid).collectAsStateWithLifecycle(emptyList())
    val allowFriendChat by viewModel.allowFriendChat.collectAsStateWithLifecycle()
    var msgText by remember { mutableStateOf("") }
    var isRecording by remember { mutableStateOf(false) }
    var playingMsgId by remember { mutableStateOf<String?>(null) }
    var showBlockDialog by remember { mutableStateOf(false) }
    var showReportDialog by remember { mutableStateOf(false) }
    var reportReason by remember { mutableStateOf("") }

    val voiceHelper = remember(context) { VoiceNoteHelper(context) }

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { picked ->
            com.dilsuno.app.core.MediaUploadValidator.validatePickedMedia(
                context = context,
                uri = picked,
                allowVideo = true,
                lang = lang
            ).onSuccess { validated ->
                val msgType = if (validated.isVideo) "video" else "image"
                viewModel.sendChatMessage(currentPeer.uid, msgType, "", mediaUri = validated.uriString)
            }.onFailure { err ->
                viewModel.reportSecurityError(err.localizedMessage ?: "Blocked unsafe chat attachment.")
            }
        }
    }

    val audioPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            isRecording = voiceHelper.startRecording()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            voiceHelper.stopRecording()
            voiceHelper.stopPlayback()
        }
    }

    Column(
        modifier = Modifier
            .widthIn(max = 640.dp)
            .fillMaxSize()
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(peerDisplayName, style = MaterialTheme.typography.titleLarge)
                Text(tr("Private Messenger (Free Chat & Voice Notes)", "निजी चैट और वॉइस नोट्स", lang), style = MaterialTheme.typography.labelSmall)
            }
            IconButton(
                onClick = { showReportDialog = true },
                modifier = Modifier.testTag("chat_report_content_button")
            ) {
                Icon(Icons.Filled.Flag, contentDescription = "Report Content", tint = MaterialTheme.colorScheme.secondary)
            }
            IconButton(
                onClick = { showBlockDialog = true },
                modifier = Modifier.testTag("chat_block_user_button")
            ) {
                Icon(Icons.Filled.Block, contentDescription = "Block User", tint = MaterialTheme.colorScheme.error)
            }
        }

        if (showBlockDialog) {
            AlertDialog(
                onDismissRequest = { showBlockDialog = false },
                title = { Text(tr("Block User?", "यूज़र को ब्लॉक करें?", lang)) },
                text = {
                    Text(
                        tr(
                            "Block $peerDisplayName? They will no longer be able to message you or appear in your friend circle.",
                            "$peerDisplayName को ब्लॉक करें? वे आपको आगे संदेश नहीं भेज पाएंगे।",
                            lang
                        )
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        viewModel.blockUser(currentPeer.uid)
                        showBlockDialog = false
                        onBack()
                    }) {
                        Text(tr("Block User", "ब्लॉक करें", lang))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showBlockDialog = false }) {
                        Text(tr("Cancel", "रद्द करें", lang))
                    }
                }
            )
        }

        if (showReportDialog) {
            AlertDialog(
                onDismissRequest = { showReportDialog = false },
                title = { Text(tr("Report Content", "सामग्री की रिपोर्ट करें", lang)) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            tr(
                                "Report inappropriate messages or behaviour from $peerDisplayName. Our moderation team reviews all reports immediately.",
                                "$peerDisplayName द्वारा अनुचित संदेश या व्यवहार की रिपोर्ट करें।",
                                lang
                            )
                        )
                        OutlinedTextField(
                            value = reportReason,
                            onValueChange = { reportReason = it },
                            label = { Text(tr("Reason (Harassment / Spam / Abuse)", "कारण (उत्पीड़न / स्पैम / दुर्व्यवहार)", lang)) },
                            modifier = Modifier.fillMaxWidth().testTag("chat_report_reason_input")
                        )
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val reason = reportReason.trim().ifBlank { "Inappropriate chat content / harassment" }
                        viewModel.submitReport(
                            targetType = "chat_user",
                            targetId = currentPeer.uid,
                            targetAuthorUid = currentPeer.uid,
                            reportType = "harassment",
                            reason = reason,
                            targetAuthorName = peerDisplayName,
                            targetCaption = messages.lastOrNull()?.text?.take(120) ?: "Direct chat with $peerDisplayName"
                        )
                        reportReason = ""
                        showReportDialog = false
                    }) {
                        Text(tr("Submit Report", "रिपोर्ट भेजें", lang))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showReportDialog = false }) {
                        Text(tr("Cancel", "रद्द करें", lang))
                    }
                }
            )
        }

        if (!allowFriendChat) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = tr("Chatting permission is OFF (चैटिंग की अनुमति बंद है)", "चैटिंग की अनुमति बंद है", lang),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { viewModel.setAllowFriendChat(true) }) {
                        Text(tr("Turn ON", "चालू करें", lang), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages, key = { it.id }) { m ->
                val isMine = m.senderUid == viewModel.currentUserId
                val senderDisplayName = SecurityUtils.resolveDisplayName(profilesByUid[m.senderUid]?.fullName, m.senderName)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        color = if (isMine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp).widthIn(max = 270.dp)) {
                            if (!isMine) {
                                Text(
                                    text = senderDisplayName,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            when (m.messageType) {
                                "voice_note" -> {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = {
                                                if (playingMsgId == m.id) {
                                                    voiceHelper.stopPlayback()
                                                    playingMsgId = null
                                                } else if (!m.mediaUri.isNullOrBlank()) {
                                                    playingMsgId = m.id
                                                    voiceHelper.playVoiceNote(m.mediaUri) { playingMsgId = null }
                                                }
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                if (playingMsgId == m.id) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                                                contentDescription = "Play voice note",
                                                tint = if (isMine) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Text(
                                            "Voice Note (${m.voiceDurationSec ?: 1}s)",
                                            color = if (isMine) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                "image", "video" -> {
                                    if (!m.mediaUri.isNullOrBlank()) {
                                        AsyncImage(
                                            model = m.mediaUri,
                                            contentDescription = "Chat media",
                                            modifier = Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(10.dp)),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                    if (m.text.isNotBlank()) {
                                        Text(m.text, color = if (isMine) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                else -> {
                                    Text(m.text, color = if (isMine) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            IconButton(
                onClick = {
                    mediaPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                },
                enabled = allowFriendChat
            ) {
                Icon(Icons.Filled.PhotoLibrary, contentDescription = "Attach Photo or Video")
            }
            IconButton(
                onClick = {
                    if (isRecording) {
                        isRecording = false
                        val rec = voiceHelper.stopRecording()
                        if (rec != null) {
                            viewModel.sendChatMessage(peer.uid, "voice_note", "Voice Note", mediaUri = rec.first, voiceDurationSec = rec.second)
                        }
                    } else {
                        audioPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                enabled = allowFriendChat
            ) {
                Icon(
                    if (isRecording) Icons.Filled.Stop else Icons.Filled.Mic,
                    contentDescription = if (isRecording) "Stop Recording" else "Record Voice Note",
                    tint = if (isRecording) Color.Red else MaterialTheme.colorScheme.primary
                )
            }
            OutlinedTextField(
                value = msgText,
                onValueChange = { msgText = it },
                enabled = allowFriendChat,
                label = { Text(tr("Message...", "संदेश...", lang)) },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            IconButton(
                onClick = {
                    if (msgText.isNotBlank()) {
                        val txt = msgText
                        msgText = ""
                        viewModel.sendChatMessage(peer.uid, "text", txt)
                    }
                },
                enabled = allowFriendChat && msgText.isNotBlank()
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Send")
            }
        }
    }
}

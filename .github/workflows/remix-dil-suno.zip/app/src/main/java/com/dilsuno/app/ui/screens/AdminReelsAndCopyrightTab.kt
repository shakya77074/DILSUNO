package com.dilsuno.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Copyright
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.AiSafetyLog
import com.dilsuno.app.data.model.CommentItem
import com.dilsuno.app.data.model.LiveStreamItem
import com.dilsuno.app.data.model.ModerationReport
import com.dilsuno.app.data.model.PostItem
import com.dilsuno.app.data.model.PublicProfile
import com.dilsuno.app.data.model.StoryItem
import com.dilsuno.app.ui.components.LiveModerationFeedPanel
import com.dilsuno.app.ui.components.ModerationQueuePanel
import com.dilsuno.app.ui.theme.HairlineDividerBlue
import com.dilsuno.app.ui.theme.RoyalBlueDeep
import com.dilsuno.app.ui.theme.RoyalBluePrimary
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.SlateDarkText
import com.dilsuno.app.ui.theme.SlateSubtleText
import com.dilsuno.app.ui.theme.SoftCardSurface
import com.dilsuno.app.viewmodel.StaffAndAdminViewModel
import kotlinx.coroutines.flow.Flow

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminReelsAndCopyrightTab(
    viewModel: StaffAndAdminViewModel,
    lang: AppLang,
    allReports: List<ModerationReport>,
    allPosts: List<PostItem>,
    allStories: List<StoryItem>,
    allLiveStreams: List<LiveStreamItem>,
    profilesByUid: Map<String, PublicProfile>,
    observePostComments: (String) -> Flow<List<CommentItem>>,
    observeLiveComments: (String) -> Flow<List<CommentItem>>,
    allAiLogs: List<AiSafetyLog>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // LIVE MODERATION QUEUE (Reported Content)
        item {
            ModerationQueuePanel(
                reports = allReports,
                lang = lang,
                onApproveIgnore = { report -> viewModel.resolveModerationQueueAction(report, "approve_ignore") },
                onDeleteAndWarn = { report -> viewModel.resolveModerationQueueAction(report, "delete_warn") },
                onDeleteAndPermanentBan = { report -> viewModel.resolveModerationQueueAction(report, "delete_ban") }
            )
        }

        // REELS & POSTS COPYRIGHT CLAIM MANAGER
        item {
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.Copyright, contentDescription = null, tint = Color(0xFFB91C1C))
                Text(
                    text = tr("Reels & Posts Copyright Manager (${allPosts.size})", "रील व पोस्ट कॉपीराइट मैनेजर (${allPosts.size})", lang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SlateDarkText
                )
            }
        }
        items(allPosts.take(25), key = { "copy_${it.id}" }) { post ->
            Card(
                colors = CardDefaults.cardColors(containerColor = if (post.copyrightClaimActive) Color(0xFFFEF2F2) else SoftCardSurface),
                border = BorderStroke(1.dp, if (post.copyrightClaimActive) Color(0xFFDC2626).copy(alpha = 0.5f) else HairlineDividerBlue),
                modifier = Modifier.fillMaxWidth().testTag("admin_copyright_post_${post.id}")
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${post.authorName} • ${post.postType.uppercase()}",
                            fontWeight = FontWeight.Bold,
                            color = SlateDarkText,
                            modifier = Modifier.weight(1f)
                        )
                        if (post.copyrightClaimActive) {
                            Surface(color = Color(0xFFB91C1C), shape = RoundedCornerShape(6.dp)) {
                                Text("COPYRIGHT CLAIM", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        } else if (post.audioMutedForClaim) {
                            Surface(color = SafeEmerald, shape = RoundedCornerShape(6.dp)) {
                                Text("AUDIO MUTED ✓", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                    }
                    Text(post.caption, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = SlateSubtleText)
                    if (!post.musicTrack.isNullOrBlank()) {
                        Text("♪ Track: ${post.musicTrack}", style = MaterialTheme.typography.labelSmall, color = RoyalBlueDeep)
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (post.copyrightClaimActive) {
                                    viewModel.markPostCopyrightClaim(post.id, active = false)
                                } else {
                                    viewModel.markPostCopyrightClaim(
                                        post.id,
                                        active = true,
                                        reason = "Third-party audio copyright claim"
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (post.copyrightClaimActive) SafeEmerald else Color(0xFFB91C1C),
                                contentColor = Color.White
                            ),
                            modifier = Modifier.heightIn(min = 48.dp).testTag("admin_toggle_copyright_${post.id}")
                        ) {
                            Text(
                                text = if (post.copyrightClaimActive) tr("Clear Claim", "क्लेम हटाएं", lang)
                                else tr("Mark Copyright Claim", "कॉपीराइट क्लेम लगाएं", lang),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        OutlinedButton(
                            onClick = { viewModel.removeContent("post", post.id, null) },
                            border = BorderStroke(1.dp, Color(0xFFB91C1C)),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Filled.Delete, contentDescription = null, tint = Color(0xFFB91C1C), modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(tr("Delete Post", "हटाएं", lang), color = Color(0xFFB91C1C), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // LIVE SOCIAL FEED & REELS MONITOR
        item {
            LiveModerationFeedPanel(
                posts = allPosts,
                stories = allStories,
                liveStreams = allLiveStreams,
                profilesByUid = profilesByUid,
                observePostComments = observePostComments,
                observeLiveComments = observeLiveComments,
                onDeleteWithWarn = { targetType, targetId, parentPostId, targetAuthorUid, targetAuthorName, contentPreview, reason ->
                    viewModel.deleteContentAsModerator(
                        targetType = targetType,
                        targetId = targetId,
                        parentPostId = parentPostId,
                        targetAuthorUid = targetAuthorUid,
                        targetAuthorName = targetAuthorName,
                        contentPreview = contentPreview,
                        reason = reason
                    )
                },
                lang = lang
            )
        }

        // GEMINI AI LEGAL AUTO-DELETE LOGS
        item {
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Filled.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Text(
                    text = tr("Gemini AI Legal Auto-Delete Logs (${allAiLogs.size})", "AI कानूनी सुरक्षा लॉग (${allAiLogs.size})", lang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        items(allAiLogs, key = { it.id }) { log ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.55f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${log.userName} • ${log.violationCategory} (${log.actionTaken})", fontWeight = FontWeight.Bold)
                    Text(log.aiReason, style = MaterialTheme.typography.bodySmall)
                    if (!log.snippet.isNullOrBlank()) {
                        Text("Snippet: \"${log.snippet}\"", style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = { viewModel.setUserBanned(log.userUid, true) }) {
                        Text(tr("Ensure Permanent Ban", "स्थायी बैन सुनिश्चित करें", lang))
                    }
                }
            }
        }
    }
}

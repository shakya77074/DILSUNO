package com.dilsuno.app.ui.screens

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.EmergencyNotificationHelper
import com.dilsuno.app.core.IncomingCallRingtoneEffect
import com.dilsuno.app.core.LiveWebRtcAudioBridge
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.DilSeCallSession
import com.dilsuno.app.ui.components.SuperAdminLiveEmergencyBanner
import com.dilsuno.app.ui.theme.PureWhiteBackground
import com.dilsuno.app.ui.theme.RoyalBlueDeep
import com.dilsuno.app.ui.theme.RoyalBluePrimary
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.SlateSubtleText
import com.dilsuno.app.viewmodel.StaffAndAdminViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SuperAdminScreen(
    adminEmail: String,
    viewModel: StaffAndAdminViewModel,
    lang: AppLang,
    onPreviewUserFeed: () -> Unit = {},
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val allStaff by viewModel.allStaff.collectAsStateWithLifecycle()
    val allActiveCalls by viewModel.allActiveCalls.collectAsStateWithLifecycle()
    val allAuditLogs by viewModel.allAuditLogs.collectAsStateWithLifecycle()
    val waitingCalls by viewModel.waitingCalls.collectAsStateWithLifecycle()
    val activeAdminCall by viewModel.activeAdminCall.collectAsStateWithLifecycle()
    val allProfiles by viewModel.allProfiles.collectAsStateWithLifecycle()
    val profilesByUid = remember(allProfiles) { allProfiles.associateBy { it.uid } }
    val allPosts by viewModel.allPosts.collectAsStateWithLifecycle()
    val allStories by viewModel.allStories.collectAsStateWithLifecycle()
    val allLiveStreams by viewModel.allLiveStreams.collectAsStateWithLifecycle()
    val allReports by viewModel.allReports.collectAsStateWithLifecycle()
    val allAiLogs by viewModel.allAiLogs.collectAsStateWithLifecycle()
    val allPayouts by viewModel.allPayouts.collectAsStateWithLifecycle()
    val allStaffRatings by viewModel.allStaffRatings.collectAsStateWithLifecycle()
    val allSupportTickets by viewModel.allSupportTickets.collectAsStateWithLifecycle()
    val allPlayBillingPurchases by viewModel.allPlayBillingPurchases.collectAsStateWithLifecycle()
    val listenerApplications by viewModel.listenerApplications.collectAsStateWithLifecycle()
    val appConfig by viewModel.appConfig.collectAsStateWithLifecycle()
    val feedback by viewModel.feedback.collectAsStateWithLifecycle()
    val activeEmergencyCalls by viewModel.activeEmergencyCalls.collectAsStateWithLifecycle()
    val emergencyLegalLogs by viewModel.emergencyLegalLogs.collectAsStateWithLifecycle()
    val contactLeakAlerts by viewModel.contactLeakAlerts.collectAsStateWithLifecycle()
    val allListenerPromoVideos by viewModel.allListenerPromoVideos.collectAsStateWithLifecycle()
    val reviewerDemoEnabled by viewModel.reviewerDemoEnabled.collectAsStateWithLifecycle()
    val allCallsHistory by viewModel.allCallsHistory.collectAsStateWithLifecycle()
    val adminCustomMusicTracks by viewModel.adminCustomMusicTracks.collectAsStateWithLifecycle()

    val pendingPayouts = remember(allPayouts) {
        allPayouts.filter { it.status == "pending" || it.status == "approved" }
    }
    val notifiedEmergencyIds = remember { mutableStateListOf<String>() }
    val notifiedModerationReportIds = remember { mutableStateListOf<String>() }

    LaunchedEffect(activeEmergencyCalls) {
        activeEmergencyCalls.forEach { emergencyCall ->
            if (emergencyCall.id !in notifiedEmergencyIds) {
                notifiedEmergencyIds.add(emergencyCall.id)
                EmergencyNotificationHelper.showSuperAdminEmergencyNotification(
                    context = context,
                    callId = emergencyCall.id,
                    listenerName = emergencyCall.listenerStaffId ?: "Listener"
                )
            }
        }
    }

    LaunchedEffect(allReports) {
        allReports.filter { it.status == "open" }.forEach { report ->
            if (report.id !in notifiedModerationReportIds) {
                notifiedModerationReportIds.add(report.id)
                EmergencyNotificationHelper.showModerationReportNotification(
                    context = context,
                    reportId = report.id,
                    reason = report.reason,
                    targetType = report.targetType
                )
            }
        }
    }

    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    if (selectedTab != 0) {
        BackHandler { selectedTab = 0 }
    }

    val tabs = listOf(
        tr("Users & Staff", "यूज़र्स व स्टाफ", lang),
        tr("Reels & Copyright", "रील व कॉपीराइट", lang),
        tr("Music & Notices", "म्यूज़िक व नोटिस", lang),
        tr("Billing & Calls", "बिलिंग व कॉल", lang)
    )

    var adminCallMuted by remember { mutableStateOf(false) }
    var adminCallSpeaker by remember { mutableStateOf(true) }
    var ownerCallSeconds by remember { mutableLongStateOf(0L) }
    var confirmAdminAbuseBlock by remember { mutableStateOf(false) }
    var pendingAdminCallToAccept by remember { mutableStateOf<DilSeCallSession?>(null) }
    var resetPinTargetStaff by remember { mutableStateOf<String?>(null) }

    var liveEpochSec by remember { mutableLongStateOf(System.currentTimeMillis() / 1000L) }
    LaunchedEffect(allActiveCalls.isNotEmpty()) {
        while (allActiveCalls.isNotEmpty()) {
            liveEpochSec = System.currentTimeMillis() / 1000L
            delay(1000L)
        }
    }

    LaunchedEffect(activeAdminCall?.id, activeAdminCall?.status) {
        if (activeAdminCall?.status == "active") {
            ownerCallSeconds = 0L
            while (activeAdminCall?.status == "active") {
                delay(1000L)
                ownerCallSeconds++
            }
        }
    }

    val adminMicLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        pendingAdminCallToAccept?.let { call ->
            pendingAdminCallToAccept = null
            viewModel.acceptCallAsAdmin(call)
        }
    }

    IncomingCallRingtoneEffect(isRinging = activeEmergencyCalls.isNotEmpty())

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhiteBackground)
            .systemBarsPadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(modifier = Modifier.widthIn(max = 720.dp).fillMaxSize()) {
            // Super Admin Blue Header (Clean, no permanent backup mode switch)
            Card(
                shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
                colors = CardDefaults.cardColors(containerColor = RoyalBlueDeep),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier.size(44.dp).clip(CircleShape).background(RoyalBluePrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.AdminPanelSettings, contentDescription = "Super Admin", tint = Color.White)
                            }
                            Column {
                                Text(
                                    text = tr("Super Admin Control Center", "सुपर एडमिन कंट्रोल सेंटर", lang),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(adminEmail, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
                            }
                        }
                        IconButton(onClick = onLogout, modifier = Modifier.size(48.dp).testTag("admin_logout_button")) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = tr("Sign Out", "लॉगआउट", lang), tint = Color.White)
                        }
                    }

                    FlowRow(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { selectedTab = 3 },
                            colors = ButtonDefaults.buttonColors(containerColor = PureWhiteBackground, contentColor = RoyalBlueDeep),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                            modifier = Modifier.heightIn(min = 48.dp).testTag("admin_header_calling_button")
                        ) {
                            Icon(Icons.Filled.Call, contentDescription = null, tint = RoyalBlueDeep, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(tr("Billing & Calls (${allActiveCalls.size})", "बिलिंग व कॉल (${allActiveCalls.size})", lang), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = RoyalBlueDeep)
                        }
                        OutlinedButton(
                            onClick = onPreviewUserFeed,
                            border = BorderStroke(1.2.dp, Color.White.copy(alpha = 0.8f)),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = RoyalBluePrimary.copy(alpha = 0.4f), contentColor = Color.White),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                            modifier = Modifier.heightIn(min = 48.dp).testTag("admin_preview_user_feed_button")
                        ) {
                            Icon(Icons.Filled.Visibility, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(tr("View User Feed", "ऐप का चेहरा देखें", lang), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(color = Color.White.copy(alpha = 0.16f), shape = RoundedCornerShape(10.dp)) {
                            Text("Staff: ${allStaff.size}", color = Color.White, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
                        }
                        Surface(color = Color.White.copy(alpha = 0.16f), shape = RoundedCornerShape(10.dp)) {
                            Text("Payouts: ${pendingPayouts.size}", color = if (pendingPayouts.isNotEmpty()) Color(0xFFFDE047) else Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
                        }
                        Surface(color = Color.White.copy(alpha = 0.16f), shape = RoundedCornerShape(10.dp)) {
                            Text("Waiting: ${waitingCalls.size}", color = if (waitingCalls.isNotEmpty()) Color(0xFFFDE047) else Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
                        }
                        Surface(color = Color.White.copy(alpha = 0.16f), shape = RoundedCornerShape(10.dp)) {
                            Text("Live Calls: ${allActiveCalls.size}", color = if (allActiveCalls.isNotEmpty()) Color(0xFF99F6E4) else Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            if (!feedback.isNullOrBlank()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Row(modifier = Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(feedback!!, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        TextButton(onClick = { viewModel.clearFeedback() }) { Text("OK") }
                    }
                }
            }

            // ONLY dynamic Emergency Alert Card (hidden completely unless triggered)
            if (activeEmergencyCalls.isNotEmpty()) {
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    SuperAdminLiveEmergencyBanner(
                        activeEmergencyCalls = activeEmergencyCalls,
                        adminUid = "owner_supervisor",
                        lang = lang,
                        onJoinEmergencyCall = { call -> viewModel.markAdminJoinedEmergencyCall(call) },
                        onDismissEmergencyAlert = { call -> viewModel.dismissEmergencyAlert(call) }
                    )
                }
            }

            // Active Admin Call Bridge (shown ONLY while Admin is in an active call)
            val currentAdminCall = activeAdminCall
            if (currentAdminCall != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Filled.HeadsetMic, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Text(tr("Owner Live Call • ${ownerCallSeconds}s", "ओनर लाइव कॉल • ${ownerCallSeconds}s", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            Surface(color = SafeEmerald, shape = RoundedCornerShape(8.dp)) {
                                Text("100% Owner: ₹${currentAdminCall.feeInr}", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                            }
                        }
                        LiveWebRtcAudioBridge(
                            callId = currentAdminCall.id,
                            localRole = "listener",
                            isCallActive = currentAdminCall.status == "active",
                            isMuted = adminCallMuted,
                            isSpeaker = adminCallSpeaker,
                            agoraAppId = appConfig.agoraAppId,
                            signalsFlow = viewModel.observeWebRtcSignals(currentAdminCall.id),
                            onSendSignal = { sigType, payload -> viewModel.sendWebRtcSignal(currentAdminCall.id, "listener", sigType, payload) },
                            lang = lang
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = { adminCallMuted = !adminCallMuted }, border = BorderStroke(1.dp, RoyalBluePrimary), modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
                                Icon(if (adminCallMuted) Icons.Filled.MicOff else Icons.Filled.Mic, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(if (adminCallMuted) "Muted" else "Mic On", fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(onClick = { adminCallSpeaker = !adminCallSpeaker }, border = BorderStroke(1.dp, RoyalBluePrimary), modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
                                Icon(Icons.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(if (adminCallSpeaker) "Speaker" else "Earpiece", fontWeight = FontWeight.Bold)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(onClick = { viewModel.endAdminCallNormally(ownerCallSeconds) }, colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary, contentColor = Color.White), modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
                                Icon(Icons.Filled.CallEnd, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(tr("End Call", "कॉल समाप्त", lang), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Button(onClick = { confirmAdminAbuseBlock = true }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C), contentColor = Color.White), modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
                                Icon(Icons.Filled.Block, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(tr("Abuse & Block", "काटें व ब्लॉक", lang), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            PrimaryScrollableTabRow(selectedTabIndex = selectedTab, containerColor = PureWhiteBackground, contentColor = RoyalBluePrimary) {
                tabs.forEachIndexed { idx, title ->
                    Tab(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        selectedContentColor = RoyalBluePrimary,
                        unselectedContentColor = SlateSubtleText,
                        text = { Text(text = title, fontWeight = if (selectedTab == idx) FontWeight.Bold else FontWeight.Medium, maxLines = 1) },
                        modifier = Modifier.testTag("admin_tab_$idx")
                    )
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                when (selectedTab) {
                    0 -> AdminUsersAndStaffTab(
                        viewModel = viewModel,
                        lang = lang,
                        reviewerDemoEnabled = reviewerDemoEnabled,
                        listenerApplications = listenerApplications,
                        allStaff = allStaff,
                        allActiveCalls = allActiveCalls,
                        liveEpochSec = liveEpochSec,
                        allStaffRatings = allStaffRatings,
                        allAuditLogs = allAuditLogs,
                        allListenerPromoVideos = allListenerPromoVideos,
                        allProfiles = allProfiles,
                        onRequestResetPin = { resetPinTargetStaff = it }
                    )
                    1 -> AdminReelsAndCopyrightTab(
                        viewModel = viewModel,
                        lang = lang,
                        allReports = allReports,
                        allPosts = allPosts,
                        allStories = allStories,
                        allLiveStreams = allLiveStreams,
                        profilesByUid = profilesByUid,
                        observePostComments = viewModel::observeCommentsForPost,
                        observeLiveComments = viewModel::observeLiveComments,
                        allAiLogs = allAiLogs
                    )
                    2 -> AdminMusicAndNoticesTab(
                        viewModel = viewModel,
                        lang = lang,
                        appConfig = appConfig,
                        adminCustomMusicTracks = adminCustomMusicTracks,
                        allSupportTickets = allSupportTickets
                    )
                    else -> AdminBillingAndCallsTab(
                        viewModel = viewModel,
                        lang = lang,
                        allPlayBillingPurchases = allPlayBillingPurchases,
                        profilesByUid = profilesByUid,
                        allPayouts = allPayouts,
                        waitingCalls = waitingCalls,
                        allActiveCalls = allActiveCalls,
                        allCallsHistory = allCallsHistory,
                        liveEpochSec = liveEpochSec,
                        allStaff = allStaff,
                        contactLeakAlerts = contactLeakAlerts,
                        emergencyLegalLogs = emergencyLegalLogs,
                        onAcceptCallRequest = { call ->
                            pendingAdminCallToAccept = call
                            adminMicLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    )
                }
            }
        }
    }

    if (confirmAdminAbuseBlock) {
        AlertDialog(
            onDismissRequest = { confirmAdminAbuseBlock = false },
            icon = { Icon(Icons.Filled.Block, contentDescription = null, tint = Color(0xFFB91C1C)) },
            title = { Text(tr("Disconnect & Permanently Block?", "कॉल काटें और हमेशा के लिए ब्लॉक करें?", lang)) },
            text = { Text(tr("Immediately disconnects the call, forfeits ₹${activeAdminCall?.feeInr ?: 100} (No Refund), and permanently bans this caller.", "यह तुरंत कॉल काट देगा और कॉलर का अकाउंट हमेशा के लिए ब्लॉक हो जाएगा।", lang)) },
            confirmButton = {
                Button(
                    onClick = {
                        confirmAdminAbuseBlock = false
                        viewModel.adminAbuseDisconnectAndBlockCaller()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C)),
                    modifier = Modifier.testTag("admin_confirm_abuse_block_button")
                ) { Text(tr("Disconnect & Block Now", "अभी काटें और ब्लॉक करें", lang), color = Color.White) }
            },
            dismissButton = { TextButton(onClick = { confirmAdminAbuseBlock = false }) { Text(tr("Cancel", "रद्द करें", lang)) } }
        )
    }

    resetPinTargetStaff?.let { username ->
        var newPin by remember { mutableStateOf("") }
        var showResetStaffPin by remember { mutableStateOf(false) }
        val staffTarget = allStaff.firstOrNull { it.staffUsername == username }
        val targetLabel = staffTarget?.staffEmail?.takeIf { it.isNotBlank() } ?: "@$username"
        AlertDialog(
            onDismissRequest = { resetPinTargetStaff = null },
            title = { Text(tr("Reset Staff PIN ($targetLabel)", "$targetLabel का स्टाफ पिन बदलें", lang)) },
            text = {
                OutlinedTextField(
                    value = newPin,
                    onValueChange = { input -> newPin = input.filter { it.isDigit() }.take(16) },
                    label = { Text(tr("New Staff PIN (8–12 digits)", "नया स्टाफ पिन (8–12 अंक)", lang)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    trailingIcon = {
                        IconButton(onClick = { showResetStaffPin = !showResetStaffPin }, modifier = Modifier.testTag("toggle_admin_reset_staff_pin_visibility")) {
                            Icon(if (showResetStaffPin) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = if (showResetStaffPin) tr("Hide PIN", "पिन छिपाएं", lang) else tr("Show PIN", "पिन दिखाएं", lang))
                        }
                    },
                    visualTransformation = if (showResetStaffPin) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth().testTag("admin_reset_staff_pin_input"),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetStaffPin(username, newPin)
                        resetPinTargetStaff = null
                    },
                    enabled = newPin.length in 6..16
                ) { Text(tr("Update PIN", "पिन सेव करें", lang)) }
            },
            dismissButton = { TextButton(onClick = { resetPinTargetStaff = null }) { Text(tr("Cancel", "रद्द", lang)) } }
        )
    }
}

package com.dilsuno.app.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.MusicTrackOption
import com.dilsuno.app.core.RoyaltyFreeMusicLibrary
import com.dilsuno.app.core.VoiceNoteHelper
import com.dilsuno.app.core.tr
import com.dilsuno.app.ui.components.ReelMusicMixerPanel
import com.dilsuno.app.ui.theme.RoyalNavy
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.VelvetIndigo
import kotlin.math.roundToInt

data class VnStudioEditResult(
    val primaryMediaUri: String?,
    val pipMediaUri: String?,
    val selectedMusicTrackId: String,
    val selectedMusicTrackTitle: String?,
    val editorSummary: String,
    val extraLayerScanText: String
)

private data class StudioClip(
    val id: String,
    val label: String,
    val uri: String?,
    val trimStart: Float = 0f,
    val trimEnd: Float = 1f,
    val transition: String = "Fade",
    val cropZoom: Float = 1f
)

private data class StudioOverlayLayer(
    val id: String,
    val content: String,
    val isSticker: Boolean,
    val isSubtitle: Boolean = false,
    val fontChoice: String = "Sans",
    val colorHex: Color = Color.White,
    val hasBgBox: Boolean = true,
    val hasShadow: Boolean = true,
    val scale: Float = 1f,
    val offsetX: Float = 20f,
    val offsetY: Float = 20f
)

private data class LutPreset(
    val id: String,
    val label: String,
    val saturation: Float,
    val contrast: Float,
    val brightness: Float
)

@Composable
fun VnVideoEditorStudioDialog(
    initialMediaUri: String?,
    lang: AppLang,
    availableMusicTracks: List<MusicTrackOption> = RoyaltyFreeMusicLibrary.tracks,
    onDismiss: () -> Unit,
    onSecurityError: (String) -> Unit = {},
    onApplyEdit: (VnStudioEditResult) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val voiceHelper = remember(context) { VoiceNoteHelper(context) }

    // Clips Timeline State
    val clips = remember {
        mutableStateListOf(
            StudioClip(
                id = "clip_1",
                label = if (initialMediaUri != null) "Clip 1" else "Intro Canvas",
                uri = initialMediaUri
            )
        )
    }
    var selectedClipIdx by remember { mutableIntStateOf(0) }

    // Canvas Aspect Ratio
    var aspectRatioLabel by remember { mutableStateOf("9:16") }
    val previewAspect = when (aspectRatioLabel) {
        "16:9" -> 16f / 9f
        "1:1" -> 1f
        else -> 9f / 16f
    }

    // Speed & Curve
    var speedPreset by remember { mutableFloatStateOf(1.0f) }
    var curveStart by remember { mutableFloatStateOf(1.0f) }
    var curveMid by remember { mutableFloatStateOf(1.0f) }
    var curveEnd by remember { mutableFloatStateOf(1.0f) }

    // Color Grading & Filters (includes Original, Warm, Cool, Vintage, Cinematic, B&W)
    val lutPresets = remember {
        listOf(
            LutPreset("orig", "Original", 1f, 1f, 0f),
            LutPreset("warm", "Warm", 1.25f, 1.08f, 12f),
            LutPreset("cool", "Cool", 0.9f, 1.05f, 10f),
            LutPreset("vintage", "Vintage", 0.72f, 1.15f, -5f),
            LutPreset("cinema", "Cinematic", 1.12f, 1.25f, -6f),
            LutPreset("bw", "B&W", 0f, 1.28f, 4f),
            LutPreset("vivid", "Vivid", 1.45f, 1.18f, 8f),
            LutPreset("golden", "Golden Hour", 1.32f, 1.1f, 16f)
        )
    }
    var selectedLutId by remember { mutableStateOf("orig") }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var vignette by remember { mutableFloatStateOf(0.15f) }

    // Keyframe Motion, PIP & Chroma Key
    var keyframeAnim by remember { mutableStateOf("None") }
    var pipUri by remember { mutableStateOf<String?>(null) }
    var chromaKeyEnabled by remember { mutableStateOf(false) }
    var chromaIntensity by remember { mutableFloatStateOf(0.55f) }

    // Overlays: Text, Subtitles, Stickers/Emojis
    val overlays = remember { mutableStateListOf<StudioOverlayLayer>() }
    var newOverlayText by remember { mutableStateOf("") }
    var newOverlayIsSubtitle by remember { mutableStateOf(false) }
    var newOverlayFont by remember { mutableStateOf("Sans") }
    var newOverlayColor by remember { mutableStateOf(Color.White) }
    var newOverlayBgBox by remember { mutableStateOf(true) }
    var newOverlayShadow by remember { mutableStateOf(true) }
    var selectedStickerPack by remember { mutableStateOf("Happy") }

    // Audio, SFX & Voiceover
    var selectedTrackId by remember { mutableStateOf("none") }
    var customAudioUri by remember { mutableStateOf<String?>(null) }
    var customAudioLabel by remember { mutableStateOf<String?>(null) }
    var selectedSfxId by remember { mutableStateOf<String?>(null) }
    var isRecordingVoiceover by remember { mutableStateOf(false) }
    var voiceoverPath by remember { mutableStateOf<String?>(null) }
    var voiceoverSec by remember { mutableStateOf(0L) }
    var originalVol by remember { mutableFloatStateOf(0.85f) }
    var musicVol by remember { mutableFloatStateOf(0.75f) }
    var voiceoverVol by remember { mutableFloatStateOf(1.0f) }
    var fadeAudio by remember { mutableStateOf(true) }

    // Editor Bottom Tool Tab
    var activeToolTab by remember { mutableIntStateOf(0) } // 0=Timeline,1=Speed,2=Grade,3=FX/PIP,4=Text/Stickers,5=Audio

    val clipPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { picked ->
            com.dilsuno.app.core.MediaUploadValidator.validatePickedMedia(
                context = context,
                uri = picked,
                allowVideo = true,
                lang = lang
            ).onSuccess { validated ->
                val newIdx = clips.size + 1
                clips.add(StudioClip(id = "clip_${System.currentTimeMillis()}", label = "Clip $newIdx", uri = validated.uriString))
                selectedClipIdx = clips.lastIndex
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Blocked unsafe media file."
                onSecurityError(msg)
                android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    val pipPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { picked ->
            com.dilsuno.app.core.MediaUploadValidator.validatePickedMedia(
                context = context,
                uri = picked,
                allowVideo = true,
                lang = lang
            ).onSuccess { validated ->
                pipUri = validated.uriString
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Blocked unsafe PIP file."
                onSecurityError(msg)
                android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    val micPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            isRecordingVoiceover = voiceHelper.startRecording()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            RoyaltyFreeMusicLibrary.stopPreview()
            voiceHelper.stopRecording()
            voiceHelper.stopPlayback()
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "vn_keyframe")
    val animProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = (2600 / speedPreset.coerceAtLeast(0.3f)).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "vn_progress"
    )

    val activeClip = clips.getOrNull(selectedClipIdx.coerceIn(0, (clips.size - 1).coerceAtLeast(0)))

    // Compute live ColorMatrix for Preview
    val colorMatrix = remember(saturation, contrast, brightness, selectedLutId) {
        val satM = ColorMatrix().apply { setToSaturation(saturation) }
        val tintScale = if (selectedLutId == "warm" || selectedLutId == "golden") 1.08f else 1f
        val blueScale = if (selectedLutId == "cool") 1.12f else if (selectedLutId == "warm" || selectedLutId == "vintage") 0.88f else 1f
        val adjM = ColorMatrix(
            floatArrayOf(
                contrast * tintScale, 0f, 0f, 0f, brightness,
                0f, contrast, 0f, 0f, brightness,
                0f, 0f, contrast * blueScale, 0f, brightness,
                0f, 0f, 0f, 1f, 0f
            )
        )
        satM.timesAssign(adjM)
        satM
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            containerColor = Color(0xFF0B0F1A),
            topBar = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RoyalNavy)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Filled.Close, contentDescription = "Close Studio", tint = Color.White)
                        }
                        Text(
                            text = tr("VN Pro Studio", "VN प्रो वीडियो स्टूडियो", lang),
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf("9:16", "16:9", "1:1").forEach { ratio ->
                            FilterChip(
                                selected = aspectRatioLabel == ratio,
                                onClick = { aspectRatioLabel = ratio },
                                label = { Text(ratio, fontSize = 11.sp) }
                            )
                        }
                        Button(
                            onClick = {
                                val trackObj = availableMusicTracks.firstOrNull { it.id == selectedTrackId }
                                val trackTitle = customAudioLabel?.takeIf { it.isNotBlank() }
                                    ?.let { "Device Audio: $it" }
                                    ?: trackObj?.takeIf { it.id != "none" }?.let { if (lang == AppLang.HI) it.titleHi else it.titleEn }
                                val sfxObj = RoyaltyFreeMusicLibrary.sfxTracks.firstOrNull { it.id == selectedSfxId }
                                val lutLabel = lutPresets.firstOrNull { it.id == selectedLutId }?.label ?: "Original"
                                val summaryParts = buildList {
                                    add("$aspectRatioLabel • ${clips.size} clip(s)")
                                    add("${speedPreset}x Speed")
                                    if (lutLabel != "Original") add("$lutLabel LUT")
                                    if (keyframeAnim != "None") add(keyframeAnim)
                                    if (pipUri != null) add(if (chromaKeyEnabled) "PIP+Chroma" else "PIP")
                                    if (overlays.isNotEmpty()) add("${overlays.size} overlays")
                                    if (trackTitle != null) add("$trackTitle (Orig ${(originalVol * 100).toInt()}% / Mus ${(musicVol * 100).toInt()}%)")
                                    if (sfxObj != null) add(sfxObj.titleEn)
                                    if (voiceoverPath != null) add("Voiceover ${voiceoverSec}s")
                                }
                                val scanLayers = buildList {
                                    overlays.forEach { layer ->
                                        val tag = if (layer.isSticker) "Sticker" else if (layer.isSubtitle) "Subtitle" else "TextOverlay"
                                        add("$tag: ${layer.content}")
                                    }
                                    if (voiceoverPath != null) add("Voiceover recorded (${voiceoverSec}s)")
                                    if (pipUri != null) add("PIP overlay included")
                                }.joinToString(" | ")

                                val primaryUri = clips.firstOrNull { !it.uri.isNullOrBlank() }?.uri ?: pipUri
                                onApplyEdit(
                                    VnStudioEditResult(
                                        primaryMediaUri = primaryUri,
                                        pipMediaUri = pipUri,
                                        selectedMusicTrackId = selectedTrackId,
                                        selectedMusicTrackTitle = trackTitle,
                                        editorSummary = summaryParts.joinToString(" • "),
                                        extraLayerScanText = scanLayers
                                    )
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SafeEmerald),
                            modifier = Modifier.testTag("vn_studio_apply_button")
                        ) {
                            Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                            Spacer(Modifier.width(4.dp))
                            Text(tr("Apply", "सेव करें", lang), color = Color.White)
                        }
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // LIVE INTERACTIVE VIDEO / REEL PREVIEW STAGE
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(250.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF151C2E)),
                    contentAlignment = Alignment.Center
                ) {
                    val cropScale = activeClip?.cropZoom ?: 1f
                    val keyScale = when (keyframeAnim) {
                        "Zoom-In" -> 1f + 0.18f * animProgress
                        "Zoom-Out" -> 1.18f - 0.18f * animProgress
                        else -> 1f
                    }
                    val keyTransX = if (keyframeAnim == "Pan Slide") (animProgress - 0.5f) * 38f else 0f
                    val keyAlpha = if (keyframeAnim == "Fade Pulse") 0.55f + 0.45f * animProgress else 1f

                    Box(
                        modifier = Modifier
                            .height(234.dp)
                            .aspectRatio(previewAspect, matchHeightConstraintsFirst = true)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(RoyalNavy, VelvetIndigo)))
                    ) {
                        if (!activeClip?.uri.isNullOrBlank()) {
                            AsyncImage(
                                model = activeClip!!.uri,
                                contentDescription = "Studio Preview Media",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer(
                                        scaleX = cropScale * keyScale,
                                        scaleY = cropScale * keyScale,
                                        translationX = keyTransX,
                                        alpha = keyAlpha
                                    ),
                                contentScale = ContentScale.Crop,
                                colorFilter = ColorFilter.colorMatrix(colorMatrix)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer(scaleX = keyScale, scaleY = keyScale, alpha = keyAlpha),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(36.dp))
                                    Text(
                                        text = "${activeClip?.label ?: "Canvas"} • $aspectRatioLabel",
                                        color = Color.White.copy(alpha = 0.85f),
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                }
                            }
                        }

                        // Vignette Canvas Overlay
                        if (vignette > 0.02f) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                drawRect(
                                    brush = Brush.radialGradient(
                                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = vignette.coerceIn(0f, 0.85f))),
                                        center = Offset(size.width / 2f, size.height / 2f),
                                        radius = size.maxDimension * 0.72f
                                    )
                                )
                            }
                        }

                        // PIP Overlay Preview
                        if (!pipUri.isNullOrBlank()) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(8.dp)
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(
                                        2.dp,
                                        if (chromaKeyEnabled) Color(0xFF22C55E) else Color.White,
                                        RoundedCornerShape(10.dp)
                                    )
                            ) {
                                AsyncImage(
                                    model = pipUri,
                                    contentDescription = "PIP Overlay Preview",
                                    modifier = Modifier.fillMaxSize().graphicsLayer(
                                        alpha = if (chromaKeyEnabled) (1f - chromaIntensity * 0.25f) else 1f
                                    ),
                                    contentScale = ContentScale.Crop
                                )
                                if (chromaKeyEnabled) {
                                    Surface(
                                        color = Color(0xFF16A34A),
                                        modifier = Modifier.align(Alignment.TopCenter)
                                    ) {
                                        Text("Chroma", color = Color.White, fontSize = 8.sp, modifier = Modifier.padding(horizontal = 4.dp))
                                    }
                                }
                            }
                        }

                        // Draggable Text, Subtitle & Sticker Overlays
                        overlays.forEachIndexed { idx, layer ->
                            val family = when (layer.fontChoice) {
                                "Serif" -> FontFamily.Serif
                                "Bold" -> FontFamily.Monospace
                                else -> FontFamily.SansSerif
                            }
                            Box(
                                modifier = Modifier
                                    .offset { IntOffset(layer.offsetX.roundToInt(), layer.offsetY.roundToInt()) }
                                    .pointerInput(layer.id) {
                                        detectDragGestures { change, dragAmount ->
                                            change.consume()
                                            overlays[idx] = overlays[idx].copy(
                                                offsetX = (overlays[idx].offsetX + dragAmount.x).coerceIn(0f, 220f),
                                                offsetY = (overlays[idx].offsetY + dragAmount.y).coerceIn(0f, 240f)
                                            )
                                        }
                                    }
                                    .background(
                                        color = if (layer.hasBgBox && !layer.isSticker) Color.Black.copy(alpha = 0.62f) else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = layer.content,
                                    color = layer.colorHex,
                                    fontFamily = family,
                                    fontSize = if (layer.isSticker) (22 * layer.scale).sp else if (layer.isSubtitle) (13 * layer.scale).sp else (16 * layer.scale).sp,
                                    fontWeight = if (layer.fontChoice == "Bold") FontWeight.ExtraBold else FontWeight.SemiBold,
                                    style = TextStyle(
                                        shadow = if (layer.hasShadow) Shadow(Color.Black, Offset(2f, 2f), 4f) else null
                                    )
                                )
                            }
                        }
                    }
                }

                // MULTI-TRACK TIMELINE STRIP
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171E31)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = tr("Multi-Track Timeline (${clips.size} clips • ${speedPreset}x)", "मल्टी-ट्रैक टाइमलाइन (${clips.size} क्लिप्स)", lang),
                            color = Color.White,
                            style = MaterialTheme.typography.labelLarge
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(clips, key = { _, c -> c.id }) { idx, clip ->
                                val selected = idx == selectedClipIdx
                                Surface(
                                    color = if (selected) MaterialTheme.colorScheme.primary else Color(0xFF26304A),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.clickable { selectedClipIdx = idx }
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                                        Text(clip.label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text("${clip.transition} • ${(clip.trimStart * 100).toInt()}-${(clip.trimEnd * 100).toInt()}%", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                                    }
                                }
                            }
                            item {
                                OutlinedButton(
                                    onClick = {
                                        clipPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                                    },
                                    modifier = Modifier.testTag("vn_add_clip_button")
                                ) {
                                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                                    Spacer(Modifier.width(4.dp))
                                    Text(tr("Add Clip", "क्लिप जोड़ें", lang), color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }
                        // Secondary Timeline Bars (Music / Voiceover / Overlays)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            Surface(color = Color(0xFF312E81), shape = RoundedCornerShape(6.dp), modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "🎵 ${if (selectedTrackId == "none") "No Music" else selectedTrackId}",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(6.dp),
                                    maxLines = 1
                                )
                            }
                            Surface(color = Color(0xFF134E4A), shape = RoundedCornerShape(6.dp), modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "🎙️ ${if (voiceoverPath != null) "Voice ${voiceoverSec}s" else "No Voiceover"}",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(6.dp),
                                    maxLines = 1
                                )
                            }
                            Surface(color = Color(0xFF701A75), shape = RoundedCornerShape(6.dp), modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "🔤 ${overlays.size} Layers",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(6.dp),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                // STUDIO TOOL SELECTOR ROW
                val toolTabs = listOf(
                    tr("Timeline", "टाइमलाइन", lang) to Icons.Filled.ContentCut,
                    tr("Speed", "स्पीड", lang) to Icons.Filled.Speed,
                    tr("Grade", "कलर/फिल्टर", lang) to Icons.Filled.Tune,
                    tr("FX & PIP", "इफेक्ट्स/PIP", lang) to Icons.Filled.PictureInPicture,
                    tr("Text/Sticker", "टेक्स्ट/स्टिकर", lang) to Icons.Filled.TextFields,
                    tr("Audio", "ऑडियो", lang) to Icons.Filled.LibraryMusic
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(toolTabs) { idx, (label, icon) ->
                        FilterChip(
                            selected = activeToolTab == idx,
                            onClick = { activeToolTab = idx },
                            leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text(label) },
                            modifier = Modifier.testTag("vn_tool_tab_$idx")
                        )
                    }
                }

                // TOOL PANEL
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        when (activeToolTab) {
                            0 -> {
                                // TIMELINE: Trim, Split, Reorder, Delete, Zoom/Crop, Transitions
                                Text(tr("Clip Edit & Transitions", "क्लिप एडिट और ट्रांज़िशन", lang), fontWeight = FontWeight.Bold)
                                if (activeClip != null) {
                                    Text(tr("Trim Range (${(activeClip.trimStart * 100).toInt()}% - ${(activeClip.trimEnd * 100).toInt()}%)", "ट्रिम रेंज", lang), style = MaterialTheme.typography.labelMedium)
                                    RangeSlider(
                                        value = activeClip.trimStart..activeClip.trimEnd,
                                        onValueChange = { range ->
                                            clips[selectedClipIdx] = activeClip.copy(
                                                trimStart = range.start.coerceAtMost(range.endInclusive - 0.05f),
                                                trimEnd = range.endInclusive.coerceAtLeast(range.start + 0.05f)
                                            )
                                        }
                                    )
                                    Text(tr("Zoom / Crop (${"%.1f".format(activeClip.cropZoom)}x)", "ज़ूम / क्रॉप", lang), style = MaterialTheme.typography.labelMedium)
                                    Slider(
                                        value = activeClip.cropZoom,
                                        onValueChange = { clips[selectedClipIdx] = activeClip.copy(cropZoom = it) },
                                        valueRange = 1.0f..2.5f
                                    )

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                        OutlinedButton(
                                            onClick = {
                                                val mid = (activeClip.trimStart + activeClip.trimEnd) / 2f
                                                val first = activeClip.copy(id = "${activeClip.id}_a", label = "${activeClip.label} (A)", trimEnd = mid)
                                                val second = activeClip.copy(id = "split_${System.currentTimeMillis()}", label = "${activeClip.label} (B)", trimStart = mid)
                                                clips[selectedClipIdx] = first
                                                clips.add(selectedClipIdx + 1, second)
                                            },
                                            modifier = Modifier.weight(1f).testTag("vn_split_clip_button")
                                        ) {
                                            Icon(Icons.Filled.ContentCut, null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(tr("Split", "काटें", lang))
                                        }
                                        IconButton(
                                            onClick = {
                                                if (selectedClipIdx > 0) {
                                                    val c = clips.removeAt(selectedClipIdx)
                                                    clips.add(selectedClipIdx - 1, c)
                                                    selectedClipIdx--
                                                }
                                            },
                                            enabled = selectedClipIdx > 0
                                        ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Move Left") }
                                        IconButton(
                                            onClick = {
                                                if (selectedClipIdx < clips.lastIndex) {
                                                    val c = clips.removeAt(selectedClipIdx)
                                                    clips.add(selectedClipIdx + 1, c)
                                                    selectedClipIdx++
                                                }
                                            },
                                            enabled = selectedClipIdx < clips.lastIndex
                                        ) { Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Move Right") }
                                        IconButton(
                                            onClick = {
                                                if (clips.size > 1) {
                                                    clips.removeAt(selectedClipIdx)
                                                    selectedClipIdx = selectedClipIdx.coerceIn(0, clips.lastIndex)
                                                }
                                            },
                                            enabled = clips.size > 1
                                        ) { Icon(Icons.Filled.Delete, contentDescription = "Delete Clip", tint = MaterialTheme.colorScheme.error) }
                                    }

                                    Text(tr("Clip Transition", "क्लिप ट्रांज़िशन", lang), fontWeight = FontWeight.SemiBold)
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        items(listOf("None", "Fade", "Dissolve", "Slide", "Zoom", "Flash")) { trName ->
                                            FilterChip(
                                                selected = activeClip.transition == trName,
                                                onClick = { clips[selectedClipIdx] = activeClip.copy(transition = trName) },
                                                label = { Text(trName) }
                                            )
                                        }
                                    }
                                }
                            }

                            1 -> {
                                // SPEED & SPEED CURVE RAMP
                                Text(tr("Slow-Mo / Fast-Mo & Speed Curve", "स्लो-मो / फ़ास्ट-मो और स्पीड कर्व", lang), fontWeight = FontWeight.Bold)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    items(listOf(0.3f to "0.3x Super Slow", 0.5f to "0.5x Slow-Mo", 1.0f to "1x Normal", 1.5f to "1.5x Fast", 2.0f to "2x Hyper")) { (spd, lbl) ->
                                        FilterChip(
                                            selected = speedPreset == spd,
                                            onClick = {
                                                speedPreset = spd
                                                curveStart = spd
                                                curveMid = spd
                                                curveEnd = spd
                                            },
                                            label = { Text(lbl) },
                                            modifier = Modifier.testTag("vn_speed_${spd}")
                                        )
                                    }
                                }
                                // Speed Curve Visual Canvas
                                Canvas(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(64.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFF0F172A))
                                        .padding(10.dp)
                                ) {
                                    val y0 = size.height * (1f - (curveStart / 2.2f).coerceIn(0.1f, 0.95f))
                                    val y1 = size.height * (1f - (curveMid / 2.2f).coerceIn(0.1f, 0.95f))
                                    val y2 = size.height * (1f - (curveEnd / 2.2f).coerceIn(0.1f, 0.95f))
                                    val path = Path().apply {
                                        moveTo(0f, y0)
                                        cubicTo(size.width * 0.25f, y0, size.width * 0.35f, y1, size.width * 0.5f, y1)
                                        cubicTo(size.width * 0.65f, y1, size.width * 0.75f, y2, size.width, y2)
                                    }
                                    drawPath(path, color = Color(0xFF38BDF8), style = Stroke(width = 4f))
                                    drawCircle(Color.White, radius = 6f, center = Offset(0f, y0))
                                    drawCircle(Color.White, radius = 6f, center = Offset(size.width * 0.5f, y1))
                                    drawCircle(Color.White, radius = 6f, center = Offset(size.width, y2))
                                }
                                Text("Curve Ramp — Start: ${"%.1f".format(curveStart)}x • Mid: ${"%.1f".format(curveMid)}x • End: ${"%.1f".format(curveEnd)}x", style = MaterialTheme.typography.labelSmall)
                                Slider(value = curveStart, onValueChange = { curveStart = it }, valueRange = 0.25f..2.0f)
                                Slider(value = curveMid, onValueChange = { curveMid = it; speedPreset = it }, valueRange = 0.25f..2.0f)
                                Slider(value = curveEnd, onValueChange = { curveEnd = it }, valueRange = 0.25f..2.0f)
                            }

                            2 -> {
                                // LIVE COLOR GRADING & LUT PRESETS
                                Text(tr("LUT Filters & Color Grading", "फ़िल्टर और कलर ग्रेडिंग", lang), fontWeight = FontWeight.Bold)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    items(lutPresets, key = { it.id }) { lut ->
                                        FilterChip(
                                            selected = selectedLutId == lut.id,
                                            onClick = {
                                                selectedLutId = lut.id
                                                saturation = lut.saturation
                                                contrast = lut.contrast
                                                brightness = lut.brightness
                                            },
                                            label = { Text(lut.label) }
                                        )
                                    }
                                }
                                Text("Brightness (${brightness.toInt()})", style = MaterialTheme.typography.labelSmall)
                                Slider(value = brightness, onValueChange = { brightness = it }, valueRange = -50f..50f)
                                Text("Contrast (${"%.2f".format(contrast)})", style = MaterialTheme.typography.labelSmall)
                                Slider(value = contrast, onValueChange = { contrast = it }, valueRange = 0.6f..1.6f)
                                Text("Saturation (${"%.2f".format(saturation)})", style = MaterialTheme.typography.labelSmall)
                                Slider(value = saturation, onValueChange = { saturation = it }, valueRange = 0f..2f)
                                Text("Vignette (${(vignette * 100).toInt()}%)", style = MaterialTheme.typography.labelSmall)
                                Slider(value = vignette, onValueChange = { vignette = it }, valueRange = 0f..0.8f)
                            }

                            3 -> {
                                // KEYFRAME MOTION, PIP & CHROMA KEY
                                Text(tr("Keyframe Motion Animation", "कीफ़्रेम मोशन एनीमेशन", lang), fontWeight = FontWeight.Bold)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    items(listOf("None", "Zoom-In", "Zoom-Out", "Pan Slide", "Fade Pulse")) { anim ->
                                        FilterChip(
                                            selected = keyframeAnim == anim,
                                            onClick = { keyframeAnim = anim },
                                            leadingIcon = { Icon(Icons.Filled.Animation, null, modifier = Modifier.size(16.dp)) },
                                            label = { Text(anim) }
                                        )
                                    }
                                }
                                HorizontalDivider()
                                Text(tr("PIP Overlay & Chroma Key (Green Screen)", "PIP ओवरले और क्रोमा की", lang), fontWeight = FontWeight.Bold)
                                OutlinedButton(
                                    onClick = {
                                        pipPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("vn_pick_pip_button")
                                ) {
                                    Icon(Icons.Filled.Layers, null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (pipUri == null) tr("Pick Picture-in-Picture (PIP) Overlay", "PIP ओवरले चुनें", lang) else tr("PIP Overlay Added ✓ (Tap to Change)", "PIP ओवरले जोड़ा गया ✓", lang))
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(tr("Chroma Key (Green Screen Removal)", "क्रोमा की (ग्रीन स्क्रीन हटाएं)", lang))
                                    Switch(checked = chromaKeyEnabled, onCheckedChange = { chromaKeyEnabled = it })
                                }
                                if (chromaKeyEnabled) {
                                    Text("Chroma Key Threshold: ${(chromaIntensity * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                                    Slider(value = chromaIntensity, onValueChange = { chromaIntensity = it }, valueRange = 0.1f..1.0f)
                                }
                            }

                            4 -> {
                                // ANIMATED HINDI/ENGLISH TEXT, SUBTITLES & STICKERS
                                Text(tr("Animated Text, Subtitles & Stickers", "टेक्स्ट, सबटाइटल और स्टिकर्स", lang), fontWeight = FontWeight.Bold)
                                OutlinedTextField(
                                    value = newOverlayText,
                                    onValueChange = { newOverlayText = it },
                                    label = { Text(tr("Enter Hindi/English Text or Subtitle...", "हिंदी/अंग्रेज़ी टेक्स्ट या सबटाइटल लिखें...", lang)) },
                                    modifier = Modifier.fillMaxWidth().testTag("vn_overlay_text_input"),
                                    singleLine = true
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    FilterChip(
                                        selected = !newOverlayIsSubtitle,
                                        onClick = { newOverlayIsSubtitle = false },
                                        label = { Text("Title Text") }
                                    )
                                    FilterChip(
                                        selected = newOverlayIsSubtitle,
                                        onClick = { newOverlayIsSubtitle = true },
                                        label = { Text("Subtitle") }
                                    )
                                    listOf("Sans", "Serif", "Bold").forEach { f ->
                                        FilterChip(selected = newOverlayFont == f, onClick = { newOverlayFont = f }, label = { Text(f) })
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    listOf(Color.White, Color(0xFFFACC15), Color(0xFFFB7185), Color(0xFF38BDF8), Color(0xFF4ADE80)).forEach { c ->
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(c)
                                                .border(if (newOverlayColor == c) 3.dp else 1.dp, Color.Black, CircleShape)
                                                .clickable { newOverlayColor = c }
                                        )
                                    }
                                    Spacer(Modifier.weight(1f))
                                    Button(
                                        onClick = {
                                            val cleanOverlay = com.dilsuno.app.core.SecurityUtils.sanitizeInput(newOverlayText, 120)
                                            if (cleanOverlay.isNotBlank()) {
                                                overlays.add(
                                                    StudioOverlayLayer(
                                                        id = "ov_${System.currentTimeMillis()}",
                                                        content = cleanOverlay,
                                                        isSticker = false,
                                                        isSubtitle = newOverlayIsSubtitle,
                                                        fontChoice = newOverlayFont,
                                                        colorHex = newOverlayColor,
                                                        hasBgBox = newOverlayBgBox,
                                                        hasShadow = newOverlayShadow
                                                    )
                                                )
                                                newOverlayText = ""
                                            }
                                        },
                                        enabled = newOverlayText.isNotBlank(),
                                        modifier = Modifier.testTag("vn_add_text_layer_button")
                                    ) {
                                        Text(tr("Add Layer", "जोड़ें", lang))
                                    }
                                }

                                HorizontalDivider()
                                val stickerPacks = remember {
                                    mapOf(
                                        "Happy" to listOf("😊", "🥳", "✨", "🎉", "🌸"),
                                        "Emotional" to listOf("💔", "🥹", "🕊️", "❤️‍🩹", "🌧️"),
                                        "Shayari" to listOf("✍️", "🌙", "🥀", "📖", "शायरी"),
                                        "Motivation" to listOf("🔥", "💪", "🚀", "🏆", "ताक़त"),
                                        "News Alert" to listOf("🚨 BREAKING", "📢 LIVE", "📍 LOCAL", "⚡ UPDATE"),
                                        "Frames" to listOf("🖼️ Cinema", "🎞️ Reel", "💫 Glow")
                                    )
                                }
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    items(stickerPacks.keys.toList()) { pack ->
                                        FilterChip(
                                            selected = selectedStickerPack == pack,
                                            onClick = { selectedStickerPack = pack },
                                            leadingIcon = { Icon(Icons.Filled.EmojiEmotions, null, modifier = Modifier.size(15.dp)) },
                                            label = { Text(pack) }
                                        )
                                    }
                                }
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(stickerPacks[selectedStickerPack].orEmpty()) { sticker ->
                                        OutlinedButton(onClick = {
                                            overlays.add(
                                                StudioOverlayLayer(
                                                    id = "st_${System.currentTimeMillis()}_${overlays.size}",
                                                    content = sticker,
                                                    isSticker = true,
                                                    hasBgBox = false
                                                )
                                            )
                                        }) {
                                            Text(sticker)
                                        }
                                    }
                                }
                                if (overlays.isNotEmpty()) {
                                    Text(tr("Active Layers (Drag on preview or remove):", "सक्रिय लेयर (प्रीव्यू पर ड्रैग करें):", lang), style = MaterialTheme.typography.labelSmall)
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        itemsIndexed(overlays, key = { _, o -> o.id }) { idx, o ->
                                            FilterChip(
                                                selected = true,
                                                onClick = { overlays.removeAt(idx) },
                                                label = { Text("${o.content.take(12)} ✕") }
                                            )
                                        }
                                    }
                                }
                            }

                            else -> {
                                // AUDIO TRACKS (MOODS + DEVICE AUDIO), SFX, IN-EDITOR VOICEOVER & MIXER
                                Text(tr("Multi-Track Audio, SFX & Voiceover", "म्यूज़िक, SFX और वॉइसओवर", lang), fontWeight = FontWeight.Bold)
                                ReelMusicMixerPanel(
                                    tracks = availableMusicTracks,
                                    selectedMusicId = selectedTrackId,
                                    customAudioUri = customAudioUri,
                                    customAudioLabel = customAudioLabel,
                                    originalVolume = originalVol,
                                    musicVolume = musicVol,
                                    lang = lang,
                                    onSelectTrack = { track ->
                                        selectedTrackId = track.id
                                        customAudioUri = null
                                        customAudioLabel = null
                                    },
                                    onPickDeviceAudio = { uriStr, name ->
                                        customAudioUri = uriStr
                                        customAudioLabel = name
                                        selectedTrackId = "device_custom"
                                    },
                                    onClearDeviceAudio = {
                                        customAudioUri = null
                                        customAudioLabel = null
                                        if (selectedTrackId == "device_custom") {
                                            selectedTrackId = "none"
                                        }
                                    },
                                    onOriginalVolumeChange = { originalVol = it },
                                    onMusicVolumeChange = { musicVol = it },
                                    onSecurityError = onSecurityError,
                                    showOriginalVolumeSlider = true
                                )

                                Text(tr("Sound Effects (SFX)", "साउंड इफ़ेक्ट्स (SFX)", lang), style = MaterialTheme.typography.labelMedium)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(RoyaltyFreeMusicLibrary.sfxTracks, key = { it.id }) { sfx ->
                                        FilterChip(
                                            selected = selectedSfxId == sfx.id,
                                            onClick = {
                                                selectedSfxId = if (selectedSfxId == sfx.id) null else sfx.id
                                                RoyaltyFreeMusicLibrary.playPreview(scope, sfx, context, musicVol) {}
                                            },
                                            leadingIcon = { Icon(Icons.Filled.GraphicEq, null, modifier = Modifier.size(16.dp)) },
                                            label = { Text(if (lang == AppLang.HI) sfx.titleHi else sfx.titleEn) }
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        if (isRecordingVoiceover) {
                                            isRecordingVoiceover = false
                                            val rec = voiceHelper.stopRecording()
                                            if (rec != null) {
                                                voiceoverPath = rec.first
                                                voiceoverSec = rec.second
                                            }
                                        } else {
                                            micPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isRecordingVoiceover) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                                    ),
                                    modifier = Modifier.fillMaxWidth().testTag("vn_voiceover_record_button")
                                ) {
                                    Icon(if (isRecordingVoiceover) Icons.Filled.Stop else Icons.Filled.Mic, null)
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        when {
                                            isRecordingVoiceover -> tr("Stop Recording Voiceover", "वॉइसओवर रोकें", lang)
                                            voiceoverPath != null -> tr("Re-record Voiceover (${voiceoverSec}s recorded ✓)", "वॉइसओवर दोबारा रिकॉर्ड करें (${voiceoverSec}s ✓)", lang)
                                            else -> tr("Record In-Editor Voiceover", "वॉइसओवर रिकॉर्ड करें", lang)
                                        }
                                    )
                                }

                                Text("Voiceover Volume: ${(voiceoverVol * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                                Slider(value = voiceoverVol, onValueChange = { voiceoverVol = it })
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(tr("Smooth Audio Fade-In / Fade-Out", "ऑडियो फ़ेड-इन / फ़ेड-आउट", lang))
                                    Switch(checked = fadeAudio, onCheckedChange = { fadeAudio = it })
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

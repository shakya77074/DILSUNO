package com.dilsuno.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.MusicTrackOption
import com.dilsuno.app.core.RoyaltyFreeMusicLibrary
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.AppConfig
import com.dilsuno.app.data.model.SupportTicket
import com.dilsuno.app.ui.components.SuperAdminAppVersionUpdateCard
import com.dilsuno.app.ui.theme.HairlineDividerBlue
import com.dilsuno.app.ui.theme.PureWhiteBackground
import com.dilsuno.app.ui.theme.RoyalBlueDeep
import com.dilsuno.app.ui.theme.RoyalBluePrimary
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.SlateDarkText
import com.dilsuno.app.ui.theme.SlateSubtleText
import com.dilsuno.app.ui.theme.SoftBlueCardSurface
import com.dilsuno.app.ui.theme.SoftCardSurface
import com.dilsuno.app.viewmodel.StaffAndAdminViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminMusicAndNoticesTab(
    viewModel: StaffAndAdminViewModel,
    lang: AppLang,
    appConfig: AppConfig,
    adminCustomMusicTracks: List<MusicTrackOption>,
    allSupportTickets: List<SupportTicket>
) {
    val context = LocalContext.current
    val musicScope = rememberCoroutineScope()
    var adminPreviewingTrackId by remember { mutableStateOf<String?>(null) }
    var newMusicTitleEn by remember { mutableStateOf("") }
    var newMusicTitleHi by remember { mutableStateOf("") }
    var newMusicMood by remember { mutableStateOf(RoyaltyFreeMusicLibrary.moodCategories.first().combinedLabel) }
    var newMusicUrl by remember { mutableStateOf("") }

    var callRateText by remember { mutableStateOf(appConfig.dilSeCallRateInr.toString()) }
    var viewBonusText by remember { mutableStateOf(appConfig.viewBonusPer1000Inr.toString()) }
    var globalMonetization by remember { mutableStateOf(appConfig.globalMonetizationEnabled) }
    var agoraAppIdText by remember { mutableStateOf(appConfig.agoraAppId.orEmpty()) }
    var supportEmailText by remember { mutableStateOf(appConfig.supportEmail ?: "supportdilsuno@gmail.com") }
    var bannerEnText by remember { mutableStateOf(appConfig.announcementBannerEn.orEmpty()) }
    var bannerHiText by remember { mutableStateOf(appConfig.announcementBannerHi.orEmpty()) }
    var bannerActive by remember { mutableStateOf(appConfig.announcementActive) }

    LaunchedEffect(appConfig) {
        callRateText = appConfig.dilSeCallRateInr.toString()
        viewBonusText = appConfig.viewBonusPer1000Inr.toString()
        globalMonetization = appConfig.globalMonetizationEnabled
        agoraAppIdText = appConfig.agoraAppId.orEmpty()
        supportEmailText = appConfig.supportEmail ?: "supportdilsuno@gmail.com"
        bannerEnText = appConfig.announcementBannerEn.orEmpty()
        bannerHiText = appConfig.announcementBannerHi.orEmpty()
        bannerActive = appConfig.announcementActive
    }

    DisposableEffect(Unit) {
        onDispose { RoyaltyFreeMusicLibrary.stopPreview() }
    }

    fun saveFullConfig() {
        viewModel.saveBusinessConfig(
            callRate = callRateText.toLongOrNull() ?: 100L,
            viewBonus = viewBonusText.toLongOrNull() ?: 25L,
            globalMonetization = globalMonetization,
            supportEmail = supportEmailText,
            announcementBannerEn = bannerEnText,
            announcementBannerHi = bannerHiText,
            announcementActive = bannerActive,
            adminCallPickupOnline = appConfig.adminCallPickupOnline,
            agoraAppId = agoraAppIdText
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // ROYALTY-FREE MUSIC LIBRARY MANAGER
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SoftBlueCardSurface),
                border = BorderStroke(1.dp, RoyalBluePrimary.copy(alpha = 0.28f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().testTag("admin_music_manager_card")
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.LibraryMusic, contentDescription = null, tint = RoyalBluePrimary)
                        Text(tr("Reel Music Library Manager", "रील म्यूज़िक लाइब्रेरी मैनेजर", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SlateDarkText)
                    }
                    OutlinedTextField(
                        value = newMusicTitleEn,
                        onValueChange = { newMusicTitleEn = it },
                        label = { Text(tr("Track Title (English) *", "ट्रैक का नाम (English) *", lang)) },
                        modifier = Modifier.fillMaxWidth().testTag("admin_music_title_en_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newMusicTitleHi,
                        onValueChange = { newMusicTitleHi = it },
                        label = { Text(tr("Track Title (Hindi • Optional)", "ट्रैक का नाम (हिंदी • वैकल्पिक)", lang)) },
                        modifier = Modifier.fillMaxWidth().testTag("admin_music_title_hi_input"),
                        singleLine = true
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        RoyaltyFreeMusicLibrary.moodCategories.forEach { mood ->
                            FilterChip(
                                selected = newMusicMood == mood.combinedLabel,
                                onClick = { newMusicMood = mood.combinedLabel },
                                label = { Text(if (lang == AppLang.HI) mood.labelHi else mood.labelEn) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = newMusicUrl,
                        onValueChange = { newMusicUrl = it },
                        label = { Text(tr("Royalty-Free HTTPS Audio URL (.mp3/.m4a)", "रॉयल्टी-फ़्री HTTPS ऑडियो URL", lang)) },
                        modifier = Modifier.fillMaxWidth().testTag("admin_music_url_input"),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            viewModel.addCustomMusicTrack(newMusicTitleEn, newMusicTitleHi, newMusicMood, newMusicUrl)
                            if (newMusicTitleEn.isNotBlank()) {
                                newMusicTitleEn = ""
                                newMusicTitleHi = ""
                                newMusicUrl = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary, contentColor = Color.White),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("admin_add_music_track_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(tr("Add Track to Music Library", "म्यूज़िक लाइब्रेरी में जोड़ें", lang), color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    if (adminCustomMusicTracks.isNotEmpty()) {
                        HorizontalDivider(color = HairlineDividerBlue)
                        adminCustomMusicTracks.forEach { track ->
                            val isPlaying = adminPreviewingTrackId == track.id
                            Surface(
                                color = PureWhiteBackground,
                                border = BorderStroke(1.dp, HairlineDividerBlue),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(track.titleEn, fontWeight = FontWeight.Bold, color = SlateDarkText)
                                        Text("${track.mood} • ${track.audioUrl ?: "Built-in Synth"}", style = MaterialTheme.typography.labelSmall, color = SlateSubtleText)
                                    }
                                    Row {
                                        IconButton(
                                            onClick = {
                                                if (isPlaying) {
                                                    RoyaltyFreeMusicLibrary.stopPreview()
                                                    adminPreviewingTrackId = null
                                                } else {
                                                    adminPreviewingTrackId = track.id
                                                    RoyaltyFreeMusicLibrary.playPreview(musicScope, track, context, 0.85f) {
                                                        adminPreviewingTrackId = null
                                                    }
                                                }
                                            },
                                            modifier = Modifier.size(48.dp)
                                        ) {
                                            Icon(if (isPlaying) Icons.Filled.Stop else Icons.Filled.PlayArrow, contentDescription = "Preview Admin Track", tint = RoyalBluePrimary)
                                        }
                                        IconButton(
                                            onClick = {
                                                if (isPlaying) {
                                                    RoyaltyFreeMusicLibrary.stopPreview()
                                                    adminPreviewingTrackId = null
                                                }
                                                viewModel.removeCustomMusicTrack(track.id)
                                            },
                                            modifier = Modifier.size(48.dp).testTag("admin_delete_music_${track.id}")
                                        ) {
                                            Icon(Icons.Filled.Delete, contentDescription = "Remove Track", tint = Color(0xFFB91C1C))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // DIL SUNO BUSINESS, VOICE, BANNER & SUPPORT EMAIL SETTINGS (ZERO UPI/GATEWAY FIELDS)
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(tr("Business, Voice, Support & Banner Settings", "बिज़नेस, वॉइस और लाइव बैनर सेटिंग्स", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    OutlinedTextField(
                        value = callRateText,
                        onValueChange = { callRateText = it },
                        label = { Text(tr("Dil Se Call Flat Rate (₹)", "दिल से कॉल शुल्क (₹)", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("admin_call_rate_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = viewBonusText,
                        onValueChange = { viewBonusText = it },
                        label = { Text(tr("Creator Bonus per 1,000 Views (₹)", "प्रति 1000 व्यूज़ बोनस (₹)", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("admin_view_bonus_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = agoraAppIdText,
                        onValueChange = { agoraAppIdText = it },
                        label = { Text(tr("Voice App ID (Optional)", "वॉइस App ID (वैकल्पिक)", lang)) },
                        modifier = Modifier.fillMaxWidth().testTag("admin_agora_app_id_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = supportEmailText,
                        onValueChange = { supportEmailText = it },
                        label = { Text(tr("Official Support Email ID", "आधिकारिक सपोर्ट ईमेल आईडी", lang)) },
                        modifier = Modifier.fillMaxWidth().testTag("admin_support_email_input"),
                        singleLine = true
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(tr("Global Creator Monetization Enabled", "ग्लोबल क्रिएटर मोनेटाइज़ेशन", lang))
                        Switch(checked = globalMonetization, onCheckedChange = { globalMonetization = it })
                    }

                    HorizontalDivider()
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Filled.Campaign, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(tr("Live Home Announcement Banner", "होम स्क्रीन लाइव घोषणा बैनर", lang), fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(tr("Show Banner on Home Feed", "होम फ़ीड पर बैनर दिखाएं", lang))
                        Switch(checked = bannerActive, onCheckedChange = { bannerActive = it })
                    }
                    OutlinedTextField(
                        value = bannerEnText,
                        onValueChange = { bannerEnText = it },
                        label = { Text("Announcement Banner (English)") },
                        modifier = Modifier.fillMaxWidth().testTag("admin_banner_en_input"),
                        minLines = 2
                    )
                    OutlinedTextField(
                        value = bannerHiText,
                        onValueChange = { bannerHiText = it },
                        label = { Text("घोषणा बैनर (हिंदी)") },
                        modifier = Modifier.fillMaxWidth().testTag("admin_banner_hi_input"),
                        minLines = 2
                    )
                    Button(
                        onClick = { saveFullConfig() },
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary, contentColor = Color.White),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("admin_save_config_button")
                    ) {
                        Text(tr("Save All Settings", "सभी सेटिंग्स सेव करें", lang), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // APP VERSIONING & UPDATE CARD
        item {
            SuperAdminAppVersionUpdateCard(
                appConfig = appConfig,
                lang = lang,
                onSaveVersionConfig = { verName, verCode, updateUrl, forceUpdate ->
                    viewModel.saveBusinessConfig(
                        callRate = callRateText.toLongOrNull() ?: appConfig.dilSeCallRateInr,
                        viewBonus = viewBonusText.toLongOrNull() ?: appConfig.viewBonusPer1000Inr,
                        globalMonetization = globalMonetization,
                        latestAppVersionName = verName,
                        latestAppVersionCode = verCode,
                        appUpdateUrl = updateUrl,
                        forceUpdate = forceUpdate
                    )
                }
            )
        }

        // CUSTOMER SUPPORT TICKETS INBOX
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.SupportAgent, contentDescription = null, tint = RoyalBluePrimary)
                Text(tr("Customer Support Tickets (${allSupportTickets.size})", "ग्राहक सहायता टिकट (${allSupportTickets.size})", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SlateDarkText)
            }
        }
        items(allSupportTickets, key = { it.id }) { ticket ->
            var replyText by remember(ticket.id) { mutableStateOf(ticket.adminReply.orEmpty()) }
            Card(
                colors = CardDefaults.cardColors(containerColor = SoftCardSurface),
                border = BorderStroke(1.dp, HairlineDividerBlue),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${ticket.userName} • ${ticket.category}", fontWeight = FontWeight.Bold, color = SlateDarkText)
                        Text(ticket.status.uppercase(), color = if (ticket.status == "resolved") SafeEmerald else Color(0xFFB91C1C), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                    Text(ticket.message, style = MaterialTheme.typography.bodyMedium, color = SlateDarkText)
                    if (!ticket.screenshotUri.isNullOrBlank()) {
                        AsyncImage(
                            model = ticket.screenshotUri,
                            contentDescription = "Ticket Screenshot",
                            modifier = Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                    OutlinedTextField(
                        value = replyText,
                        onValueChange = { replyText = it },
                        label = { Text(tr("Write Reply", "उत्तर लिखें", lang)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.replySupportTicket(ticket.id, ticket.userUid, replyText, markResolved = false) },
                            border = BorderStroke(1.dp, RoyalBluePrimary),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) { Text(tr("Send Reply", "उत्तर भेजें", lang), color = RoyalBlueDeep, fontWeight = FontWeight.Bold) }
                        Button(
                            onClick = { viewModel.replySupportTicket(ticket.id, ticket.userUid, replyText, markResolved = true) },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary, contentColor = Color.White),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) { Text(tr("Reply & Resolve", "हल चिह्नित करें", lang), color = Color.White, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }
}

package com.dilsuno.app.ui.components

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.DilSePolicyText
import com.dilsuno.app.core.DilSunoBillingRules
import com.dilsuno.app.core.PlayBillingManager
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.UiState
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.RoyalNavy
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.VelvetIndigo
import com.dilsuno.app.viewmodel.MainAppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DilSunoMenuDrawerSheet(
    viewModel: MainAppViewModel,
    lang: AppLang,
    onDismiss: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenFriends: () -> Unit,
    onOpenSmartListenerCall: (needsRechargePopup: Boolean) -> Unit,
    onOpenReelFullscreen: (String) -> Unit,
    onToggleLang: () -> Unit,
    onSignOut: () -> Unit,
    onAccountDeleted: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val myAccount by viewModel.myAccount.collectAsStateWithLifecycle()
    val myProfile by viewModel.myProfile.collectAsStateWithLifecycle()
    val walletBalance by viewModel.walletBalance.collectAsStateWithLifecycle()
    val friendLinks by viewModel.friendLinks.collectAsStateWithLifecycle()
    val onlineFriendsCount by viewModel.onlineFriendsCount.collectAsStateWithLifecycle()
    val savedPostIds by viewModel.savedPostIds.collectAsStateWithLifecycle()
    val blockedUserUids by viewModel.blockedUserUids.collectAsStateWithLifecycle()
    val allowFriendChat by viewModel.allowFriendChat.collectAsStateWithLifecycle()
    val postsState by viewModel.postsState.collectAsStateWithLifecycle()
    val stories by viewModel.stories.collectAsStateWithLifecycle()
    val profiles by viewModel.communityProfiles.collectAsStateWithLifecycle()
    val appConfig by viewModel.appConfig.collectAsStateWithLifecycle()
    val milestones by viewModel.creatorMilestoneProgress.collectAsStateWithLifecycle()
    val myListenerApp by viewModel.myListenerApplication.collectAsStateWithLifecycle()
    val isReviewerDemoAccount = viewModel.isReviewerDemoAccount

    val totalFriendsCount = remember(friendLinks, viewModel.currentUserId) {
        friendLinks.filter { it.status == "accepted" }
            .flatMap { it.participantUids }
            .filter { it != viewModel.currentUserId }
            .distinct()
            .size
    }

    val myDisplayName = viewModel.resolveDisplayName("Dil Suno Member")
    val myAvatar = myProfile?.avatarUri

    val playBillingManager = remember(context) {
        PlayBillingManager(
            context = context,
            onPurchaseVerifiedForFirebase = { verified ->
                viewModel.creditVerifiedPlayBillingPurchase(verified)
            },
            onBillingMessage = { msg ->
                viewModel.reportSecurityError(msg)
            }
        )
    }
    DisposableEffect(playBillingManager) {
        runCatching { playBillingManager.startConnection() }
        onDispose { runCatching { playBillingManager.endConnection() } }
    }

    var expandHelp by remember { mutableStateOf(false) }
    var expandSettings by remember { mutableStateOf(false) }

    var showCreatorDialog by remember { mutableStateOf(false) }
    var showAiDialog by remember { mutableStateOf(false) }
    var showSavedDialog by remember { mutableStateOf(false) }
    var showMemoriesDialog by remember { mutableStateOf(false) }
    var showSupportModal by remember { mutableStateOf(false) }
    var showLegalViewerTab by remember { mutableStateOf<Int?>(null) }
    var showBlockedUsersDialog by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var showJoinTeamDialog by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Menu • Dil Suno",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = CrimsonPrimary
            )

            // a) Top Rounded Profile + Listener Call Card
            Card(
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                onDismiss()
                                onOpenProfile()
                            }
                            .padding(vertical = 4.dp)
                            .testTag("drawer_profile_row"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(CrimsonPrimary.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (!myAvatar.isNullOrBlank()) {
                                AsyncImage(
                                    model = myAvatar,
                                    contentDescription = myDisplayName,
                                    modifier = Modifier.fillMaxWidth(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(
                                    text = myDisplayName.take(2).uppercase(),
                                    color = CrimsonPrimary,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(myDisplayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                text = tr("View your profile & cover", "अपनी प्रोफ़ाइल और कवर देखें", lang),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    HorizontalDivider()

                    Button(
                        onClick = {
                            onDismiss()
                            onOpenSmartListenerCall(walletBalance < DilSunoBillingRules.CALL_CHARGE_INR)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary, contentColor = Color.White),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 50.dp)
                            .testTag("drawer_listener_call_button")
                    ) {
                        Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Listener Call (दिल हल्का करें - कॉल)",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // c) Facebook-style Drawer Feature List (100% Dil Suno)
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    DrawerMenuItemRow(
                        icon = Icons.Filled.Group,
                        iconTint = VelvetIndigo,
                        title = tr("Friends", "दोस्त", lang),
                        subtitle = "$totalFriendsCount friends • $onlineFriendsCount online",
                        testTag = "drawer_friends_item",
                        onClick = {
                            onDismiss()
                            onOpenFriends()
                        }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    DrawerMenuItemRow(
                        icon = Icons.Filled.MonetizationOn,
                        iconTint = SafeEmerald,
                        title = tr("Creator Dashboard", "क्रिएटर डैशबोर्ड", lang),
                        subtitle = "${milestones.first}/10 shares • ${milestones.second}/5 reels • ${milestones.third}/25 likes",
                        testTag = "drawer_creator_dashboard_item",
                        onClick = { showCreatorDialog = true }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    DrawerMenuItemRow(
                        icon = Icons.Filled.AutoAwesome,
                        iconTint = CrimsonPrimary,
                        title = "Dil Suno AI",
                        subtitle = tr("Free 24x7 AI Voice Listener (₹0)", "निःशुल्क 24x7 AI वॉयस मित्र (₹0)", lang),
                        testTag = "drawer_ai_item",
                        onClick = { showAiDialog = true }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    DrawerMenuItemRow(
                        icon = Icons.Filled.Bookmark,
                        iconTint = RoyalNavy,
                        title = tr("Saved", "सहेजे गए (Saved)", lang),
                        subtitle = tr("${savedPostIds.size} saved posts & reels", "${savedPostIds.size} सहेजी गई पोस्ट और रील", lang),
                        testTag = "drawer_saved_item",
                        onClick = { showSavedDialog = true }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    val allPosts = (postsState as? UiState.Success)?.data.orEmpty()
                    val myMemoryCount = allPosts.count { it.authorUid == viewModel.currentUserId } +
                        stories.count { it.authorUid == viewModel.currentUserId }
                    DrawerMenuItemRow(
                        icon = Icons.Filled.History,
                        iconTint = VelvetIndigo,
                        title = tr("Memories", "यादें (Memories)", lang),
                        subtitle = tr("$myMemoryCount past posts, reels & stories", "$myMemoryCount आपकी पोस्ट, रील और स्टोरीज़", lang),
                        testTag = "drawer_memories_item",
                        onClick = { showMemoriesDialog = true }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    val teamBadge = when (myListenerApp?.status) {
                        "pending" -> tr("Status: Pending Staff Review", "स्थिति: स्टाफ समीक्षा में", lang)
                        "staff_verified" -> tr("Status: Verified by Staff (Admin Step Next)", "स्थिति: स्टाफ सत्यापित (एडमिन स्वीकृति बाकी)", lang)
                        "approved" -> tr("Approved! Open Staff Portal", "स्वीकृत! स्टाफ पोर्टल से जुड़ें", lang)
                        else -> tr("Apply to become a Paid Dil Suno Listener", "दिल सुनो श्रोता बनकर जुड़ें", lang)
                    }
                    DrawerMenuItemRow(
                        icon = Icons.Filled.HeadsetMic,
                        iconTint = CrimsonPrimary,
                        title = tr("Join Our Team", "हमारी टीम से जुड़ें (Join Our Team)", lang),
                        subtitle = teamBadge,
                        testTag = "drawer_join_our_team_item",
                        onClick = { showJoinTeamDialog = true }
                    )
                }
            }

            // d) Expandable Help & Support
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .clickable { expandHelp = !expandHelp }
                            .testTag("drawer_help_expand_button"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Filled.SupportAgent, contentDescription = null, tint = CrimsonPrimary)
                            Text(tr("Help and support", "सहायता और समर्थन", lang), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }
                        Icon(if (expandHelp) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, contentDescription = null)
                    }

                    AnimatedVisibility(visible = expandHelp) {
                        Column(
                            modifier = Modifier.padding(top = 6.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                                        data = Uri.parse("mailto:${DilSePolicyText.OFFICIAL_SUPPORT_EMAIL}")
                                        putExtra(Intent.EXTRA_SUBJECT, "Dil Suno App Support")
                                    }
                                    try {
                                        context.startActivity(Intent.createChooser(emailIntent, "Email Support"))
                                    } catch (_: ActivityNotFoundException) {
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.Email, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Email: ${DilSePolicyText.OFFICIAL_SUPPORT_EMAIL}")
                            }
                            Button(
                                onClick = { showSupportModal = true },
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalNavy, contentColor = Color.White),
                                modifier = Modifier.fillMaxWidth().testTag("drawer_contact_support_button")
                            ) {
                                Icon(Icons.Filled.SupportAgent, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(tr("Contact Support (Super Admin Ticket)", "सुपर एडमिन को सहायता टिकट भेजें", lang))
                            }
                        }
                    }
                }
            }

            // Expandable Settings & Privacy
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .clickable { expandSettings = !expandSettings }
                            .testTag("drawer_settings_expand_button"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Filled.Settings, contentDescription = null, tint = RoyalNavy)
                            Text(tr("Settings and privacy", "सेटिंग्स और गोपनीयता", lang), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }
                        Icon(if (expandSettings) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, contentDescription = null)
                    }

                    AnimatedVisibility(visible = expandSettings) {
                        Column(
                            modifier = Modifier.padding(top = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Friend Chat Permission ON/OFF
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Chat, null, tint = SafeEmerald)
                                    Column {
                                        Text(
                                            text = "चैटिंग की अनुमति (Friend Chat)",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (allowFriendChat) "ON — Friends can message you" else "OFF — Friend messaging paused",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Switch(
                                    checked = allowFriendChat,
                                    onCheckedChange = { viewModel.setAllowFriendChat(it) },
                                    modifier = Modifier.testTag("drawer_chat_permission_switch")
                                )
                            }

                            HorizontalDivider()

                            // Dil Suno Privacy Policy (In-app Bilingual Viewer)
                            OutlinedButton(
                                onClick = { showLegalViewerTab = 0 },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("drawer_privacy_policy_button")
                            ) {
                                Icon(Icons.Filled.PrivacyTip, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(tr("Dil Suno Privacy Policy", "दिल सुनो गोपनीयता नीति", lang), modifier = Modifier.weight(1f))
                            }

                            // Terms, Zero-Liability & All Legal Policies (In-app Bilingual Viewer)
                            OutlinedButton(
                                onClick = { showLegalViewerTab = 1 },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("drawer_terms_policies_button")
                            ) {
                                Icon(Icons.Filled.Gavel, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    tr("Terms, Liability & All Policies", "नियम, शर्तें व सभी कानूनी नीतियाँ", lang),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            // 18+ Community Guidelines & Child Safety Policy
                            OutlinedButton(
                                onClick = { showLegalViewerTab = 2 },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("drawer_child_safety_button")
                            ) {
                                Icon(Icons.Filled.Policy, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(tr("18+ Guidelines & Child Safety Policy", "18+ कम्युनिटी व बाल सुरक्षा नीति", lang))
                            }

                            // Blocked Users
                            OutlinedButton(
                                onClick = { showBlockedUsersDialog = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.Block, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(tr("Blocked Users (${blockedUserUids.size})", "ब्लॉक किए गए लोग (${blockedUserUids.size})", lang))
                            }

                            // Language Switch
                            OutlinedButton(
                                onClick = {
                                    onToggleLang()
                                    onDismiss()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.Language, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(if (lang == AppLang.EN) "भाषा बदलें: हिंदी" else "Switch Language: English")
                            }

                            // Delete Account
                            OutlinedButton(
                                onClick = { showDeleteAccountDialog = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.DeleteForever, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    tr("Delete Account", "अकाउंट डिलीट करें", lang),
                                    color = MaterialTheme.colorScheme.error
                                )
                            }

                            // Sign Out
                            OutlinedButton(
                                onClick = {
                                    onDismiss()
                                    onSignOut()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.Logout, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(tr("Sign Out / Switch Account", "साइन आउट / अकाउंट बदलें", lang))
                            }
                        }
                    }
                }
            }

            // Bottom Card: Wallet & Quick Google Play Billing Recharge (₹100 - ₹500)
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = RoyalNavy),
                modifier = Modifier.fillMaxWidth().testTag("drawer_wallet_card")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.AccountBalanceWallet, null, tint = Color.White)
                            Column {
                                Text(
                                    text = tr("Wallet & Recharge", "वॉलेट और रिचार्ज", lang),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = tr("Call Rate: ₹100 / 30-min", "कॉल दर: ₹100 / 30 मिनट", lang),
                                    color = Color.White.copy(alpha = 0.78f),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                        Surface(color = SafeEmerald, shape = RoundedCornerShape(10.dp)) {
                            Text(
                                text = "₹$walletBalance",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    val row1 = PlayBillingManager.PLAY_BILLING_PACKS.take(3)
                    val row2 = PlayBillingManager.PLAY_BILLING_PACKS.drop(3)
                    listOf(row1, row2).forEach { packRow ->
                        if (packRow.isNotEmpty()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                packRow.forEach { pack ->
                                    Button(
                                        onClick = {
                                            playBillingManager.launchPackPurchase(
                                                activity = activity,
                                                pack = pack,
                                                isReviewerDemoAccount = isReviewerDemoAccount
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = CrimsonPrimary,
                                            contentColor = Color.White
                                        ),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(pack.fallbackPriceLabel, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
        }
    }

    // Creator Dashboard Milestones Dialog (10 shares, 5 speaking reels, 25 likes)
    if (showCreatorDialog) {
        val (shares, reels, likes) = milestones
        AlertDialog(
            onDismissRequest = { showCreatorDialog = false },
            icon = { Icon(Icons.Filled.MonetizationOn, null, tint = SafeEmerald) },
            title = { Text(tr("Creator Dashboard • Dil Suno", "क्रिएटर डैशबोर्ड", lang), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = tr(
                            "Complete these creator milestones to unlock Creator Monetization & Tips:",
                            "क्रिएटर मोनेटाइज़ेशन और टिप्स पाने के लिए ये लक्ष्य पूरे करें:",
                            lang
                        ),
                        style = MaterialTheme.typography.bodySmall
                    )
                    CreatorMilestoneBar("Shares", shares, 10L)
                    CreatorMilestoneBar("Speaking Reels", reels, 5L)
                    CreatorMilestoneBar("Likes & Loves", likes, 25L)
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.CheckCircle, null, tint = SafeEmerald, modifier = Modifier.size(18.dp))
                            Text(
                                text = if (myProfile?.monetizationApproved == true || myAccount?.monetizationStatus == "approved") {
                                    tr("Creator Monetization ACTIVE!", "क्रिएटर मोनेटाइज़ेशन सक्रिय है!", lang)
                                } else {
                                    tr("Visit Profile tab to apply once milestones complete.", "लक्ष्य पूरे होने पर प्रोफ़ाइल टैब से आवेदन करें।", lang)
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    showCreatorDialog = false
                    onDismiss()
                    onOpenProfile()
                }) {
                    Text(tr("Go to Profile", "प्रोफ़ाइल खोलें", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreatorDialog = false }) { Text(tr("Close", "बंद करें", lang)) }
            }
        )
    }

    if (showAiDialog) {
        FreeAiVoiceListenerDialog(
            viewModel = viewModel,
            lang = lang,
            onDismiss = { showAiDialog = false }
        )
    }

    if (showSavedDialog) {
        val allPosts = (postsState as? UiState.Success)?.data.orEmpty()
        val savedPosts = allPosts.filter { it.id in savedPostIds }
        AlertDialog(
            onDismissRequest = { showSavedDialog = false },
            icon = { Icon(Icons.Filled.Bookmark, null, tint = RoyalNavy) },
            title = { Text(tr("Saved Posts & Reels", "सहेजे गए पोस्ट और रील", lang), fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (savedPosts.isEmpty()) {
                        Text(
                            text = tr("No saved posts yet. Tap Save on any post or reel in the Home feed.", "अभी कोई पोस्ट सहेजी नहीं गई है। होम फ़ीड में किसी भी पोस्ट पर Save दबाएं।", lang),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    } else {
                        savedPosts.forEach { p ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(p.authorName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                                        Text(p.caption.take(80), style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (p.postType == "reel") {
                                        TextButton(onClick = {
                                            showSavedDialog = false
                                            onDismiss()
                                            onOpenReelFullscreen(p.id)
                                        }) {
                                            Text(tr("Watch", "देखें", lang))
                                        }
                                    }
                                    TextButton(onClick = { viewModel.toggleSavePost(p.id) }) {
                                        Text(tr("Remove", "हटाएं", lang))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSavedDialog = false }) { Text(tr("Close", "बंद करें", lang)) }
            }
        )
    }

    if (showMemoriesDialog) {
        val allPosts = (postsState as? UiState.Success)?.data.orEmpty()
        val myPosts = allPosts.filter { it.authorUid == viewModel.currentUserId }
        val myStories = stories.filter { it.authorUid == viewModel.currentUserId }
        AlertDialog(
            onDismissRequest = { showMemoriesDialog = false },
            icon = { Icon(Icons.Filled.History, null, tint = VelvetIndigo) },
            title = { Text(tr("Your Dil Suno Memories", "आपकी दिल सुनो यादें", lang), fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (myPosts.isEmpty() && myStories.isEmpty()) {
                        Text(
                            text = tr("Your shared posts, reels, and 24h stories will be saved here as memories.", "आपकी पोस्ट, रील और स्टोरीज़ यहाँ यादों के रूप में दिखाई देंगी।", lang),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    } else {
                        myPosts.forEach { p ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(if (p.postType == "reel") "🎬 Reel" else "📝 Post", style = MaterialTheme.typography.labelSmall, color = CrimsonPrimary, fontWeight = FontWeight.Bold)
                                    Text(p.caption.ifBlank { p.title.orEmpty() }, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        myStories.forEach { s ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("✨ 24h Story", style = MaterialTheme.typography.labelSmall, color = VelvetIndigo, fontWeight = FontWeight.Bold)
                                    Text(s.caption, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showMemoriesDialog = false }) { Text(tr("Close", "बंद करें", lang)) }
            }
        )
    }

    if (showBlockedUsersDialog) {
        val profilesByUid = remember(profiles) { profiles.associateBy { it.uid } }
        AlertDialog(
            onDismissRequest = { showBlockedUsersDialog = false },
            icon = { Icon(Icons.Filled.Block, null, tint = MaterialTheme.colorScheme.error) },
            title = { Text(tr("Blocked Users", "ब्लॉक किए गए लोग", lang), fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (blockedUserUids.isEmpty()) {
                        Text(tr("No blocked users.", "कोई यूज़र ब्लॉक नहीं है।", lang), style = MaterialTheme.typography.bodyMedium)
                    } else {
                        blockedUserUids.forEach { uid ->
                            val name = SecurityUtils.resolveDisplayName(profilesByUid[uid]?.fullName, fallback = "Blocked Member")
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(name, fontWeight = FontWeight.Bold)
                                    OutlinedButton(onClick = { viewModel.unblockUser(uid, name) }) {
                                        Text(tr("Unblock", "अनब्लॉक", lang))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBlockedUsersDialog = false }) { Text(tr("Close", "बंद करें", lang)) }
            }
        )
    }

    if (showSupportModal) {
        CustomerSupportModal(
            viewModel = viewModel,
            appConfig = appConfig,
            lang = lang,
            onDismiss = { showSupportModal = false }
        )
    }

    showLegalViewerTab?.let { tab ->
        LegalPoliciesViewerDialog(
            initialTab = tab,
            lang = lang,
            onDismiss = { showLegalViewerTab = null }
        )
    }

    if (showDeleteAccountDialog) {
        val hasPassword = !myAccount?.passwordHash.isNullOrBlank()
        AccountDeletionDialog(
            viewModel = viewModel,
            hasPassword = hasPassword,
            lang = lang,
            onDismiss = { showDeleteAccountDialog = false },
            onDeleted = {
                showDeleteAccountDialog = false
                onDismiss()
                onAccountDeleted()
            }
        )
    }

    if (showJoinTeamDialog) {
        ListenerApplicationDialog(
            existingApplication = myListenerApp,
            defaultName = myDisplayName,
            defaultEmail = myAccount?.email.orEmpty(),
            lang = lang,
            onSubmit = { name, email, phone, city, motivation ->
                viewModel.submitListenerApplication(name, email, phone, city, motivation) {
                    showJoinTeamDialog = false
                }
            },
            onDismiss = { showJoinTeamDialog = false }
        )
    }
}

@Composable
private fun DrawerMenuItemRow(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            color = iconTint.copy(alpha = 0.14f),
            shape = CircleShape,
            modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = title, tint = iconTint, modifier = Modifier.size(20.dp))
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun CreatorMilestoneBar(label: String, current: Long, target: Long) {
    val progress = (current.toFloat() / target.toFloat()).coerceIn(0f, 1f)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Text("$current / $target", style = MaterialTheme.typography.labelMedium, color = CrimsonPrimary, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(6.dp)),
            color = if (current >= target) SafeEmerald else CrimsonPrimary
        )
    }
}

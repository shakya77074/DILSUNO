package com.dilsuno.app.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Copyright
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.dilsuno.app.core.MusicTrackOption
import com.dilsuno.app.ui.components.ReelMusicMixerPanel
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.content.pm.PackageManager
import coil.compose.AsyncImage
import com.dilsuno.app.R
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.MediaUploadValidator
import com.dilsuno.app.core.RoyaltyFreeMusicLibrary
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.PostItem
import com.dilsuno.app.data.model.PublicProfile
import com.dilsuno.app.data.model.StoryItem
import com.dilsuno.app.data.model.UiState
import com.dilsuno.app.ui.components.ClickableHashtagAndMentionText
import com.dilsuno.app.ui.components.CommunityGuidelines18PlusDialog
import com.dilsuno.app.ui.components.DilSunoMenuDrawerSheet
import com.dilsuno.app.ui.components.EditPostCaptionDialog
import com.dilsuno.app.ui.components.HashtagFeedDialog
import com.dilsuno.app.ui.components.POST_BG_STYLES
import com.dilsuno.app.ui.components.PostThreeDotActionMenu
import com.dilsuno.app.ui.components.ProminentPermissionDisclosureDialog
import com.dilsuno.app.ui.components.ReportContentReasonDialog
import com.dilsuno.app.ui.components.resolvePostBgColors
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.RoyalNavy
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.VelvetIndigo
import com.dilsuno.app.viewmodel.MainAppViewModel
import java.io.File

private data class DemoStoryVisual(
    val story: StoryItem,
    val drawableRes: Int
)

private data class DemoFeedShowcase(
    val post: PostItem,
    val drawableRes: Int
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeFeedScreen(
    viewModel: MainAppViewModel,
    lang: AppLang,
    onOpenDilSeCall: () -> Unit,
    onToggleLang: () -> Unit,
    onOpenCreateReel: () -> Unit = {},
    onOpenReelFullscreen: (String) -> Unit = {},
    onSignOut: () -> Unit = {},
    onOpenProfile: () -> Unit = {},
    onOpenFriends: () -> Unit = {},
    onAccountDeleted: () -> Unit = {},
    onOpenSmartListenerCall: (Boolean) -> Unit = { onOpenDilSeCall() }
) {
    val postsState by viewModel.postsState.collectAsStateWithLifecycle()
    val stories by viewModel.stories.collectAsStateWithLifecycle()
    val profiles by viewModel.communityProfiles.collectAsStateWithLifecycle()
    val myProfile by viewModel.myProfile.collectAsStateWithLifecycle()
    val appConfig by viewModel.appConfig.collectAsStateWithLifecycle()
    val isScanningAi by viewModel.isScanningAi.collectAsStateWithLifecycle()
    val hasAcceptedGuidelines by viewModel.hasAcceptedCommunityGuidelines18Plus.collectAsStateWithLifecycle()
    val savedPostIds by viewModel.savedPostIds.collectAsStateWithLifecycle()
    val availableMusicTracks by viewModel.availableMusicTracks.collectAsStateWithLifecycle()

    var showCreatePostSheet by remember { mutableStateOf(false) }
    var showCreateStoryDialog by remember { mutableStateOf(false) }
    var showPlusMenu by remember { mutableStateOf(false) }
    var showMenuSheet by remember { mutableStateOf(false) }
    var showSearchBar by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var activeStory by remember { mutableStateOf<StoryItem?>(null) }
    var activeDemoDrawable by remember { mutableStateOf<Int?>(null) }
    var commentPost by remember { mutableStateOf<PostItem?>(null) }
    var reportTargetPost by remember { mutableStateOf<PostItem?>(null) }
    var pendingGuidelinesAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var activeHashtagFeed by remember { mutableStateOf<String?>(null) }
    var editingCaptionPost by remember { mutableStateOf<PostItem?>(null) }

    fun runWithGuidelinesGate(action: () -> Unit) {
        if (hasAcceptedGuidelines) {
            action()
        } else {
            pendingGuidelinesAction = action
        }
    }

    val creatorProfilesByUid = remember(profiles) { profiles.associateBy { it.uid } }
    val friendLinks by viewModel.friendLinks.collectAsStateWithLifecycle()
    val acceptedFriendUids = remember(friendLinks, viewModel.currentUserId) {
        friendLinks.filter { it.status == "accepted" }
            .flatMap { it.participantUids }
            .filter { it != viewModel.currentUserId }
            .toSet()
    }
    val myDisplayName = viewModel.resolveDisplayName("Dil Suno")
    val myAvatar = myProfile?.avatarUri

    val showcaseStories = remember {
        listOf(
            DemoStoryVisual(
                StoryItem(id = "demo_s1", authorUid = "s1", authorName = "Arjun Verma", caption = "सुबह की सकारात्मक शुरुआत • ❤️ दिल सुनो"),
                R.drawable.img_community_hero
            ),
            DemoStoryVisual(
                StoryItem(id = "demo_s2", authorUid = "s2", authorName = "Meera Nair", caption = "आज मन हल्का है — बात करके अच्छा लगा!"),
                R.drawable.img_dil_se_banner
            ),
            DemoStoryVisual(
                StoryItem(id = "demo_s3", authorUid = "s3", authorName = "Rohan Joshi", caption = "जयपुर शाम की ताज़ा झलक"),
                R.drawable.img_header_heart_logo
            ),
            DemoStoryVisual(
                StoryItem(id = "demo_s4", authorUid = "s4", authorName = "Kavita Yadav", caption = "सकारात्मक विचार आपके दिन के लिए"),
                R.drawable.img_community_hero
            )
        )
    }

    val showcasePosts = remember {
        listOf(
            DemoFeedShowcase(
                post = PostItem(
                    id = "demo_post_reel_1",
                    authorUid = "demo_author_1",
                    authorName = "Ananya Iyer",
                    postType = "reel",
                    title = "मन की बात साझा करें ❤️",
                    caption = "दिल सुनो पर हर आवाज़ और भावना सुरक्षित है। नई रील देखें या नीचे कॉल बटन से तुरंत जुड़ें!",
                    city = null,
                    musicTrack = "Calm Acoustic Breeze",
                    loveCount = 64L,
                    likesCount = 112L,
                    commentsCount = 18L,
                    viewsCount = 950L
                ),
                drawableRes = R.drawable.img_community_hero
            ),
            DemoFeedShowcase(
                post = PostItem(
                    id = "demo_post_news_2",
                    authorUid = "demo_author_2",
                    authorName = "Vikram Rathore",
                    postType = "news",
                    title = "सामुदायिक मिलन व सुकून शाम",
                    caption = "आज शाम दोस्तों से जुड़ें और अपने अनुभव साझा करें। #DilKaho #Bharat",
                    city = null,
                    likesCount = 87L,
                    loveCount = 41L,
                    commentsCount = 11L,
                    viewsCount = 610L
                ),
                drawableRes = R.drawable.img_dil_se_banner
            )
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .align(Alignment.TopCenter),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            // 1. FACEBOOK-STYLE TOP HEADER: Menu (☰) + Bold "Dil Suno" on Left | Plus (+) Dropdown + Search (🔍) on Right
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            IconButton(
                                onClick = { showMenuSheet = true },
                                modifier = Modifier.testTag("home_menu_button")
                            ) {
                                Icon(Icons.Filled.Menu, contentDescription = "Menu")
                            }
                            Text(
                                text = "Dil Suno",
                                color = CrimsonPrimary,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.ExtraBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.testTag("home_header_heart_logo")
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box {
                                Surface(
                                    color = CrimsonPrimary,
                                    shape = CircleShape,
                                    shadowElevation = 2.dp,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    IconButton(
                                        onClick = { showPlusMenu = true },
                                        modifier = Modifier.testTag("header_create_button")
                                    ) {
                                        Icon(
                                            Icons.Filled.Add,
                                            contentDescription = tr("Create Reel or Post", "रील या पोस्ट बनाएं", lang),
                                            tint = Color.White
                                        )
                                    }
                                }
                                DropdownMenu(
                                    expanded = showPlusMenu,
                                    onDismissRequest = { showPlusMenu = false },
                                    modifier = Modifier.testTag("header_create_dropdown")
                                ) {
                                    DropdownMenuItem(
                                        text = { Text(tr("Upload Reel / Video", "रील / वीडियो अपलोड करें", lang), fontWeight = FontWeight.SemiBold) },
                                        leadingIcon = { Icon(Icons.Filled.VideoLibrary, contentDescription = null, tint = CrimsonPrimary) },
                                        onClick = {
                                            showPlusMenu = false
                                            runWithGuidelinesGate { onOpenCreateReel() }
                                        },
                                        modifier = Modifier.testTag("menu_upload_reel")
                                    )
                                    DropdownMenuItem(
                                        text = { Text(tr("Create Post / Photo", "पोस्ट / फ़ोटो बनाएं", lang), fontWeight = FontWeight.SemiBold) },
                                        leadingIcon = { Icon(Icons.Filled.PhotoLibrary, contentDescription = null, tint = SafeEmerald) },
                                        onClick = {
                                            showPlusMenu = false
                                            runWithGuidelinesGate { showCreatePostSheet = true }
                                        },
                                        modifier = Modifier.testTag("menu_create_post")
                                    )
                                }
                            }
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = CircleShape,
                                modifier = Modifier.size(40.dp)
                            ) {
                                IconButton(
                                    onClick = { showSearchBar = !showSearchBar },
                                    modifier = Modifier.testTag("header_search_button")
                                ) {
                                    Icon(Icons.Filled.Search, contentDescription = tr("Search Friends & Posts", "दोस्त और पोस्ट खोजें", lang))
                                }
                            }
                        }
                    }

                    if (showSearchBar) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text(tr("Search friends, people, or posts...", "दोस्त, लोग या पोस्ट खोजें...", lang)) },
                            leadingIcon = { Icon(Icons.Filled.Search, null) },
                            trailingIcon = {
                                IconButton(onClick = {
                                    searchQuery = ""
                                    showSearchBar = false
                                }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Close Search")
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp)
                                .testTag("home_search_input")
                        )
                    }
                }
            }

            // Live Super Admin Announcement Banner
            val bannerText = if (lang == AppLang.HI) {
                appConfig.announcementBannerHi?.ifBlank { appConfig.announcementBannerEn }
            } else {
                appConfig.announcementBannerEn?.ifBlank { appConfig.announcementBannerHi }
            }
            if (appConfig.announcementActive && !bannerText.isNullOrBlank()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .testTag("admin_announcement_banner")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Filled.Campaign, contentDescription = "Announcement", tint = CrimsonPrimary)
                            Text(
                                text = bannerText,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }

            // 3. CUSTOM PILL-ROUNDED VERTICAL STORY CARDS CAROUSEL
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // First Card: "स्टोरी जोड़ें"
                    item {
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            modifier = Modifier
                                .width(104.dp)
                                .height(166.dp)
                                .clickable { runWithGuidelinesGate { showCreateStoryDialog = true } }
                                .testTag("add_story_button")
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                Column(modifier = Modifier.fillMaxSize()) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(0.68f)
                                            .background(Brush.verticalGradient(listOf(CrimsonPrimary, VelvetIndigo))),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (!myAvatar.isNullOrBlank()) {
                                            AsyncImage(
                                                model = myAvatar,
                                                contentDescription = myDisplayName,
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        } else {
                                            Text(
                                                text = myDisplayName.take(2).uppercase(),
                                                color = Color.White,
                                                style = MaterialTheme.typography.headlineSmall,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(0.32f)
                                            .background(MaterialTheme.colorScheme.surface)
                                            .padding(top = 12.dp, start = 6.dp, end = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "स्टोरी जोड़ें",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }
                                }
                                Surface(
                                    color = CrimsonPrimary,
                                    shape = CircleShape,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .align(Alignment.Center)
                                        .padding(top = 0.dp)
                                        .border(2.5.dp, Color.White, CircleShape)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Filled.Add, contentDescription = "Add Story", tint = Color.White, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }

                    if (stories.isNotEmpty()) {
                        items(stories, key = { it.id }) { story ->
                            val storyAuthorName = SecurityUtils.resolveDisplayName(
                                creatorProfilesByUid[story.authorUid]?.fullName,
                                story.authorName
                            )
                            PillStoryCard(
                                authorName = storyAuthorName,
                                mediaUri = story.mediaUri,
                                sampleRes = null,
                                onClick = {
                                    activeDemoDrawable = null
                                    activeStory = story
                                }
                            )
                        }
                    } else {
                        items(showcaseStories, key = { it.story.id }) { demo ->
                            PillStoryCard(
                                authorName = demo.story.authorName,
                                mediaUri = null,
                                sampleRes = demo.drawableRes,
                                onClick = {
                                    activeDemoDrawable = demo.drawableRes
                                    activeStory = demo.story
                                }
                            )
                        }
                    }
                }
            }

            // 3. PEOPLE SEARCH RESULTS (when Searching via 🔍 icon)
            val queryTrimmed = searchQuery.trim()
            if (queryTrimmed.isNotBlank()) {
                val matchedPeople = profiles.filter { p ->
                    p.uid != viewModel.currentUserId &&
                        !p.isBanned &&
                        (p.fullName.contains(queryTrimmed, ignoreCase = true) ||
                            p.currentCity.orEmpty().contains(queryTrimmed, ignoreCase = true))
                }
                if (matchedPeople.isNotEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = tr("People Found (${matchedPeople.size})", "मिले हुए लोग (${matchedPeople.size})", lang),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = RoyalNavy
                            )
                            matchedPeople.take(8).forEach { person ->
                                val existingLink = friendLinks.firstOrNull { person.uid in it.participantUids }
                                Card(
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(38.dp)
                                                    .clip(CircleShape)
                                                    .background(CrimsonPrimary.copy(alpha = 0.14f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (!person.avatarUri.isNullOrBlank()) {
                                                    AsyncImage(
                                                        model = person.avatarUri,
                                                        contentDescription = person.fullName,
                                                        modifier = Modifier.fillMaxSize(),
                                                        contentScale = ContentScale.Crop
                                                    )
                                                } else {
                                                    Text(person.fullName.take(2).uppercase(), color = CrimsonPrimary, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                            Column {
                                                Text(person.fullName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                                if (!person.currentCity.isNullOrBlank()) {
                                                    Text(person.currentCity, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                            }
                                        }
                                        when {
                                            existingLink?.status == "accepted" -> {
                                                TextButton(onClick = onOpenFriends) {
                                                    Text(tr("Friends", "दोस्त", lang), color = SafeEmerald, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                            existingLink?.status == "pending" -> {
                                                Text(
                                                    tr("Pending", "लंबित", lang),
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.padding(horizontal = 8.dp)
                                                )
                                            }
                                            else -> {
                                                Button(
                                                    onClick = { viewModel.sendFriendRequest(person.uid) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                                                    shape = RoundedCornerShape(10.dp)
                                                ) {
                                                    Icon(Icons.Filled.PersonAdd, null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(4.dp))
                                                    Text(tr("Add Friend", "जोड़ें", lang), style = MaterialTheme.typography.labelMedium)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. PEOPLE YOU MAY KNOW & SUGGESTED FRIENDS SOCIAL CAROUSEL (Strictly Separate from Anonymous Calls)
            item {
                com.dilsuno.app.ui.components.PeopleYouMayKnowSection(
                    viewModel = viewModel,
                    lang = lang
                )
            }

            // 5. UNIFIED SCROLLING FEED (Friends' posts automatically boosted to the top)
            when (val state = postsState) {
                is UiState.Loading -> {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                }
                is UiState.Error -> {
                    item {
                        Card(
                            modifier = Modifier.padding(16.dp).fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                        ) {
                            Text(
                                text = state.message,
                                modifier = Modifier.padding(16.dp),
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
                is UiState.Success -> {
                    val query = searchQuery.trim()
                    val visibleFeedPosts = state.data.filter { !it.copyrightClaimActive }
                    val boostedUnified = visibleFeedPosts.sortedWith(
                        compareByDescending<PostItem> { it.authorUid in acceptedFriendUids }
                            .thenByDescending { it.authorUid == viewModel.currentUserId }
                    )
                    val filteredLive = if (query.isBlank()) {
                        boostedUnified
                    } else {
                        boostedUnified.filter { p ->
                            p.caption.contains(query, ignoreCase = true) ||
                                p.title.orEmpty().contains(query, ignoreCase = true) ||
                                p.authorName.contains(query, ignoreCase = true) ||
                                p.city.orEmpty().contains(query, ignoreCase = true)
                        }
                    }

                    if (filteredLive.isNotEmpty()) {
                        items(filteredLive, key = { it.id }) { post ->
                            val authorProfile = creatorProfilesByUid[post.authorUid]
                            val authorName = SecurityUtils.resolveDisplayName(authorProfile?.fullName, post.authorName)
                            PostFeedCard(
                                post = post,
                                authorProfile = authorProfile,
                                lang = lang,
                                isSaved = post.id in savedPostIds,
                                onToggleSave = { viewModel.toggleSavePost(post.id) },
                                onSharePost = { viewModel.recordPostShare(post) },
                                onReact = { field, emoji -> viewModel.reactToPost(post, field, emoji) },
                                onOpenComments = { commentPost = post },
                                onOpenReel = {
                                    if (post.postType == "reel" || post.postType == "video") {
                                        onOpenReelFullscreen(post.id)
                                    }
                                },
                                onHashtagClick = { activeHashtagFeed = it },
                                onEditCaption = if (post.authorUid == viewModel.currentUserId) {
                                    { editingCaptionPost = post }
                                } else null,
                                onReportContent = { reportTargetPost = post },
                                onBlockUser = { viewModel.blockUser(post.authorUid, authorName) }
                            )
                        }
                    } else if (query.isBlank()) {
                        items(showcasePosts, key = { it.post.id }) { showcase ->
                            PostFeedCard(
                                post = showcase.post,
                                authorProfile = null,
                                sampleDrawableRes = showcase.drawableRes,
                                lang = lang,
                                isSaved = showcase.post.id in savedPostIds,
                                onToggleSave = { viewModel.toggleSavePost(showcase.post.id) },
                                onSharePost = { viewModel.recordPostShare(showcase.post) },
                                onReact = { _, _ -> runWithGuidelinesGate { showCreatePostSheet = true } },
                                onOpenComments = { runWithGuidelinesGate { showCreatePostSheet = true } },
                                onOpenReel = { onOpenReelFullscreen(showcase.post.id) },
                                onHashtagClick = { activeHashtagFeed = it },
                                onReportContent = { reportTargetPost = showcase.post },
                                onBlockUser = { viewModel.blockUser(showcase.post.authorUid, showcase.post.authorName) }
                            )
                        }
                    } else {
                        item {
                            Card(
                                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Text(
                                    text = tr("No posts matched \"$query\".", "\"$query\" से कोई पोस्ट नहीं मिली।", lang),
                                    modifier = Modifier.padding(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Facebook-Style 3-Line Menu Drawer (100% Dil Suno branding)
    if (showMenuSheet) {
        DilSunoMenuDrawerSheet(
            viewModel = viewModel,
            lang = lang,
            onDismiss = { showMenuSheet = false },
            onOpenProfile = onOpenProfile,
            onOpenFriends = onOpenFriends,
            onOpenSmartListenerCall = onOpenSmartListenerCall,
            onOpenReelFullscreen = onOpenReelFullscreen,
            onToggleLang = onToggleLang,
            onSignOut = onSignOut,
            onAccountDeleted = onAccountDeleted
        )
    }

    // Create Post / News / Reel / Video Sheet
    if (showCreatePostSheet) {
        CreatePostModal(
            isScanningAi = isScanningAi,
            lang = lang,
            availableMusicTracks = availableMusicTracks,
            onDismiss = { showCreatePostSheet = false },
            onSecurityError = { msg -> viewModel.reportSecurityError(msg) },
            onPublish = { type, title, caption, city, mediaUri, music, bgStyleId, editorSummary, extraScanText, extraMediaUris ->
                viewModel.createPost(
                    postType = type,
                    title = title,
                    caption = caption,
                    city = city,
                    mediaUri = mediaUri,
                    musicTrack = music,
                    bgStyleId = bgStyleId,
                    editorSummary = editorSummary,
                    extraLayerScanText = extraScanText,
                    extraMediaUris = extraMediaUris
                ) {
                    showCreatePostSheet = false
                }
            }
        )
    }

    // Create 24h Story Dialog
    if (showCreateStoryDialog) {
        CreateStoryDialog(
            isScanningAi = isScanningAi,
            lang = lang,
            onDismiss = { showCreateStoryDialog = false },
            onSecurityError = { msg -> viewModel.reportSecurityError(msg) },
            onPublish = { caption, uri ->
                viewModel.createStory(caption, uri, "#E11D48") {
                    showCreateStoryDialog = false
                }
            }
        )
    }

    // Story Viewer Dialog
    activeStory?.let { story ->
        val storyAuthorName = SecurityUtils.resolveDisplayName(
            creatorProfilesByUid[story.authorUid]?.fullName,
            story.authorName
        )
        AlertDialog(
            onDismissRequest = { activeStory = null },
            title = { Text("$storyAuthorName • 24h Story") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (activeDemoDrawable != null) {
                        Image(
                            painter = painterResource(id = activeDemoDrawable!!),
                            contentDescription = story.caption,
                            modifier = Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(16.dp)),
                            contentScale = ContentScale.Crop
                        )
                    } else if (!story.mediaUri.isNullOrBlank()) {
                        AsyncImage(
                            model = story.mediaUri,
                            contentDescription = story.caption,
                            modifier = Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(16.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Text(story.caption, style = MaterialTheme.typography.bodyLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            viewModel.submitReport("story", story.id, story.authorUid, "violation", "Story policy violation")
                            activeStory = null
                        }) {
                            Icon(Icons.Filled.Flag, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(tr("Report Violation", "रिपोर्ट करें", lang))
                        }
                        TextButton(onClick = {
                            viewModel.submitReport("story", story.id, story.authorUid, "copyright", "Story copyright claim")
                            activeStory = null
                        }) {
                            Icon(Icons.Filled.Copyright, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(tr("Copyright", "कॉपीराइट", lang))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { activeStory = null }) { Text(tr("Close", "बंद करें", lang)) }
            }
        )
    }

    // Comments Sheet
    commentPost?.let { post ->
        val comments by viewModel.observeCommentsForPost(post.id).collectAsStateWithLifecycle(emptyList())
        var commentText by remember { mutableStateOf("") }
        ModalBottomSheet(onDismissRequest = { commentPost = null }) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(tr("Comments (AI-Moderated)", "टिप्पणियाँ (AI-सत्यापित)", lang), style = MaterialTheme.typography.titleLarge)
                comments.forEach { c ->
                    val commenterName = SecurityUtils.resolveDisplayName(
                        creatorProfilesByUid[c.authorUid]?.fullName,
                        c.authorName
                    )
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(commenterName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                            Text(c.text, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = commentText,
                        onValueChange = { commentText = it },
                        label = { Text(tr("Write a respectful comment...", "सभ्य टिप्पणी लिखें...", lang)) },
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            val txt = commentText
                            runWithGuidelinesGate {
                                commentText = ""
                                viewModel.addComment(post, txt)
                            }
                        },
                        enabled = !isScanningAi
                    ) {
                        Icon(Icons.Filled.Send, contentDescription = "Send Comment")
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // Standard Google Play UGC Report Content Dialog (Nudity, Harassment, Spam, Child Safety)
    reportTargetPost?.let { target ->
        val targetAuthorName = SecurityUtils.resolveDisplayName(
            creatorProfilesByUid[target.authorUid]?.fullName,
            target.authorName
        )
        ReportContentReasonDialog(
            lang = lang,
            onSelectReason = { reasonKey, details ->
                val combinedReason = if (details.isNotBlank()) "$reasonKey — $details" else reasonKey
                viewModel.submitReport(
                    targetType = target.postType.ifBlank { "post" },
                    targetId = target.id,
                    targetAuthorUid = target.authorUid,
                    reportType = reasonKey,
                    reason = combinedReason,
                    targetAuthorName = targetAuthorName,
                    targetMediaUri = target.mediaUri,
                    targetCaption = target.title?.takeIf { it.isNotBlank() }?.let { "$it — ${target.caption}" } ?: target.caption
                )
                reportTargetPost = null
            },
            onDismiss = { reportTargetPost = null }
        )
    }

    // Mandatory Community Guidelines & 18+ Policy Gate before uploading any post, story, reel, or comment
    if (pendingGuidelinesAction != null) {
        CommunityGuidelines18PlusDialog(
            lang = lang,
            onAccept = {
                viewModel.acceptCommunityGuidelines18Plus()
                val action = pendingGuidelinesAction
                pendingGuidelinesAction = null
                action?.invoke()
            },
            onDismiss = { pendingGuidelinesAction = null }
        )
    }

    activeHashtagFeed?.let { hashtag ->
        val allPosts = (postsState as? UiState.Success)?.data.orEmpty() + showcasePosts.map { it.post }
        HashtagFeedDialog(
            hashtag = hashtag,
            allPosts = allPosts,
            lang = lang,
            onOpenReel = onOpenReelFullscreen,
            onDismiss = { activeHashtagFeed = null }
        )
    }

    editingCaptionPost?.let { target ->
        EditPostCaptionDialog(
            initialCaption = target.caption,
            lang = lang,
            isScanning = isScanningAi,
            onSave = { updated ->
                viewModel.editPostCaption(target, updated) {
                    editingCaptionPost = null
                }
            },
            onDismiss = { editingCaptionPost = null }
        )
    }

}

@Composable
fun NotificationsScreen(
    viewModel: MainAppViewModel,
    lang: AppLang
) {
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val profiles by viewModel.communityProfiles.collectAsStateWithLifecycle()
    val profilesByUid = remember(profiles) { profiles.associateBy { it.uid } }

    LazyColumn(
        modifier = Modifier
            .widthIn(max = 640.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = tr("Notifications • सूचनाएं", "सूचनाएं • Notifications", lang),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }
        if (notifications.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Text(
                        text = tr("No notifications yet. Activity on your posts, Reels, and friends will appear here.", "अभी कोई सूचना नहीं है। पोस्ट, रील व मित्रों की गतिविधि यहाँ दिखेगी।", lang),
                        modifier = Modifier.padding(20.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(notifications, key = { it.id }) { n ->
                val actorName = SecurityUtils.resolveDisplayName(
                    profilesByUid[n.actorUid]?.fullName,
                    n.actorName
                )
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.markNotificationRead(n.id) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (n.isRead) MaterialTheme.colorScheme.surface
                        else CrimsonPrimary.copy(alpha = 0.1f)
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(actorName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text(n.message, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun PillStoryCard(
    authorName: String,
    mediaUri: String?,
    sampleRes: Int?,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .width(104.dp)
            .height(166.dp)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(VelvetIndigo, RoyalNavy)))
        ) {
            if (sampleRes != null) {
                Image(
                    painter = painterResource(id = sampleRes),
                    contentDescription = authorName,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else if (!mediaUri.isNullOrBlank()) {
                AsyncImage(
                    model = mediaUri,
                    contentDescription = authorName,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Black.copy(alpha = 0.25f), Color.Transparent, Color.Black.copy(alpha = 0.72f))
                        )
                    )
            )
            // Top-left Circular Avatar Ring
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .size(34.dp)
                    .border(2.dp, CrimsonPrimary, CircleShape)
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(VelvetIndigo),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = authorName.take(2).uppercase(),
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = authorName,
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
            )
        }
    }
}

@Composable
fun PostFeedCard(
    post: PostItem,
    authorProfile: PublicProfile?,
    lang: AppLang,
    sampleDrawableRes: Int? = null,
    isSaved: Boolean = false,
    onToggleSave: () -> Unit = {},
    onSharePost: () -> Unit = {},
    onReact: (String, String) -> Unit,
    onOpenComments: () -> Unit,
    onOpenReel: () -> Unit = {},
    onHashtagClick: (String) -> Unit = {},
    onEditCaption: (() -> Unit)? = null,
    onReportContent: () -> Unit,
    onBlockUser: () -> Unit
) {
    val context = LocalContext.current
    val authorDisplayName = SecurityUtils.resolveDisplayName(authorProfile?.fullName, post.authorName)
    val authorDisplayAvatar = authorProfile?.avatarUri?.takeIf { it.isNotBlank() } ?: post.authorAvatar
    var isReelMuted by remember { mutableStateOf(true) }

    val isVideo = remember(post.mediaUri) {
        val u = post.mediaUri.orEmpty()
        if (u.isBlank()) false
        else {
            val mime = runCatching { context.contentResolver.getType(Uri.parse(u)) }.getOrNull().orEmpty()
            mime.startsWith("video") || u.endsWith(".mp4", true) || u.endsWith(".mov", true)
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(CrimsonPrimary.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!authorDisplayAvatar.isNullOrBlank()) {
                            AsyncImage(
                                model = authorDisplayAvatar,
                                contentDescription = authorDisplayName,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Text(authorDisplayName.take(2).uppercase(), color = CrimsonPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                    Column {
                        Text(authorDisplayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Surface(
                                color = if (post.postType == "reel") CrimsonPrimary.copy(alpha = 0.14f) else MaterialTheme.colorScheme.secondaryContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = if (post.postType == "reel") "🎬 REEL" else post.postType.uppercase(),
                                    color = if (post.postType == "reel") CrimsonPrimary else MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (post.hasAiLabel) {
                                Surface(
                                    color = VelvetIndigo.copy(alpha = 0.14f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "AI Info",
                                        color = VelvetIndigo,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
                PostThreeDotActionMenu(
                    lang = lang,
                    testTagPrefix = "post_${post.id}",
                    onEditCaption = onEditCaption,
                    onReportContent = onReportContent,
                    onBlockUser = onBlockUser
                )
            }

            if (!post.title.isNullOrBlank()) {
                Text(post.title, style = MaterialTheme.typography.titleLarge)
            }
            val bgColors = remember(post.bgStyleId, post.mediaUri, sampleDrawableRes) {
                if (sampleDrawableRes == null && post.mediaUri.isNullOrBlank()) {
                    resolvePostBgColors(post.bgStyleId)
                } else null
            }
            if (post.caption.isNotBlank()) {
                if (bgColors != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 190.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Brush.linearGradient(bgColors))
                            .padding(20.dp)
                            .testTag("colored_bg_post_${post.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = post.caption,
                            color = Color.White,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                } else {
                    ClickableHashtagAndMentionText(
                        text = post.caption,
                        textColor = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.bodyLarge,
                        onHashtagClick = onHashtagClick
                    )
                }
            }
            if (!post.musicTrack.isNullOrBlank() && post.musicTrack != "none") {
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.LibraryMusic, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(post.musicTrack, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (!post.editorSummary.isNullOrBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.MovieCreation, null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("VN Studio: ${post.editorSummary}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            if (sampleDrawableRes != null || !post.mediaUri.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(RoyalNavy)
                        .clickable {
                            if (post.postType == "reel" || post.postType == "video") onOpenReel()
                        }
                ) {
                    if (sampleDrawableRes != null) {
                        Image(
                            painter = painterResource(id = sampleDrawableRes),
                            contentDescription = post.title ?: post.caption,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else if (isVideo) {
                        com.dilsuno.app.ui.components.TextureVideoPlayer(
                            videoUri = post.mediaUri.orEmpty(),
                            volume = if (isReelMuted) 0f else 1f,
                            isPlaying = true,
                            isLooping = true,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        AsyncImage(
                            model = post.mediaUri,
                            contentDescription = post.title ?: post.caption,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }

                    if (post.postType == "reel" || post.postType == "video") {
                        Surface(
                            color = Color.Black.copy(alpha = 0.5f),
                            shape = CircleShape,
                            modifier = Modifier.align(Alignment.Center)
                        ) {
                            Icon(
                                Icons.Filled.PlayCircle,
                                contentDescription = "Open Fullscreen Reel",
                                tint = Color.White,
                                modifier = Modifier.size(50.dp).padding(4.dp)
                            )
                        }
                        IconButton(
                            onClick = { isReelMuted = !isReelMuted },
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.6f))
                        ) {
                            Icon(
                                if (isReelMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Mute Reel",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = { onReact("likesCount", "👍") },
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("post_like_button_${post.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ThumbUp,
                        contentDescription = tr("Like", "लाइक", lang),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = "${post.likesCount}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                TextButton(
                    onClick = onOpenComments,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("post_comment_button_${post.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ChatBubbleOutline,
                        contentDescription = tr("Comment", "टिप्पणी", lang),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = "${post.commentsCount}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                TextButton(
                    onClick = {
                        onSharePost()
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "$authorDisplayName on ❤️ दिल सुनो • Dil Suno: ${post.title ?: ""} ${post.caption}")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share via"))
                    },
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("post_share_button_${post.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = tr("Share", "शेयर", lang),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = tr("Share", "शेयर", lang),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                TextButton(
                    onClick = onToggleSave,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("post_save_button_${post.id}")
                ) {
                    Icon(
                        imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = tr("Save", "सहेजें", lang),
                        tint = if (isSaved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = if (isSaved) tr("Saved", "सहेजा", lang) else tr("Save", "सहेजें", lang),
                        color = if (isSaved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreatePostModal(
    isScanningAi: Boolean,
    lang: AppLang,
    availableMusicTracks: List<MusicTrackOption> = RoyaltyFreeMusicLibrary.tracks,
    onDismiss: () -> Unit,
    onSecurityError: (String) -> Unit,
    onPublish: (
        type: String,
        title: String,
        caption: String,
        city: String,
        mediaUri: String?,
        musicTrack: String?,
        bgStyleId: String?,
        editorSummary: String?,
        extraScanText: String,
        extraMediaUris: List<String>
    ) -> Unit
) {
    val context = LocalContext.current
    var postType by remember { mutableStateOf("news") }
    var title by remember { mutableStateOf("") }
    var caption by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var selectedBgStyleId by remember { mutableStateOf("none") }
    var selectedMediaUri by remember { mutableStateOf<String?>(null) }
    var uploadError by remember { mutableStateOf<String?>(null) }
    var selectedTrackId by remember { mutableStateOf("none") }
    var customAudioUri by remember { mutableStateOf<String?>(null) }
    var customAudioLabel by remember { mutableStateOf<String?>(null) }
    var originalVol by remember { mutableFloatStateOf(0.85f) }
    var musicVol by remember { mutableFloatStateOf(0.8f) }
    var showVnStudio by remember { mutableStateOf(false) }
    var studioResult by remember { mutableStateOf<VnStudioEditResult?>(null) }

    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var showCameraDisclosure by remember { mutableStateOf(false) }

    val mediaPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { picked ->
            MediaUploadValidator.validatePickedMedia(
                context = context,
                uri = picked,
                allowVideo = true,
                lang = lang
            ).onSuccess { validated ->
                uploadError = null
                selectedMediaUri = validated.uriString
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Unsafe or oversized file rejected."
                uploadError = msg
                onSecurityError(msg)
            }
        }
    }

    val captureVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CaptureVideo()
    ) { success ->
        if (success) {
            pendingCameraUri?.let { recorded ->
                MediaUploadValidator.validatePickedMedia(
                    context = context,
                    uri = recorded,
                    allowVideo = true,
                    lang = lang
                ).onSuccess { validated ->
                    uploadError = null
                    selectedMediaUri = validated.uriString
                }.onFailure { err ->
                    val msg = err.localizedMessage ?: "Recorded video exceeds 25 MB limit."
                    uploadError = msg
                    onSecurityError(msg)
                }
            }
        }
    }

    fun launchCameraVideoCapture() {
        val file = File(context.cacheDir, "vid_${System.currentTimeMillis()}.mp4")
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        pendingCameraUri = uri
        captureVideoLauncher.launch(uri)
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            launchCameraVideoCapture()
        }
    }

    DisposableEffect(Unit) {
        onDispose { RoyaltyFreeMusicLibrary.stopPreview() }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = tr("Create Local News, Reel or Video", "समाचार, रील या वीडियो पोस्ट करें", lang),
                style = MaterialTheme.typography.headlineSmall
            )
            Text(
                text = tr(
                    "Every post is instantly scanned by Gemini AI Legal & Safety Filter before publishing.",
                    "प्रकाशन से पहले हर पोस्ट की Gemini AI कानूनी और सुरक्षा जाँच होती है।",
                    lang
                ),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.tertiary
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("news" to "Local News", "reel" to "Reel", "video" to "Video").forEach { (type, label) ->
                    FilterChip(
                        selected = postType == type,
                        onClick = { postType = type },
                        label = { Text(label) }
                    )
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text(tr("Headline / Title (optional)", "शीर्षक (वैकल्पिक)", lang)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            OutlinedTextField(
                value = caption,
                onValueChange = { caption = it },
                label = { Text(tr("Write news, story, or caption...", "समाचार या कैप्शन लिखें...", lang)) },
                modifier = Modifier.fillMaxWidth().testTag("create_post_caption_input"),
                minLines = 3
            )

            if (selectedMediaUri.isNullOrBlank()) {
                Text(
                    text = tr("Colored Card Style (Text Posts)", "रंगीन बैकग्राउंड कार्ड (टेक्स्ट पोस्ट)", lang),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(POST_BG_STYLES, key = { it.id }) { bgStyle ->
                        val isSelected = selectedBgStyleId == bgStyle.id
                        Box(
                            modifier = Modifier
                                .size(width = 64.dp, height = 44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(bgStyle.colors))
                                .border(
                                    width = if (isSelected) 2.5.dp else 1.dp,
                                    color = if (isSelected) CrimsonPrimary else Color.LightGray,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable { selectedBgStyleId = bgStyle.id }
                                .testTag("create_post_bg_${bgStyle.id}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = bgStyle.label,
                                color = if (bgStyle.id == "none") Color.DarkGray else Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                val previewColors = resolvePostBgColors(selectedBgStyleId)
                if (previewColors != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 140.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Brush.linearGradient(previewColors))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = caption.ifBlank { tr("Your colorful post preview...", "आपका रंगीन पोस्ट प्रीव्यू...", lang) },
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        mediaPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.PhotoLibrary, null)
                    Spacer(Modifier.width(6.dp))
                    Text(tr("Gallery", "गैलरी", lang))
                }
                OutlinedButton(
                    onClick = {
                        val hasCam = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.CAMERA
                        ) == PackageManager.PERMISSION_GRANTED
                        if (hasCam) {
                            launchCameraVideoCapture()
                        } else {
                            showCameraDisclosure = true
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.CameraAlt, null)
                    Spacer(Modifier.width(6.dp))
                    Text(tr("Record Video", "रिकॉर्ड करें", lang))
                }
            }

            OutlinedButton(
                onClick = { showVnStudio = true },
                modifier = Modifier.fillMaxWidth().testTag("open_vn_studio_from_post")
            ) {
                Icon(Icons.Filled.MovieCreation, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
                Text(tr("Edit in VN Pro Video Studio (Slow-Mo, Filters, Text, Voiceover)", "VN प्रो वीडियो स्टूडियो में एडिट करें", lang))
            }

            studioResult?.let { res ->
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Studio Edit Applied: ${res.editorSummary}",
                        modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (!uploadError.isNullOrBlank()) {
                Text(
                    text = uploadError!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            if (!selectedMediaUri.isNullOrBlank()) {
                AsyncImage(
                    model = selectedMediaUri,
                    contentDescription = "Selected Media",
                    modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(14.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            // Royalty-Free Music Library + Device Audio & Mixer
            Text(
                text = tr("Background Music & Audio Mixer", "बैकग्राउंड संगीत और ऑडियो मिक्सर", lang),
                style = MaterialTheme.typography.titleMedium
            )
            ReelMusicMixerPanel(
                tracks = availableMusicTracks,
                selectedMusicId = selectedTrackId,
                customAudioUri = customAudioUri,
                customAudioLabel = customAudioLabel,
                originalVolume = originalVol,
                musicVolume = musicVol,
                lang = lang,
                onSelectTrack = { track ->
                    selectedTrackId = track.id
                    customAudioUri = null
                    customAudioLabel = null
                    originalVol = if (track.id == "none") 0.85f else 0f
                },
                onPickDeviceAudio = { uriStr, name ->
                    customAudioUri = uriStr
                    customAudioLabel = name
                    selectedTrackId = "device_custom"
                    originalVol = 0f
                },
                onClearDeviceAudio = {
                    customAudioUri = null
                    customAudioLabel = null
                    if (selectedTrackId == "device_custom") {
                        selectedTrackId = "none"
                        originalVol = 0.85f
                    }
                },
                onOriginalVolumeChange = { originalVol = it },
                onMusicVolumeChange = { musicVol = it },
                onSecurityError = { msg ->
                    uploadError = msg
                    onSecurityError(msg)
                },
                showOriginalVolumeSlider = !selectedMediaUri.isNullOrBlank()
            )

            Button(
                onClick = {
                    RoyaltyFreeMusicLibrary.stopPreview()
                    val trackTitle = studioResult?.selectedMusicTrackTitle
                        ?: customAudioLabel?.takeIf { it.isNotBlank() }?.let { "Device Audio: $it" }
                        ?: availableMusicTracks.firstOrNull { it.id == selectedTrackId && it.id != "none" }?.titleEn
                    val extraMedia = listOfNotNull(studioResult?.pipMediaUri)
                    val finalMediaUri = selectedMediaUri ?: studioResult?.primaryMediaUri
                    onPublish(
                        postType,
                        title,
                        caption,
                        city,
                        finalMediaUri,
                        trackTitle,
                        if (finalMediaUri.isNullOrBlank() && selectedBgStyleId != "none") selectedBgStyleId else null,
                        studioResult?.editorSummary,
                        studioResult?.extraLayerScanText.orEmpty(),
                        extraMedia
                    )
                },
                enabled = !isScanningAi,
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("publish_post_button")
            ) {
                if (isScanningAi) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text(tr("Gemini AI Scanning...", "Gemini AI जाँच जारी...", lang))
                } else {
                    Text(tr("Scan & Publish", "AI जाँच और प्रकाशित करें", lang))
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    if (showCameraDisclosure) {
        ProminentPermissionDisclosureDialog(
            lang = lang,
            onContinue = {
                showCameraDisclosure = false
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            },
            onNotNow = { showCameraDisclosure = false }
        )
    }

    if (showVnStudio) {
        VnVideoEditorStudioDialog(
            initialMediaUri = selectedMediaUri,
            lang = lang,
            availableMusicTracks = availableMusicTracks,
            onDismiss = { showVnStudio = false },
            onSecurityError = { msg ->
                uploadError = msg
                onSecurityError(msg)
            },
            onApplyEdit = { res ->
                studioResult = res
                if (res.primaryMediaUri != null) selectedMediaUri = res.primaryMediaUri
                selectedTrackId = res.selectedMusicTrackId
                showVnStudio = false
            }
        )
    }
}

@Composable
private fun CreateStoryDialog(
    isScanningAi: Boolean,
    lang: AppLang,
    onDismiss: () -> Unit,
    onSecurityError: (String) -> Unit,
    onPublish: (String, String?) -> Unit
) {
    val context = LocalContext.current
    var caption by remember { mutableStateOf("") }
    var mediaUri by remember { mutableStateOf<String?>(null) }
    var storyUploadError by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { picked ->
            MediaUploadValidator.validatePickedMedia(
                context = context,
                uri = picked,
                allowVideo = false,
                lang = lang
            ).onSuccess { validated ->
                storyUploadError = null
                mediaUri = validated.uriString
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Blocked unsafe story photo."
                storyUploadError = msg
                onSecurityError(msg)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Post 24-Hour Story", "24 घंटे की स्टोरी डालें", lang)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    label = { Text(tr("Story message", "स्टोरी संदेश", lang)) },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.PhotoLibrary, null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (mediaUri == null) tr("Pick Photo", "फ़ोटो चुनें", lang) else tr("Photo Selected", "फ़ोटो चुना गया", lang))
                }
                if (!storyUploadError.isNullOrBlank()) {
                    Text(
                        text = storyUploadError!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onPublish(caption, mediaUri) },
                enabled = !isScanningAi
            ) {
                Text(if (isScanningAi) "AI Scanning..." else tr("Publish", "डालें", lang))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(tr("Cancel", "रद्द", lang)) }
        }
    )
}

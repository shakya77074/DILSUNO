package com.dilsuno.app.core

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

data class ValidatedMediaResult(
    val uriString: String,
    val isVideo: Boolean,
    val sizeBytes: Long
)

object MediaUploadValidator {

    fun validatePickedMedia(
        context: Context,
        uri: Uri,
        allowVideo: Boolean,
        lang: AppLang = AppLang.EN
    ): Result<ValidatedMediaResult> {
        val scheme = uri.scheme?.lowercase().orEmpty()
        if (scheme != "content" && scheme != "file") {
            return Result.failure(
                SecurityException(
                    tr(
                        "Unsupported media source. Only safe local gallery/camera files are allowed.",
                        "अमान्य मीडिया स्रोत। केवल सुरक्षित गैलरी या कैमरा फ़ाइलें मान्य हैं।",
                        lang
                    )
                )
            )
        }

        var displayName: String? = null
        var reportedSize: Long = -1L

        if (scheme == "content") {
            try {
                context.contentResolver.query(
                    uri,
                    arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIdx >= 0 && !cursor.isNull(nameIdx)) {
                            displayName = cursor.getString(nameIdx)
                        }
                        val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                            reportedSize = cursor.getLong(sizeIdx)
                        }
                    }
                }
            } catch (_: Exception) {
                // Fall back to AssetFileDescriptor / InputStream below
            }
        } else {
            val filePath = uri.path
            if (!filePath.isNullOrBlank()) {
                val f = File(filePath)
                displayName = f.name
                if (f.exists()) reportedSize = f.length()
            }
        }

        if (reportedSize < 0L) {
            reportedSize = measureStreamSizeUpToLimit(context, uri)
        }

        val mimeType = if (scheme == "content") {
            context.contentResolver.getType(uri)
        } else {
            null
        }
        val descriptor = displayName ?: uri.lastPathSegment ?: uri.toString()

        val descriptorCheck = SecurityUtils.validateMediaDescriptor(
            fileNameOrUri = descriptor,
            mimeType = mimeType,
            sizeBytes = if (reportedSize >= 0L) reportedSize else null,
            allowVideo = allowVideo,
            lang = lang
        )
        if (descriptorCheck.isFailure) {
            return Result.failure(descriptorCheck.exceptionOrNull()!!)
        }

        val ext = SecurityUtils.extractFileExtension(descriptor)
        val isVideo = (mimeType?.startsWith("video/", ignoreCase = true) == true) ||
            (ext != null && ext in SecurityUtils.ALLOWED_VIDEO_EXTENSIONS)

        return Result.success(
            ValidatedMediaResult(
                uriString = uri.toString(),
                isVideo = isVideo,
                sizeBytes = reportedSize.coerceAtLeast(0L)
            )
        )
    }

    fun validatePickedAudio(
        context: Context,
        uri: Uri,
        lang: AppLang = AppLang.EN
    ): Result<Pair<String, String>> {
        val scheme = uri.scheme?.lowercase().orEmpty()
        if (scheme != "content" && scheme != "file") {
            return Result.failure(
                SecurityException(
                    tr(
                        "Unsupported audio source. Only safe local device audio files are allowed.",
                        "अमान्य ऑडियो स्रोत। केवल सुरक्षित डिवाइस ऑडियो फ़ाइलें मान्य हैं।",
                        lang
                    )
                )
            )
        }
        var displayName: String? = null
        var reportedSize: Long = -1L
        if (scheme == "content") {
            try {
                context.contentResolver.query(
                    uri,
                    arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIdx >= 0 && !cursor.isNull(nameIdx)) {
                            displayName = cursor.getString(nameIdx)
                        }
                        val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                            reportedSize = cursor.getLong(sizeIdx)
                        }
                    }
                }
            } catch (_: Exception) {
            }
        } else {
            val filePath = uri.path
            if (!filePath.isNullOrBlank()) {
                val f = File(filePath)
                displayName = f.name
                if (f.exists()) reportedSize = f.length()
            }
        }
        if (reportedSize < 0L) {
            reportedSize = measureStreamSizeUpToLimit(context, uri)
        }
        val mimeType = if (scheme == "content") context.contentResolver.getType(uri) else null
        val descriptor = displayName ?: uri.lastPathSegment ?: uri.toString()
        val ext = SecurityUtils.extractFileExtension(descriptor)
        if (ext != null && ext in SecurityUtils.BLOCKED_DANGEROUS_EXTENSIONS) {
            return Result.failure(
                SecurityException(
                    tr(
                        "Blocked dangerous file (.$ext).",
                        "खतरनाक फ़ाइल (.$ext) ब्लॉक की गई।",
                        lang
                    )
                )
            )
        }
        val validExt = ext == null || ext in SecurityUtils.ALLOWED_AUDIO_EXTENSIONS
        val normalizedMime = mimeType?.trim()?.lowercase()?.substringBefore(';')
        val validMime = normalizedMime == null ||
            normalizedMime.startsWith("audio/") ||
            normalizedMime in SecurityUtils.ALLOWED_AUDIO_MIME_TYPES
        if (!validExt || !validMime || (ext == null && normalizedMime == null)) {
            return Result.failure(
                IllegalArgumentException(
                    tr(
                        "Only safe audio files (.mp3, .m4a, .aac, .wav, .ogg) are allowed.",
                        "केवल सुरक्षित ऑडियो फ़ाइलें (.mp3, .m4a, .aac, .wav, .ogg) मान्य हैं।",
                        lang
                    )
                )
            )
        }
        if (reportedSize > SecurityUtils.MAX_MEDIA_UPLOAD_BYTES) {
            return Result.failure(
                IllegalArgumentException(
                    tr(
                        "Audio file exceeds 25 MB limit.",
                        "ऑडियो फ़ाइल 25 MB सीमा से बड़ी है।",
                        lang
                    )
                )
            )
        }
        val cleanTitle = SecurityUtils.sanitizeInput(displayName ?: "Device Audio Track", 60)
            .ifBlank { "Device Audio Track" }
        return Result.success(uri.toString() to cleanTitle)
    }

    private fun measureStreamSizeUpToLimit(context: Context, uri: Uri): Long {
        try {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                if (afd.length >= 0L) return afd.length
            }
        } catch (_: Exception) {
        }
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(16 * 1024)
                var total = 0L
                val cap = SecurityUtils.MAX_MEDIA_UPLOAD_BYTES + 1L
                while (total <= cap) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    total += read
                }
                total
            } ?: -1L
        } catch (_: Exception) {
            -1L
        }
    }
}

package com.dilsuno.app.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import android.net.Uri
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Shield
import com.dilsuno.app.R
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.DilSePolicyText
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.UiState
import com.dilsuno.app.ui.components.AccountDeletionDialog
import com.dilsuno.app.ui.components.CustomerSupportModal
import com.dilsuno.app.ui.components.LegalPoliciesViewerDialog
import com.dilsuno.app.ui.components.ListenerApplicationDialog
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.RoyalNavy
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.VelvetIndigo
import com.dilsuno.app.viewmodel.MainAppViewModel

@Composable
fun ProfileAndCreatorScreen(
    viewModel: MainAppViewModel,
    lang: AppLang,
    onToggleLang: () -> Unit,
    onSwitchRoleOrSignOut: () -> Unit,
    onAccountDeleted: () -> Unit,
    onOpenCreateReel: () -> Unit = {},
    onOpenLive: () -> Unit = {},
    onOpenPrivateCall: () -> Unit = {}
) {
    val myAccount by viewModel.myAccount.collectAsStateWithLifecycle()
    val myProfile by viewModel.myProfile.collectAsStateWithLifecycle()
    val postsState by viewModel.postsState.collectAsStateWithLifecycle()
    val myTips by viewModel.myTips.collectAsStateWithLifecycle()
    val myPayouts by viewModel.myPayouts.collectAsStateWithLifecycle()
    val appConfig by viewModel.appConfig.collectAsStateWithLifecycle()
    val myListenerApp by viewModel.myListenerApplication.collectAsStateWithLifecycle()

    var fullName by remember { mutableStateOf("") }
    var ageText by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var avatarUri by remember { mutableStateOf<String?>(null) }
    var coverUri by remember { mutableStateOf<String?>(null) }
    var currentCity by remember { mutableStateOf("") }
    var hometown by remember { mutableStateOf("") }
    var schoolCollege by remember { mutableStateOf("") }
    var workplace by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var isProfileLocked by remember { mutableStateOf(false) }
    var lockInitialized by remember { mutableStateOf(false) }

    val context = LocalContext.current
    var showCreatorForm by remember { mutableStateOf(false) }
    var showEditDetails by remember { mutableStateOf(true) }
    var showProfileStoryDialog by remember { mutableStateOf(false) }
    var profileFilterTab by remember { mutableIntStateOf(0) } // 0 = All, 1 = Reels, 2 = Photos, 3 = Events
    var payoutAccount by remember { mutableStateOf("") }
    var legalDialogTab by remember { mutableStateOf<Int?>(null) }
    var showSupportModal by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showJoinTeamDialog by remember { mutableStateOf(false) }

    LaunchedEffect(myProfile, myAccount) {
        val p = myProfile
        val a = myAccount
        if (fullName.isBlank()) {
            fullName = SecurityUtils.resolveDisplayName(p?.fullName, a?.fullName, "")
        }
        if (ageText.isBlank() && a?.age != null) ageText = a.age.toString()
        if (gender.isBlank() && !a?.gender.isNullOrBlank()) gender = a.gender.orEmpty()
        if (phone.isBlank()) phone = a?.phone.orEmpty()
        if (avatarUri == null) avatarUri = p?.avatarUri
        if (coverUri == null) coverUri = p?.coverUri
        if (currentCity.isBlank()) currentCity = p?.currentCity.orEmpty()
        if (hometown.isBlank()) hometown = p?.hometown.orEmpty()
        if (schoolCollege.isBlank()) schoolCollege = p?.schoolCollege.orEmpty()
        if (workplace.isBlank()) workplace = p?.workplace.orEmpty()
        if (bio.isBlank()) bio = p?.bio.orEmpty()
        if (!lockInitialized && p != null) {
            isProfileLocked = p.isProfileLocked
            lockInitialized = true
        }
    }

    fun persistCurrentProfile(newAvatarUri: String? = avatarUri, newCoverUri: String? = coverUri) {
        if (fullName.trim().length >= 2) {
            viewModel.saveProfile(
                fullName = fullName,
                phone = phone,
                avatarUri = newAvatarUri,
                coverUri = newCoverUri,
                currentCity = currentCity,
                hometown = hometown,
                schoolCollege = schoolCollege,
                workplace = workplace,
                bio = bio,
                isProfileLocked = isProfileLocked,
                age = ageText.toLongOrNull(),
                gender = gender.ifBlank { null }
            )
        }
    }

    val photoPickerContext = androidx.compose.ui.platform.LocalContext.current
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { picked ->
            com.dilsuno.app.core.MediaUploadValidator.validatePickedMedia(
                context = photoPickerContext,
                uri = picked,
                allowVideo = false,
                lang = lang
            ).onSuccess { validated ->
                avatarUri = validated.uriString
                persistCurrentProfile(newAvatarUri = validated.uriString, newCoverUri = coverUri)
            }.onFailure { err ->
                viewModel.reportSecurityError(err.localizedMessage ?: "Blocked unsafe profile photo.")
            }
        }
    }

    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { picked ->
            com.dilsuno.app.core.MediaUploadValidator.validatePickedMedia(
                context = photoPickerContext,
                uri = picked,
                allowVideo = false,
                lang = lang
            ).onSuccess { validated ->
                coverUri = validated.uriString
                persistCurrentProfile(newAvatarUri = avatarUri, newCoverUri = validated.uriString)
            }.onFailure { err ->
                viewModel.reportSecurityError(err.localizedMessage ?: "Blocked unsafe cover photo.")
            }
        }
    }

    val myPosts = (postsState as? UiState.Success)?.data?.filter { it.authorUid == viewModel.currentUserId } ?: emptyList()
    val totalViews = myPosts.sumOf { it.viewsCount }
    val totalLikes = myPosts.sumOf { it.likesCount + it.loveCount }
    val totalTipsInr = myTips.sumOf { it.amountInr }
    val viewBonusInr = if (myAccount?.monetizationStatus == "approved" && appConfig.globalMonetizationEnabled) {
        (totalViews / 1000L) * appConfig.viewBonusPer1000Inr
    } else 0L
    val availableEarnings = if (myAccount?.monetizationStatus == "approved") {
        (myAccount?.walletBalance ?: 0L) + totalTipsInr + viewBonusInr
    } else 0L

    val contentTabs = listOf(
        tr("All", "सभी", lang),
        tr("Reels", "रील्स", lang),
        tr("Photos", "फ़ोटो", lang),
        tr("Events", "कार्यक्रम", lang)
    )
    val filteredMyPosts = remember(myPosts, profileFilterTab) {
        when (profileFilterTab) {
            1 -> myPosts.filter { it.postType == "reel" || it.postType == "video" }
            2 -> myPosts.filter { !it.mediaUri.isNullOrBlank() && it.postType != "reel" }
            3 -> myPosts.filter { it.postType == "news" }
            else -> myPosts
        }
    }

    Column(
        modifier = Modifier
            .widthIn(max = 600.dp)
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("❤️ दिल सुनो • ${tr("Profile", "प्रोफ़ाइल", lang)}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = onSwitchRoleOrSignOut) {
                Icon(Icons.Filled.Logout, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(tr("Sign Out", "बाहर", lang))
            }
        }

        // Cover Banner + Overlapping Circular Profile Photo + Follower/Following Counts
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(152.dp)
                ) {
                    if (!coverUri.isNullOrBlank()) {
                        AsyncImage(
                            model = coverUri,
                            contentDescription = "Profile Cover Banner",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Image(
                            painter = painterResource(id = R.drawable.img_community_hero),
                            contentDescription = "Profile Cover Banner",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(RoyalNavy.copy(alpha = 0.14f), RoyalNavy.copy(alpha = 0.45f))
                                )
                            )
                    )
                    Surface(
                        color = CrimsonPrimary,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(10.dp)
                            .clickable { onOpenPrivateCall() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Call, null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("₹100 Call", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Cover Banner Camera Edit Button (Bottom-Right)
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(4.dp)
                            .size(48.dp)
                            .clickable {
                                coverPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                            .testTag("edit_cover_banner_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            color = CrimsonPrimary,
                            shape = CircleShape,
                            shadowElevation = 3.dp,
                            modifier = Modifier
                                .size(34.dp)
                                .border(2.dp, Color.White, CircleShape)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.PhotoCamera,
                                    contentDescription = tr("Edit Cover Banner Photo", "कवर बैनर फ़ोटो बदलें", lang),
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .padding(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Box(
                            contentAlignment = Alignment.BottomEnd,
                            modifier = Modifier.offset(y = (-34).dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(92.dp)
                                    .border(3.5.dp, Color.White, CircleShape)
                                    .clip(CircleShape)
                                    .background(CrimsonPrimary.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (!avatarUri.isNullOrBlank()) {
                                    AsyncImage(
                                        model = avatarUri,
                                        contentDescription = "Profile Photo",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Text(
                                        fullName.take(2).uppercase().ifBlank { "DS" },
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = CrimsonPrimary
                                    )
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .offset(x = 6.dp, y = 6.dp)
                                    .clickable {
                                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                    }
                                    .testTag("edit_avatar_photo_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Surface(
                                    color = CrimsonPrimary,
                                    shape = CircleShape,
                                    shadowElevation = 3.dp,
                                    modifier = Modifier
                                        .size(32.dp)
                                        .border(2.dp, Color.White, CircleShape)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Filled.PhotoCamera,
                                            contentDescription = tr("Edit Profile Photo", "प्रोफ़ाइल फ़ोटो बदलें", lang),
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(18.dp),
                            modifier = Modifier.padding(top = 8.dp)
                        ) {
                            MetricBox(tr("Followers", "फ़ॉलोअर्स", lang), "${myProfile?.followersCount ?: 0L}")
                            MetricBox(tr("Friends", "मित्र", lang), "${myProfile?.friendsCount ?: 0L}")
                            MetricBox(tr("Posts", "पोस्ट", lang), "${myPosts.size}")
                        }
                    }

                    Text(
                        text = fullName.ifBlank { "Dil Suno Member" },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                    if (bio.isNotBlank() || currentCity.isNotBlank()) {
                        Text(
                            text = listOf(currentCity, bio).filter { it.isNotBlank() }.joinToString(" • "),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Primary Profile Actions: "Dashboard" + "+ Add to story"
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { showCreatorForm = !showCreatorForm },
                            colors = ButtonDefaults.buttonColors(containerColor = VelvetIndigo),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f).testTag("profile_dashboard_button")
                        ) {
                            Icon(Icons.Filled.Dashboard, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(tr("Dashboard", "डैशबोर्ड", lang), maxLines = 1)
                        }
                        Button(
                            onClick = { showProfileStoryDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f).testTag("profile_add_story_button")
                        ) {
                            Icon(Icons.Filled.Add, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(tr("+ Add to story", "+ स्टोरी जोड़ें", lang), maxLines = 1)
                        }
                    }

                    // Quick Reel & Live Shortcut Buttons
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = onOpenCreateReel,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f).testTag("profile_create_reel_button")
                        ) {
                            Icon(Icons.Filled.MovieCreation, null, tint = CrimsonPrimary, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(tr("🎬 Reel", "🎬 रील", lang), fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = onOpenLive,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f).testTag("profile_go_live_button")
                        ) {
                            Icon(Icons.Filled.RadioButtonChecked, null, tint = Color.Red, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(tr("📹 Live", "📹 लाइव", lang), fontWeight = FontWeight.Bold)
                        }
                    }

                    // Highlights Row
                    Text(tr("Highlights • हाइलाइट्स", "हाइलाइट्स", lang), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(vertical = 2.dp)
                    ) {
                        val highlights = listOf("❤️ दिल की बात", "🎬 My Reels", "🌸 Positive Days")
                        items(highlights) { hl ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.clickable { onOpenCreateReel() }
                            ) {
                                Text(
                                    text = hl,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }

                    // All | Reels | Photos | Events Filter Tabs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        contentTabs.forEachIndexed { idx, label ->
                            FilterChip(
                                selected = profileFilterTab == idx,
                                onClick = { profileFilterTab = idx },
                                label = { Text(label, maxLines = 1) },
                                modifier = Modifier.testTag("profile_filter_tab_$idx")
                            )
                        }
                    }

                    if (filteredMyPosts.isEmpty()) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = tr("Tap 🎬 Reel or 📹 Live above to publish into this tab.", "इस टैब में पोस्ट करने के लिए ऊपर 🎬 Reel या 📹 Live चुनें।", lang),
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(12.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        filteredMyPosts.take(5).forEach { mp ->
                            Surface(
                                color = if (mp.copyrightClaimActive) Color(0xFFFEF2F2) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                border = if (mp.copyrightClaimActive) BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.5f)) else null,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("${mp.postType.uppercase()} • ❤️ ${mp.loveCount}", style = MaterialTheme.typography.labelSmall, color = CrimsonPrimary, fontWeight = FontWeight.Bold)
                                    Text(mp.title ?: mp.caption, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
                                    if (mp.copyrightClaimActive) {
                                        Text(
                                            text = tr(
                                                "⚠️ Copyright Claim – Reach Limited${mp.copyrightClaimReason?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: ""}",
                                                "⚠️ कॉपीराइट क्लेम – रीच सीमित${mp.copyrightClaimReason?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: ""}",
                                                lang
                                            ),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFB91C1C)
                                        )
                                        Button(
                                            onClick = { viewModel.muteMyReelAudioForClaim(mp) },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C), contentColor = Color.White),
                                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("mute_copyright_audio_${mp.id}")
                                        ) {
                                            Icon(Icons.AutoMirrored.Filled.VolumeOff, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                                            Spacer(Modifier.width(6.dp))
                                            Text(tr("Mute Audio to Remove Claim", "क्लेम हटाने के लिए ऑडियो म्यूट करें", lang), color = Color.White, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Profile Lock Toggle
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Filled.Lock, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(tr("Profile Lock", "प्रोफ़ाइल लॉक", lang), fontWeight = FontWeight.SemiBold)
                                    Text(
                                        tr("Personal details & photos visible only to friends", "विवरण व फ़ोटो केवल मित्रों को दिखेंगे", lang),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                            Switch(
                                checked = isProfileLocked,
                                onCheckedChange = { isProfileLocked = it },
                                modifier = Modifier.testTag("profile_lock_switch")
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tr("Edit Profile / प्रोफ़ाइल संपादित करें", "प्रोफ़ाइल संपादित करें / Edit Profile", lang),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { showEditDetails = !showEditDetails }) {
                            Icon(Icons.Filled.Edit, contentDescription = "Toggle Edit Profile")
                        }
                    }
                    if (showEditDetails) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text(tr("Full Name *", "पूरा नाम *", lang)) },
                    modifier = Modifier.fillMaxWidth().testTag("profile_fullname_input"),
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = ageText,
                        onValueChange = { input -> ageText = input.filter { it.isDigit() }.take(3) },
                        label = { Text(tr("Age", "उम्र", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("profile_age_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = gender,
                        onValueChange = { gender = it },
                        label = { Text(tr("Gender", "लिंग", lang)) },
                        modifier = Modifier.weight(1f).testTag("profile_gender_input"),
                        singleLine = true
                    )
                }
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(tr("Phone Number (Optional)", "फ़ोन नंबर (वैकल्पिक)", lang)) },
                    leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth().testTag("profile_phone_input"),
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = currentCity, onValueChange = { currentCity = it }, label = { Text(tr("Current City", "वर्तमान शहर", lang)) }, modifier = Modifier.weight(1f).testTag("profile_city_input"), singleLine = true)
                    OutlinedTextField(value = hometown, onValueChange = { hometown = it }, label = { Text(tr("Hometown / Village", "गृहनगर / गाँव", lang)) }, modifier = Modifier.weight(1f).testTag("profile_hometown_input"), singleLine = true)
                }
                OutlinedTextField(value = schoolCollege, onValueChange = { schoolCollege = it }, label = { Text(tr("School / College (कहाँ पढ़ा है)", "स्कूल / कॉलेज (कहाँ पढ़ा है)", lang)) }, modifier = Modifier.fillMaxWidth().testTag("profile_school_input"), singleLine = true)
                OutlinedTextField(value = workplace, onValueChange = { workplace = it }, label = { Text(tr("Workplace / Profession", "कार्यस्थल / पेशा", lang)) }, modifier = Modifier.fillMaxWidth().testTag("profile_workplace_input"), singleLine = true)
                OutlinedTextField(value = bio, onValueChange = { bio = it }, label = { Text(tr("Bio", "बायो", lang)) }, modifier = Modifier.fillMaxWidth().testTag("profile_bio_input"), minLines = 2)

                Button(
                    onClick = {
                        viewModel.saveProfile(
                            fullName = fullName,
                            phone = phone,
                            avatarUri = avatarUri,
                            coverUri = coverUri,
                            currentCity = currentCity,
                            hometown = hometown,
                            schoolCollege = schoolCollege,
                            workplace = workplace,
                            bio = bio,
                            isProfileLocked = isProfileLocked,
                            age = ageText.toLongOrNull(),
                            gender = gender.ifBlank { null }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary, contentColor = Color.White),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("save_profile_button")
                ) {
                    Text(tr("Save Profile", "प्रोफ़ाइल सहेजें", lang), fontWeight = FontWeight.Bold)
                }
                    } // end showEditDetails
                }
            }
        }

        // STEP 1 vs STEP 2/3: OPT-IN CREATOR REGISTRATION & CREATOR DASHBOARD
        val isCreator = myAccount?.isCreator == true || myProfile?.isCreator == true
        if (!isCreator) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.Star, null, tint = MaterialTheme.colorScheme.secondary)
                        Text(tr("Become a Creator / क्रिएटर बनें", "क्रिएटर बनें / Become a Creator", lang), style = MaterialTheme.typography.titleLarge)
                    }
                    Text(
                        text = tr(
                            "Regular users can post casual news & videos anytime without a Creator Dashboard. Register here only if you want an official Creator Dashboard & monetization eligibility.",
                            "सामान्य यूज़र बिना डैशबोर्ड के भी न्यूज़ व वीडियो डाल सकते हैं। आधिकारिक क्रिएटर डैशबोर्ड और कमाई के लिए यहाँ रजिस्टर करें।",
                            lang
                        ),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(
                        onClick = { showCreatorForm = true },
                        modifier = Modifier.fillMaxWidth().testTag("become_creator_button")
                    ) {
                        Text(tr("Register as Official Creator", "क्रिएटर के रूप में जुड़ें", lang))
                    }
                }
            }
        } else {
            // CREATOR DASHBOARD (Unlocked ONLY after self-registration)
            val monStatus = myAccount?.monetizationStatus ?: "none"
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Filled.AutoGraph, null, tint = MaterialTheme.colorScheme.primary)
                            Text(tr("Creator Dashboard", "क्रिएटर डैशबोर्ड", lang), style = MaterialTheme.typography.titleLarge)
                        }
                        Surface(
                            color = if (monStatus == "approved") MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.secondary,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = when (monStatus) {
                                    "approved" -> "Monetization ON"
                                    "pending" -> "Pending Admin Review"
                                    "rejected" -> "Monetization OFF"
                                    else -> "Monetization OFF"
                                },
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        MetricBox(tr("Views", "व्यूज़", lang), "$totalViews")
                        MetricBox(tr("Likes", "लाइक्स", lang), "$totalLikes")
                        MetricBox(tr("Followers", "फ़ॉलोअर्स", lang), "${myProfile?.followersCount ?: 0L}")
                        MetricBox(tr("Wallet", "वॉलेट", lang), "₹$availableEarnings")
                    }

                    when (monStatus) {
                        "none", "rejected" -> {
                            Text(
                                text = tr(
                                    "Earnings remain ₹0 until Super Admin reviews and turns ON Monetization for your account.",
                                    "सुपर एडमिन द्वारा मोनेटाइजेशन चालू करने के बाद ही कमाई शुरू होगी।",
                                    lang
                                ),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Button(
                                onClick = { viewModel.applyForMonetization() },
                                modifier = Modifier.fillMaxWidth().testTag("apply_monetization_button")
                            ) {
                                Text(tr("Apply for Monetization", "मोनेटाइजेशन के लिए आवेदन करें", lang))
                            }
                        }
                        "pending" -> {
                            Text(
                                text = tr("Your monetization request is waiting for Super Admin approval.", "आपका आवेदन सुपर एडमिन की समीक्षा में है।", lang),
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        "approved" -> {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Filled.Verified, null, tint = MaterialTheme.colorScheme.tertiary)
                                Text(
                                    tr("Monetization Approved! Tips (₹$totalTipsInr) + View Bonus (₹$viewBonusInr)", "मोनेटाइजेशन सक्रिय! टिप्स (₹$totalTipsInr) + व्यू बोनस (₹$viewBonusInr)", lang),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            OutlinedTextField(
                                value = payoutAccount,
                                onValueChange = { payoutAccount = it },
                                label = { Text(tr("Bank / Payout Account Reference", "बैंक / पेआउट अकाउंट विवरण", lang)) },
                                modifier = Modifier.fillMaxWidth().testTag("creator_payout_account_input"),
                                singleLine = true
                            )
                            Button(
                                onClick = { viewModel.requestPayout(payoutAccount, availableEarnings) },
                                enabled = availableEarnings > 0L && payoutAccount.trim().length >= 4,
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("creator_request_payout_button")
                            ) {
                                Icon(Icons.Filled.AccountBalanceWallet, null)
                                Spacer(Modifier.width(6.dp))
                                Text(tr("Request Payout (₹$availableEarnings)", "पेआउट अनुरोध भेजें (₹$availableEarnings)", lang))
                            }
                            myPayouts.forEach { p ->
                                Text("• Payout ₹${p.amountInr} (${p.payoutAccount}): ${p.status.uppercase()}", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        // Join Our Team (2-Step Listener Onboarding Card)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.HeadsetMic, contentDescription = null, tint = CrimsonPrimary)
                    Text(
                        text = tr("Join Our Team • Dil Suno Listener", "हमारी टीम से जुड़ें • दिल सुनो श्रोता", lang),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = when (myListenerApp?.status) {
                        "pending" -> tr("Status: Step 1 — Waiting for Staff Verification", "स्थिति: चरण 1 — स्टाफ सत्यापन बाकी", lang)
                        "staff_verified" -> tr("Status: Verified by Staff ✓ — Waiting Super Admin Approval", "स्थिति: स्टाफ सत्यापित ✓ — सुपर एडमिन मंज़ूरी बाकी", lang)
                        "approved" -> tr("Status: Approved! Use Staff Portal with your assigned PIN.", "स्थिति: स्वीकृत! स्टाफ पोर्टल में पिन से लॉगिन करें।", lang)
                        else -> tr("Apply to become a verified Dil Suno Listener and support the community.", "दिल सुनो के सत्यापित श्रोता बनने के लिए आवेदन करें।", lang)
                    },
                    style = MaterialTheme.typography.bodySmall
                )
                Button(
                    onClick = { showJoinTeamDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary, contentColor = Color.White),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("profile_join_team_button")
                ) {
                    Icon(Icons.Filled.HeadsetMic, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(tr("Join Our Team", "हमारी टीम से जुड़ें", lang), color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Settings, Support, Legal & Play-Compliant Account Controls
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = tr("Settings, Legal & Support", "सेटिंग्स, नियम और सहायता", lang),
                    style = MaterialTheme.typography.titleLarge
                )

                OutlinedButton(
                    onClick = onToggleLang,
                    modifier = Modifier.fillMaxWidth().testTag("settings_lang_toggle")
                ) {
                    Icon(Icons.Filled.Language, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (lang == AppLang.EN) "भाषा बदलें: हिंदी / English" else "Switch Language: English / हिंदी")
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { legalDialogTab = 0 },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("settings_privacy_policy_button")
                    ) {
                        Icon(Icons.Filled.PrivacyTip, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(tr("Privacy Policy", "गोपनीयता नीति", lang), maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = { legalDialogTab = 1 },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("settings_terms_button")
                    ) {
                        Icon(Icons.Filled.Gavel, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(tr("Terms", "नियम व शर्तें", lang), maxLines = 1)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { legalDialogTab = 2 },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("settings_child_safety_button")
                    ) {
                        Icon(Icons.Filled.Shield, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(tr("Child Safety", "बाल सुरक्षा", lang), maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = { legalDialogTab = 3 },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("settings_medical_disclaimer_button")
                    ) {
                        Icon(Icons.Filled.HealthAndSafety, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(tr("Medical Info", "मेडिकल नीति", lang), maxLines = 1)
                    }
                }

                Button(
                    onClick = { showSupportModal = true },
                    modifier = Modifier.fillMaxWidth().testTag("open_customer_support_button")
                ) {
                    Icon(Icons.Filled.SupportAgent, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(tr("Customer Support (Text & Email)", "ग्राहक सहायता (टेक्स्ट व ईमेल)", lang))
                }

                OutlinedButton(
                    onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(
                                Intent.EXTRA_TEXT,
                                tr(
                                    "Join me on ❤️ दिल सुनो • Dil Suno — Connect with friends, share AI-safe Reels & stories, and talk privately with verified listeners!",
                                    "❤️ दिल सुनो • Dil Suno से जुड़ें — दोस्तों से जुड़ें, रील व स्टोरी साझा करें और सुरक्षित प्राइवेट कॉल पर बात करें!",
                                    lang
                                )
                            )
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Invite Friends via WhatsApp / Share"))
                    },
                    modifier = Modifier.fillMaxWidth().testTag("invite_friends_share_button")
                ) {
                    Icon(Icons.Filled.Share, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(tr("Invite Friends / Share App (WhatsApp)", "दोस्तों को आमंत्रित करें / ऐप शेयर करें", lang))
                }

                OutlinedButton(
                    onClick = { showDeleteDialog = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("delete_account_button")
                ) {
                    Icon(Icons.Filled.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        tr("Delete My Account & All Data", "मेरा अकाउंट व सभी डेटा डिलीट करें", lang),
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold
                    )
                }

                // External Web Account Deletion URL & Official Support Email (Google Play Data Safety Compliance)
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = tr("Web Account Deletion & Support", "वेब अकाउंट डिलीट व सहायता लिंक", lang),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DilSePolicyText.WEB_ACCOUNT_DELETION_URL))
                                runCatching { context.startActivity(intent) }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("web_delete_account_link")
                        ) {
                            Icon(Icons.Filled.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(DilSePolicyText.WEB_ACCOUNT_DELETION_URL, style = MaterialTheme.typography.labelMedium)
                        }
                        TextButton(
                            onClick = {
                                val mailIntent = Intent(Intent.ACTION_SENDTO).apply {
                                    data = Uri.parse("mailto:${DilSePolicyText.OFFICIAL_SUPPORT_EMAIL}")
                                    putExtra(Intent.EXTRA_SUBJECT, "Dil Suno Support / Account Request")
                                }
                                runCatching { context.startActivity(mailIntent) }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("settings_support_email_link")
                        ) {
                            Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(DilSePolicyText.OFFICIAL_SUPPORT_EMAIL, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }

                Text(
                    text = "Dil Suno • App Version v${com.dilsuno.app.BuildConfig.VERSION_NAME} (Build ${com.dilsuno.app.BuildConfig.VERSION_CODE})",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.testTag("settings_app_version_text")
                )
            }
        }
    }

    if (showProfileStoryDialog) {
        var storyCaption by remember { mutableStateOf("") }
        var storyMedia by remember { mutableStateOf<String?>(null) }
        val storyPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            uri?.let { picked ->
                com.dilsuno.app.core.MediaUploadValidator.validatePickedMedia(context, picked, allowVideo = false, lang = lang)
                    .onSuccess { storyMedia = it.uriString }
                    .onFailure { viewModel.reportSecurityError(it.localizedMessage ?: "Unsafe photo") }
            }
        }
        AlertDialog(
            onDismissRequest = { showProfileStoryDialog = false },
            title = { Text(tr("Add to Story", "स्टोरी जोड़ें", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = storyCaption,
                        onValueChange = { storyCaption = it },
                        label = { Text(tr("Story caption", "स्टोरी संदेश", lang)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(
                        onClick = { storyPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (storyMedia == null) tr("Pick Photo", "फ़ोटो चुनें", lang) else tr("Photo Ready", "फ़ोटो तैयार", lang))
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.createStory(storyCaption, storyMedia, "#E11D48") {
                        showProfileStoryDialog = false
                    }
                }) { Text(tr("Publish", "प्रकाशित करें", lang)) }
            },
            dismissButton = {
                TextButton(onClick = { showProfileStoryDialog = false }) { Text(tr("Cancel", "रद्द", lang)) }
            }
        )
    }

    if (showCreatorForm) {
        var cName by remember { mutableStateOf(fullName.ifBlank { viewModel.resolveDisplayName("") }) }
        var cCat by remember { mutableStateOf("Local News & Stories") }
        var cBio by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreatorForm = false },
            title = { Text(tr("Creator Registration", "क्रिएटर पंजीकरण", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = cName, onValueChange = { cName = it }, label = { Text("Creator Name *") })
                    OutlinedTextField(value = cCat, onValueChange = { cCat = it }, label = { Text("Content Category *") })
                    OutlinedTextField(value = cBio, onValueChange = { cBio = it }, label = { Text("Creator Bio") }, minLines = 2)
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.registerAsCreator(cName, cCat, cBio)
                    showCreatorForm = false
                }) { Text(tr("Unlock Dashboard", "डैशबोर्ड खोलें", lang)) }
            },
            dismissButton = { TextButton(onClick = { showCreatorForm = false }) { Text(tr("Cancel", "रद्द", lang)) } }
        )
    }

    legalDialogTab?.let { tabIdx ->
        LegalPoliciesViewerDialog(
            initialTab = tabIdx,
            lang = lang,
            onDismiss = { legalDialogTab = null }
        )
    }

    if (showSupportModal) {
        CustomerSupportModal(
            viewModel = viewModel,
            appConfig = appConfig,
            lang = lang,
            onDismiss = { showSupportModal = false }
        )
    }

    if (showDeleteDialog) {
        val hasPassword = !myAccount?.passwordHash.isNullOrBlank() && !myAccount?.passwordSalt.isNullOrBlank()
        AccountDeletionDialog(
            viewModel = viewModel,
            hasPassword = hasPassword,
            lang = lang,
            onDismiss = { showDeleteDialog = false },
            onDeleted = {
                showDeleteDialog = false
                onAccountDeleted()
            }
        )
    }

    if (showJoinTeamDialog) {
        ListenerApplicationDialog(
            existingApplication = myListenerApp,
            defaultName = fullName.ifBlank { viewModel.resolveDisplayName("") },
            defaultEmail = myAccount?.email.orEmpty(),
            lang = lang,
            onSubmit = { appName, appEmail, appPhone, appCity, motivation ->
                viewModel.submitListenerApplication(
                    fullName = appName,
                    email = appEmail,
                    phone = appPhone,
                    city = appCity,
                    motivation = motivation
                ) {
                    showJoinTeamDialog = false
                }
            },
            onDismiss = { showJoinTeamDialog = false }
        )
    }
}

@Composable
private fun MetricBox(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

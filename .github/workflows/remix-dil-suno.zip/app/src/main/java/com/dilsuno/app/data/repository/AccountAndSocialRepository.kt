package com.dilsuno.app.data.repository

import android.content.Context
import com.dilsuno.app.R
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.data.model.ChatMessage
import com.dilsuno.app.data.model.CommunityGroup
import com.dilsuno.app.data.model.Conversation
import com.dilsuno.app.data.model.FriendLink
import com.dilsuno.app.data.model.FriendSuggestion
import com.dilsuno.app.data.model.NotificationItem
import com.dilsuno.app.data.model.PublicPage
import com.dilsuno.app.data.model.PublicProfile
import com.dilsuno.app.data.model.UserAccount
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.auth.userProfileChangeRequest
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class AccountAndSocialRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUid(): String {
        return Firebase.auth.currentUser?.uid
            ?: throw IllegalStateException("Sign-In required before accessing Dil Suno data.")
    }

    suspend fun getMyAccount(uid: String = requireUid()): Result<UserAccount?> {
        val path = "users/$uid/private/account"
        return try {
            val snap = db.collection("users").document(uid)
                .collection("private").document("account")
                .get().await()
            val account = if (snap.exists()) {
                snap.toObject(UserAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            } else {
                null
            }
            Result.success(account)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    fun observeMyAccount(uid: String): Flow<UserAccount?> {
        val docRef = db.collection("users").document(uid)
            .collection("private").document("account")
        return docRef.snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(UserAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser?.uid == uid) {
                    handleFirestoreError(fsErr ?: error, OperationType.GET, docRef.path)
                }
                throw error
            }
    }

    suspend fun createOrUpdateUserOnSignUp(
        fullName: String,
        email: String?,
        phone: String?,
        passwordHash: String? = null,
        passwordSalt: String? = null,
        termsAccepted: Boolean,
        currentCity: String = "",
        hometown: String = "",
        schoolCollege: String = "",
        age: Long? = null,
        gender: String? = null,
        avatarUri: String? = null
    ): Result<UserAccount> {
        val uid = requireUid()
        val privateRef = db.collection("users").document(uid)
            .collection("private").document("account")
        val publicRef = db.collection("public_profiles").document(uid)

        val cleanFullName = SecurityUtils.sanitizeInput(fullName, 100)
        if (cleanFullName.length < 2) {
            return Result.failure(IllegalArgumentException("Please enter a valid Full Name."))
        }
        if (age != null && (age < 13L || age > 120L)) {
            return Result.failure(IllegalArgumentException("Please enter a valid age between 13 and 120."))
        }
        if (!SecurityUtils.isSafeMediaUri(avatarUri, allowVideo = false)) {
            return Result.failure(SecurityException("Blocked unsafe profile photo format. Only JPG, PNG, WEBP images (max 25 MB) are allowed."))
        }
        val cleanEmail = email?.let { SecurityUtils.sanitizeInput(it, 150) }?.ifBlank { null }
        val cleanPhone = phone?.let { SecurityUtils.sanitizeInput(it, 30) }?.ifBlank { null }
        val cleanGender = gender?.let { SecurityUtils.sanitizeInput(it, 40) }?.ifBlank { null }
        val cleanCity = SecurityUtils.sanitizeInput(currentCity, 100).ifBlank { null }
        val cleanHometown = SecurityUtils.sanitizeInput(hometown, 100).ifBlank { null }
        val cleanSchool = SecurityUtils.sanitizeInput(schoolCollege, 140).ifBlank { null }
        val cleanAvatar = avatarUri?.trim()?.take(600)?.ifBlank { null }

        return try {
            val existingPrivate = privateRef.get().await()
            if (existingPrivate.exists()) {
                val updates = mutableMapOf<String, Any>(
                    "fullName" to cleanFullName,
                    "termsAccepted" to termsAccepted,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!cleanEmail.isNullOrBlank()) updates["email"] = cleanEmail
                if (!cleanPhone.isNullOrBlank()) updates["phone"] = cleanPhone
                if (age != null) updates["age"] = age
                if (!cleanGender.isNullOrBlank()) updates["gender"] = cleanGender
                if (!passwordHash.isNullOrBlank()) updates["passwordHash"] = passwordHash
                if (!passwordSalt.isNullOrBlank()) updates["passwordSalt"] = passwordSalt
                privateRef.update(updates).await()
            } else {
                val payload = mapOf(
                    "userId" to uid,
                    "fullName" to cleanFullName,
                    "email" to cleanEmail,
                    "phone" to cleanPhone,
                    "age" to age,
                    "gender" to cleanGender,
                    "passwordHash" to passwordHash,
                    "passwordSalt" to passwordSalt,
                    "role" to "user",
                    "termsAccepted" to termsAccepted,
                    "isCreator" to false,
                    "monetizationStatus" to "none",
                    "walletBalance" to 0L,
                    "totalEarnings" to 0L,
                    "isBanned" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null } as Map<String, Any>
                privateRef.set(payload).await()
            }

            val existingPublic = publicRef.get().await()
            if (!existingPublic.exists()) {
                val pubPayload = mapOf(
                    "uid" to uid,
                    "fullName" to cleanFullName,
                    "avatarUri" to cleanAvatar,
                    "currentCity" to cleanCity,
                    "hometown" to cleanHometown,
                    "schoolCollege" to cleanSchool,
                    "isProfileLocked" to false,
                    "isCreator" to false,
                    "monetizationApproved" to false,
                    "visibility" to "community",
                    "isBanned" to false,
                    "followersCount" to 0L,
                    "friendsCount" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null } as Map<String, Any>
                publicRef.set(pubPayload).await()
            } else {
                val pubUpdates = mutableMapOf<String, Any>(
                    "fullName" to cleanFullName,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!cleanAvatar.isNullOrBlank()) pubUpdates["avatarUri"] = cleanAvatar
                if (!cleanCity.isNullOrBlank()) pubUpdates["currentCity"] = cleanCity
                if (!cleanHometown.isNullOrBlank()) pubUpdates["hometown"] = cleanHometown
                publicRef.update(pubUpdates).await()
            }

            try {
                Firebase.auth.currentUser?.updateProfile(
                    userProfileChangeRequest { displayName = cleanFullName }
                )?.await()
            } catch (_: Exception) {
                // Best-effort FirebaseAuth profile sync
            }

            if (!cleanEmail.isNullOrBlank() && !cleanPhone.isNullOrBlank()) {
                upsertPhoneLoginLookup(uid = uid, email = cleanEmail, rawPhone = cleanPhone)
            }

            val fresh = privateRef.get().await()
                .toObject(UserAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: UserAccount(
                    userId = uid,
                    fullName = cleanFullName,
                    email = cleanEmail,
                    phone = cleanPhone,
                    age = age,
                    gender = cleanGender,
                    termsAccepted = termsAccepted
                )
            Result.success(fresh)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, privateRef.path)
            Result.failure(e)
        }
    }

    suspend fun ensurePublicProfileSynced(account: UserAccount) {
        val uid = Firebase.auth.currentUser?.uid ?: return
        val cleanName = SecurityUtils.sanitizeInput(account.fullName, 100)
        if (cleanName.isBlank()) return
        val publicRef = db.collection("public_profiles").document(uid)
        try {
            val snap = publicRef.get().await()
            if (!snap.exists()) {
                val pubPayload = mapOf(
                    "uid" to uid,
                    "fullName" to cleanName,
                    "isProfileLocked" to false,
                    "isCreator" to account.isCreator,
                    "creatorName" to account.creatorName,
                    "creatorCategory" to account.creatorCategory,
                    "creatorBio" to account.creatorBio,
                    "monetizationApproved" to (account.monetizationStatus == "approved"),
                    "visibility" to "community",
                    "isBanned" to account.isBanned,
                    "followersCount" to 0L,
                    "friendsCount" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null } as Map<String, Any>
                publicRef.set(pubPayload).await()
            } else {
                val existingName = snap.getString("fullName").orEmpty()
                if (existingName != cleanName) {
                    publicRef.update(
                        mapOf(
                            "fullName" to cleanName,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
        } catch (_: Exception) {
            // Non-blocking sync safeguard
        }
    }

    suspend fun updateProfileDetails(
        fullName: String,
        phone: String = "",
        avatarUri: String?,
        coverUri: String? = null,
        currentCity: String,
        hometown: String,
        schoolCollege: String,
        workplace: String,
        bio: String,
        isProfileLocked: Boolean,
        age: Long? = null,
        gender: String? = null
    ): Result<Unit> {
        val uid = requireUid()
        val cleanName = SecurityUtils.sanitizeInput(fullName, 100)
        if (cleanName.length < 2) {
            return Result.failure(IllegalArgumentException("Please enter your Full Name (at least 2 characters)."))
        }
        val cleanPhone = SecurityUtils.sanitizeInput(phone, 30)
        if (cleanPhone.isNotBlank() && !SecurityUtils.isValidPhone(cleanPhone)) {
            return Result.failure(IllegalArgumentException("Enter a valid 10-digit mobile number or leave Phone blank."))
        }
        if (age != null && (age < 13L || age > 120L)) {
            return Result.failure(IllegalArgumentException("Please enter a valid age between 13 and 120."))
        }
        if (!SecurityUtils.isSafeMediaUri(avatarUri, allowVideo = false)) {
            return Result.failure(SecurityException("Blocked unsafe profile photo format. Only JPG, PNG, WEBP images (max 25 MB) are allowed."))
        }
        if (!SecurityUtils.isSafeMediaUri(coverUri, allowVideo = false)) {
            return Result.failure(SecurityException("Blocked unsafe cover photo format. Only JPG, PNG, WEBP images (max 25 MB) are allowed."))
        }
        val cleanGender = gender?.let { SecurityUtils.sanitizeInput(it, 40) }?.ifBlank { null }

        val publicRef = db.collection("public_profiles").document(uid)
        val privateRef = db.collection("users").document(uid).collection("private").document("account")
        return try {
            val snap = publicRef.get().await()
            if (snap.exists()) {
                val updates = mutableMapOf<String, Any>(
                    "fullName" to cleanName,
                    "currentCity" to SecurityUtils.sanitizeInput(currentCity, 100),
                    "hometown" to SecurityUtils.sanitizeInput(hometown, 100),
                    "schoolCollege" to SecurityUtils.sanitizeInput(schoolCollege, 140),
                    "workplace" to SecurityUtils.sanitizeInput(workplace, 140),
                    "bio" to SecurityUtils.sanitizeInput(bio, 400),
                    "isProfileLocked" to isProfileLocked,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!avatarUri.isNullOrBlank()) {
                    updates["avatarUri"] = avatarUri.take(600)
                }
                if (!coverUri.isNullOrBlank()) {
                    updates["coverUri"] = coverUri.take(600)
                }
                publicRef.update(updates).await()
            } else {
                val createPayload = mapOf(
                    "uid" to uid,
                    "fullName" to cleanName,
                    "avatarUri" to avatarUri?.take(600),
                    "coverUri" to coverUri?.take(600),
                    "currentCity" to SecurityUtils.sanitizeInput(currentCity, 100),
                    "hometown" to SecurityUtils.sanitizeInput(hometown, 100),
                    "schoolCollege" to SecurityUtils.sanitizeInput(schoolCollege, 140),
                    "workplace" to SecurityUtils.sanitizeInput(workplace, 140),
                    "bio" to SecurityUtils.sanitizeInput(bio, 400),
                    "isProfileLocked" to isProfileLocked,
                    "isCreator" to false,
                    "monetizationApproved" to false,
                    "visibility" to "community",
                    "isBanned" to false,
                    "followersCount" to 0L,
                    "friendsCount" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null } as Map<String, Any>
                publicRef.set(createPayload).await()
            }
            if (privateRef.get().await().exists()) {
                val privateUpdates = mutableMapOf<String, Any>(
                    "fullName" to cleanName,
                    "phone" to (cleanPhone.ifBlank { null } ?: FieldValue.delete()),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (age != null) privateUpdates["age"] = age
                if (!cleanGender.isNullOrBlank()) privateUpdates["gender"] = cleanGender
                privateRef.update(privateUpdates).await()
            }
            try {
                Firebase.auth.currentUser?.updateProfile(
                    userProfileChangeRequest { displayName = cleanName }
                )?.await()
            } catch (_: Exception) {
                // Best-effort FirebaseAuth profile sync
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, publicRef.path)
            Result.failure(e)
        }
    }

    suspend fun registerAsCreator(
        creatorName: String,
        creatorCategory: String,
        creatorBio: String
    ): Result<Unit> {
        val uid = requireUid()
        val privateRef = db.collection("users").document(uid).collection("private").document("account")
        val publicRef = db.collection("public_profiles").document(uid)
        return try {
            val cleanName = SecurityUtils.sanitizeInput(creatorName, 100)
            val cleanCat = SecurityUtils.sanitizeInput(creatorCategory, 60)
            val cleanBio = SecurityUtils.sanitizeInput(creatorBio, 400)
            privateRef.update(
                mapOf(
                    "isCreator" to true,
                    "creatorName" to cleanName,
                    "creatorCategory" to cleanCat,
                    "creatorBio" to cleanBio,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            if (publicRef.get().await().exists()) {
                publicRef.update(
                    mapOf(
                        "isCreator" to true,
                        "creatorName" to cleanName,
                        "creatorCategory" to cleanCat,
                        "creatorBio" to cleanBio,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, privateRef.path)
            Result.failure(e)
        }
    }

    suspend fun applyForMonetization(): Result<Unit> {
        val uid = requireUid()
        val privateRef = db.collection("users").document(uid).collection("private").document("account")
        return try {
            privateRef.update(
                mapOf(
                    "monetizationStatus" to "pending",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, privateRef.path)
            Result.failure(e)
        }
    }

    fun observeCommunityProfiles(): Flow<List<PublicProfile>> {
        val query = db.collection("public_profiles")
            .whereEqualTo("visibility", "community")
            .whereEqualTo("isBanned", false)
        return query.snapshots()
            .map { it.toObjects(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "public_profiles")
                throw error
            }
    }

    fun observeAllProfilesForAdmin(): Flow<List<PublicProfile>> {
        return db.collection("public_profiles")
            .snapshots()
            .map { it.toObjects(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "public_profiles")
                throw error
            }
    }

    fun computeSmartFriendSuggestions(
        myProfile: PublicProfile?,
        allProfiles: List<PublicProfile>,
        myLinks: List<FriendLink>,
        myUid: String
    ): List<FriendSuggestion> {
        val linkedUids = myLinks.flatMap { it.participantUids }.toSet()
        val myFriends = myLinks.filter { it.status == "accepted" }
            .flatMap { it.participantUids }.filter { it != myUid }.toSet()

        return allProfiles
            .filter { it.uid != myUid && it.uid !in linkedUids && !it.isBanned }
            .map { candidate ->
                var score = 1
                val reasonsEn = mutableListOf<String>()
                val reasonsHi = mutableListOf<String>()

                if (!myProfile?.schoolCollege.isNullOrBlank() &&
                    !candidate.schoolCollege.isNullOrBlank() &&
                    myProfile!!.schoolCollege!!.equals(candidate.schoolCollege, ignoreCase = true)
                ) {
                    score += 5
                    reasonsEn.add("Same School/College: ${candidate.schoolCollege}")
                    reasonsHi.add("एक ही स्कूल/कॉलेज: ${candidate.schoolCollege}")
                }
                if (!myProfile?.hometown.isNullOrBlank() &&
                    !candidate.hometown.isNullOrBlank() &&
                    myProfile!!.hometown!!.equals(candidate.hometown, ignoreCase = true)
                ) {
                    score += 4
                    reasonsEn.add("Same Hometown: ${candidate.hometown}")
                    reasonsHi.add("एक ही गृहनगर/गाँव: ${candidate.hometown}")
                }
                if (!myProfile?.currentCity.isNullOrBlank() &&
                    !candidate.currentCity.isNullOrBlank() &&
                    myProfile!!.currentCity!!.equals(candidate.currentCity, ignoreCase = true)
                ) {
                    score += 3
                    reasonsEn.add("Lives in ${candidate.currentCity}")
                    reasonsHi.add("${candidate.currentCity} में रहते हैं")
                }
                if (myFriends.isNotEmpty() && candidate.friendsCount > 0) {
                    reasonsEn.add("Community acquaintance")
                    reasonsHi.add("समुदाय से जुड़े")
                }
                FriendSuggestion(candidate, reasonsEn, reasonsHi, score)
            }
            .sortedByDescending { it.score }
    }

    fun observeFriendLinks(uid: String): Flow<List<FriendLink>> {
        val query = db.collection("friend_links")
            .whereArrayContains("participantUids", uid)
        return query.snapshots()
            .map { it.toObjects(FriendLink::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser?.uid == uid) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, "friend_links")
                }
                throw error
            }
    }

    suspend fun sendFriendRequest(toUid: String, myName: String): Result<Unit> {
        val uid = requireUid()
        val sorted = listOf(uid, toUid).sorted()
        val linkId = "${sorted[0]}_${sorted[1]}"
        val docRef = db.collection("friend_links").document(linkId)
        return try {
            val payload = mapOf(
                "fromUid" to uid,
                "toUid" to toUid,
                "participantUids" to sorted,
                "status" to "pending",
                "actionByUid" to uid,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            sendNotification(
                recipientUid = toUid,
                actorName = myName,
                type = "friend_request",
                message = "$myName sent you a friend request / ने आपको फ्रेंड रिक्वेस्ट भेजी",
                targetId = uid
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateFriendLinkStatus(linkId: String, newStatus: String, otherUid: String, myName: String): Result<Unit> {
        val uid = requireUid()
        val docRef = db.collection("friend_links").document(linkId)
        return try {
            docRef.update(
                mapOf(
                    "status" to newStatus,
                    "actionByUid" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            if (newStatus == "accepted") {
                sendNotification(
                    recipientUid = otherUid,
                    actorName = myName,
                    type = "friend_accept",
                    message = "$myName accepted your friend request / ने आपकी फ्रेंड रिक्वेस्ट स्वीकार की",
                    targetId = uid
                )
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun removeFriendLink(linkId: String): Result<Unit> {
        val docRef = db.collection("friend_links").document(linkId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun blockUser(targetUid: String): Result<Unit> {
        val uid = requireUid()
        val sorted = listOf(uid, targetUid).sorted()
        val linkId = "${sorted[0]}_${sorted[1]}"
        val docRef = db.collection("friend_links").document(linkId)
        return try {
            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(
                    mapOf(
                        "status" to "blocked",
                        "actionByUid" to uid,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.set(
                    mapOf(
                        "fromUid" to uid,
                        "toUid" to targetUid,
                        "participantUids" to sorted,
                        "status" to "blocked",
                        "actionByUid" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    fun conversationIdFor(uidA: String, uidB: String): String {
        val sorted = listOf(uidA, uidB).sorted()
        return "conv_${sorted[0]}_${sorted[1]}"
    }

    fun observeMyConversations(uid: String): Flow<List<Conversation>> {
        return db.collection("conversations")
            .whereArrayContains("participantUids", uid)
            .snapshots()
            .map { snap ->
                snap.toObjects(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser?.uid == uid) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, "conversations")
                }
                throw error
            }
    }

    fun observeMessages(convId: String, uid: String): Flow<List<ChatMessage>> {
        val path = "conversations/$convId/messages"
        return db.collection("conversations").document(convId).collection("messages")
            .whereArrayContains("participantUids", uid)
            .snapshots()
            .map { snap ->
                snap.toObjects(ChatMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser?.uid == uid) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                }
                throw error
            }
    }

    suspend fun sendChatMessage(
        otherUid: String,
        senderName: String,
        messageType: String,
        text: String,
        mediaUri: String? = null,
        voiceDurationSec: Long? = null
    ): Result<Unit> {
        val uid = requireUid()
        if (!SecurityUtils.isSafeMediaUri(mediaUri, allowVideo = true, allowVoiceNotePath = (messageType == "voice_note"))) {
            return Result.failure(SecurityException("Blocked dangerous or unsupported chat attachment."))
        }
        val cleanText = SecurityUtils.sanitizeInput(text, 1000)
        val cleanSenderName = SecurityUtils.sanitizeInput(senderName, 100).ifBlank { "Member" }
        val sorted = listOf(uid, otherUid).sorted()
        val convId = "conv_${sorted[0]}_${sorted[1]}"
        val convRef = db.collection("conversations").document(convId)
        val msgRef = convRef.collection("messages").document(UUID.randomUUID().toString())
        val preview = when (messageType) {
            "voice_note" -> "Voice note (${voiceDurationSec ?: 1}s)"
            "image" -> if (cleanText.isNotBlank()) cleanText else "Photo"
            "video" -> if (cleanText.isNotBlank()) cleanText else "Video"
            else -> cleanText
        }.take(500)

        return try {
            val convSnap = convRef.get().await()
            if (convSnap.exists()) {
                convRef.update(
                    mapOf(
                        "lastMessage" to preview,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                convRef.set(
                    mapOf(
                        "participantUids" to sorted,
                        "lastMessage" to preview,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            val msgPayload = mapOf(
                "senderUid" to uid,
                "senderName" to cleanSenderName,
                "participantUids" to sorted,
                "messageType" to messageType,
                "text" to cleanText,
                "mediaUri" to mediaUri?.take(600),
                "voiceDurationSec" to voiceDurationSec,
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            msgRef.set(msgPayload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, msgRef.path)
            Result.failure(e)
        }
    }

    fun observeGroups(): Flow<List<CommunityGroup>> {
        return db.collection("groups")
            .whereEqualTo("moderationStatus", "active")
            .snapshots()
            .map { snap ->
                snap.toObjects(CommunityGroup::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "groups")
                throw error
            }
    }

    suspend fun createGroup(name: String, description: String, city: String, category: String): Result<Unit> {
        val uid = requireUid()
        val docRef = db.collection("groups").document(UUID.randomUUID().toString())
        return try {
            val payload = mapOf(
                "name" to SecurityUtils.sanitizeInput(name, 120),
                "description" to SecurityUtils.sanitizeInput(description, 500),
                "city" to SecurityUtils.sanitizeInput(city, 100).ifBlank { null },
                "category" to SecurityUtils.sanitizeInput(category, 60),
                "ownerUid" to uid,
                "memberUids" to listOf(uid),
                "memberCount" to 1L,
                "moderationStatus" to "active",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun toggleJoinGroup(group: CommunityGroup): Result<Unit> {
        val uid = requireUid()
        val docRef = db.collection("groups").document(group.id)
        return try {
            val current = group.memberUids.toMutableList()
            val newCount: Long
            if (uid in current) {
                current.remove(uid)
                newCount = (group.memberCount - 1L).coerceAtLeast(0L)
            } else {
                if (current.size < 50) current.add(uid)
                newCount = group.memberCount + 1L
            }
            docRef.update(
                mapOf(
                    "memberUids" to current,
                    "memberCount" to newCount,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    fun observePages(): Flow<List<PublicPage>> {
        return db.collection("pages")
            .whereEqualTo("moderationStatus", "active")
            .snapshots()
            .map { snap ->
                snap.toObjects(PublicPage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "pages")
                throw error
            }
    }

    suspend fun createPage(name: String, description: String, category: String, city: String): Result<Unit> {
        val uid = requireUid()
        val docRef = db.collection("pages").document(UUID.randomUUID().toString())
        return try {
            val payload = mapOf(
                "name" to SecurityUtils.sanitizeInput(name, 120),
                "description" to SecurityUtils.sanitizeInput(description, 500),
                "category" to SecurityUtils.sanitizeInput(category, 60),
                "city" to SecurityUtils.sanitizeInput(city, 100).ifBlank { null },
                "ownerUid" to uid,
                "followerUids" to listOf(uid),
                "followerCount" to 1L,
                "moderationStatus" to "active",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun toggleFollowPage(page: PublicPage): Result<Unit> {
        val uid = requireUid()
        val docRef = db.collection("pages").document(page.id)
        return try {
            val current = page.followerUids.toMutableList()
            val newCount: Long
            if (uid in current) {
                current.remove(uid)
                newCount = (page.followerCount - 1L).coerceAtLeast(0L)
            } else {
                if (current.size < 50) current.add(uid)
                newCount = page.followerCount + 1L
            }
            docRef.update(
                mapOf(
                    "followerUids" to current,
                    "followerCount" to newCount,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeNotifications(uid: String): Flow<List<NotificationItem>> {
        return db.collection("notifications")
            .whereEqualTo("recipientUid", uid)
            .snapshots()
            .map { snap ->
                snap.toObjects(NotificationItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser?.uid == uid) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, "notifications")
                }
                throw error
            }
    }

    suspend fun sendNotification(
        recipientUid: String,
        actorName: String,
        type: String,
        message: String,
        targetId: String? = null
    ) {
        val uid = Firebase.auth.currentUser?.uid ?: return
        if (uid == recipientUid) return
        val docRef = db.collection("notifications").document(UUID.randomUUID().toString())
        try {
            val payload = mapOf(
                "recipientUid" to recipientUid,
                "actorUid" to uid,
                "actorName" to SecurityUtils.sanitizeInput(actorName, 100),
                "type" to type,
                "message" to SecurityUtils.sanitizeInput(message, 300),
                "targetId" to targetId?.take(128),
                "isRead" to false,
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
        }
    }

    suspend fun markNotificationRead(notifId: String) {
        val docRef = db.collection("notifications").document(notifId)
        try {
            docRef.update(mapOf("isRead" to true)).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
        }
    }

    suspend fun resetCustomerPassword(newPassword: String, email: String? = null): Result<Unit> {
        val uid = requireUid()
        if (!SecurityUtils.isAcceptablePassword(newPassword)) {
            return Result.failure(IllegalArgumentException("Password must be at least 6 characters."))
        }
        val privateRef = db.collection("users").document(uid).collection("private").document("account")
        return try {
            val snap = privateRef.get().await()
            if (!snap.exists()) {
                return Result.failure(IllegalStateException("No Dil Suno customer account found for this login."))
            }
            val salt = SecurityUtils.generateSalt()
            val hash = SecurityUtils.hashPassword(newPassword, salt)
            privateRef.update(
                mapOf(
                    "passwordHash" to hash,
                    "passwordSalt" to salt,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, privateRef.path)
            Result.failure(e)
        }
    }

    suspend fun upsertPhoneLoginLookup(
        uid: String,
        email: String,
        rawPhone: String
    ): Result<Unit> {
        val cleanEmail = SecurityUtils.normalizeEmail(SecurityUtils.sanitizeInput(email, 160))
        val e164Phone = SecurityUtils.normalizeIndianPhoneE164(rawPhone)
        if (!SecurityUtils.isValidEmail(cleanEmail) || e164Phone == null) {
            return Result.success(Unit)
        }
        val phoneHash = SecurityUtils.sha256Hex(e164Phone)
        val docRef = db.collection("phone_lookup").document(phoneHash)
        return try {
            val payload = mapOf(
                "uid" to uid,
                "email" to cleanEmail,
                "phoneHash" to phoneHash,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun lookupEmailByPhone(rawPhone: String): String? {
        if (Firebase.auth.currentUser == null) return null
        val e164Phone = SecurityUtils.normalizeIndianPhoneE164(rawPhone) ?: return null
        val phoneHash = SecurityUtils.sha256Hex(e164Phone)
        return try {
            val snap = db.collection("phone_lookup").document(phoneHash).get().await()
            if (!snap.exists()) null else snap.getString("email")?.trim()?.ifBlank { null }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            null
        }
    }

    suspend fun deleteMyAccountCompletely(): Result<Unit> {
        val uid = requireUid()
        val privateRef = db.collection("users").document(uid).collection("private").document("account")
        val publicRef = db.collection("public_profiles").document(uid)
        return try {
            val privateSnap = privateRef.get().await()
            val savedPhone = privateSnap.getString("phone")
            if (savedPhone != null) {
                SecurityUtils.normalizeIndianPhoneE164(savedPhone)?.let { e164 ->
                    val hash = SecurityUtils.sha256Hex(e164)
                    runCatching { db.collection("phone_lookup").document(hash).delete().await() }
                }
            }
            if (privateSnap.exists()) {
                privateRef.delete().await()
            }
            if (publicRef.get().await().exists()) {
                publicRef.delete().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, privateRef.path)
            Result.failure(e)
        }
    }

    suspend fun creditWalletBalance(uid: String, amountInr: Long): Result<Long> {
        if (amountInr <= 0L) {
            return Result.failure(IllegalArgumentException("Credit amount must be positive."))
        }
        val privateRef = db.collection("users").document(uid).collection("private").document("account")
        return try {
            val newBalance = db.runTransaction { tx ->
                val snap = tx.get(privateRef)
                val current = snap.getLong("walletBalance") ?: 0L
                val updated = current + amountInr
                if (snap.exists()) {
                    tx.update(
                        privateRef,
                        mapOf(
                            "walletBalance" to updated,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                updated
            }.await()
            Result.success(newBalance)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, privateRef.path)
            Result.failure(e)
        }
    }

    suspend fun deductWalletBalance(uid: String, amountInr: Long): Result<Long> {
        if (amountInr <= 0L) {
            return Result.failure(IllegalArgumentException("Deduction amount must be positive."))
        }
        val privateRef = db.collection("users").document(uid).collection("private").document("account")
        return try {
            val newBalance = db.runTransaction { tx ->
                val snap = tx.get(privateRef)
                val current = snap.getLong("walletBalance") ?: 0L
                if (current < amountInr) {
                    throw IllegalStateException("Insufficient wallet balance (₹$current < ₹$amountInr).")
                }
                val updated = current - amountInr
                if (snap.exists()) {
                    tx.update(
                        privateRef,
                        mapOf(
                            "walletBalance" to updated,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                updated
            }.await()
            Result.success(newBalance)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, privateRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateActiveSessionToken(uid: String, sessionToken: String): Result<Unit> {
        val privateRef = db.collection("users").document(uid).collection("private").document("account")
        return try {
            val snap = privateRef.get().await()
            if (snap.exists()) {
                privateRef.update(
                    mapOf(
                        "activeSessionToken" to sessionToken,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, privateRef.path)
            Result.failure(e)
        }
    }

}


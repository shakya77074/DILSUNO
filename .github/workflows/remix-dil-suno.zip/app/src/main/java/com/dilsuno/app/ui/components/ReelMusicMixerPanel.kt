package com.dilsuno.app.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.MediaUploadValidator
import com.dilsuno.app.core.MusicTrackOption
import com.dilsuno.app.core.RoyaltyFreeMusicLibrary
import com.dilsuno.app.core.tr
import com.dilsuno.app.ui.theme.HairlineDividerBlue
import com.dilsuno.app.ui.theme.PureWhiteBackground
import com.dilsuno.app.ui.theme.RoyalBlueDeep
import com.dilsuno.app.ui.theme.RoyalBluePrimary
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.SlateDarkText
import com.dilsuno.app.ui.theme.SlateSubtleText
import com.dilsuno.app.ui.theme.SoftBlueCardSurface

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReelMusicMixerPanel(
    tracks: List<MusicTrackOption>,
    selectedMusicId: String,
    customAudioUri: String?,
    customAudioLabel: String?,
    originalVolume: Float,
    musicVolume: Float,
    lang: AppLang,
    onSelectTrack: (MusicTrackOption) -> Unit,
    onPickDeviceAudio: (uriString: String, displayName: String) -> Unit,
    onClearDeviceAudio: () -> Unit,
    onOriginalVolumeChange: (Float) -> Unit,
    onMusicVolumeChange: (Float) -> Unit,
    onSecurityError: (String) -> Unit,
    showOriginalVolumeSlider: Boolean = true,
    showDeviceAudioPicker: Boolean = true,
    maxVisibleTracks: Int = 20,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedMoodFilter by remember { mutableStateOf("ALL") }
    var playingPreviewId by remember { mutableStateOf<String?>(null) }

    val deviceAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { picked ->
            MediaUploadValidator.validatePickedAudio(
                context = context,
                uri = picked,
                lang = lang
            ).onSuccess { validated ->
                RoyaltyFreeMusicLibrary.stopPreview()
                playingPreviewId = null
                onPickDeviceAudio(validated.first, validated.second)
            }.onFailure { err ->
                onSecurityError(err.localizedMessage ?: "Unsupported or oversized audio file.")
            }
        }
    }

    val filteredTracks = remember(tracks, selectedMoodFilter) {
        val list = if (selectedMoodFilter == "ALL") {
            tracks
        } else {
            val moodObj = RoyaltyFreeMusicLibrary.moodCategories.firstOrNull { it.id == selectedMoodFilter }
            tracks.filter { track ->
                track.id == "none" ||
                    track.mood.equals(moodObj?.combinedLabel, ignoreCase = true) ||
                    track.mood.contains(moodObj?.labelEn.orEmpty(), ignoreCase = true) ||
                    track.mood.contains(moodObj?.labelHi.orEmpty(), ignoreCase = true)
            }
        }
        list.take(maxVisibleTracks)
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Copyright-Free Safety Header Badge
        Surface(
            color = SafeEmerald.copy(alpha = 0.12f),
            border = BorderStroke(1.dp, SafeEmerald.copy(alpha = 0.45f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Verified,
                    contentDescription = null,
                    tint = SafeEmerald,
                    modifier = Modifier.size(18.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = tr(
                            RoyaltyFreeMusicLibrary.COPYRIGHT_FREE_BADGE_EN,
                            RoyaltyFreeMusicLibrary.COPYRIGHT_FREE_BADGE_HI,
                            lang
                        ),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = SafeEmerald
                    )
                    Text(
                        text = tr(
                            "Zero copyright strikes • Categorized Hindi & Instrumental tracks",
                            "कोई कॉपीराइट स्ट्राइक नहीं • मूड के अनुसार हिंदी व इंस्ट्रुमेंटल धुन",
                            lang
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateSubtleText
                    )
                }
            }
        }

        // Device Audio Attachment Button (Zero-Permission SAF Picker)
        if (showDeviceAudioPicker) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { deviceAudioLauncher.launch(arrayOf("audio/*")) },
                    border = BorderStroke(1.dp, RoyalBluePrimary),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = RoyalBlueDeep),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("reel_pick_device_audio_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.AudioFile,
                        contentDescription = null,
                        tint = RoyalBlueDeep,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = tr("Attach Device Audio (.mp3 / .m4a)", "डिवाइस से अपना ऑडियो जोड़ें", lang),
                        color = RoyalBlueDeep,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (!customAudioUri.isNullOrBlank()) {
                val isDevicePlaying = playingPreviewId == "device_audio"
                Card(
                    colors = CardDefaults.cardColors(containerColor = SoftBlueCardSurface),
                    border = BorderStroke(1.dp, RoyalBluePrimary.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Filled.MusicNote, null, tint = RoyalBluePrimary, modifier = Modifier.size(18.dp))
                                Text(
                                    text = customAudioLabel?.ifBlank { "Device Audio Selected" } ?: "Device Audio Selected",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateDarkText,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        if (isDevicePlaying) {
                                            RoyaltyFreeMusicLibrary.stopPreview()
                                            playingPreviewId = null
                                        } else {
                                            playingPreviewId = "device_audio"
                                            RoyaltyFreeMusicLibrary.playUriPreview(
                                                context = context,
                                                uriString = customAudioUri,
                                                trackKey = "device_audio",
                                                volume = musicVolume
                                            ) {
                                                playingPreviewId = null
                                            }
                                        }
                                    },
                                    modifier = Modifier.size(48.dp).testTag("reel_preview_device_audio_button")
                                ) {
                                    Icon(
                                        imageVector = if (isDevicePlaying) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                                        contentDescription = tr("Preview Device Audio", "ऑडियो सुनें", lang),
                                        tint = RoyalBluePrimary
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        if (isDevicePlaying) {
                                            RoyaltyFreeMusicLibrary.stopPreview()
                                            playingPreviewId = null
                                        }
                                        onClearDeviceAudio()
                                    },
                                    modifier = Modifier.size(48.dp).testTag("reel_clear_device_audio_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = tr("Remove Device Audio", "ऑडियो हटाएं", lang),
                                        tint = SlateSubtleText
                                    )
                                }
                            }
                        }
                        Text(
                            text = tr(
                                "User Responsibility: 100% copyright & content liability for attached device audio rests solely with you.",
                                "100% यूज़र जिम्मेदारी: डिवाइस से जोड़े गए ऑडियो के कॉपीराइट और कंटेंट की पूरी जिम्मेदारी स्वयं आपकी है।",
                                lang
                            ),
                            style = MaterialTheme.typography.labelSmall,
                            color = SlateSubtleText
                        )
                    }
                }
            }
        }

        // 5 Mood Categories Filter Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item(key = "mood_ALL") {
                FilterChip(
                    selected = selectedMoodFilter == "ALL",
                    onClick = { selectedMoodFilter = "ALL" },
                    leadingIcon = { Icon(Icons.Filled.LibraryMusic, null, modifier = Modifier.size(16.dp)) },
                    label = { Text(tr("All Moods", "सभी मूड", lang)) },
                    modifier = Modifier.testTag("music_mood_all")
                )
            }
            items(RoyaltyFreeMusicLibrary.moodCategories, key = { it.id }) { mood ->
                FilterChip(
                    selected = selectedMoodFilter == mood.id,
                    onClick = { selectedMoodFilter = mood.id },
                    label = {
                        Text(
                            text = if (lang == AppLang.HI) mood.labelHi else mood.labelEn,
                            maxLines = 1
                        )
                    },
                    modifier = Modifier.testTag("music_mood_${mood.id}")
                )
            }
        }

        // Categorized Built-In & Owner-Curated Copyright-Free Music Tracks
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            filteredTracks.forEach { track ->
                val isSelected = customAudioUri.isNullOrBlank() && selectedMusicId == track.id
                val isPlaying = playingPreviewId == track.id
                Surface(
                    color = if (isSelected) SoftBlueCardSurface else PureWhiteBackground,
                    border = BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) RoyalBluePrimary else HairlineDividerBlue
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            onClearDeviceAudio()
                            onSelectTrack(track)
                        }
                        .testTag("music_track_${track.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Text(
                                text = if (lang == AppLang.HI) track.titleHi else track.titleEn,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                color = SlateDarkText,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (track.id != "none") {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Surface(
                                        color = SafeEmerald.copy(alpha = 0.14f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = if (lang == AppLang.HI) RoyaltyFreeMusicLibrary.COPYRIGHT_FREE_BADGE_HI
                                            else RoyaltyFreeMusicLibrary.COPYRIGHT_FREE_BADGE_EN,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = SafeEmerald,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Surface(
                                        color = RoyalBluePrimary.copy(alpha = 0.1f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = track.mood.substringBefore(" ("),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = RoyalBlueDeep,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                        if (track.id != "none") {
                            IconButton(
                                onClick = {
                                    onClearDeviceAudio()
                                    onSelectTrack(track)
                                    if (isPlaying) {
                                        RoyaltyFreeMusicLibrary.stopPreview()
                                        playingPreviewId = null
                                    } else {
                                        playingPreviewId = track.id
                                        RoyaltyFreeMusicLibrary.playPreview(
                                            scope = scope,
                                            track = track,
                                            context = context,
                                            volume = musicVolume
                                        ) {
                                            playingPreviewId = null
                                        }
                                    }
                                },
                                modifier = Modifier.size(48.dp).testTag("music_preview_${track.id}")
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                                    contentDescription = tr("Preview Music", "संगीत सुनें", lang),
                                    tint = RoyalBluePrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Audio Mixer Sliders: Original Video Audio vs Background Music
        HorizontalDivider(color = HairlineDividerBlue)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.VolumeUp, null, tint = RoyalBluePrimary, modifier = Modifier.size(18.dp))
                Text(
                    text = tr("Audio Volume Mixer", "ऑडियो वॉल्यूम मिक्सर", lang),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = SlateDarkText
                )
            }
            if (showOriginalVolumeSlider) {
                Text(
                    text = tr(
                        "Original Video Audio: ${(originalVolume * 100).toInt()}%",
                        "मूल वीडियो आवाज़: ${(originalVolume * 100).toInt()}%",
                        lang
                    ),
                    style = MaterialTheme.typography.labelMedium,
                    color = SlateDarkText
                )
                Slider(
                    value = originalVolume,
                    onValueChange = onOriginalVolumeChange,
                    valueRange = 0f..1f,
                    modifier = Modifier.fillMaxWidth().testTag("mixer_original_audio_slider")
                )
            }
            Text(
                text = tr(
                    "Background Music Volume: ${(musicVolume * 100).toInt()}%",
                    "बैकग्राउंड म्यूज़िक आवाज़: ${(musicVolume * 100).toInt()}%",
                    lang
                ),
                style = MaterialTheme.typography.labelMedium,
                color = SlateDarkText
            )
            Slider(
                value = musicVolume,
                onValueChange = { vol ->
                    onMusicVolumeChange(vol)
                    RoyaltyFreeMusicLibrary.setPreviewVolume(vol)
                },
                valueRange = 0f..1f,
                modifier = Modifier.fillMaxWidth().testTag("mixer_background_music_slider")
            )
        }
    }
}

package com.dilsuno.app.core

import android.content.Context
import android.os.Build
import com.dilsuno.app.BuildConfig
import java.io.File

data class DeviceSecurityReport(
    val isRooted: Boolean,
    val isEmulator: Boolean,
    val isCloned: Boolean,
    val reasons: List<String>,
    val shouldHardBlock: Boolean
)

/**
 * Runtime integrity protection detecting rooted devices, emulators, and cloned/repackaged APKs.
 * In debug preview builds (`BuildConfig.DEBUG`), root/emulator checks are reported without hard-blocking
 * so developers can verify the app on Android emulators; release builds enforce full hard-blocking.
 */
object DeviceSecurityGuard {
    const val EXPECTED_PACKAGE_NAME = "com.dilsuno.app"

    private val ROOT_BINARY_PATHS = listOf(
        "/system/bin/su",
        "/system/xbin/su",
        "/sbin/su",
        "/system/su",
        "/system/bin/.ext/.su",
        "/system/usr/we-need-root/su",
        "/data/local/su",
        "/data/local/bin/su",
        "/data/local/xbin/su",
        "/su/bin/su",
        "/magisk/.core/bin/su",
        "/system/app/Superuser.apk",
        "/system/app/SuperSU.apk"
    )

    fun evaluateDeviceSecurity(context: Context): DeviceSecurityReport {
        val reasons = mutableListOf<String>()

        val isCloned = context.packageName != EXPECTED_PACKAGE_NAME &&
            !Build.FINGERPRINT.equals("robolectric", ignoreCase = true)
        if (isCloned) {
            reasons.add("Unverified/Cloned APK package detected (${context.packageName}).")
        }

        val isRooted = detectRoot()
        if (isRooted) {
            reasons.add("Rooted device environment detected.")
        }

        val isEmulator = detectEmulator()
        if (isEmulator) {
            reasons.add("Virtual/Emulator runtime detected.")
        }

        val isRobolectric = Build.FINGERPRINT.equals("robolectric", ignoreCase = true)
        val shouldHardBlock = !isRobolectric && (isCloned || (!BuildConfig.DEBUG && (isRooted || isEmulator)))

        return DeviceSecurityReport(
            isRooted = isRooted,
            isEmulator = isEmulator,
            isCloned = isCloned,
            reasons = reasons,
            shouldHardBlock = shouldHardBlock
        )
    }

    internal fun detectRoot(): Boolean {
        val tags = Build.TAGS.orEmpty()
        if (tags.contains("test-keys", ignoreCase = true)) {
            return true
        }
        return ROOT_BINARY_PATHS.any { path ->
            runCatching { File(path).exists() }.getOrDefault(false)
        }
    }

    internal fun detectEmulator(): Boolean {
        val fingerprint = Build.FINGERPRINT.orEmpty().lowercase()
        val model = Build.MODEL.orEmpty().lowercase()
        val manufacturer = Build.MANUFACTURER.orEmpty().lowercase()
        val brand = Build.BRAND.orEmpty().lowercase()
        val device = Build.DEVICE.orEmpty().lowercase()
        val product = Build.PRODUCT.orEmpty().lowercase()
        val hardware = Build.HARDWARE.orEmpty().lowercase()

        if (fingerprint == "robolectric") return false

        return fingerprint.startsWith("generic") ||
            fingerprint.startsWith("unknown") ||
            fingerprint.contains("emulator") ||
            model.contains("google_sdk") ||
            model.contains("emulator") ||
            model.contains("android sdk built for x86") ||
            manufacturer.contains("genymotion") ||
            hardware.contains("goldfish") ||
            hardware.contains("ranchu") ||
            product.contains("sdk_gphone") ||
            product.contains("vbox86p") ||
            product.contains("emulator") ||
            (brand.startsWith("generic") && device.startsWith("generic"))
    }
}

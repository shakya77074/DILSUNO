package com.dilsuno.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Copyright
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.dilsuno.app.R
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.LiveStreamItem
import com.dilsuno.app.data.model.PostItem
import com.dilsuno.app.data.model.PublicProfile
import com.dilsuno.app.data.model.UiState
import com.dilsuno.app.ui.components.ClickableHashtagAndMentionText
import com.dilsuno.app.ui.components.CommunityGuidelines18PlusDialog
import com.dilsuno.app.ui.components.EditPostCaptionDialog
import com.dilsuno.app.ui.components.HashtagFeedDialog
import com.dilsuno.app.ui.components.PostThreeDotActionMenu
import com.dilsuno.app.ui.components.ReportContentReasonDialog
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.RoyalNavy
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.VelvetIndigo
import com.dilsuno.app.viewmodel.MainAppViewModel

private data class ReelShowcaseDisplay(
    val post: PostItem,
    val isStarterSample: Boolean,
    val sampleDrawableRes: Int? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReelsAndLiveScreen(
    viewModel: MainAppViewModel,
    lang: AppLang,
    initialReelId: String? = null,
    onOpenPrivateCall: () -> Unit = {},
    onOpenCreateReel: () -> Unit = {}
) {
    val context = LocalContext.current
    val postsState by viewModel.postsState.collectAsStateWithLifecycle()
    val liveStreams by viewModel.liveStreams.collectAsStateWithLifecycle()
    val profiles by viewModel.communityProfiles.collectAsStateWithLifecycle()
    val appConfig by viewModel.appConfig.collectAsStateWithLifecycle()
    val savedPostIds by viewModel.savedPostIds.collectAsStateWithLifecycle()
    val isScanningAi by viewModel.isScanningAi.collectAsStateWithLifecycle()
    val hasAcceptedGuidelines by viewModel.hasAcceptedCommunityGuidelines18Plus.collectAsStateWithLifecycle()
    val availableMusicTracks by viewModel.availableMusicTracks.collectAsStateWithLifecycle()

    var showGoLiveDialog by remember { mutableStateOf(false) }
    var showLiveRoomsSheet by remember { mutableStateOf(false) }
    var activeLiveRoom by remember { mutableStateOf<LiveStreamItem?>(null) }
    var showVnStudio by remember { mutableStateOf(false) }
    var pendingStudioPublish by remember { mutableStateOf<VnStudioEditResult?>(null) }
    var commentTargetReel by remember { mutableStateOf<PostItem?>(null) }
    var reportTargetReel by remember { mutableStateOf<PostItem?>(null) }
    var pendingGuidelinesAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var activeHashtagFeed by remember { mutableStateOf<String?>(null) }
    var editingCaptionReel by remember { mutableStateOf<PostItem?>(null) }
    var isMuted by remember { mutableStateOf(false) }

    fun runWithGuidelinesGate(action: () -> Unit) {
        if (hasAcceptedGuidelines) {
            action()
        } else {
            pendingGuidelinesAction = action
        }
    }

    val profilesByUid = remember(profiles) { profiles.associateBy { it.uid } }

    val livePosts = (postsState as? UiState.Success)?.data
        ?.filter { !it.copyrightClaimActive && (it.postType == "reel" || it.postType == "video" || !it.mediaUri.isNullOrBlank()) }
        ?: emptyList()

    val pagerReels = remember(livePosts) {
        if (livePosts.isNotEmpty()) {
            livePosts.map { ReelShowcaseDisplay(post = it, isStarterSample = false) }
        } else {
            listOf(
                ReelShowcaseDisplay(
                    post = PostItem(
                        id = "sample_reel_1",
                        authorUid = "sample_1",
                        authorName = "Aarav Sharma",
                        postType = "reel",
                        title = "दिल की बात सुनो ❤️",
                        caption = "जब भी मन भारी लगे, ❤️ दिल सुनो पर अपने दिल की बात खुलकर साझा करें। #DilSuno #PositiveIndia",
                        city = "Jaipur",
                        musicTrack = "Calm Acoustic Breeze",
                        loveCount = 128L,
                        commentsCount = 14L,
                        viewsCount = 1420L
                    ),
                    isStarterSample = true,
                    sampleDrawableRes = R.drawable.img_community_hero
                ),
                ReelShowcaseDisplay(
                    post = PostItem(
                        id = "sample_reel_2",
                        authorUid = "sample_2",
                        authorName = "Priya Deshmukh",
                        postType = "reel",
                        title = "शाम की चाय और सुकून ☕",
                        caption = "आज के छोटे-छोटे सुकून भरे पल। नीचे कैमरा आइकॉन से अपनी पहली रील बनाएं! #DesiVibes",
                        city = "Pune",
                        musicTrack = "Lofi Sunset Beat",
                        loveCount = 94L,
                        commentsCount = 9L,
                        viewsCount = 890L
                    ),
                    isStarterSample = true,
                    sampleDrawableRes = R.drawable.img_dil_se_banner
                ),
                ReelShowcaseDisplay(
                    post = PostItem(
                        id = "sample_reel_3",
                        authorUid = "sample_3",
                        authorName = "Kabir Malhotra",
                        postType = "reel",
                        title = "अकेले महसूस कर रहे हैं? 🎧",
                        caption = "सिर्फ ₹100 में हमारे वेरिफाइड श्रोता से सुरक्षित प्राइवेट ऑडियो कॉल पर बात करें।",
                        city = "Lucknow",
                        musicTrack = "Soft Piano Warmth",
                        loveCount = 215L,
                        commentsCount = 21L,
                        viewsCount = 2310L
                    ),
                    isStarterSample = true,
                    sampleDrawableRes = R.drawable.img_header_heart_logo
                )
            )
        }
    }

    val initialPage = remember(initialReelId, pagerReels) {
        val idx = if (initialReelId != null) pagerReels.indexOfFirst { it.post.id == initialReelId } else 0
        idx.coerceAtLeast(0)
    }
    val pagerState = rememberPagerState(initialPage = initialPage, pageCount = { pagerReels.size })

    val activeLiveCount = liveStreams.count { it.status == "live" }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RoyalNavy)
    ) {
        VerticalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize().testTag("vertical_reels_pager")
        ) { pageIndex ->
            val item = pagerReels[pageIndex]
            val reel = item.post
            val isCurrentPage = pagerState.currentPage == pageIndex
            val authorProf = profilesByUid[reel.authorUid]
            val authorName = SecurityUtils.resolveDisplayName(authorProf?.fullName, reel.authorName)

            val isVideo = remember(reel.mediaUri) {
                val u = reel.mediaUri.orEmpty()
                if (u.isBlank()) false
                else {
                    val mime = runCatching { context.contentResolver.getType(Uri.parse(u)) }.getOrNull().orEmpty()
                    mime.startsWith("video") || u.endsWith(".mp4", true) || u.endsWith(".mov", true)
                }
            }

            Box(modifier = Modifier.fillMaxSize()) {
                // Visual Layer: VideoView / Image / Gradient
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(listOf(RoyalNavy, VelvetIndigo, Color.Black))
                        )
                ) {
                    if (item.sampleDrawableRes != null) {
                        Image(
                            painter = painterResource(id = item.sampleDrawableRes),
                            contentDescription = reel.title ?: reel.caption,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else if (!reel.mediaUri.isNullOrBlank() && isVideo) {
                        com.dilsuno.app.ui.components.TextureVideoPlayer(
                            videoUri = reel.mediaUri,
                            volume = if (isMuted || !isCurrentPage) 0f else 1f,
                            isPlaying = isCurrentPage,
                            isLooping = true,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else if (!reel.mediaUri.isNullOrBlank()) {
                        AsyncImage(
                            model = reel.mediaUri,
                            contentDescription = reel.caption,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }

                // Bottom Gradient Scrim
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                            )
                        )
                )

                val isSaved = reel.id in savedPostIds

                // Creator & Caption Info (Above Bottom 4-Icon Action Bar)
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 74.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, CrimsonPrimary, CircleShape)
                                    .background(VelvetIndigo),
                                contentAlignment = Alignment.Center
                            ) {
                                val avatar = authorProf?.avatarUri ?: reel.authorAvatar
                                if (!avatar.isNullOrBlank()) {
                                    AsyncImage(
                                        model = avatar,
                                        contentDescription = authorName,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Text(
                                        text = authorName.take(2).uppercase(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = authorName,
                                        color = Color.White,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (item.isStarterSample) {
                                        Surface(
                                            color = CrimsonPrimary,
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = tr("Featured", "फीचर्ड", lang),
                                                color = Color.White,
                                                style = MaterialTheme.typography.labelSmall,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                                if (!reel.city.isNullOrBlank()) {
                                    Text(
                                        text = "${reel.city} • ${pageIndex + 1}/${pagerReels.size}",
                                        color = Color.White.copy(alpha = 0.78f),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }

                        // Visible 3-Dot Action Menu: Report Content & Block User
                        Surface(
                            color = Color.Black.copy(alpha = 0.5f),
                            shape = CircleShape
                        ) {
                            PostThreeDotActionMenu(
                                lang = lang,
                                testTagPrefix = "reel_${reel.id}",
                                iconTint = Color.White,
                                onEditCaption = if (!item.isStarterSample && reel.authorUid == viewModel.currentUserId) {
                                    { editingCaptionReel = reel }
                                } else null,
                                onReportContent = { reportTargetReel = reel },
                                onBlockUser = { viewModel.blockUser(reel.authorUid, authorName) }
                            )
                        }
                    }

                    if (!reel.title.isNullOrBlank()) {
                        Text(
                            text = reel.title,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    ClickableHashtagAndMentionText(
                        text = reel.caption,
                        textColor = Color.White.copy(alpha = 0.94f),
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 3,
                        onHashtagClick = { activeHashtagFeed = it }
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!reel.musicTrack.isNullOrBlank() && reel.musicTrack != "none") {
                            Surface(
                                color = Color.Black.copy(alpha = 0.55f),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.LibraryMusic, null, tint = Color.White, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text(reel.musicTrack, color = Color.White, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                        if (!reel.editorSummary.isNullOrBlank()) {
                            Surface(
                                color = VelvetIndigo.copy(alpha = 0.85f),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text(
                                    text = "🎬 ${reel.editorSummary}",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }

                // Clean Facebook-Style 4-Icon Bottom Action Row (Like, Comment, Share, Save)
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.55f))
                ) {
                    HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = {
                                if (!item.isStarterSample) {
                                    viewModel.reactToPost(reel, "likesCount", "👍")
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("reel_like_button_${reel.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ThumbUp,
                                contentDescription = tr("Like", "लाइक", lang),
                                tint = Color.White,
                                modifier = Modifier.size(19.dp)
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                text = "${reel.likesCount}",
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        TextButton(
                            onClick = {
                                if (!item.isStarterSample) {
                                    commentTargetReel = reel
                                } else {
                                    onOpenCreateReel()
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("reel_comment_button_${reel.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ChatBubbleOutline,
                                contentDescription = tr("Comment", "टिप्पणी", lang),
                                tint = Color.White,
                                modifier = Modifier.size(19.dp)
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                text = "${reel.commentsCount}",
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        TextButton(
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "$authorName on ❤️ दिल सुनो • Dil Suno: ${reel.title ?: ""} ${reel.caption}"
                                    )
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Reel"))
                            },
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("reel_share_button_${reel.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Share,
                                contentDescription = tr("Share", "शेयर", lang),
                                tint = Color.White,
                                modifier = Modifier.size(19.dp)
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                text = tr("Share", "शेयर", lang),
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        TextButton(
                            onClick = { viewModel.toggleSavePost(reel.id) },
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("reel_save_button_${reel.id}")
                        ) {
                            Icon(
                                imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                contentDescription = tr("Save", "सहेजें", lang),
                                tint = if (isSaved) Color(0xFF60A5FA) else Color.White,
                                modifier = Modifier.size(19.dp)
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                text = if (isSaved) tr("Saved", "सहेजा", lang) else tr("Save", "सहेजें", lang),
                                color = if (isSaved) Color(0xFF60A5FA) else Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }
        }

        // Top Floating Header Controls (Always Visible Above VerticalPager)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(horizontal = 12.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.55f),
                shape = RoundedCornerShape(22.dp)
            ) {
                Text(
                    text = "❤️ दिल सुनो • ${tr("Reels", "रील्स", lang)}",
                    color = Color.White,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = CrimsonPrimary,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .clickable { onOpenCreateReel() }
                        .testTag("reels_create_camera_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.CameraAlt, null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(tr("Create", "बनाएं", lang), color = Color.White, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                }

                Surface(
                    color = if (activeLiveCount > 0) Color.Red else Color.Black.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .clickable {
                            if (activeLiveCount > 0) showLiveRoomsSheet = true else showGoLiveDialog = true
                        }
                        .testTag("go_live_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.RadioButtonChecked, null, tint = Color.White, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = if (activeLiveCount > 0) "LIVE ($activeLiveCount)" else tr("Live", "लाइव", lang),
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                IconButton(
                    onClick = { showVnStudio = true },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.55f))
                        .testTag("reels_open_vn_studio_button")
                ) {
                    Icon(Icons.Filled.MovieCreation, contentDescription = "VN Studio", tint = Color.White, modifier = Modifier.size(18.dp))
                }

                IconButton(
                    onClick = { isMuted = !isMuted },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.55f))
                        .testTag("reels_mute_toggle_button")
                ) {
                    Icon(
                        if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Mute Toggle",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }

    // Comments Sheet for Reels
    commentTargetReel?.let { post ->
        val comments by viewModel.observeCommentsForPost(post.id).collectAsStateWithLifecycle(emptyList())
        var commentText by remember { mutableStateOf("") }
        ModalBottomSheet(onDismissRequest = { commentTargetReel = null }) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(tr("Reel Comments (AI-Moderated)", "रील टिप्पणियाँ", lang), style = MaterialTheme.typography.titleLarge)
                comments.forEach { c ->
                    val cname = SecurityUtils.resolveDisplayName(profilesByUid[c.authorUid]?.fullName, c.authorName)
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(cname, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                            Text(c.text, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = commentText,
                        onValueChange = { commentText = it },
                        label = { Text(tr("Add a comment...", "टिप्पणी लिखें...", lang)) },
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            val txt = commentText
                            runWithGuidelinesGate {
                                commentText = ""
                                viewModel.addComment(post, txt)
                            }
                        },
                        enabled = !isScanningAi
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send Comment")
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // Active Live Streams Sheet
    if (showLiveRoomsSheet) {
        ModalBottomSheet(onDismissRequest = { showLiveRoomsSheet = false }) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(tr("Live Broadcasts", "लाइव प्रसारण", lang), style = MaterialTheme.typography.titleLarge)
                    Button(
                        onClick = {
                            showLiveRoomsSheet = false
                            showGoLiveDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Text(tr("Start Live", "लाइव शुरू करें", lang))
                    }
                }
                liveStreams.filter { it.status == "live" }.forEach { stream ->
                    val hostName = SecurityUtils.resolveDisplayName(profilesByUid[stream.hostUid]?.fullName, stream.hostName)
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("🔴 $hostName", fontWeight = FontWeight.Bold)
                                Text(stream.title, style = MaterialTheme.typography.bodyMedium)
                            }
                            Button(onClick = {
                                showLiveRoomsSheet = false
                                activeLiveRoom = stream
                            }) {
                                Text(tr("Join", "जुड़ें", lang))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showGoLiveDialog) {
        var title by remember { mutableStateOf("") }
        var city by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showGoLiveDialog = false },
            title = { Text(tr("Go Live • लाइव प्रसारण शुरू करें", "लाइव प्रसारण शुरू करें", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(tr("Broadcast title is scanned by Gemini AI before starting.", "प्रसारण शुरू होने से पहले Gemini AI द्वारा जाँच की जाती है।", lang), style = MaterialTheme.typography.labelSmall)
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text(tr("Live News / Event Title *", "लाइव समाचार / कार्यक्रम शीर्षक *", lang)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = city,
                        onValueChange = { city = it },
                        label = { Text(tr("City / Location", "शहर / स्थान", lang)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.startLiveStream(title, city) { streamId ->
                            showGoLiveDialog = false
                            activeLiveRoom = LiveStreamItem(
                                id = streamId,
                                hostUid = viewModel.currentUserId,
                                hostName = viewModel.resolveDisplayName("Broadcaster"),
                                title = title,
                                city = city,
                                status = "live"
                            )
                        }
                    },
                    enabled = !isScanningAi
                ) {
                    Text(if (isScanningAi) "AI Scanning..." else tr("Start Live", "लाइव शुरू करें", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showGoLiveDialog = false }) { Text(tr("Cancel", "रद्द", lang)) }
            }
        )
    }

    activeLiveRoom?.let { stream ->
        val liveComments by viewModel.observeLiveComments(stream.id).collectAsStateWithLifecycle(emptyList())
        var liveCommentText by remember { mutableStateOf("") }
        val hostDisplayName = SecurityUtils.resolveDisplayName(
            profilesByUid[stream.hostUid]?.fullName,
            stream.hostName
        )
        AlertDialog(
            onDismissRequest = { activeLiveRoom = null },
            title = { Text("🔴 LIVE: ${stream.title}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("$hostDisplayName • ${stream.city ?: "India"}", fontWeight = FontWeight.SemiBold)
                    Box(
                        modifier = Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(14.dp)).background(RoyalNavy),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.LiveTv, null, tint = Color.White, modifier = Modifier.size(40.dp))
                            Text("Live Broadcast Active", color = Color.White)
                        }
                    }
                    liveComments.takeLast(5).forEach { c ->
                        val commenterName = SecurityUtils.resolveDisplayName(
                            profilesByUid[c.authorUid]?.fullName,
                            c.authorName
                        )
                        Text("$commenterName: ${c.text}", style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = liveCommentText,
                            onValueChange = { liveCommentText = it },
                            label = { Text(tr("Live comment...", "लाइव कमेंट...", lang)) },
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            val txt = liveCommentText
                            liveCommentText = ""
                            viewModel.sendLiveComment(stream.id, txt)
                        }) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send live comment")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (stream.hostUid == viewModel.currentUserId) {
                            OutlinedButton(onClick = {
                                viewModel.endLiveStream(stream.id)
                                activeLiveRoom = null
                            }) {
                                Text(tr("End Broadcast", "प्रसारण समाप्त करें", lang))
                            }
                        } else {
                            TextButton(onClick = {
                                viewModel.submitReport("live", stream.id, stream.hostUid, "violation", "Live stream violation")
                                activeLiveRoom = null
                            }) {
                                Text(tr("Report Live", "रिपोर्ट करें", lang))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { activeLiveRoom = null }) { Text(tr("Leave", "बाहर आएं", lang)) }
            }
        )
    }

    if (showVnStudio) {
        VnVideoEditorStudioDialog(
            initialMediaUri = null,
            lang = lang,
            availableMusicTracks = availableMusicTracks,
            onDismiss = { showVnStudio = false },
            onApplyEdit = { res ->
                showVnStudio = false
                pendingStudioPublish = res
            }
        )
    }

    pendingStudioPublish?.let { res ->
        var reelTitle by remember { mutableStateOf("") }
        var reelCaption by remember { mutableStateOf("") }
        var reelCity by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pendingStudioPublish = null },
            title = { Text(tr("Publish VN Edited Reel", "एडिट किया गया रील प्रकाशित करें", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Studio Edit: ${res.editorSummary}", style = MaterialTheme.typography.labelSmall)
                    OutlinedTextField(value = reelTitle, onValueChange = { reelTitle = it }, label = { Text(tr("Reel Title", "शीर्षक", lang)) })
                    OutlinedTextField(value = reelCaption, onValueChange = { reelCaption = it }, label = { Text(tr("Caption *", "कैप्शन *", lang)) }, minLines = 2)
                    OutlinedTextField(value = reelCity, onValueChange = { reelCity = it }, label = { Text(tr("City", "शहर", lang)) })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.createPost(
                            postType = "reel",
                            title = reelTitle,
                            caption = reelCaption.ifBlank { res.editorSummary },
                            city = reelCity,
                            mediaUri = res.primaryMediaUri,
                            musicTrack = res.selectedMusicTrackTitle,
                            editorSummary = res.editorSummary,
                            extraLayerScanText = res.extraLayerScanText,
                            extraMediaUris = listOfNotNull(res.pipMediaUri)
                        ) {
                            pendingStudioPublish = null
                        }
                    },
                    enabled = !isScanningAi
                ) {
                    Text(if (isScanningAi) "AI Scanning..." else tr("Scan & Publish Reel", "रील प्रकाशित करें", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingStudioPublish = null }) { Text(tr("Cancel", "रद्द", lang)) }
            }
        )
    }

    activeHashtagFeed?.let { hashtag ->
        HashtagFeedDialog(
            hashtag = hashtag,
            allPosts = pagerReels.map { it.post },
            lang = lang,
            onOpenReel = { activeHashtagFeed = null },
            onDismiss = { activeHashtagFeed = null }
        )
    }

    editingCaptionReel?.let { target ->
        EditPostCaptionDialog(
            initialCaption = target.caption,
            lang = lang,
            isScanning = isScanningAi,
            onSave = { updated ->
                viewModel.editPostCaption(target, updated) {
                    editingCaptionReel = null
                }
            },
            onDismiss = { editingCaptionReel = null }
        )
    }

    reportTargetReel?.let { reel ->
        val reelAuthorName = SecurityUtils.resolveDisplayName(
            profilesByUid[reel.authorUid]?.fullName,
            reel.authorName
        )
        ReportContentReasonDialog(
            lang = lang,
            onSelectReason = { reasonKey, details ->
                val combinedReason = if (details.isNotBlank()) "$reasonKey — $details" else reasonKey
                viewModel.submitReport(
                    targetType = "reel",
                    targetId = reel.id,
                    targetAuthorUid = reel.authorUid,
                    reportType = reasonKey,
                    reason = combinedReason,
                    targetAuthorName = reelAuthorName,
                    targetMediaUri = reel.mediaUri,
                    targetCaption = reel.title?.takeIf { it.isNotBlank() }?.let { "$it — ${reel.caption}" } ?: reel.caption
                )
                reportTargetReel = null
            },
            onDismiss = { reportTargetReel = null }
        )
    }

    if (pendingGuidelinesAction != null) {
        CommunityGuidelines18PlusDialog(
            lang = lang,
            onAccept = {
                viewModel.acceptCommunityGuidelines18Plus()
                val action = pendingGuidelinesAction
                pendingGuidelinesAction = null
                action?.invoke()
            },
            onDismiss = { pendingGuidelinesAction = null }
        )
    }
}

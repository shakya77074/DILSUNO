package com.dilsuno.app.ui.components

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.DilSePolicyText
import com.dilsuno.app.core.MediaUploadValidator
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.AppConfig
import com.dilsuno.app.data.model.ModerationReport
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.RoyalNavy
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.VelvetIndigo
import com.dilsuno.app.viewmodel.MainAppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Prominent Permission Disclosure shown BEFORE any native Android runtime permission prompt
 * for Microphone, Camera, or Media access (Google Play Developer Program Policy compliant).
 */
@Composable
fun ProminentPermissionDisclosureDialog(
    lang: AppLang,
    onContinue: () -> Unit,
    onNotNow: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onNotNow,
        icon = {
            Icon(
                Icons.Filled.PrivacyTip,
                contentDescription = "Permission Disclosure",
                tint = CrimsonPrimary
            )
        },
        title = {
            Text(
                text = tr(
                    "Permission Disclosure • अनुमति जानकारी",
                    "अनुमति जानकारी • Permission Disclosure",
                    lang
                ),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = DilSePolicyText.PROMINENT_PERMISSION_DISCLOSURE_EN,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.testTag("permission_disclosure_copy_en")
                )
                if (lang == AppLang.HI) {
                    Text(
                        text = DilSePolicyText.PROMINENT_PERMISSION_DISCLOSURE_HI,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onContinue,
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary, contentColor = Color.White),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("permission_disclosure_continue")
            ) {
                Text("Continue", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onNotNow,
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("permission_disclosure_not_now")
            ) {
                Text("Not Now")
            }
        }
    )
}

/**
 * Non-intrusive Google Play Health & Suicide Prevention disclaimer paired with
 * a permanent 1-tap "Emergency Help: Call Tele-MANAS (14416)" ACTION_DIAL button.
 * Displayed on BOTH Home Feed and Calling screens.
 */
@Composable
fun HealthDisclaimerAndHelplineCard(
    lang: AppLang,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("health_disclaimer_helpline_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Filled.HealthAndSafety,
                    contentDescription = "Peer Support Disclaimer",
                    tint = VelvetIndigo,
                    modifier = Modifier.size(20.dp)
                )
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = DilSePolicyText.HEALTH_DISCLAIMER_EN,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.testTag("health_disclaimer_text")
                    )
                    if (lang == AppLang.HI) {
                        Text(
                            text = DilSePolicyText.HEALTH_DISCLAIMER_HI,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Button(
                onClick = {
                    val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                        data = Uri.parse("tel:${DilSePolicyText.TELE_MANAS_DIAL_NUMBER}")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    runCatching { context.startActivity(dialIntent) }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = CrimsonPrimary,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("tele_manas_one_tap_call_button")
            ) {
                Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = DilSePolicyText.TELE_MANAS_BUTTON_LABEL_EN,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Explicit Recording Consent notice shown on the Call Waiting / Connecting screen.
 */
@Composable
fun ExplicitEmergencyRecordingNoticeBanner(
    lang: AppLang,
    modifier: Modifier = Modifier
) {
    Surface(
        color = RoyalNavy.copy(alpha = 0.08f),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("explicit_emergency_recording_notice")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                Icons.Filled.Shield,
                contentDescription = "Call Privacy Notice",
                tint = SafeEmerald,
                modifier = Modifier.size(20.dp)
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = DilSePolicyText.EXPLICIT_EMERGENCY_RECORDING_NOTICE_EN,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (lang == AppLang.HI) {
                    Text(
                        text = DilSePolicyText.EXPLICIT_EMERGENCY_RECORDING_NOTICE_HI,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

/**
 * Mandatory Community Guidelines & 18+ Policy gate before uploading any video, post, reel, story, or comment.
 */
@Composable
fun CommunityGuidelines18PlusDialog(
    lang: AppLang,
    onAccept: () -> Unit,
    onDismiss: () -> Unit
) {
    var acceptedChecked by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                Icons.Filled.Policy,
                contentDescription = "Community Guidelines & 18+ Policy",
                tint = CrimsonPrimary
            )
        },
        title = {
            Text(
                text = tr(
                    "Community Guidelines & 18+ Policy",
                    "कम्युनिटी गाइडलाइन्स और 18+ नीति",
                    lang
                ),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = if (lang == AppLang.HI) {
                        DilSePolicyText.COMMUNITY_GUIDELINES_18_PLUS_HI.trim()
                    } else {
                        DilSePolicyText.COMMUNITY_GUIDELINES_18_PLUS_EN.trim()
                    },
                    style = MaterialTheme.typography.bodySmall
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .clickable { acceptedChecked = !acceptedChecked }
                        .testTag("community_guidelines_18plus_checkbox_row")
                ) {
                    Checkbox(
                        checked = acceptedChecked,
                        onCheckedChange = { acceptedChecked = it },
                        modifier = Modifier.testTag("community_guidelines_18plus_checkbox")
                    )
                    Text(
                        text = tr(
                            "I confirm I am 18+ and agree to obey Dil Suno's Community Guidelines & Child Safety Policy.",
                            "मैं पुष्टि करता/करती हूँ कि मैं 18+ हूँ और दिल सुनो के कम्युनिटी गाइडलाइन्स व बाल सुरक्षा नीति का पालन करूंगा/करूंगी।",
                            lang
                        ),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onAccept,
                enabled = acceptedChecked,
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary, contentColor = Color.White),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("accept_community_guidelines_18plus_button")
            ) {
                Text(tr("I Accept (18+)", "मैं सहमत हूँ (18+)", lang), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Text(tr("Cancel", "रद्द करें", lang))
            }
        }
    )
}

/**
 * Visible 3-Dot Action Menu on every public video, post, and reel with "Report Content" and "Block User".
 */
@Composable
fun PostThreeDotActionMenu(
    lang: AppLang,
    testTagPrefix: String,
    iconTint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    onEditCaption: (() -> Unit)? = null,
    onReportContent: () -> Unit,
    onBlockUser: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        IconButton(
            onClick = { expanded = true },
            modifier = Modifier
                .size(48.dp)
                .testTag("${testTagPrefix}_three_dot_menu")
        ) {
            Icon(
                imageVector = Icons.Filled.MoreVert,
                contentDescription = tr("More options: Report or Block", "अधिक विकल्प: रिपोर्ट या ब्लॉक", lang),
                tint = iconTint
            )
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            if (onEditCaption != null) {
                DropdownMenuItem(
                    text = {
                        Text(
                            tr("Edit Caption", "कैप्शन बदलें (Edit Caption)", lang),
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    leadingIcon = {
                        Icon(Icons.Filled.Edit, contentDescription = null, tint = VelvetIndigo)
                    },
                    onClick = {
                        expanded = false
                        onEditCaption()
                    },
                    modifier = Modifier.testTag("${testTagPrefix}_edit_caption")
                )
            }
            DropdownMenuItem(
                text = {
                    Text(
                        tr("Report Content", "सामग्री रिपोर्ट करें (Report Content)", lang),
                        fontWeight = FontWeight.SemiBold
                    )
                },
                leadingIcon = {
                    Icon(Icons.Filled.Flag, contentDescription = null, tint = CrimsonPrimary)
                },
                onClick = {
                    expanded = false
                    onReportContent()
                },
                modifier = Modifier.testTag("${testTagPrefix}_report_content")
            )
            DropdownMenuItem(
                text = {
                    Text(
                        tr("Block User", "यूज़र को ब्लॉक करें (Block User)", lang),
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.error
                    )
                },
                leadingIcon = {
                    Icon(Icons.Filled.Block, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                },
                onClick = {
                    expanded = false
                    onBlockUser()
                },
                modifier = Modifier.testTag("${testTagPrefix}_block_user")
            )
        }
    }
}

/**
 * Standard Google Play UGC Report dialog with 4 exact categories:
 * Nudity, Harassment, Spam, Child Safety.
 */
@Composable
fun ReportContentReasonDialog(
    lang: AppLang,
    onSelectReason: (reasonKey: String, details: String) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedReason by remember { mutableStateOf(DilSePolicyText.REPORT_CONTENT_REASONS.first().first) }
    var extraNotes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Flag, contentDescription = "Report Content", tint = CrimsonPrimary) },
        title = {
            Text(
                tr("Report Content • सामग्री रिपोर्ट करें", "सामग्री रिपोर्ट करें • Report Content", lang),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    tr(
                        "Select why this content violates Dil Suno's Community Guidelines. Reports are sent directly to our Moderation Queue.",
                        "कारण चुनें। आपकी रिपोर्ट तुरंत हमारी मॉडरेशन टीम को भेजी जाती है।",
                        lang
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                DilSePolicyText.REPORT_CONTENT_REASONS.forEach { (key, bilingualLabel) ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .clickable { selectedReason = key }
                            .testTag("report_reason_${key.lowercase().replace(" ", "_")}")
                    ) {
                        RadioButton(
                            selected = selectedReason == key,
                            onClick = { selectedReason = key }
                        )
                        Text(
                            text = if (lang == AppLang.HI) bilingualLabel else key,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (selectedReason == key) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
                OutlinedTextField(
                    value = extraNotes,
                    onValueChange = { extraNotes = it },
                    label = { Text(tr("Additional details (optional)", "अतिरिक्त विवरण (वैकल्पिक)", lang)) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSelectReason(selectedReason, extraNotes.ifBlank { selectedReason }) },
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary, contentColor = Color.White),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("submit_report_content_button")
            ) {
                Text(tr("Submit Report", "रिपोर्ट भेजें", lang), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Text(tr("Cancel", "रद्द करें", lang))
            }
        }
    )
}

/**
 * Comprehensive 6-tab bilingual (Hindi + English) Legal & Compliance Policy Viewer
 * for Dil Suno (operated by SHAKYA, support: supportdilsuno@gmail.com):
 * 0 = Privacy Policy, 1 = Terms & All Policies (with Top Prominent Zero-Liability Clause),
 * 2 = Child Safety Standards, 3 = Medical Disclaimer, 4 = Account & Data Deletion,
 * 5 = Community Guidelines & Google Play Billing.
 */
@Composable
fun LegalPoliciesViewerDialog(
    initialTab: Int = 1,
    lang: AppLang,
    onDismiss: () -> Unit
) {
    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, 5)) }
    val tabs = listOf(
        tr("Privacy", "गोपनीयता", lang),
        tr("Terms & All", "नियम व सभी नीतियाँ", lang),
        tr("Child Safety", "बाल सुरक्षा", lang),
        tr("Medical", "मेडिकल", lang),
        tr("Deletion", "डिलीशन", lang),
        tr("Guidelines & Billing", "गाइडलाइंस व बिलिंग", lang)
    )

    val allPoliciesCombinedBilingual = remember {
        listOf(
            "${DilSePolicyText.TERMS_FULL_HI.trim()}\n\n${DilSePolicyText.TERMS_FULL_EN.trim()}",
            "${DilSePolicyText.PRIVACY_POLICY_HI.trim()}\n\n${DilSePolicyText.PRIVACY_POLICY_EN.trim()}",
            "${DilSePolicyText.CHILD_SAFETY_POLICY_HI.trim()}\n\n${DilSePolicyText.CHILD_SAFETY_POLICY_EN.trim()}",
            "${DilSePolicyText.ACCOUNT_DELETION_POLICY_HI.trim()}\n\n${DilSePolicyText.ACCOUNT_DELETION_POLICY_EN.trim()}",
            "${DilSePolicyText.MEDICAL_DISCLAIMER_HI.trim()}\n\n${DilSePolicyText.MEDICAL_DISCLAIMER_EN.trim()}",
            "${DilSePolicyText.COMMUNITY_GUIDELINES_18_PLUS_HI.trim()}\n\n${DilSePolicyText.COMMUNITY_GUIDELINES_18_PLUS_EN.trim()}"
        ).joinToString("\n\n━━━━━━━━━━━━━━━━━━━━\n\n")
    }

    val content = when (selectedTab) {
        0 -> "${DilSePolicyText.PRIVACY_POLICY_HI.trim()}\n\n${DilSePolicyText.PRIVACY_POLICY_EN.trim()}"
        1 -> allPoliciesCombinedBilingual
        2 -> "${DilSePolicyText.CHILD_SAFETY_POLICY_HI.trim()}\n\n${DilSePolicyText.CHILD_SAFETY_POLICY_EN.trim()}"
        3 -> "${DilSePolicyText.MEDICAL_DISCLAIMER_HI.trim()}\n\n${DilSePolicyText.MEDICAL_DISCLAIMER_EN.trim()}"
        4 -> "${DilSePolicyText.ACCOUNT_DELETION_POLICY_HI.trim()}\n\n${DilSePolicyText.ACCOUNT_DELETION_POLICY_EN.trim()}"
        else -> "${DilSePolicyText.COMMUNITY_GUIDELINES_18_PLUS_HI.trim()}\n\n${DilSePolicyText.COMMUNITY_GUIDELINES_18_PLUS_EN.trim()}"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.Policy, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(
                        text = tr("Dil Suno Legal & Policies", "दिल सुनो नियम और नीतियाँ", lang),
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "Operated by SHAKYA • ${DilSePolicyText.OFFICIAL_SUPPORT_EMAIL}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 0.dp
                ) {
                    tabs.forEachIndexed { idx, label ->
                        Tab(
                            selected = selectedTab == idx,
                            onClick = { selectedTab = idx },
                            text = { Text(label, style = MaterialTheme.typography.labelMedium) },
                            modifier = Modifier.testTag("legal_tab_$idx")
                        )
                    }
                }
                Column(
                    modifier = Modifier
                        .heightIn(max = 390.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Top Prominent Clause: Absolute User Responsibility & Zero Company Liability (HI + EN)
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("legal_prominent_liability_card")
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Gavel,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "100% User Responsibility & Zero Company Liability",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text(
                                text = DilSePolicyText.ABSOLUTE_USER_RESPONSIBILITY_HI,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = DilSePolicyText.ABSOLUTE_USER_RESPONSIBILITY_EN,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            HorizontalDivider()
                            Text(
                                text = DilSePolicyText.COPYRIGHT_IT_ACT_79_EN,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = DilSePolicyText.COPYRIGHT_IT_ACT_79_HI,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Text(
                        text = content.trim(),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.testTag("legal_policy_body_text")
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("legal_policy_close_button")
            ) {
                Text(tr("Close", "बंद करें", lang))
            }
        }
    )
}

/**
 * Live Employee & Super Admin Moderation Queue Panel.
 * Displays reported videos/posts with inline media preview and 3 1-tap actions:
 * 1. "Approve / Ignore Report"
 * 2. "Delete Video & Warn User"
 * 3. "Delete Video & Permanent Ban"
 */
@Composable
fun ModerationQueuePanel(
    reports: List<ModerationReport>,
    lang: AppLang,
    onApproveIgnore: (ModerationReport) -> Unit,
    onDeleteAndWarn: (ModerationReport) -> Unit,
    onDeleteAndPermanentBan: (ModerationReport) -> Unit
) {
    val context = LocalContext.current
    val dateFmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    val openReports = remember(reports) { reports.filter { it.status == "open" } }
    val resolvedReports = remember(reports) { reports.filter { it.status != "open" }.take(20) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            color = if (openReports.isNotEmpty()) CrimsonPrimary.copy(alpha = 0.14f) else SafeEmerald.copy(alpha = 0.14f),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().testTag("moderation_queue_summary_banner")
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = if (openReports.isNotEmpty()) Icons.Filled.Warning else Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = if (openReports.isNotEmpty()) CrimsonPrimary else SafeEmerald
                )
                Column {
                    Text(
                        text = tr(
                            "Live Moderation Queue (${openReports.size} Open Reports)",
                            "लाइव मॉडरेशन कतार (${openReports.size} लंबित रिपोर्ट)",
                            lang
                        ),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = tr(
                            "Every moderation decision is permanently logged to Staff Audit Logs with Employee ID & Timestamp.",
                            "हर मॉडरेशन कार्रवाई कर्मचारी आईडी और समय के साथ ऑडिट लॉग में दर्ज होती है।",
                            lang
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (openReports.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
            ) {
                Text(
                    text = tr(
                        "All caught up! No pending user reports in the Moderation Queue.",
                        "सब सुरक्षित है! मॉडरेशन कतार में कोई लंबित रिपोर्ट नहीं है।",
                        lang
                    ),
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        openReports.forEach { report ->
            val mediaUri = report.targetMediaUri
            val isVideo = remember(mediaUri) {
                val u = mediaUri.orEmpty()
                if (u.isBlank()) false
                else {
                    val mime = runCatching { context.contentResolver.getType(Uri.parse(u)) }.getOrNull().orEmpty()
                    mime.startsWith("video") || u.endsWith(".mp4", true) || u.endsWith(".mov", true)
                }
            }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("moderation_report_card_${report.id}"),
                shape = RoundedCornerShape(18.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = if (report.reason.equals("Child Safety", true)) Color(0xFFB91C1C) else CrimsonPrimary,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "🚩 ${report.reason.uppercase()} • ${report.targetType.uppercase()}",
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Text(
                            text = report.createdAt?.toDate()?.let { dateFmt.format(it) } ?: "Just now",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(
                        text = "Uploader: ${report.targetAuthorName ?: report.targetAuthorUid ?: "Unknown"}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    if (!report.targetCaption.isNullOrBlank()) {
                        Text(
                            text = "\"${report.targetCaption}\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    if (report.reason.isNotBlank()) {
                        Text(
                            text = "Report details: ${report.reason}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Media Preview inside Moderation Queue
                    if (!mediaUri.isNullOrBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(RoyalNavy)
                        ) {
                            if (isVideo) {
                                TextureVideoPlayer(
                                    videoUri = mediaUri,
                                    volume = 0f,
                                    isPlaying = true,
                                    isLooping = true,
                                    modifier = Modifier.fillMaxWidth().height(180.dp)
                                )
                            } else {
                                AsyncImage(
                                    model = mediaUri,
                                    contentDescription = "Reported Media Preview",
                                    modifier = Modifier.fillMaxWidth().height(180.dp),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }

                    HorizontalDivider()

                    // 3 One-Tap Moderation Actions
                    OutlinedButton(
                        onClick = { onApproveIgnore(report) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("mod_approve_${report.id}")
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = SafeEmerald)
                        Spacer(Modifier.width(8.dp))
                        Text("Approve / Ignore Report", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onDeleteAndWarn(report) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VelvetIndigo,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("mod_delete_warn_${report.id}")
                    ) {
                        Icon(Icons.Filled.DeleteForever, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Delete Video & Warn User", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onDeleteAndPermanentBan(report) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFB91C1C),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("mod_delete_ban_${report.id}")
                    ) {
                        Icon(Icons.Filled.Gavel, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Delete Video & Permanent Ban", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (resolvedReports.isNotEmpty()) {
            Text(
                text = tr("Recent Resolved Moderation Actions", "हाल की हल की गई रिपोर्ट", lang),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 6.dp)
            )
            resolvedReports.forEach { r ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "${r.reason} • ${r.resolutionAction ?: r.status}",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Handled by ${r.resolvedByName ?: r.resolvedByStaffId ?: "Moderator"} • ${r.createdAt?.toDate()?.let { dateFmt.format(it) } ?: "Just now"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LegalPolicyDialog(
    isPrivacyPolicy: Boolean,
    lang: AppLang,
    onDismiss: () -> Unit
) {
    val title = if (isPrivacyPolicy) {
        tr("Privacy Policy & Legal Terms", "गोपनीयता नीति व कानूनी शर्तें", lang)
    } else {
        tr("Terms, Liability & Legal Policies", "नियम, शर्तें व कानूनी नीतियाँ", lang)
    }
    val body = if (isPrivacyPolicy) {
        "${DilSePolicyText.PRIVACY_POLICY_HI.trim()}\n\n${DilSePolicyText.PRIVACY_POLICY_EN.trim()}"
    } else {
        listOf(
            "${DilSePolicyText.TERMS_FULL_HI.trim()}\n\n${DilSePolicyText.TERMS_FULL_EN.trim()}",
            "${DilSePolicyText.PRIVACY_POLICY_HI.trim()}\n\n${DilSePolicyText.PRIVACY_POLICY_EN.trim()}",
            "${DilSePolicyText.CHILD_SAFETY_POLICY_HI.trim()}\n\n${DilSePolicyText.CHILD_SAFETY_POLICY_EN.trim()}",
            "${DilSePolicyText.ACCOUNT_DELETION_POLICY_HI.trim()}\n\n${DilSePolicyText.ACCOUNT_DELETION_POLICY_EN.trim()}",
            "${DilSePolicyText.MEDICAL_DISCLAIMER_HI.trim()}\n\n${DilSePolicyText.MEDICAL_DISCLAIMER_EN.trim()}",
            "${DilSePolicyText.COMMUNITY_GUIDELINES_18_PLUS_HI.trim()}\n\n${DilSePolicyText.COMMUNITY_GUIDELINES_18_PLUS_EN.trim()}"
        ).joinToString("\n\n━━━━━━━━━━━━━━━━━━━━\n\n")
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                if (isPrivacyPolicy) Icons.Filled.PrivacyTip else Icons.Filled.Gavel,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = DilSePolicyText.ABSOLUTE_USER_RESPONSIBILITY_HI,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = DilSePolicyText.ABSOLUTE_USER_RESPONSIBILITY_EN,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                Text(body.trim(), style = MaterialTheme.typography.bodyMedium)
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("close_legal_dialog_button")
            ) {
                Text(tr("I Understand / Close", "मैं समझ गया / बंद करें", lang))
            }
        }
    )
}

@Composable
fun CustomerSupportModal(
    viewModel: MainAppViewModel,
    appConfig: AppConfig,
    lang: AppLang,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val tickets by viewModel.mySupportTickets.collectAsStateWithLifecycle()
    val officialEmail = appConfig.supportEmail?.ifBlank { null } ?: DilSePolicyText.OFFICIAL_SUPPORT_EMAIL

    var selectedCategory by remember { mutableStateOf(DilSePolicyText.supportCategories.first().first) }
    var message by remember { mutableStateOf("") }
    var screenshotUri by remember { mutableStateOf<String?>(null) }
    var screenshotError by remember { mutableStateOf<String?>(null) }

    val screenshotPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { picked ->
            MediaUploadValidator.validatePickedMedia(
                context = context,
                uri = picked,
                allowVideo = false,
                lang = lang
            ).onSuccess { validated ->
                screenshotError = null
                screenshotUri = validated.uriString
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Blocked unsafe screenshot file."
                screenshotError = msg
                viewModel.reportSecurityError(msg)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.SupportAgent, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        title = { Text(tr("Customer Support (Text & Email Only)", "ग्राहक सहायता (केवल टेक्स्ट व ईमेल)", lang)) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = tr(
                        "Support is handled via written in-app tickets and official email ($officialEmail). No phone support line is used.",
                        "सहायता केवल इन-ऐप टेक्स्ट टिकट और आधिकारिक ईमेल ($officialEmail) द्वारा दी जाती है (कोई फ़ोन नंबर नहीं)।",
                        lang
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedButton(
                    onClick = {
                        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("mailto:$officialEmail")
                            putExtra(Intent.EXTRA_SUBJECT, "Dil Suno Support - $selectedCategory")
                            putExtra(Intent.EXTRA_TEXT, message)
                        }
                        try {
                            context.startActivity(Intent.createChooser(emailIntent, "Email Support"))
                        } catch (_: ActivityNotFoundException) {
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("email_support_button")
                ) {
                    Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(tr("Email Support ($officialEmail)", "ईमेल भेजें ($officialEmail)", lang), maxLines = 1)
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                }

                HorizontalDivider()

                Text(tr("Issue Category", "समस्या की श्रेणी", lang), fontWeight = FontWeight.SemiBold)
                DilSePolicyText.supportCategories.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        pair.forEach { (key, hiLabel) ->
                            FilterChip(
                                selected = selectedCategory == key,
                                onClick = { selectedCategory = key },
                                label = { Text(if (lang == AppLang.HI) hiLabel else key, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text(tr("Describe your issue in detail *", "अपनी समस्या विस्तार से लिखें *", lang)) },
                    modifier = Modifier.fillMaxWidth().testTag("support_message_input"),
                    minLines = 3
                )

                OutlinedButton(
                    onClick = {
                        screenshotPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Filled.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (screenshotUri == null) tr("Attach Screenshot (optional)", "स्क्रीनशॉट जोड़ें (वैकल्पिक)", lang)
                        else tr("Screenshot Attached ✓", "स्क्रीनशॉट जोड़ा गया ✓", lang)
                    )
                }
                if (!screenshotError.isNullOrBlank()) {
                    Text(
                        text = screenshotError!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Button(
                    onClick = {
                        viewModel.submitSupportTicket(selectedCategory, message, screenshotUri) {
                            message = ""
                            screenshotUri = null
                        }
                    },
                    enabled = message.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("submit_support_ticket_button")
                ) {
                    Text(tr("Submit Support Ticket", "सहायता टिकट भेजें", lang))
                }

                if (tickets.isNotEmpty()) {
                    HorizontalDivider()
                    Text(tr("My Support Tickets (${tickets.size})", "मेरे टिकट (${tickets.size})", lang), fontWeight = FontWeight.Bold)
                    tickets.forEach { t ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(t.category, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                                    Text(
                                        text = t.status.uppercase(),
                                        color = if (t.status == "resolved") SafeEmerald else MaterialTheme.colorScheme.primary,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(t.message, style = MaterialTheme.typography.bodySmall)
                                if (!t.adminReply.isNullOrBlank()) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "Admin: ${t.adminReply}",
                                            modifier = Modifier.padding(8.dp),
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss, modifier = Modifier.heightIn(min = 48.dp)) {
                Text(tr("Close", "बंद करें", lang))
            }
        }
    )
}

@Composable
fun AccountDeletionDialog(
    viewModel: MainAppViewModel,
    hasPassword: Boolean,
    lang: AppLang,
    onDismiss: () -> Unit,
    onDeleted: () -> Unit
) {
    val deleteOtp by viewModel.deleteOtp.collectAsStateWithLifecycle()
    var useOtp by remember { mutableStateOf(false) }
    var credentialInput by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
        title = {
            Text(
                tr("Delete My Account Permanently", "मेरा अकाउंट हमेशा के लिए डिलीट करें", lang),
                color = MaterialTheme.colorScheme.error
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.errorContainer, RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Text(
                        text = if (hasPassword) {
                            tr(
                                "This permanently removes your Dil Suno account, private credentials, and public profile. Verify your password or OTP to proceed.",
                                "यह आपका दिल सुनो अकाउंट और प्रोफ़ाइल हमेशा के लिए हटा देगा। पुष्टि के लिए पासवर्ड या OTP दर्ज करें।",
                                lang
                            )
                        } else {
                            tr(
                                "This permanently removes your Dil Suno account, posts, chats, and wallet history. Type DELETE or verify via OTP to proceed.",
                                "यह आपका दिल सुनो अकाउंट, पोस्ट और डेटा हमेशा के लिए हटा देगा। आगे बढ़ने के लिए DELETE लिखें या OTP से पुष्टि करें।",
                                lang
                            )
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !useOtp,
                        onClick = { useOtp = false; credentialInput = "" },
                        label = {
                            Text(
                                if (hasPassword) tr("Use Password", "पासवर्ड से", lang)
                                else tr("Type DELETE", "DELETE लिखें", lang)
                            )
                        }
                    )
                    FilterChip(
                        selected = useOtp,
                        onClick = { useOtp = true; credentialInput = "" },
                        label = { Text(tr("Use OTP", "OTP से", lang)) }
                    )
                }

                if (useOtp) {
                    OutlinedButton(
                        onClick = { viewModel.requestAccountDeleteOtp() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("send_delete_otp_button")
                    ) {
                        Text(tr("Generate Deletion OTP", "डिलीशन OTP प्राप्त करें", lang))
                    }
                    if (!deleteOtp.isNullOrBlank()) {
                        Text(
                            text = "Verification OTP: $deleteOtp",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    OutlinedTextField(
                        value = credentialInput,
                        onValueChange = { credentialInput = it },
                        label = { Text(tr("Enter 6-Digit OTP", "6-अंकों का OTP दर्ज करें", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("delete_otp_input"),
                        singleLine = true
                    )
                } else if (hasPassword) {
                    var showDeletePassword by remember { mutableStateOf(false) }
                    OutlinedTextField(
                        value = credentialInput,
                        onValueChange = { credentialInput = it },
                        label = { Text(tr("Enter Account Password", "अकाउंट पासवर्ड दर्ज करें", lang)) },
                        trailingIcon = {
                            IconButton(
                                onClick = { showDeletePassword = !showDeletePassword },
                                modifier = Modifier.testTag("toggle_delete_password_visibility")
                            ) {
                                Icon(
                                    if (showDeletePassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = if (showDeletePassword) tr("Hide password", "पासवर्ड छिपाएं", lang) else tr("Show password", "पासवर्ड दिखाएं", lang)
                                )
                            }
                        },
                        visualTransformation = if (showDeletePassword) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().testTag("delete_password_input"),
                        singleLine = true
                    )
                } else {
                    OutlinedTextField(
                        value = credentialInput,
                        onValueChange = { credentialInput = it },
                        label = { Text(tr("Type DELETE to confirm", "पुष्टि के लिए DELETE लिखें", lang)) },
                        placeholder = { Text("DELETE") },
                        modifier = Modifier.fillMaxWidth().testTag("delete_phrase_input"),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            val isConfirmReady = if (!useOtp && !hasPassword) {
                credentialInput.trim().equals("DELETE", ignoreCase = true)
            } else {
                credentialInput.isNotBlank()
            }
            Button(
                onClick = {
                    viewModel.deleteAccountAfterVerification(credentialInput, useOtp, onDeleted)
                },
                enabled = isConfirmReady,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("confirm_delete_account_button")
            ) {
                Text(tr("Delete Permanently", "हमेशा के लिए डिलीट करें", lang), color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, modifier = Modifier.heightIn(min = 48.dp)) {
                Text(tr("Cancel", "रद्द करें", lang))
            }
        }
    )
}


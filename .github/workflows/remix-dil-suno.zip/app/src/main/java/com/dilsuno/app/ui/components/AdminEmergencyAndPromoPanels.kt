package com.dilsuno.app.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.DilSePolicyText
import com.dilsuno.app.core.DilSunoBillingRules
import com.dilsuno.app.core.ZegoCallManager
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.AppConfig
import com.dilsuno.app.data.model.ContactLeakAlert
import com.dilsuno.app.data.model.DilSeCallSession
import com.dilsuno.app.data.model.EmergencyLegalLog
import com.dilsuno.app.data.model.ListenerPromoVideo
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.VelvetIndigo

/**
 * Dynamic high-priority EMERGENCY ALERT card on the Super Admin Dashboard shown ONLY when
 * a user/call actively triggers Emergency mode, featuring user name/ID, alert timestamp,
 * a high-contrast Red "Call User Now (Emergency)" button, and a "Dismiss Alert" button.
 */
@Composable
fun SuperAdminLiveEmergencyBanner(
    activeEmergencyCalls: List<DilSeCallSession>,
    adminUid: String,
    lang: AppLang,
    onJoinEmergencyCall: (DilSeCallSession) -> Unit,
    onDismissEmergencyAlert: (DilSeCallSession) -> Unit
) {
    val context = LocalContext.current
    if (activeEmergencyCalls.isEmpty()) return

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        activeEmergencyCalls.forEach { call ->
            val userDisplay = call.callerAlias.ifBlank { "Anonymous User" }
            val userIdDisplay = call.callerUid.ifBlank { call.id }.take(14)
            val alertTimeDisplay = DilSunoBillingRules.formatTimestamp(
                call.emergencyTriggeredAtMillis ?: call.updatedAt?.toDate()?.time
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, Color(0xFFDC2626), RoundedCornerShape(18.dp))
                    .testTag("admin_live_emergency_banner")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Warning,
                            contentDescription = tr("Emergency Alert", "आपातकालीन अलर्ट", lang),
                            tint = Color(0xFFB91C1C)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = tr("EMERGENCY ALERT", "आपातकालीन अलर्ट", lang),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF991B1B)
                        )
                    }
                    Text(
                        text = tr(
                            "User: $userDisplay (ID: $userIdDisplay)",
                            "यूज़र: $userDisplay (ID: $userIdDisplay)",
                            lang
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B)
                    )
                    Text(
                        text = tr(
                            "Alert Time: $alertTimeDisplay • Call #${call.id.take(8)} • Helpline: ${DilSePolicyText.TELE_MANAS_HELPLINE}",
                            "अलर्ट समय: $alertTimeDisplay • कॉल #${call.id.take(8)} • हेल्पलाइन: ${DilSePolicyText.TELE_MANAS_HELPLINE}",
                            lang
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF475569)
                    )
                    Button(
                        onClick = {
                            onJoinEmergencyCall(call)
                            ZegoCallManager.launchEmergencyVoiceRoom(
                                context = context,
                                callId = call.id,
                                rawUserId = adminUid.ifBlank { "owner_supervisor" },
                                anonymousRoleLabel = ZegoCallManager.EMERGENCY_SUPERVISOR_LABEL
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFDC2626),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 50.dp)
                            .testTag("admin_join_live_call_button")
                    ) {
                        Icon(Icons.Filled.Call, contentDescription = null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = tr("📞 Call User Now (Emergency)", "📞 यूज़र को अभी कॉल करें (इमरजेंसी)", lang),
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                    OutlinedButton(
                        onClick = { onDismissEmergencyAlert(call) },
                        border = BorderStroke(1.5.dp, Color(0xFF991B1B)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF991B1B)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("admin_dismiss_emergency_alert_button")
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = tr("Dismiss Alert", "अलर्ट हटाएं", lang),
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF991B1B)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Owner-only "Emergency Legal Logs" card showing Tele-MANAS escalation records (no call audio recorded/stored).
 */
@Composable
fun SuperAdminEmergencyLegalLogsCard(
    logs: List<EmergencyLegalLog>,
    lang: AppLang
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_emergency_legal_logs_card")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Gavel, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = tr("Emergency Escalation Logs (Owner Exclusive • ${logs.size})", "आपातकालीन अलर्ट लॉग (केवल Owner • ${logs.size})", lang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            if (logs.isEmpty()) {
                Text(
                    text = tr("No emergency escalations logged. Calls are private and never recorded.", "कोई आपातकालीन लॉग नहीं। कॉल्स पूरी तरह निजी हैं और कभी रिकॉर्ड नहीं होतीं।", lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                logs.take(10).forEach { log ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Call #${log.callId.take(8)} • Listener: ${log.listenerDisplayName}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Helpline: ${log.helplineDisplayed} • Admin Joined: ${if (log.adminJoined) "Yes" else "Pending"}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Displays real-time Phone Number / UPI / WhatsApp leak warnings & auto-block alerts for Super Admin.
 */
@Composable
fun SuperAdminContactLeakAlertsCard(
    alerts: List<ContactLeakAlert>,
    lang: AppLang
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_contact_leak_alerts_card")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Security, contentDescription = null, tint = CrimsonPrimary)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = tr("Live Contact Leak Auto-Block Alerts (${alerts.size})", "लाइव संपर्क लीक ऑटो-ब्लॉक अलर्ट (${alerts.size})", lang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            if (alerts.isEmpty()) {
                Text(
                    text = tr("Zero phone/UPI/WhatsApp leak violations detected.", "कोई फ़ोन/UPI/WhatsApp लीक उल्लंघन नहीं मिला।", lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                alerts.take(10).forEach { alert ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "Strike #${alert.strikeCount} • ${alert.offenderRole.uppercase()} • ${alert.category}",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (alert.strikeCount >= 2L) MaterialTheme.colorScheme.error else CrimsonPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Action: ${alert.actionTaken} | Call #${alert.callId.take(8)}",
                                style = MaterialTheme.typography.labelSmall
                            )
                            if (alert.transcriptSnippet.isNotBlank()) {
                                Text(
                                    text = "Detected: \"${alert.transcriptSnippet}\"",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Super Admin panel to review Listener-created 3-video promo submissions & upload ready-made promo assets.
 */
@Composable
fun SuperAdminPromoReviewAndAssetsCard(
    promoVideos: List<ListenerPromoVideo>,
    lang: AppLang,
    onUploadPromoAsset: (title: String, caption: String, mediaType: String, mediaUri: String) -> Unit
) {
    var assetTitle by remember { mutableStateOf("") }
    var assetCaption by remember { mutableStateOf("") }
    var selectedUri by remember { mutableStateOf<String?>(null) }
    var mediaType by remember { mutableStateOf("video") }

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) selectedUri = uri.toString()
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = VelvetIndigo.copy(alpha = 0.08f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_promo_review_card")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = tr("Listener 3-Video Promo Review (${promoVideos.size})", "Listener 3-वीडियो प्रोमो समीक्षा (${promoVideos.size})", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = VelvetIndigo
            )
            if (promoVideos.isEmpty()) {
                Text(
                    text = tr("No listener promo videos uploaded yet.", "अभी तक किसी Listener ने प्रोमो वीडियो अपलोड नहीं किया है।", lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                promoVideos.take(10).forEach { pv ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("${pv.staffDisplayName.ifBlank { pv.staffUsername }} — ${pv.title}", fontWeight = FontWeight.Bold)
                            Text(
                                text = if (pv.isShared) "✅ Shared on: ${pv.sharedPlatforms.joinToString(", ")}" else "⏳ Created — Not shared yet",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (pv.isShared) SafeEmerald else CrimsonPrimary
                            )
                        }
                    }
                }
            }

            Text(
                text = tr("Upload Ready-Made Promo Video / Poster for Listeners", "Listeners के लिए तैयार प्रोमो वीडियो / पोस्टर अपलोड करें", lang),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            OutlinedTextField(
                value = assetTitle,
                onValueChange = { assetTitle = it },
                label = { Text("Promo Title") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = assetCaption,
                onValueChange = { assetCaption = it },
                label = { Text("Pre-written Caption (Optional)") },
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = {
                        mediaType = "video"
                        mediaPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                    },
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Filled.UploadFile, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Pick Video")
                }
                OutlinedButton(
                    onClick = {
                        mediaType = "poster"
                        mediaPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Filled.UploadFile, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Pick Poster")
                }
            }
            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    onUploadPromoAsset(assetTitle.ifBlank { "Official Dil Suno Promo" }, assetCaption, mediaType, uri)
                    assetTitle = ""
                    assetCaption = ""
                    selectedUri = null
                },
                enabled = !selectedUri.isNullOrBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = VelvetIndigo,
                    contentColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
            ) {
                Text("Publish Official Promo Asset", fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Super Admin "Latest App Version & Update Link" control that pushes automatic
 * "New Update Available — Update Now" prompts to older app builds.
 */
@Composable
fun SuperAdminAppVersionUpdateCard(
    appConfig: AppConfig,
    lang: AppLang,
    onSaveVersionConfig: (versionName: String, versionCode: Long, updateUrl: String, forceUpdate: Boolean) -> Unit
) {
    var versionName by remember(appConfig.latestAppVersionName) { mutableStateOf(appConfig.latestAppVersionName) }
    var versionCodeText by remember(appConfig.latestAppVersionCode) { mutableStateOf(appConfig.latestAppVersionCode.toString()) }
    var updateUrl by remember(appConfig.appUpdateUrl) { mutableStateOf(appConfig.appUpdateUrl ?: "https://dilsuno.app/download") }
    var forceUpdate by remember(appConfig.forceUpdate) { mutableStateOf(appConfig.forceUpdate) }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_app_version_update_card")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.SystemUpdate, contentDescription = null, tint = CrimsonPrimary)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = tr("Latest App Version & Update Link", "लेटेस्ट ऐप वर्ज़न और अपडेट लिंक", lang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = versionName,
                    onValueChange = { versionName = it },
                    label = { Text("Version (e.g. 1.0.1)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f).testTag("admin_latest_version_name_input")
                )
                OutlinedTextField(
                    value = versionCodeText,
                    onValueChange = { versionCodeText = it.filter(Char::isDigit) },
                    label = { Text("Build #") },
                    singleLine = true,
                    modifier = Modifier.weight(0.7f).testTag("admin_latest_version_code_input")
                )
            }
            OutlinedTextField(
                value = updateUrl,
                onValueChange = { updateUrl = it },
                label = { Text("Update Download URL") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("admin_app_update_url_input")
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(tr("Force Update (Non-dismissible)", "अनिवार्य अपडेट (Force Update)", lang), style = MaterialTheme.typography.bodySmall)
                Switch(checked = forceUpdate, onCheckedChange = { forceUpdate = it })
            }
            Button(
                onClick = {
                    val code = versionCodeText.toLongOrNull()?.coerceAtLeast(1L) ?: 1L
                    onSaveVersionConfig(versionName.ifBlank { "1.0.0" }, code, updateUrl.trim(), forceUpdate)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = CrimsonPrimary,
                    contentColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("admin_save_version_button")
            ) {
                Text(tr("Publish App Version Update", "ऐप वर्ज़न अपडेट सेव करें", lang), color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

package com.dilsuno.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.FriendLink
import com.dilsuno.app.data.model.PublicProfile
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.VelvetIndigo
import com.dilsuno.app.viewmodel.MainAppViewModel

/**
 * Social Feed "People You May Know (जान-पहचान के लोग)" + "Suggested Friends" + Friend Requests
 * carousel for the Customer Social Feed using community profiles & smart suggestions only
 * (zero device contact access).
 */
@Composable
fun PeopleYouMayKnowSection(
    viewModel: MainAppViewModel,
    lang: AppLang
) {
    val profiles by viewModel.communityProfiles.collectAsStateWithLifecycle()
    val links by viewModel.friendLinks.collectAsStateWithLifecycle()
    val smartSuggestions by viewModel.smartFriendSuggestions.collectAsStateWithLifecycle()

    val myUid = viewModel.currentUserId

    val incomingRequests = remember(links, myUid) {
        links.filter { it.status == "pending" && it.toUid == myUid }
    }
    val outgoingPendingUids = remember(links, myUid) {
        links.filter { it.status == "pending" && it.fromUid == myUid }.map { it.toUid }.toSet()
    }
    val friendUids = remember(links, myUid) {
        links.filter { it.status == "accepted" }
            .flatMap { it.participantUids }
            .filter { it != myUid }
            .toSet()
    }
    val blockedUids = remember(links, myUid) {
        links.filter { it.status == "blocked" }
            .flatMap { it.participantUids }
            .filter { it != myUid }
            .toSet()
    }
    val profilesByUid = remember(profiles) { profiles.associateBy { it.uid } }

    val smartSuggestedIds = remember(smartSuggestions) { smartSuggestions.map { it.profile.uid }.toSet() }
    val combinedPeople = remember(smartSuggestions, profiles, myUid, blockedUids, smartSuggestedIds) {
        val list = mutableListOf<Pair<PublicProfile, String?>>()
        smartSuggestions.filter { it.profile.uid !in blockedUids && !it.profile.isBanned }.forEach { sug ->
            val reason = if (lang == AppLang.HI) sug.matchReasonsHi.firstOrNull() else sug.matchReasonsEn.firstOrNull()
            list.add(sug.profile to reason)
        }
        profiles.filter { p ->
            p.uid != myUid &&
                !p.isBanned &&
                p.uid !in blockedUids &&
                p.uid !in smartSuggestedIds
        }.take(12).forEach { list.add(it to null) }
        list
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f), RoundedCornerShape(18.dp))
            .testTag("people_you_may_know_section")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = tr("People You May Know • जान-पहचान के लोग", "जान-पहचान के लोग • People You May Know", lang),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = CrimsonPrimary
                )
                Text(
                    text = tr("Suggested Friends from your Dil Suno community", "दिल सुनो समुदाय से सुझाए गए दोस्त", lang),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Incoming Friend Requests with Accept / Decline
            if (incomingRequests.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = tr("Friend Requests (${incomingRequests.size})", "मित्रता अनुरोध (${incomingRequests.size})", lang),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = VelvetIndigo
                    )
                    incomingRequests.take(4).forEach { link ->
                        val sender = profilesByUid[link.fromUid]
                        val senderName = SecurityUtils.resolveDisplayName(sender?.fullName)
                        Surface(
                            color = VelvetIndigo.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = senderName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Button(
                                    onClick = { viewModel.acceptFriendRequest(link, link.fromUid) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SafeEmerald),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("accept_friend_req_${link.fromUid}")
                                ) {
                                    Text(tr("Accept", "स्वीकार", lang), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { viewModel.declineFriendRequest(link.id) },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("decline_friend_req_${link.fromUid}")
                                ) {
                                    Text(tr("Decline", "अस्वीकार", lang), style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
            }

            if (combinedPeople.isEmpty()) {
                Text(
                    text = tr(
                        "Connect safely with verified members of the Dil Suno community.",
                        "दिल सुनो समुदाय के सत्यापित सदस्यों से सुरक्षित रूप से जुड़ें।",
                        lang
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(combinedPeople, key = { it.first.uid }) { (profile, matchReason) ->
                        val incomingLink = incomingRequests.firstOrNull { it.fromUid == profile.uid }
                        val isFriend = profile.uid in friendUids
                        val isPendingSent = profile.uid in outgoingPendingUids

                        PersonSuggestionCard(
                            profile = profile,
                            matchReason = matchReason,
                            isFriend = isFriend,
                            isPendingSent = isPendingSent,
                            incomingLink = incomingLink,
                            lang = lang,
                            onAddFriend = { viewModel.sendFriendRequest(profile.uid) },
                            onAccept = { link -> viewModel.acceptFriendRequest(link, profile.uid) },
                            onDecline = { link -> viewModel.declineFriendRequest(link.id) }
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.Shield,
                    contentDescription = null,
                    tint = SafeEmerald,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    text = tr(
                        "Social Friends are strictly separate from 100% Anonymous ₹100 'Talk Now' support calls.",
                        "सोशल फ्रेंड्स 100% गुमनाम ₹100 'Talk Now' सपोर्ट कॉल से पूरी तरह अलग रहते हैं।",
                        lang
                    ),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun PersonSuggestionCard(
    profile: PublicProfile,
    matchReason: String?,
    isFriend: Boolean,
    isPendingSent: Boolean,
    incomingLink: FriendLink?,
    lang: AppLang,
    onAddFriend: () -> Unit,
    onAccept: (FriendLink) -> Unit,
    onDecline: (FriendLink) -> Unit
) {
    val displayName = SecurityUtils.resolveDisplayName(profile.fullName)
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.width(168.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(CrimsonPrimary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                if (!profile.avatarUri.isNullOrBlank()) {
                    AsyncImage(
                        model = profile.avatarUri,
                        contentDescription = displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(56.dp).clip(CircleShape)
                    )
                } else {
                    Text(
                        text = displayName.firstOrNull()?.uppercase() ?: "D",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = CrimsonPrimary
                    )
                }
            }

            Text(
                text = displayName,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Surface(
                color = VelvetIndigo.copy(alpha = 0.12f),
                shape = RoundedCornerShape(999.dp)
            ) {
                Text(
                    text = matchReason?.takeIf { it.isNotBlank() }
                        ?: profile.currentCity?.takeIf { it.isNotBlank() }
                        ?: tr("Suggested Friend", "सुझाए गए दोस्त", lang),
                    style = MaterialTheme.typography.labelSmall,
                    color = VelvetIndigo,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }

            Spacer(Modifier.height(2.dp))

            when {
                isFriend -> {
                    OutlinedButton(
                        onClick = {},
                        enabled = false,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Filled.Group, contentDescription = null, modifier = Modifier.size(16.dp), tint = SafeEmerald)
                        Spacer(Modifier.width(4.dp))
                        Text(tr("Friends", "दोस्त", lang), color = SafeEmerald, fontWeight = FontWeight.Bold)
                    }
                }
                incomingLink != null -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { onAccept(incomingLink) },
                            colors = ButtonDefaults.buttonColors(containerColor = SafeEmerald),
                            contentPadding = PaddingValues(horizontal = 6.dp),
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) {
                            Text(tr("Accept", "स्वीकार", lang), style = MaterialTheme.typography.labelSmall)
                        }
                        OutlinedButton(
                            onClick = { onDecline(incomingLink) },
                            contentPadding = PaddingValues(horizontal = 6.dp),
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) {
                            Text(tr("Decline", "रद्द", lang), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                isPendingSent -> {
                    OutlinedButton(
                        onClick = {},
                        enabled = false,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(tr("Requested", "भेजा गया", lang), style = MaterialTheme.typography.labelSmall)
                    }
                }
                else -> {
                    Button(
                        onClick = onAddFriend,
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("add_friend_${profile.uid}")
                    ) {
                        Icon(Icons.Filled.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(tr("Add Friend", "दोस्त बनाएं", lang), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

package com.dilsuno.app.ui.screens

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.content.pm.PackageManager
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Warning
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.ContactLeakDetector
import com.dilsuno.app.core.DilSePolicyText
import com.dilsuno.app.core.DilSunoBillingRules
import com.dilsuno.app.core.EmergencyNotificationHelper
import com.dilsuno.app.core.IncomingCallRingtoneEffect
import com.dilsuno.app.core.LiveSpeechLeakMonitor
import com.dilsuno.app.core.LiveWebRtcAudioBridge
import com.dilsuno.app.core.ZegoCallManager
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.DilSeCallSession
import com.dilsuno.app.data.model.StaffAccount
import com.dilsuno.app.ui.components.ListenerGoOnlineGateCard
import com.dilsuno.app.ui.components.LiveModerationFeedPanel
import com.dilsuno.app.ui.components.MandatoryListenerRulesBanner
import com.dilsuno.app.ui.components.ModerationQueuePanel
import com.dilsuno.app.ui.components.ProminentPermissionDisclosureDialog
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.RoyalNavy
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.viewmodel.StaffAndAdminViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StaffPortalScreen(
    staff: StaffAccount,
    viewModel: StaffAndAdminViewModel,
    lang: AppLang,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val liveStaff by viewModel.myStaffAccount.collectAsStateWithLifecycle()
    val isOnline by viewModel.isStaffOnline.collectAsStateWithLifecycle()
    val earnings by viewModel.staffEarnings.collectAsStateWithLifecycle()
    val totalCalls by viewModel.staffTotalCalls.collectAsStateWithLifecycle()
    val waitingCalls by viewModel.waitingCalls.collectAsStateWithLifecycle()
    val activeCall by viewModel.activeStaffCall.collectAsStateWithLifecycle()
    val myStaffPayouts by viewModel.myStaffPayouts.collectAsStateWithLifecycle()
    val allPosts by viewModel.allPosts.collectAsStateWithLifecycle()
    val allStories by viewModel.allStories.collectAsStateWithLifecycle()
    val allLiveStreams by viewModel.allLiveStreams.collectAsStateWithLifecycle()
    val communityProfiles by viewModel.communityProfiles.collectAsStateWithLifecycle()
    val profilesByUid = remember(communityProfiles) { communityProfiles.associateBy { it.uid } }
    val appConfig by viewModel.appConfig.collectAsStateWithLifecycle()
    val feedback by viewModel.feedback.collectAsStateWithLifecycle()
    val hasAcceptedRulesBanner by viewModel.hasAcceptedRulesBanner.collectAsStateWithLifecycle()
    val hasAcceptedGoldenRules by viewModel.hasAcceptedGoldenRules.collectAsStateWithLifecycle()
    val myPromoVideos by viewModel.myPromoVideos.collectAsStateWithLifecycle()
    val adminPromoAssets by viewModel.adminPromoAssets.collectAsStateWithLifecycle()
    val canGoOnline by viewModel.canGoOnline.collectAsStateWithLifecycle()
    val isTrustedStaffManager by viewModel.isTrustedStaffManager.collectAsStateWithLifecycle()
    val allReports by viewModel.allReports.collectAsStateWithLifecycle()
    val listenerApps by viewModel.listenerApplications.collectAsStateWithLifecycle()
    val pendingListenerApps = remember(listenerApps) { listenerApps.filter { it.status == "pending" } }
    val openReportCount = remember(allReports) { allReports.count { it.status == "open" } }
    val notifiedReportIds = remember { mutableStateListOf<String>() }

    val hasMicPermission = remember(context, activeCall?.status) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    }

    var selectedPortalTab by rememberSaveable { mutableIntStateOf(0) }
    var isMuted by remember { mutableStateOf(false) }
    var isSpeaker by remember { mutableStateOf(true) }
    var callSeconds by remember { mutableLongStateOf(0L) }
    var confirmAbuseBlock by remember { mutableStateOf(false) }
    var showStaffMicDisclosure by remember { mutableStateOf(false) }
    var staffPayoutAccount by remember { mutableStateOf("") }
    var withdrawAmountText by remember { mutableStateOf("") }
    var pendingCallToAccept by remember { mutableStateOf<DilSeCallSession?>(null) }

    // Fire instant alert notification on Trusted Staff Manager device when new reports arrive
    LaunchedEffect(isTrustedStaffManager, allReports) {
        if (isTrustedStaffManager) {
            allReports.filter { it.status == "open" }.forEach { report ->
                if (report.id !in notifiedReportIds) {
                    notifiedReportIds.add(report.id)
                    EmergencyNotificationHelper.showModerationReportNotification(
                        context = context,
                        reportId = report.id,
                        reason = report.reason,
                        targetType = report.targetType
                    )
                }
            }
        } else if (selectedPortalTab == 2) {
            selectedPortalTab = 0
        }
    }

    DisposableEffect(activeCall?.id) {
        onDispose {
            ZegoCallManager.setEmergencyFreeOverride(false)
        }
    }

    LaunchedEffect(earnings) {
        withdrawAmountText = if (earnings >= DilSunoBillingRules.MIN_LISTENER_WITHDRAWAL_INR) {
            earnings.toString()
        } else {
            ""
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        pendingCallToAccept?.let { call ->
            pendingCallToAccept = null
            viewModel.acceptCall(call)
        }
    }

    if (selectedPortalTab != 0) {
        BackHandler {
            selectedPortalTab = 0
        }
    }

    LaunchedEffect(staff.staffUsername) {
        viewModel.initStaffMetrics(staff)
    }

    // Real-time Super Admin suspension enforcement
    LaunchedEffect(liveStaff?.isActive) {
        if (liveStaff != null && liveStaff?.isActive == false) {
            onLogout()
        }
    }

    LaunchedEffect(activeCall?.id, activeCall?.status) {
        if (activeCall?.status == "active") {
            callSeconds = 0L
            while (activeCall?.status == "active") {
                delay(1000L)
                callSeconds++
            }
        }
    }

    // Ringtone alert when online staff member has incoming waiting calls
    IncomingCallRingtoneEffect(
        isRinging = isOnline && activeCall == null && waitingCalls.isNotEmpty()
    )

    // Mandatory full-screen Listener Rules & Code of Conduct banner right after login
    if (!hasAcceptedRulesBanner) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .systemBarsPadding()
        ) {
            MandatoryListenerRulesBanner(
                listenerName = liveStaff?.displayName ?: staff.displayName,
                lang = lang,
                onAcceptAndContinue = { viewModel.acceptRulesBanner() }
            )
        }
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = RoyalNavy),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(SafeEmerald),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Filled.HeadsetMic, contentDescription = "Staff Listener", tint = Color.White)
                                    }
                                    Column {
                                        Text(
                                            text = if (isTrustedStaffManager) {
                                                tr("Trusted Staff Manager", "ट्रस्टेड स्टाफ मैनेजर", lang)
                                            } else {
                                                tr("Staff Listener Dashboard", "स्टाफ श्रोता डैशबोर्ड", lang)
                                            },
                                            style = MaterialTheme.typography.titleLarge,
                                            color = Color.White
                                        )
                                        val staffSubtitle = (liveStaff?.staffEmail ?: staff.staffEmail).ifBlank { "@${staff.staffUsername}" }
                                        Text(
                                            text = "${liveStaff?.displayName ?: staff.displayName} • $staffSubtitle",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Color.White.copy(alpha = 0.8f)
                                        )
                                        if (isTrustedStaffManager) {
                                            Surface(
                                                color = CrimsonPrimary,
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.padding(top = 4.dp).testTag("trusted_staff_manager_badge")
                                            ) {
                                                Text(
                                                    text = tr("Moderation Queue Enabled • Zero Bank/Payout Access", "मॉडरेशन कतार सक्रिय • कोई बैंक एक्सेस नहीं", lang),
                                                    color = Color.White,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                                IconButton(
                                    onClick = onLogout,
                                    modifier = Modifier.testTag("staff_logout_button")
                                ) {
                                    Icon(
                                        Icons.AutoMirrored.Filled.Logout,
                                        contentDescription = tr("Sign Out", "लॉगआउट", lang),
                                        tint = Color.White
                                    )
                                }
                            }

                            Surface(
                                color = Color.White.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (isOnline) tr("ON DUTY (Receiving Calls)", "ऑन ड्यूटी (कॉल सक्रिय)", lang)
                                            else if (!canGoOnline) tr("GO ONLINE LOCKED (Complete Steps Below)", "GO ONLINE लॉक (नीचे चरण पूरे करें)", lang)
                                            else tr("OFFLINE (Ready to Go Online)", "ऑफलाइन (ड्यूटी बंद)", lang),
                                            color = if (isOnline) Color(0xFF5EEAD4) else Color.White.copy(alpha = 0.78f),
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (canGoOnline) {
                                                tr("Restricted portal — zero admin settings access", "सीमित पोर्टल — कोई एडमिन सेटिंग्स एक्सेस नहीं", lang)
                                            } else {
                                                tr("Complete 5 Golden Rules + 3 shared promo videos to unlock", "अनलॉक के लिए 5 नियम + 3 प्रोमो वीडियो शेयर करें", lang)
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White.copy(alpha = 0.72f)
                                        )
                                    }
                                    Switch(
                                        checked = isOnline,
                                        enabled = canGoOnline || isOnline,
                                        onCheckedChange = { viewModel.toggleStaffDuty(it) },
                                        modifier = Modifier.testTag("staff_duty_switch")
                                    )
                                }
                            }
                        }
                    }
                }

                // Duty vs Live Social Feed & Reels Monitor (+ Moderation Queue for Trusted Staff Managers only)
                item {
                    PrimaryTabRow(selectedTabIndex = selectedPortalTab) {
                        Tab(
                            selected = selectedPortalTab == 0,
                            onClick = { selectedPortalTab = 0 },
                            icon = { Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            text = { Text(tr("Duty & Calls", "कॉल ड्यूटी", lang)) },
                            modifier = Modifier.testTag("staff_tab_duty")
                        )
                        Tab(
                            selected = selectedPortalTab == 1,
                            onClick = { selectedPortalTab = 1 },
                            icon = { Icon(Icons.Filled.OndemandVideo, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            text = { Text(tr("Monitor Feed", "सोशल फीड", lang)) },
                            modifier = Modifier.testTag("staff_tab_feed_monitor")
                        )
                        if (isTrustedStaffManager) {
                            Tab(
                                selected = selectedPortalTab == 2,
                                onClick = { selectedPortalTab = 2 },
                                icon = { Icon(Icons.Filled.Flag, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                text = {
                                    Text(
                                        tr(
                                            "Moderation ($openReportCount)",
                                            "मॉडरेशन ($openReportCount)",
                                            lang
                                        )
                                    )
                                },
                                modifier = Modifier.testTag("staff_tab_moderation_queue")
                            )
                        }
                    }
                }

                if (!feedback.isNullOrBlank()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = feedback!!,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = { viewModel.clearFeedback() }) {
                                    Text(tr("OK", "ठीक", lang))
                                }
                            }
                        }
                    }
                }

                if (selectedPortalTab == 2 && isTrustedStaffManager) {
                    item {
                        ModerationQueuePanel(
                            reports = allReports,
                            lang = lang,
                            onApproveIgnore = { report ->
                                viewModel.resolveModerationQueueAction(report, "approve_ignore")
                            },
                            onDeleteAndWarn = { report ->
                                viewModel.resolveModerationQueueAction(report, "delete_warn")
                            },
                            onDeleteAndPermanentBan = { report ->
                                viewModel.resolveModerationQueueAction(report, "delete_ban")
                            }
                        )
                    }
                } else if (selectedPortalTab == 1) {
                    item {
                        LiveModerationFeedPanel(
                            posts = allPosts,
                            stories = allStories,
                            liveStreams = allLiveStreams,
                            profilesByUid = profilesByUid,
                            observePostComments = viewModel::observeCommentsForPost,
                            observeLiveComments = viewModel::observeLiveComments,
                            onDeleteWithWarn = { targetType, targetId, parentPostId, targetAuthorUid, targetAuthorName, contentPreview, reason ->
                                viewModel.deleteContentAsModerator(
                                    targetType = targetType,
                                    targetId = targetId,
                                    parentPostId = parentPostId,
                                    targetAuthorUid = targetAuthorUid,
                                    targetAuthorName = targetAuthorName,
                                    contentPreview = contentPreview,
                                    reason = reason
                                )
                            },
                            lang = lang
                        )
                    }
                } else {
                    // Metrics Summary
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Card(modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Filled.CurrencyRupee, contentDescription = null, tint = SafeEmerald)
                                        Text(tr("Call Earnings", "कॉल कमाई", lang), style = MaterialTheme.typography.labelLarge)
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        text = "₹$earnings",
                                        style = MaterialTheme.typography.headlineMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = SafeEmerald,
                                        modifier = Modifier.testTag("staff_earnings_text")
                                    )
                                    Text(
                                        text = tr("₹30 / completed 30-min call", "₹30 प्रति 30-मिनट पूर्ण कॉल", lang),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Card(modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Filled.Call, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Text(tr("Completed Calls", "पूर्ण कॉल", lang), style = MaterialTheme.typography.labelLarge)
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        text = "$totalCalls",
                                        style = MaterialTheme.typography.headlineMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Mandatory Go Online Onboarding Gate (Step A: 5 Golden Rules + Step B: 3 In-App Promo Videos & Share)
                    item {
                        ListenerGoOnlineGateCard(
                            hasAcceptedGoldenRules = hasAcceptedGoldenRules,
                            myPromoVideos = myPromoVideos,
                            adminPromoAssets = adminPromoAssets,
                            canGoOnline = canGoOnline,
                            appDownloadUrl = appConfig.appUpdateUrl,
                            lang = lang,
                            onAcceptGoldenRules = { viewModel.acceptGoldenRules() },
                            onAddPromoVideo = { title, caption, uri ->
                                viewModel.addListenerPromoVideo(title, caption, uri)
                            },
                            onMarkVideoShared = { video, platform ->
                                viewModel.markPromoVideoShared(video, platform)
                            }
                        )
                    }

                    // Active Call Card with 100% Anonymous Labels, Emergency Alert & Live Contact Leak Blocking
                    val currentCall = activeCall
                    if (currentCall != null) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                shape = RoundedCornerShape(22.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp).fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        Icons.Filled.HeadsetMic,
                                        contentDescription = "Active Dil Se Call",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(44.dp)
                                    )
                                    val slotRemaining = (DilSunoBillingRules.CALL_SLOT_DURATION_SECONDS - (callSeconds % DilSunoBillingRules.CALL_SLOT_DURATION_SECONDS)).coerceAtLeast(0L)
                                    val countdownStr = DilSunoBillingRules.formatCountdownMmSs(slotRemaining)
                                    Text(
                                        text = tr(
                                            "Live Anonymous Call • $countdownStr / 30:00",
                                            "लाइव गुमनाम कॉल • $countdownStr / 30:00",
                                            lang
                                        ),
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Caller ↔ Listener (100% Anonymous Audio) • ₹30 Listener Payout",
                                        style = MaterialTheme.typography.bodyMedium
                                    )

                                    // Real-Time On-Device Contact Leak Protection (zero regular audio saved)
                                    LiveSpeechLeakMonitor(
                                        active = currentCall.status == "active",
                                        hasAudioPermission = hasMicPermission,
                                        onContactLeakDetected = { leak ->
                                            viewModel.reportContactLeakDuringCall(
                                                category = leak.category,
                                                snippet = leak.matchedSnippet,
                                                offenderRole = "listener"
                                            )
                                        }
                                    )

                                    if (currentCall.contactLeakWarnings >= 1L) {
                                        Surface(
                                            color = Color(0xFFB91C1C),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.fillMaxWidth().testTag("staff_contact_leak_warning_banner")
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(Icons.Filled.Warning, contentDescription = null, tint = Color.White)
                                                Text(
                                                    text = currentCall.lastLeakWarningText ?: ContactLeakDetector.WARNING_BANNER_TEXT,
                                                    color = Color.White,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.ExtraBold
                                                )
                                            }
                                        }
                                    }

                                    if (currentCall.emergencyAlertActive) {
                                        Surface(
                                            color = Color(0xFF991B1B),
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier.fillMaxWidth().testTag("staff_emergency_active_banner")
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(12.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(
                                                    text = "🚨 EMERGENCY OVERRIDE ACTIVE • FREE CALL (NEVER DISCONNECTS)",
                                                    color = Color.White,
                                                    style = MaterialTheme.typography.labelLarge,
                                                    fontWeight = FontWeight.ExtraBold
                                                )
                                                Text(
                                                    text = "Super Admin Alerted • Share Helpline: ${DilSePolicyText.TELE_MANAS_HELPLINE}",
                                                    color = Color(0xFFFDE047),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                if (!currentCall.zegoRoomId.isNullOrBlank()) {
                                                    Button(
                                                        onClick = {
                                                            ZegoCallManager.launchEmergencyVoiceRoom(
                                                                context = context,
                                                                callId = currentCall.id,
                                                                rawUserId = staff.staffUsername,
                                                                anonymousRoleLabel = ZegoCallManager.ANONYMOUS_LISTENER_LABEL
                                                            )
                                                        },
                                                        colors = ButtonDefaults.buttonColors(
                                                            containerColor = Color.White,
                                                            contentColor = Color(0xFF991B1B)
                                                        ),
                                                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                                                    ) {
                                                        Icon(Icons.Filled.Call, contentDescription = null)
                                                        Spacer(Modifier.width(6.dp))
                                                        Text("Join 3-Way Emergency Audio Room", fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    LiveWebRtcAudioBridge(
                                        callId = currentCall.id,
                                        localRole = "listener",
                                        isCallActive = currentCall.status == "active",
                                        isMuted = isMuted,
                                        isSpeaker = isSpeaker,
                                        agoraAppId = appConfig.agoraAppId,
                                        signalsFlow = viewModel.observeWebRtcSignals(currentCall.id),
                                        onSendSignal = { sigType, payload ->
                                            viewModel.sendWebRtcSignal(currentCall.id, "listener", sigType, payload)
                                        },
                                        lang = lang
                                    )

                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        OutlinedButton(
                                            onClick = { isMuted = !isMuted },
                                            modifier = Modifier.heightIn(min = 48.dp).testTag("staff_mute_button")
                                        ) {
                                            Icon(if (isMuted) Icons.Filled.MicOff else Icons.Filled.Mic, contentDescription = null)
                                            Spacer(Modifier.width(6.dp))
                                            Text(if (isMuted) "Muted" else "Mic On")
                                        }
                                        OutlinedButton(
                                            onClick = { isSpeaker = !isSpeaker },
                                            modifier = Modifier.heightIn(min = 48.dp).testTag("staff_speaker_button")
                                        ) {
                                            Icon(Icons.Filled.VolumeUp, contentDescription = null)
                                            Spacer(Modifier.width(6.dp))
                                            Text(if (isSpeaker) "Speaker" else "Earpiece")
                                        }
                                    }

                                    // Emergency / Suicide Alert Button (Free Override + Super Admin Alert + Tele-MANAS 14416)
                                    Button(
                                        onClick = {
                                            viewModel.triggerEmergencySuicideAlert(null)
                                        },
                                        enabled = !currentCall.emergencyAlertActive,
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 52.dp)
                                            .testTag("staff_emergency_suicide_alert_button")
                                    ) {
                                        Icon(Icons.Filled.Warning, contentDescription = "Emergency Suicide Alert", tint = Color.White)
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            text = if (currentCall.emergencyAlertActive) {
                                                "🚨 Emergency Alert Active (Tele-MANAS: 14416)"
                                            } else {
                                                "Emergency / Suicide Alert"
                                            },
                                            color = Color.White,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            ZegoCallManager.setEmergencyFreeOverride(false)
                                            viewModel.endCallNormally(callSeconds)
                                        },
                                        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("staff_end_call_button")
                                    ) {
                                        Icon(Icons.Filled.CallEnd, contentDescription = null)
                                        Spacer(Modifier.width(8.dp))
                                        Text(tr("Complete & End Call", "कॉल सम्मानपूर्वक समाप्त करें", lang))
                                    }

                                    Button(
                                        onClick = { confirmAbuseBlock = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C)),
                                        modifier = Modifier.fillMaxWidth().height(54.dp).testTag("staff_abuse_disconnect_block_button")
                                    ) {
                                        Icon(Icons.Filled.Block, contentDescription = "Report and Block Abuse", tint = Color.White)
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            text = tr(
                                                "Report & Block Abuse",
                                                "Report & Block Abuse • दुर्व्यवहार ब्लॉक करें",
                                                lang
                                            ),
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Waiting Queue Header
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text(
                                text = tr("Incoming Dil Se Calls (${waitingCalls.size})", "आने वाली दिल से कॉल (${waitingCalls.size})", lang),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (waitingCalls.isEmpty()) {
                        item {
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(
                                    modifier = Modifier.padding(20.dp).fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = if (isOnline) tr("No callers waiting right now.", "अभी कोई कॉलर प्रतीक्षा में नहीं है।", lang)
                                        else tr("Toggle Duty ONLINE above to accept anonymous Dil Se calls.", "कॉल स्वीकार करने के लिए ऊपर ड्यूटी ONLINE करें।", lang),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    } else {
                        items(waitingCalls, key = { it.id }) { call ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = tr("Anonymous Caller", "गुमनाम कॉलर", lang),
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = tr("100% Anonymous Audio • Fee ₹${call.feeInr}", "100% गुमनाम ऑडियो • शुल्क ₹${call.feeInr}", lang),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Button(
                                        onClick = {
                                            pendingCallToAccept = call
                                            if (hasMicPermission) {
                                                pendingCallToAccept = null
                                                viewModel.acceptCall(call)
                                            } else {
                                                showStaffMicDisclosure = true
                                            }
                                        },
                                        enabled = isOnline && activeCall == null,
                                        modifier = Modifier.height(48.dp).testTag("accept_call_${call.id}")
                                    ) {
                                        Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(tr("Answer", "उठाएं", lang))
                                    }
                                }
                            }
                        }
                    }

                    // Listener Applications (Step 1: Verify by Staff)
                    if (pendingListenerApps.isNotEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().testTag("staff_listener_applications_card"),
                                shape = RoundedCornerShape(18.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text(
                                        text = tr(
                                            "New Listener Applications (${pendingListenerApps.size}) • Step 1 Review",
                                            "नए श्रोता आवेदन (${pendingListenerApps.size}) • चरण 1 समीक्षा",
                                            lang
                                        ),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    pendingListenerApps.forEach { app ->
                                        Surface(
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Text("${app.fullName} • ${app.email}", fontWeight = FontWeight.Bold)
                                                if (!app.city.isNullOrBlank()) {
                                                    Text(tr("City: ${app.city}", "शहर: ${app.city}", lang), style = MaterialTheme.typography.labelSmall)
                                                }
                                                Text(app.motivation, style = MaterialTheme.typography.bodySmall)
                                                Button(
                                                    onClick = { viewModel.verifyListenerApplicationByStaff(app) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = SafeEmerald, contentColor = Color.White),
                                                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("staff_verify_listener_app_${app.id}")
                                                ) {
                                                    Text(tr("Verify by Staff ✓", "स्टाफ द्वारा सत्यापित करें ✓", lang), color = Color.White, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Staff Withdrawal Request Card (Strict Minimum ₹500 + 24h Processing)
                    item {
                        val canWithdraw = earnings >= DilSunoBillingRules.MIN_LISTENER_WITHDRAWAL_INR
                        val parsedWithdrawAmount = withdrawAmountText.toLongOrNull() ?: 0L
                        val isWithdrawFormValid = canWithdraw &&
                            staffPayoutAccount.trim().length >= 4 &&
                            parsedWithdrawAmount in DilSunoBillingRules.MIN_LISTENER_WITHDRAWAL_INR..earnings

                        Card(
                            modifier = Modifier.fillMaxWidth().testTag("staff_withdrawal_card"),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Text(tr("Listener Payout Withdrawal", "श्रोता पेआउट निकासी", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    }
                                    Surface(
                                        color = if (canWithdraw) SafeEmerald.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = "₹$earnings",
                                            color = if (canWithdraw) SafeEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                if (!canWithdraw) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.55f),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth().testTag("staff_min_withdrawal_lock_banner")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(
                                                Icons.Filled.Lock,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Column {
                                                Text(
                                                    text = DilSunoBillingRules.MIN_WITHDRAWAL_NOTE,
                                                    style = MaterialTheme.typography.labelLarge,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onErrorContainer
                                                )
                                                Text(
                                                    text = tr(
                                                        "Earn ₹${DilSunoBillingRules.MIN_LISTENER_WITHDRAWAL_INR - earnings} more to unlock withdrawal.",
                                                        "निकासी खोलने के लिए ₹${DilSunoBillingRules.MIN_LISTENER_WITHDRAWAL_INR - earnings} और कमाएं।",
                                                        lang
                                                    ),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onErrorContainer
                                                )
                                            }
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = staffPayoutAccount,
                                    onValueChange = { staffPayoutAccount = it },
                                    label = { Text(tr("Bank / Payout Account Reference", "बैंक / पेआउट अकाउंट विवरण", lang)) },
                                    modifier = Modifier.fillMaxWidth().testTag("staff_payout_account_input"),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = withdrawAmountText,
                                    onValueChange = { input ->
                                        withdrawAmountText = input.filter { it.isDigit() }
                                    },
                                    label = {
                                        Text(
                                            tr(
                                                "Withdrawal Amount (₹500 – ₹$earnings)",
                                                "निकासी राशि (₹500 – ₹$earnings)",
                                                lang
                                            )
                                        )
                                    },
                                    enabled = canWithdraw,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.fillMaxWidth().testTag("staff_withdraw_amount_input"),
                                    singleLine = true
                                )

                                Button(
                                    onClick = {
                                        viewModel.requestStaffPayout(
                                            staffDisplayName = liveStaff?.displayName ?: staff.displayName,
                                            payoutAccount = staffPayoutAccount,
                                            requestedAmountInr = parsedWithdrawAmount
                                        )
                                    },
                                    enabled = isWithdrawFormValid,
                                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("staff_request_payout_button")
                                ) {
                                    Icon(
                                        if (canWithdraw) Icons.Filled.AccountBalanceWallet else Icons.Filled.Lock,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        if (canWithdraw) {
                                            tr(
                                                "Withdraw ₹${parsedWithdrawAmount.coerceAtLeast(DilSunoBillingRules.MIN_LISTENER_WITHDRAWAL_INR)}",
                                                "₹${parsedWithdrawAmount.coerceAtLeast(DilSunoBillingRules.MIN_LISTENER_WITHDRAWAL_INR)} निकासी अनुरोध भेजें",
                                                lang
                                            )
                                        } else {
                                            DilSunoBillingRules.MIN_WITHDRAWAL_NOTE
                                        },
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                if (myStaffPayouts.isNotEmpty()) {
                                    Text(
                                        text = tr("Recent Withdrawal Requests", "हाल के निकासी अनुरोध", lang),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    myStaffPayouts.forEach { p ->
                                        val statusLabel = DilSunoBillingRules.formatPayoutStatusLabel(p.status)
                                        val timeStr = DilSunoBillingRules.formatTimestamp(p.createdAt?.toDate()?.time)
                                        Surface(
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp).fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = "₹${p.amountInr} • ${p.payoutAccount}",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = timeStr,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                Surface(
                                                    color = if (p.status == "paid") SafeEmerald else MaterialTheme.colorScheme.secondaryContainer,
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Text(
                                                        text = statusLabel,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (p.status == "paid") Color.White else MaterialTheme.colorScheme.onSecondaryContainer,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmAbuseBlock) {
        AlertDialog(
            onDismissRequest = { confirmAbuseBlock = false },
            icon = { Icon(Icons.Filled.Block, contentDescription = null, tint = Color(0xFFB91C1C)) },
            title = { Text(tr("Disconnect & Permanently Block?", "कॉल काटें और हमेशा के लिए ब्लॉक करें?", lang)) },
            text = {
                Text(
                    tr(
                        "This immediately terminates the call, forfeits the caller's ₹${activeCall?.feeInr ?: 100} fee (No Refund), and permanently bans their account.",
                        "यह तुरंत कॉल काट देगा, शुल्क वापस (Refund) नहीं होगा, और कॉलर का अकाउंट हमेशा के लिए ब्लॉक हो जाएगा।",
                        lang
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmAbuseBlock = false
                        ZegoCallManager.setEmergencyFreeOverride(false)
                        viewModel.abuseDisconnectAndBlockCaller()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C)),
                    modifier = Modifier.testTag("confirm_abuse_block_button")
                ) {
                    Text(tr("Disconnect & Block Now", "अभी काटें और ब्लॉक करें", lang), color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmAbuseBlock = false }) {
                    Text(tr("Cancel", "रद्द करें", lang))
                }
            }
        )
    }

    if (showStaffMicDisclosure) {
        ProminentPermissionDisclosureDialog(
            lang = lang,
            onContinue = {
                showStaffMicDisclosure = false
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            },
            onNotNow = {
                showStaffMicDisclosure = false
                pendingCallToAccept = null
            }
        )
    }
}

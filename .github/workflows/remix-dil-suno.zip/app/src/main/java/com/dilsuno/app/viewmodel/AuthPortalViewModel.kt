package com.dilsuno.app.viewmodel

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.PreviewUserCredential
import com.dilsuno.app.core.RateLimiterStore
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.data.model.ActivePortalSession
import com.dilsuno.app.data.model.AppConfig
import com.dilsuno.app.data.model.StaffDirectoryEntry
import com.dilsuno.app.data.model.UserAccount
import com.dilsuno.app.data.repository.AccountAndSocialRepository
import com.dilsuno.app.data.repository.FeedModerationAndCallRepository
import com.google.firebase.Firebase
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.auth
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull

enum class SignUpChannel {
    EMAIL,
    PHONE
}

class AuthPortalViewModel(
    private val accountRepo: AccountAndSocialRepository,
    private val feedRepo: FeedModerationAndCallRepository,
    private val rateLimiter: RateLimiterStore
) : ViewModel() {

    val language: StateFlow<AppLang> = rateLimiter.languageFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = AppLang.EN
    )

    val appConfig: StateFlow<AppConfig> = feedRepo.observeAppConfig()
        .catch { emit(AppConfig()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = AppConfig()
        )

    private val _session = MutableStateFlow<ActivePortalSession>(ActivePortalSession.UnverifiedPortal)
    val session: StateFlow<ActivePortalSession> = _session.asStateFlow()

    private val _isCheckingPortalAccess = MutableStateFlow(true)
    val isCheckingPortalAccess: StateFlow<Boolean> = _isCheckingPortalAccess.asStateFlow()

    private val _existingCustomerAccount = MutableStateFlow<UserAccount?>(null)
    val existingCustomerAccount: StateFlow<UserAccount?> = _existingCustomerAccount.asStateFlow()

    // Sign Up Step 2: Inline 6-digit OTP box directly inside the Sign Up card
    private val _isSignUpInlineOtpOpen = MutableStateFlow(false)
    val isSignUpInlineOtpOpen: StateFlow<Boolean> = _isSignUpInlineOtpOpen.asStateFlow()

    private val _pendingSignUpChannel = MutableStateFlow(SignUpChannel.EMAIL)
    val pendingSignUpChannel: StateFlow<SignUpChannel> = _pendingSignUpChannel.asStateFlow()

    private val _pendingSignUpEmail = MutableStateFlow<String?>(null)
    val pendingSignUpEmail: StateFlow<String?> = _pendingSignUpEmail.asStateFlow()

    private val _pendingSignUpPhone = MutableStateFlow<String?>(null)
    val pendingSignUpPhone: StateFlow<String?> = _pendingSignUpPhone.asStateFlow()

    private var pendingSignUpPassword: String? = null
    private var pendingSignUpFullName: String? = null
    private var phoneVerificationId: String? = null
    private var phoneResendToken: PhoneAuthProvider.ForceResendingToken? = null
    private var createdPendingEmailAuthUser: Boolean = false

    private val _isRealPhoneAuthActive = MutableStateFlow(true)
    val isRealPhoneAuthActive: StateFlow<Boolean> = _isRealPhoneAuthActive.asStateFlow()

    private val _isRealEmailVerificationSent = MutableStateFlow(false)
    val isRealEmailVerificationSent: StateFlow<Boolean> = _isRealEmailVerificationSent.asStateFlow()

    // Shown ONLY AFTER an approved Staff Gmail ID passes Sign In
    private val _pendingStaffVerification = MutableStateFlow<StaffDirectoryEntry?>(null)
    val pendingStaffVerification: StateFlow<StaffDirectoryEntry?> = _pendingStaffVerification.asStateFlow()

    // Forgot password state (OTP / Email reset lives ONLY in Forgot Password)
    private val _resetOtpSent = MutableStateFlow(false)
    val resetOtpSent: StateFlow<Boolean> = _resetOtpSent.asStateFlow()

    private val _resetUsesPreviewOtp = MutableStateFlow(false)
    val resetUsesPreviewOtp: StateFlow<Boolean> = _resetUsesPreviewOtp.asStateFlow()

    private val _resetResolvedEmail = MutableStateFlow<String?>(null)
    val resetResolvedEmail: StateFlow<String?> = _resetResolvedEmail.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _lockoutSecondsLeft = MutableStateFlow(0L)
    val lockoutSecondsLeft: StateFlow<Long> = _lockoutSecondsLeft.asStateFlow()

    init {
        refreshLockoutCountdown()
        loadInitialAccountState()
    }

    private fun activeUid(): String = Firebase.auth.currentUser?.uid ?: "preview_local_user"

    private fun extractFirebaseEmail(user: com.google.firebase.auth.FirebaseUser): String {
        val direct = user.email?.trim().orEmpty()
        if (direct.isNotBlank()) return direct
        return user.providerData
            .firstOrNull { !it.email.isNullOrBlank() }
            ?.email
            ?.trim()
            .orEmpty()
    }

    private fun hasVerifiedFirebaseEmail(user: com.google.firebase.auth.FirebaseUser): Boolean {
        return user.isEmailVerified || user.providerData.any { it.providerId == "google.com" }
    }

    private fun loadInitialAccountState() {
        viewModelScope.launch {
            val user = runCatching { Firebase.auth.currentUser }.getOrNull()
            if (user == null) {
                _existingCustomerAccount.value = null
                _isCheckingPortalAccess.value = false
                return@launch
            }
            _isCheckingPortalAccess.value = true
            try {
                resolveAuthenticatedFirebaseUser(user)
            } catch (_: Throwable) {
                // Keep safe UnverifiedPortal fallback on unexpected startup errors
            } finally {
                _isCheckingPortalAccess.value = false
            }
        }
    }

    private suspend fun resolveAuthenticatedFirebaseUser(user: com.google.firebase.auth.FirebaseUser) {
        runCatching {
            withTimeoutOrNull(3_500L) {
                user.reload().await()
            }
        }.onFailure { err ->
            if (err is FirebaseAuthInvalidUserException) {
                runCatching { Firebase.auth.signOut() }
                _existingCustomerAccount.value = null
                return
            }
        }

        val freshUser = runCatching { Firebase.auth.currentUser }.getOrNull() ?: user
        val userEmail = extractFirebaseEmail(freshUser)
        val isVerifiedEmailOrGoogle = hasVerifiedFirebaseEmail(freshUser)

        // 1. Verified Owner Super Admin session -> Direct Super Admin Dashboard
        if (SecurityUtils.isVerifiedOwnerEmail(userEmail, isVerifiedEmailOrGoogle)) {
            _existingCustomerAccount.value = null
            _pendingStaffVerification.value = null
            _statusMessage.value = null
            _session.value = ActivePortalSession.AdminSession(
                adminUid = freshUser.uid,
                email = SecurityUtils.OWNER_EMAIL
            )
            return
        }

        // Do not auto-unlock unverified Firebase owner user on startup
        if (userEmail.equals(SecurityUtils.OWNER_EMAIL, ignoreCase = true) && !isVerifiedEmailOrGoogle) {
            return
        }

        var acct = withTimeoutOrNull(4_000L) {
            accountRepo.getMyAccount(freshUser.uid).getOrNull()
        }
        if (acct != null && acct.isBanned) {
            runCatching { Firebase.auth.signOut() }
            _existingCustomerAccount.value = null
            _statusMessage.value = "Account permanently suspended for policy violation."
            return
        }

        val hasVerifiedSession = isVerifiedEmailOrGoogle ||
            !freshUser.phoneNumber.isNullOrBlank() ||
            !acct?.phone.isNullOrBlank() ||
            acct != null

        if (!hasVerifiedSession) {
            _existingCustomerAccount.value = acct
            return
        }

        // 2. Active Staff Listener still verifies PIN for security
        if (userEmail.isNotBlank()) {
            val staffEntry = withTimeoutOrNull(3_000L) {
                feedRepo.findActiveStaffByEmail(userEmail)
            } ?: rateLimiter.findPreviewStaffByEmail(userEmail)
            if (staffEntry != null && staffEntry.isActive) {
                _existingCustomerAccount.value = acct
                _pendingStaffVerification.value = staffEntry
                return
            }
        }

        // 3. Regular user with active Firebase session -> straight to Home Screen
        if (acct == null) {
            val visibleEmail = userEmail.takeIf { it.isNotBlank() && !SecurityUtils.isPhoneLoginAliasEmail(it) }
            val fallbackName = SecurityUtils.resolveDisplayName(
                primary = freshUser.displayName,
                secondary = if (visibleEmail != null && visibleEmail.contains("@")) {
                    SecurityUtils.deriveDisplayNameFromEmail(visibleEmail)
                } else {
                    freshUser.phoneNumber?.takeLast(4)?.let { "Dil Suno Member $it" }
                },
                fallback = "Dil Suno Member"
            )
            acct = withTimeoutOrNull(3_000L) {
                accountRepo.createOrUpdateUserOnSignUp(
                    fullName = fallbackName,
                    email = visibleEmail,
                    phone = freshUser.phoneNumber,
                    termsAccepted = true
                ).getOrNull()
            } ?: UserAccount(
                userId = freshUser.uid,
                fullName = fallbackName,
                email = visibleEmail,
                phone = freshUser.phoneNumber,
                termsAccepted = true
            )
        }

        runCatching {
            withTimeoutOrNull(2_500L) {
                accountRepo.ensurePublicProfileSynced(acct)
            }
        }
        _existingCustomerAccount.value = acct
        _statusMessage.value = null
        _session.value = ActivePortalSession.UserSession(acct)
    }

    fun setLanguage(lang: AppLang) {
        viewModelScope.launch { rateLimiter.setLanguage(lang) }
    }

    fun clearMessage() {
        _statusMessage.value = null
    }

    fun reportAuthStatusMessage(message: String) {
        _statusMessage.value = message
    }

    fun handleGoogleSignInSuccess() {
        viewModelScope.launch {
            _statusMessage.value = null
            _isBusy.value = true
            try {
                val user = runCatching { Firebase.auth.currentUser }.getOrNull()
                if (user == null) {
                    _statusMessage.value = "Google Sign-In session could not be restored. Please try again."
                    return@launch
                }
                resolveAuthenticatedFirebaseUser(user)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _statusMessage.value = e.localizedMessage ?: "Google Sign-In failed. Please try again."
            } finally {
                _isBusy.value = false
            }
        }
    }

    private fun isProviderFallbackError(err: Throwable): Boolean {
        if (err is FirebaseNetworkException) return true
        val code = (err as? FirebaseAuthException)?.errorCode.orEmpty()
        val msg = err.localizedMessage.orEmpty()
        return code in setOf(
            "ERROR_OPERATION_NOT_ALLOWED",
            "CONFIGURATION_NOT_FOUND",
            "ERROR_API_NOT_AVAILABLE",
            "ERROR_APP_NOT_AUTHORIZED",
            "ERROR_INVALID_API_KEY",
            "INVALID_API_KEY",
            "MISSING_CLIENT_IDENTIFIER",
            "ERROR_MISSING_CLIENT_IDENTIFIER",
            "ERROR_QUOTA_EXCEEDED"
        ) || msg.contains("reCAPTCHA", ignoreCase = true) ||
            msg.contains("Play Integrity", ignoreCase = true) ||
            msg.contains("API key", ignoreCase = true) ||
            msg.contains("internal error", ignoreCase = true) ||
            msg.contains("not authorized to use Firebase Authentication", ignoreCase = true)
    }

    // =====================================================================
    // SIGN UP (Dynamic Single-Channel Flow: Strictly Email OTP OR SMS OTP)
    // =====================================================================
    fun beginSignUpWithChannel(
        channel: SignUpChannel,
        emailRaw: String,
        tenDigitPhoneRaw: String,
        password: String,
        activity: Activity?,
        fullNameRaw: String = ""
    ) {
        viewModelScope.launch {
            if (!checkNotLocked()) return@launch
            val cleanName = SecurityUtils.sanitizeInput(fullNameRaw, 100)
            if (cleanName.isNotBlank() && cleanName.length < 2) {
                _statusMessage.value = "कृपया सही नाम दर्ज करें / Please enter your full name."
                return@launch
            }
            if (!SecurityUtils.isAcceptablePassword(password)) {
                _statusMessage.value = "पासवर्ड कम से कम 6 अक्षरों का होना चाहिए / Password must be at least 6 characters."
                return@launch
            }
            pendingSignUpFullName = cleanName.ifBlank { null }

            when (channel) {
                SignUpChannel.EMAIL -> {
                    val cleanEmail = SecurityUtils.normalizeEmail(SecurityUtils.sanitizeInput(emailRaw, 150))
                    if (!SecurityUtils.isValidEmail(cleanEmail)) {
                        _statusMessage.value = "कृपया सही ईमेल आईडी दर्ज करें / Please enter a valid Email ID."
                        return@launch
                    }
                    if (Firebase.auth.currentUser != null) {
                        runCatching { Firebase.auth.signOut() }
                    }
                    _pendingSignUpChannel.value = SignUpChannel.EMAIL
                    _pendingSignUpEmail.value = cleanEmail
                    _pendingSignUpPhone.value = null
                    pendingSignUpPassword = password
                    phoneVerificationId = null
                    createdPendingEmailAuthUser = false
                    _statusMessage.value = null

                    startSignUpEmailVerificationInternal(cleanEmail, password)
                }

                SignUpChannel.PHONE -> {
                    val e164Phone = SecurityUtils.normalizeIndianPhoneE164(tenDigitPhoneRaw)
                    if (e164Phone == null) {
                        _statusMessage.value = "कृपया सही 10-अंकों का मोबाइल नंबर दर्ज करें / Please enter a valid 10-digit Mobile No."
                        return@launch
                    }
                    if (Firebase.auth.currentUser != null) {
                        runCatching { Firebase.auth.signOut() }
                    }
                    _pendingSignUpChannel.value = SignUpChannel.PHONE
                    _pendingSignUpEmail.value = null
                    _pendingSignUpPhone.value = e164Phone
                    pendingSignUpPassword = password
                    phoneVerificationId = null
                    createdPendingEmailAuthUser = false
                    _statusMessage.value = null

                    startSignUpPhoneVerificationInternal(e164Phone, password, activity)
                }
            }
        }
    }

    private suspend fun startSignUpEmailVerificationInternal(
        cleanEmail: String,
        password: String
    ) {
        _isBusy.value = true
        try {
            if (rateLimiter.findPreviewUserByEmail(cleanEmail) != null) {
                _statusMessage.value = "यह ईमेल ($cleanEmail) पहले से पंजीकृत है। कृपया 'Sign In' करें। / An account with $cleanEmail already exists. Please Sign In."
                return
            }
            createdPendingEmailAuthUser = false
            _isRealEmailVerificationSent.value = false
            _isSignUpInlineOtpOpen.value = true
            _statusMessage.value = "Email OTP (${SecurityUtils.PREVIEW_TEST_MODE_OTP}) ready for $cleanEmail."
        } finally {
            _isBusy.value = false
        }
    }

    private fun startSignUpPhoneVerificationInternal(
        e164Phone: String,
        password: String,
        activity: Activity?
    ) {
        if (activity == null) {
            _isRealPhoneAuthActive.value = false
            _isSignUpInlineOtpOpen.value = true
            _isBusy.value = false
            _statusMessage.value = "$e164Phone पर टेस्ट मोड SMS OTP तैयार है / Test Mode SMS OTP ready for $e164Phone."
            return
        }

        _isBusy.value = true
        var callbackHandled = false
        // Watchdog ensures _isBusy never hangs if PhoneAuth callback doesn't fire within 8s
        val watchdogJob = viewModelScope.launch {
            delay(SIGN_IN_TIMEOUT_MS)
            if (!callbackHandled && _isBusy.value) {
                callbackHandled = true
                _isRealPhoneAuthActive.value = false
                _isSignUpInlineOtpOpen.value = true
                _isBusy.value = false
                _statusMessage.value = "Test Mode SMS OTP (${SecurityUtils.PREVIEW_TEST_MODE_OTP}) active for $e164Phone."
            }
        }
        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                callbackHandled = true
                watchdogJob.cancel()
                viewModelScope.launch {
                    finalizePhoneSignUp(
                        e164Phone = e164Phone,
                        password = password,
                        phoneCredential = credential
                    )
                }
            }

            override fun onVerificationFailed(e: FirebaseException) {
                if (callbackHandled) return
                callbackHandled = true
                watchdogJob.cancel()
                if (isProviderFallbackError(e)) {
                    _isRealPhoneAuthActive.value = false
                    _isSignUpInlineOtpOpen.value = true
                    _isBusy.value = false
                    _statusMessage.value = "Test Mode SMS OTP (${SecurityUtils.PREVIEW_TEST_MODE_OTP}) active for $e164Phone."
                } else {
                    _isBusy.value = false
                    _statusMessage.value = e.localizedMessage ?: "SMS OTP भेजने में समस्या आई / Could not send SMS OTP. Try again."
                }
            }

            override fun onCodeSent(
                verificationId: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                if (callbackHandled) return
                callbackHandled = true
                watchdogJob.cancel()
                phoneVerificationId = verificationId
                phoneResendToken = token
                _isRealPhoneAuthActive.value = true
                _isSignUpInlineOtpOpen.value = true
                _isBusy.value = false
                _statusMessage.value = "$e164Phone पर 6-अंकों का SMS OTP भेजा गया है / 6-digit SMS OTP sent to $e164Phone."
            }
        }

        try {
            val builder = PhoneAuthOptions.newBuilder(Firebase.auth)
                .setPhoneNumber(e164Phone)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(activity)
                .setCallbacks(callbacks)
            phoneResendToken?.let { builder.setForceResendingToken(it) }
            PhoneAuthProvider.verifyPhoneNumber(builder.build())
        } catch (e: Throwable) {
            callbackHandled = true
            watchdogJob.cancel()
            if (isProviderFallbackError(e)) {
                _isRealPhoneAuthActive.value = false
                _isSignUpInlineOtpOpen.value = true
                _isBusy.value = false
                _statusMessage.value = "Test Mode SMS OTP (${SecurityUtils.PREVIEW_TEST_MODE_OTP}) active for $e164Phone."
            } else {
                _isBusy.value = false
                _statusMessage.value = e.localizedMessage ?: "Could not start phone OTP verification."
            }
        }
    }

    fun resendSignUpInlineOtp(activity: Activity?) {
        val pass = pendingSignUpPassword ?: return
        viewModelScope.launch {
            if (!checkNotLocked()) return@launch
            when (_pendingSignUpChannel.value) {
                SignUpChannel.EMAIL -> {
                    val email = _pendingSignUpEmail.value ?: return@launch
                    val currentUser = runCatching { Firebase.auth.currentUser }.getOrNull()
                    if (currentUser != null && currentUser.email.equals(email, ignoreCase = true)) {
                        _isBusy.value = true
                        try {
                            val sent = runCatching {
                                withTimeoutOrNull(SIGN_IN_TIMEOUT_MS) {
                                    currentUser.sendEmailVerification().await()
                                    true
                                } ?: false
                            }.getOrDefault(false)
                            _statusMessage.value = if (sent) {
                                "$email पर ईमेल सत्यापन OTP/लिंक फिर से भेजा गया / Verification email resent to $email."
                            } else {
                                "Email OTP (${SecurityUtils.PREVIEW_TEST_MODE_OTP}) ready for $email."
                            }
                        } finally {
                            _isBusy.value = false
                        }
                    } else {
                        startSignUpEmailVerificationInternal(email, pass)
                    }
                }

                SignUpChannel.PHONE -> {
                    val phone = _pendingSignUpPhone.value ?: return@launch
                    startSignUpPhoneVerificationInternal(phone, pass, activity)
                }
            }
        }
    }

    fun cancelSignUpInlineOtp() {
        val shouldCleanUncommittedUser = createdPendingEmailAuthUser
        createdPendingEmailAuthUser = false
        _isSignUpInlineOtpOpen.value = false
        _pendingSignUpEmail.value = null
        _pendingSignUpPhone.value = null
        _isRealEmailVerificationSent.value = false
        pendingSignUpPassword = null
        phoneVerificationId = null
        _statusMessage.value = null

        if (shouldCleanUncommittedUser) {
            viewModelScope.launch {
                val pendingUser = Firebase.auth.currentUser
                if (pendingUser != null && !pendingUser.isEmailVerified) {
                    runCatching { pendingUser.delete().await() }
                }
                runCatching { Firebase.auth.signOut() }
            }
        }
    }

    fun verifySignUpInlineOtp(otpRaw: String) {
        viewModelScope.launch {
            if (!checkNotLocked()) return@launch
            val pendingPass = pendingSignUpPassword
            if (pendingPass.isNullOrBlank()) {
                _isSignUpInlineOtpOpen.value = false
                _statusMessage.value = "Session expired. Please fill your details again."
                return@launch
            }

            val cleanOtp = otpRaw.filter { it.isDigit() }

            when (_pendingSignUpChannel.value) {
                SignUpChannel.EMAIL -> {
                    val pendingEmail = _pendingSignUpEmail.value
                    if (pendingEmail.isNullOrBlank()) {
                        _isSignUpInlineOtpOpen.value = false
                        _statusMessage.value = "Session expired. Please enter your Email ID again."
                        return@launch
                    }

                    // If user already tapped the real Firebase verification link in their email inbox, allow direct completion
                    val existingUser = Firebase.auth.currentUser
                    if (existingUser != null && existingUser.email.equals(pendingEmail, ignoreCase = true)) {
                        runCatching { existingUser.reload().await() }
                        if (Firebase.auth.currentUser?.isEmailVerified == true) {
                            finalizeEmailSignUp(cleanEmail = pendingEmail, password = pendingPass)
                            return@launch
                        }
                    }

                    if (cleanOtp.length != 6) {
                        _statusMessage.value = "कृपया 6-अंकों का ईमेल OTP दर्ज करें / Please enter the 6-digit Email OTP."
                        return@launch
                    }
                    if (cleanOtp != SecurityUtils.PREVIEW_TEST_MODE_OTP) {
                        recordFailureAndNotify("गलत ईमेल OTP कोड / Invalid 6-digit Email OTP. Enter ${SecurityUtils.PREVIEW_TEST_MODE_OTP} or verify via your email link.")
                        return@launch
                    }
                    finalizeEmailSignUp(cleanEmail = pendingEmail, password = pendingPass)
                }

                SignUpChannel.PHONE -> {
                    val pendingPhone = _pendingSignUpPhone.value
                    if (pendingPhone.isNullOrBlank()) {
                        _isSignUpInlineOtpOpen.value = false
                        _statusMessage.value = "Session expired. Please enter your Mobile No. again."
                        return@launch
                    }
                    if (cleanOtp.length != 6) {
                        _statusMessage.value = "कृपया 6-अंकों का SMS OTP दर्ज करें / Please enter the 6-digit SMS OTP."
                        return@launch
                    }

                    if (_isRealPhoneAuthActive.value) {
                        val vid = phoneVerificationId
                        if (vid.isNullOrBlank()) {
                            _statusMessage.value = "Verification ID missing. Tap Resend OTP."
                            return@launch
                        }
                        val phoneCred = PhoneAuthProvider.getCredential(vid, cleanOtp)
                        finalizePhoneSignUp(
                            e164Phone = pendingPhone,
                            password = pendingPass,
                            phoneCredential = phoneCred
                        )
                    } else {
                        if (cleanOtp != SecurityUtils.PREVIEW_TEST_MODE_OTP) {
                            recordFailureAndNotify("गलत SMS OTP कोड / Invalid 6-digit SMS OTP. Enter Test Mode OTP: ${SecurityUtils.PREVIEW_TEST_MODE_OTP}.")
                            return@launch
                        }
                        finalizePhoneSignUp(
                            e164Phone = pendingPhone,
                            password = pendingPass,
                            phoneCredential = null
                        )
                    }
                }
            }
        }
    }

    private suspend fun finalizeEmailSignUp(
        cleanEmail: String,
        password: String
    ) {
        _isBusy.value = true
        try {
            withTimeout(SIGN_IN_TIMEOUT_MS) {
                val salt = SecurityUtils.generateSalt()
                val hash = SecurityUtils.hashPassword(password, salt)
                val fallbackName = pendingSignUpFullName?.takeIf { it.length >= 2 }
                    ?: SecurityUtils.deriveDisplayNameFromEmail(cleanEmail)
                var usedOfflineFallback = true
                val currentUser = runCatching { Firebase.auth.currentUser }.getOrNull()
                    ?.takeIf { it.email.equals(cleanEmail, ignoreCase = true) }
                if (currentUser != null) {
                    usedOfflineFallback = false
                } else if (rateLimiter.findPreviewUserByEmail(cleanEmail) != null) {
                    _statusMessage.value = "यह ईमेल ($cleanEmail) पहले से पंजीकृत है। कृपया 'Sign In' करें। / An account with $cleanEmail already exists. Please Sign In."
                    return@withTimeout
                }

                rateLimiter.clearFailedAttempts()
                createdPendingEmailAuthUser = false
                val isOwnerAccount = SecurityUtils.isOwnerEmail(cleanEmail)
                val resolvedUid = currentUser?.uid ?: if (isOwnerAccount) {
                    "owner_${SecurityUtils.sha256Hex(cleanEmail).take(16)}"
                } else {
                    "user_${SecurityUtils.sha256Hex(cleanEmail).take(16)}"
                }

                rateLimiter.savePreviewUserCredential(
                    PreviewUserCredential(
                        email = cleanEmail,
                        passwordHash = hash,
                        passwordSalt = salt,
                        fullName = pendingSignUpFullName ?: currentUser?.displayName?.takeIf { it.isNotBlank() && !it.contains("@") } ?: fallbackName,
                        uid = resolvedUid,
                        phone = null
                    )
                )

                if (isOwnerAccount) {
                    pendingSignUpFullName = null
                    clearSignUpPendingState()
                    _pendingStaffVerification.value = null
                    _statusMessage.value = null
                    _session.value = ActivePortalSession.AdminSession(
                        adminUid = resolvedUid,
                        email = SecurityUtils.OWNER_EMAIL
                    )
                    return@withTimeout
                }

                if (currentUser != null && !usedOfflineFallback) {
                    runCatching { withTimeoutOrNull(1_500L) { currentUser.reload().await() } }
                    val freshUser = runCatching { Firebase.auth.currentUser }.getOrNull() ?: currentUser

                    val existing = withTimeoutOrNull(2_000L) { accountRepo.getMyAccount(freshUser.uid).getOrNull() }
                    if (existing != null && existing.isBanned) {
                        runCatching { Firebase.auth.signOut() }
                        _statusMessage.value = "This account is permanently banned."
                        return@withTimeout
                    }
                    val resolvedName = SecurityUtils.resolveDisplayName(pendingSignUpFullName ?: existing?.fullName, freshUser.displayName, fallbackName)
                    val acctResult = withTimeoutOrNull(2_000L) {
                        accountRepo.createOrUpdateUserOnSignUp(
                            fullName = resolvedName,
                            email = cleanEmail,
                            phone = null,
                            passwordHash = hash,
                            passwordSalt = salt,
                            termsAccepted = true
                        )
                    }
                    val sessionToken = withTimeoutOrNull(1_500L) { issueSingleDeviceSessionForUser(freshUser.uid) }
                        ?: java.util.UUID.randomUUID().toString().also { rateLimiter.setActiveSessionToken(it) }
                    val acct = (acctResult?.getOrNull() ?: UserAccount(
                        userId = freshUser.uid,
                        fullName = resolvedName,
                        email = cleanEmail,
                        phone = null,
                        passwordHash = hash,
                        passwordSalt = salt,
                        termsAccepted = true
                    )).copy(activeSessionToken = sessionToken)
                    runCatching { withTimeoutOrNull(1_500L) { accountRepo.ensurePublicProfileSynced(acct) } }
                    _existingCustomerAccount.value = acct
                    pendingSignUpFullName = null
                    clearSignUpPendingState()

                    val staffEntry = withTimeoutOrNull(1_500L) { feedRepo.findActiveStaffByEmail(cleanEmail) }
                        ?: rateLimiter.findPreviewStaffByEmail(cleanEmail)
                    if (staffEntry != null && staffEntry.isActive) {
                        _pendingStaffVerification.value = staffEntry
                    } else {
                        _session.value = ActivePortalSession.UserSession(acct)
                    }
                } else {
                    pendingSignUpFullName = null
                    clearSignUpPendingState()
                    val previewStaff = rateLimiter.findPreviewStaffByEmail(cleanEmail)
                    if (previewStaff != null && previewStaff.isActive) {
                        _pendingStaffVerification.value = previewStaff
                    } else {
                        val token = java.util.UUID.randomUUID().toString()
                        rateLimiter.setActiveSessionToken(token)
                        val acct = UserAccount(
                            userId = resolvedUid,
                            fullName = fallbackName,
                            email = cleanEmail,
                            phone = null,
                            passwordHash = hash,
                            passwordSalt = salt,
                            termsAccepted = true,
                            activeSessionToken = token
                        )
                        _existingCustomerAccount.value = acct
                        _session.value = ActivePortalSession.UserSession(acct)
                    }
                }
            }
        } catch (_: TimeoutCancellationException) {
            _statusMessage.value = "साइन-अप अनुरोध का समय समाप्त हो गया (8 सेकंड)। कृपया फिर प्रयास करें। / Sign Up timed out (8s). Please try again."
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            _statusMessage.value = e.localizedMessage ?: "Email Sign Up failed. Please try again."
        } finally {
            _isBusy.value = false
        }
    }

    private suspend fun finalizePhoneSignUp(
        e164Phone: String,
        password: String,
        phoneCredential: PhoneAuthCredential?
    ) {
        _isBusy.value = true
        try {
            withTimeout(SIGN_IN_TIMEOUT_MS) {
                val salt = SecurityUtils.generateSalt()
                val hash = SecurityUtils.hashPassword(password, salt)
                val fallbackName = pendingSignUpFullName?.takeIf { it.length >= 2 }
                    ?: "Dil Suno Member ${e164Phone.takeLast(4)}"
                val internalAliasEmail = SecurityUtils.phoneLoginAliasEmail(e164Phone)
                var usedOfflineFallback = false

                if (phoneCredential != null) {
                    try {
                        // 1. Verify 6-digit SMS OTP strictly via Firebase Phone Auth
                        val phoneResult = Firebase.auth.signInWithCredential(phoneCredential).await()
                        val phoneUser = phoneResult.user
                        if (phoneUser == null) {
                            recordFailureAndNotify("SMS OTP सत्यापन असफल रहा / SMS OTP verification failed.")
                            return@withTimeout
                        }
                        // 2. Best-effort link password credential under internal phone alias so Phone+Password Sign In works later
                        val aliasCred = EmailAuthProvider.getCredential(internalAliasEmail, password)
                        runCatching { withTimeoutOrNull(1_500L) { phoneUser.linkWithCredential(aliasCred).await() } }
                    } catch (_: FirebaseAuthInvalidCredentialsException) {
                        recordFailureAndNotify("गलत 6-अंकों का SMS OTP / Incorrect 6-digit SMS OTP code.")
                        return@withTimeout
                    } catch (e: Exception) {
                        if (isProviderFallbackError(e)) {
                            usedOfflineFallback = true
                        } else {
                            recordFailureAndNotify(e.localizedMessage ?: "SMS OTP verification failed.")
                            return@withTimeout
                        }
                    }
                } else {
                    // Preview / Emulator Test Mode SMS OTP (123456)
                    if (rateLimiter.findPreviewUserByPhone(e164Phone) != null ||
                        rateLimiter.findPreviewUserByEmail(internalAliasEmail) != null
                    ) {
                        _statusMessage.value = "यह मोबाइल नंबर ($e164Phone) पहले से पंजीकृत है। कृपया 'Sign In' करें। / This mobile number is already registered. Please Sign In."
                        return@withTimeout
                    }
                    usedOfflineFallback = true
                }

                rateLimiter.clearFailedAttempts()
                val currentUser = runCatching { Firebase.auth.currentUser }.getOrNull()
                val resolvedUid = currentUser?.uid ?: "user_${e164Phone.filter { it.isDigit() }}"

                // Cache mobile mapping locally for resilient Phone + Password Sign In
                rateLimiter.savePreviewUserCredential(
                    PreviewUserCredential(
                        email = internalAliasEmail,
                        passwordHash = hash,
                        passwordSalt = salt,
                        fullName = currentUser?.displayName?.takeIf { it.isNotBlank() && !it.contains("@") } ?: fallbackName,
                        uid = resolvedUid,
                        phone = e164Phone
                    )
                )

                if (currentUser != null && !usedOfflineFallback) {
                    val existing = withTimeoutOrNull(2_000L) { accountRepo.getMyAccount(currentUser.uid).getOrNull() }
                    if (existing != null && existing.isBanned) {
                        runCatching { Firebase.auth.signOut() }
                        _statusMessage.value = "This account is permanently banned."
                        return@withTimeout
                    }
                    val resolvedName = SecurityUtils.resolveDisplayName(existing?.fullName, currentUser.displayName, fallbackName)
                    val acctResult = withTimeoutOrNull(2_000L) {
                        accountRepo.createOrUpdateUserOnSignUp(
                            fullName = resolvedName,
                            email = null,
                            phone = e164Phone,
                            passwordHash = hash,
                            passwordSalt = salt,
                            termsAccepted = true
                        )
                    }
                    runCatching {
                        withTimeoutOrNull(1_500L) {
                            accountRepo.upsertPhoneLoginLookup(
                                uid = currentUser.uid,
                                email = internalAliasEmail,
                                rawPhone = e164Phone
                            )
                        }
                    }
                    val sessionToken = withTimeoutOrNull(1_500L) { issueSingleDeviceSessionForUser(currentUser.uid) }
                        ?: java.util.UUID.randomUUID().toString().also { rateLimiter.setActiveSessionToken(it) }
                    val acct = (acctResult?.getOrNull() ?: UserAccount(
                        userId = currentUser.uid,
                        fullName = resolvedName,
                        email = null,
                        phone = e164Phone,
                        passwordHash = hash,
                        passwordSalt = salt,
                        termsAccepted = true
                    )).copy(activeSessionToken = sessionToken)
                    runCatching { withTimeoutOrNull(1_500L) { accountRepo.ensurePublicProfileSynced(acct) } }
                    _existingCustomerAccount.value = acct
                    pendingSignUpFullName = null
                    clearSignUpPendingState()
                    _session.value = ActivePortalSession.UserSession(acct)
                } else {
                    pendingSignUpFullName = null
                    clearSignUpPendingState()
                    val token = java.util.UUID.randomUUID().toString()
                    rateLimiter.setActiveSessionToken(token)
                    val acct = UserAccount(
                        userId = resolvedUid,
                        fullName = fallbackName,
                        email = null,
                        phone = e164Phone,
                        passwordHash = hash,
                        passwordSalt = salt,
                        termsAccepted = true,
                        activeSessionToken = token
                    )
                    _existingCustomerAccount.value = acct
                    _session.value = ActivePortalSession.UserSession(acct)
                }
            }
        } catch (_: TimeoutCancellationException) {
            _statusMessage.value = "OTP सत्यापन का समय समाप्त हो गया (8 सेकंड)। कृपया फिर प्रयास करें। / OTP verification timed out (8s). Please try again."
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            _statusMessage.value = e.localizedMessage ?: "Phone Sign Up failed. Please try again."
        } finally {
            _isBusy.value = false
        }
    }

    private fun clearSignUpPendingState() {
        createdPendingEmailAuthUser = false
        _isSignUpInlineOtpOpen.value = false
        _pendingSignUpEmail.value = null
        _pendingSignUpPhone.value = null
        _isRealEmailVerificationSent.value = false
        pendingSignUpPassword = null
        phoneVerificationId = null
        _statusMessage.value = null
    }

    // =====================================================================
    // SIGN IN (Mobile No. OR Email ID + Password — 8s Timeout + try-catch-finally)
    // =====================================================================
    fun signInWithEmailOrPhoneAndPassword(identifierRaw: String, password: String) {
        viewModelScope.launch {
            if (!checkNotLocked()) return@launch
            val trimmed = SecurityUtils.sanitizeInput(identifierRaw, 150)
            if (trimmed.isBlank()) {
                _statusMessage.value = "कृपया मोबाइल नंबर या ईमेल आईडी दर्ज करें / Enter Mobile No. or Email ID."
                return@launch
            }

            if (password.isBlank()) {
                _statusMessage.value = "कृपया पासवर्ड दर्ज करें / Please enter your Password."
                return@launch
            }

            val looksLikePhone = !trimmed.contains("@") && trimmed.none { it.isLetter() }
            val matchedPhoneE164 = if (looksLikePhone) SecurityUtils.normalizeIndianPhoneE164(trimmed) else null

            if (looksLikePhone && matchedPhoneE164 == null) {
                _statusMessage.value = "कृपया सही 10-अंकों का मोबाइल नंबर दर्ज करें / Please enter a valid 10-digit Mobile No."
                return@launch
            }

            _isBusy.value = true
            var resolvedCleanEmailForFallback = SecurityUtils.normalizeEmail(trimmed)
            try {
                withTimeout(SIGN_IN_TIMEOUT_MS) {

                    val resolvedEmail: String? = if (SecurityUtils.isOwnerIdentifier(trimmed)) {
                        SecurityUtils.OWNER_EMAIL
                    } else if (matchedPhoneE164 != null) {
                        withTimeoutOrNull(2_500L) { accountRepo.lookupEmailByPhone(matchedPhoneE164) }
                            ?: rateLimiter.findPreviewUserByPhone(matchedPhoneE164)?.email
                            ?: SecurityUtils.phoneLoginAliasEmail(matchedPhoneE164)
                    } else {
                        SecurityUtils.normalizeEmail(trimmed)
                    }

                    if (resolvedEmail.isNullOrBlank() || !SecurityUtils.isValidEmail(resolvedEmail)) {
                        _statusMessage.value = if (matchedPhoneE164 != null) {
                            "$matchedPhoneE164 से जुड़ा कोई खाता नहीं मिला। कृपया पहले 'नया खाता बनाएं • Sign Up' करें। / No account linked to $matchedPhoneE164."
                        } else {
                            "कृपया सही ईमेल आईडी दर्ज करें / Please enter a valid Email ID."
                        }
                        return@withTimeout
                    }

                    val cleanEmail = SecurityUtils.normalizeEmail(resolvedEmail)
                    resolvedCleanEmailForFallback = cleanEmail

                    // Dedicated Google Play Console Reviewer Demo Account (Pre-funded ₹500 test credits)
                    if (SecurityUtils.isReviewerDemoEmail(cleanEmail)) {
                        val localDemoEnabled = rateLimiter.isReviewerDemoEnabled()
                        if (!localDemoEnabled) {
                            _statusMessage.value = "Demo access is currently disabled by Admin."
                            return@withTimeout
                        }
                        if (SecurityUtils.verifyReviewerDemoCredentials(cleanEmail, password)) {
                            rateLimiter.clearFailedAttempts()
                            val firebaseUser = runCatching { Firebase.auth.currentUser }.getOrNull()
                            val resolvedUid = if (firebaseUser != null && firebaseUser.email.equals(cleanEmail, ignoreCase = true)) {
                                firebaseUser.uid
                            } else {
                                SecurityUtils.REVIEWER_DEMO_UID
                            }
                            if (firebaseUser != null) {
                                val remoteCfg = runCatching {
                                    withTimeoutOrNull(1_500L) { feedRepo.observeAppConfig().first() }
                                }.getOrNull()
                                if (remoteCfg?.reviewerDemoEnabled == false) {
                                    runCatching { Firebase.auth.signOut() }
                                    _statusMessage.value = "Demo access is currently disabled by Admin."
                                    return@withTimeout
                                }
                            }
                            val token = java.util.UUID.randomUUID().toString()
                            rateLimiter.setActiveSessionToken(token)
                            val existingLocalBal = rateLimiter.observeLocalWalletBalance(resolvedUid).first()
                            val reviewerBalance = maxOf(
                                existingLocalBal ?: 0L,
                                SecurityUtils.REVIEWER_INITIAL_CREDITS_INR
                            )
                            rateLimiter.setLocalWalletBalance(resolvedUid, reviewerBalance)
                            val reviewerAcct = UserAccount(
                                userId = resolvedUid,
                                fullName = "Google Play Reviewer",
                                email = SecurityUtils.REVIEWER_DEMO_EMAIL,
                                termsAccepted = true,
                                communityGuidelinesAccepted = false,
                                walletBalance = reviewerBalance,
                                activeSessionToken = token
                            )
                            if (firebaseUser != null && firebaseUser.email.equals(cleanEmail, ignoreCase = true)) {
                                runCatching {
                                    withTimeoutOrNull(2_000L) {
                                        accountRepo.createOrUpdateUserOnSignUp(
                                            fullName = reviewerAcct.fullName,
                                            email = reviewerAcct.email,
                                            phone = null,
                                            termsAccepted = true
                                        )
                                        accountRepo.ensurePublicProfileSynced(reviewerAcct)
                                    }
                                }
                            }
                            _existingCustomerAccount.value = reviewerAcct
                            _statusMessage.value = null
                            _session.value = ActivePortalSession.UserSession(reviewerAcct)
                            return@withTimeout
                        } else {
                            recordFailureAndNotify("Invalid password for Demo Reviewer account.")
                            return@withTimeout
                        }
                    }

                    val existingFirebaseUser = runCatching { Firebase.auth.currentUser }.getOrNull()
                    if (existingFirebaseUser == null || !extractFirebaseEmail(existingFirebaseUser).equals(cleanEmail, ignoreCase = true)) {
                        handleOfflinePreviewSignIn(cleanEmail, password, matchedPhoneE164)
                        return@withTimeout
                    }
                    val previewMatch = rateLimiter.findPreviewUserByEmail(cleanEmail)
                    if (previewMatch != null && !SecurityUtils.verifyPassword(password, previewMatch.passwordSalt, previewMatch.passwordHash)) {
                        recordFailureAndNotify("गलत पासवर्ड / Incorrect Password.")
                        return@withTimeout
                    }
                    val freshUser = existingFirebaseUser
                    rateLimiter.clearFailedAttempts()
                    if (SecurityUtils.isVerifiedOwnerEmail(cleanEmail, hasVerifiedFirebaseEmail(freshUser))) {
                        _existingCustomerAccount.value = null
                        _pendingStaffVerification.value = null
                        _statusMessage.value = null
                        _session.value = ActivePortalSession.AdminSession(
                            adminUid = freshUser.uid,
                            email = SecurityUtils.OWNER_EMAIL
                        )
                        return@withTimeout
                    }

                    // 2. LOAD OR AUTO-PROVISION FIRESTORE PROFILE
                    var account = withTimeoutOrNull(2_500L) {
                        accountRepo.getMyAccount(freshUser.uid).getOrNull()
                    }
                    val isPhoneAlias = SecurityUtils.isPhoneLoginAliasEmail(cleanEmail)
                    val visibleEmail = if (isPhoneAlias) null else cleanEmail
                    val effectivePhone = matchedPhoneE164 ?: account?.phone ?: freshUser.phoneNumber
                    val salt = SecurityUtils.generateSalt()
                    val hash = SecurityUtils.hashPassword(password, salt)

                    if (account == null) {
                        val derivedName = freshUser.displayName?.takeIf { it.isNotBlank() && !it.contains("@") }
                            ?: visibleEmail?.let { SecurityUtils.deriveDisplayNameFromEmail(it) }
                            ?: effectivePhone?.takeLast(4)?.let { "Dil Suno Member $it" }
                            ?: "Dil Suno Member"
                        account = withTimeoutOrNull(2_500L) {
                            accountRepo.createOrUpdateUserOnSignUp(
                                fullName = derivedName,
                                email = visibleEmail,
                                phone = effectivePhone,
                                passwordHash = hash,
                                passwordSalt = salt,
                                termsAccepted = true
                            ).getOrNull()
                        } ?: UserAccount(
                            userId = freshUser.uid,
                            fullName = derivedName,
                            email = visibleEmail,
                            phone = effectivePhone,
                            passwordHash = hash,
                            passwordSalt = salt,
                            termsAccepted = true
                        )
                    }
                    if (!effectivePhone.isNullOrBlank()) {
                        runCatching {
                            withTimeoutOrNull(1_500L) {
                                accountRepo.upsertPhoneLoginLookup(freshUser.uid, cleanEmail, effectivePhone)
                            }
                        }
                    }

                    // Ensure local preview cache stays synced for both email and phone
                    rateLimiter.savePreviewUserCredential(
                        PreviewUserCredential(
                            email = cleanEmail,
                            passwordHash = hash,
                            passwordSalt = salt,
                            fullName = account.fullName.ifBlank {
                                visibleEmail?.let { SecurityUtils.deriveDisplayNameFromEmail(it) }
                                    ?: "Dil Suno Member"
                            },
                            uid = freshUser.uid,
                            phone = effectivePhone
                        )
                    )

                    if (account.isBanned) {
                        runCatching { Firebase.auth.signOut() }
                        _statusMessage.value = "This account is permanently banned due to safety violations."
                        return@withTimeout
                    }

                    // For non-owner accounts: allow entry if Email verified, Phone verified, or completed OTP registration profile exists
                    val hasVerifiedContact = freshUser.isEmailVerified ||
                        !freshUser.phoneNumber.isNullOrBlank() ||
                        !account.phone.isNullOrBlank() ||
                        account.userId.isNotBlank()
                    if (!hasVerifiedContact) {
                        runCatching { withTimeoutOrNull(1_500L) { freshUser.sendEmailVerification().await() } }
                        _statusMessage.value = "कृपया $cleanEmail पर भेजा गया सत्यापन लिंक खोलें। / Please verify your email link sent to $cleanEmail."
                        return@withTimeout
                    }

                    // 3. APPROVED STAFF LISTENER ROUTING -> Prompt 8-12 Digit Staff PIN
                    val staffEntry = withTimeoutOrNull(2_000L) {
                        feedRepo.findActiveStaffByEmail(cleanEmail)
                    } ?: rateLimiter.findPreviewStaffByEmail(cleanEmail)
                    if (staffEntry != null && staffEntry.isActive) {
                        _statusMessage.value = null
                        _pendingStaffVerification.value = staffEntry
                        return@withTimeout
                    }

                    // 4. REGULAR USER -> Customer Home Screen directly (Single-Device Session Lock enforced)
                    val sessionToken = withTimeoutOrNull(1_500L) {
                        issueSingleDeviceSessionForUser(freshUser.uid)
                    } ?: java.util.UUID.randomUUID().toString().also { rateLimiter.setActiveSessionToken(it) }
                    val syncedAccount = account.copy(activeSessionToken = sessionToken)
                    runCatching {
                        withTimeoutOrNull(1_500L) {
                            accountRepo.ensurePublicProfileSynced(syncedAccount)
                        }
                    }
                    _existingCustomerAccount.value = syncedAccount
                    _statusMessage.value = null
                    _session.value = ActivePortalSession.UserSession(syncedAccount)
                }
            } catch (_: TimeoutCancellationException) {
                _statusMessage.value = "लॉगिन अनुरोध का समय समाप्त हो गया (8 सेकंड)। कृपया नेटवर्क जांचें और फिर प्रयास करें। / Sign In timed out (8s). Please check your connection and try again."
            } catch (e: CancellationException) {
                throw e
            } catch (_: FirebaseAuthInvalidUserException) {
                recordFailureAndNotify("कोई खाता नहीं मिला। कृपया पहले 'नया खाता बनाएं • Sign Up' करें। / No account found.")
            } catch (_: FirebaseAuthInvalidCredentialsException) {
                recordFailureAndNotify("गलत मोबाइल नंबर, ईमेल या पासवर्ड / Incorrect credentials or password.")
            } catch (e: Throwable) {
                if (isProviderFallbackError(e)) {
                    runCatching {
                        withTimeout(3_000L) {
                            handleOfflinePreviewSignIn(resolvedCleanEmailForFallback, password, matchedPhoneE164)
                        }
                    }.onFailure {
                        recordFailureAndNotify(e.localizedMessage ?: "Sign in failed. Please try again.")
                    }
                } else {
                    recordFailureAndNotify(e.localizedMessage ?: "Sign in failed. Please try again.")
                }
            } finally {
                _isBusy.value = false
            }
        }
    }

    private suspend fun handleOfflinePreviewSignIn(
        cleanEmail: String,
        password: String,
        matchedPhoneE164: String?
    ) {
        val uid = activeUid()
        val isOwnerAccount = SecurityUtils.isOwnerEmail(cleanEmail) || SecurityUtils.isOwnerIdentifier(matchedPhoneE164)

        val previewStaff = rateLimiter.findPreviewStaffByEmail(cleanEmail)
        val previewUser = rateLimiter.findPreviewUserByEmail(cleanEmail)
            ?: matchedPhoneE164?.let { rateLimiter.findPreviewUserByPhone(it) }

        if (previewUser != null) {
            if (!SecurityUtils.verifyPassword(password, previewUser.passwordSalt, previewUser.passwordHash)) {
                _isBusy.value = false
                recordFailureAndNotify("गलत पासवर्ड / Incorrect Password.")
                return
            }
            rateLimiter.clearFailedAttempts()
            _statusMessage.value = null
            _isBusy.value = false
            if (isOwnerAccount) {
                _existingCustomerAccount.value = null
                _pendingStaffVerification.value = null
                _session.value = ActivePortalSession.AdminSession(
                    adminUid = previewUser.uid,
                    email = SecurityUtils.OWNER_EMAIL
                )
            } else if (previewStaff != null && previewStaff.isActive) {
                _pendingStaffVerification.value = previewStaff
            } else {
                val visibleEmail = previewUser.email.takeIf { !SecurityUtils.isPhoneLoginAliasEmail(it) }
                val acct = UserAccount(
                    userId = previewUser.uid,
                    fullName = previewUser.fullName,
                    email = visibleEmail,
                    phone = previewUser.phone ?: matchedPhoneE164,
                    termsAccepted = true
                )
                _existingCustomerAccount.value = acct
                _session.value = ActivePortalSession.UserSession(acct)
            }
            return
        }

        if (previewStaff != null && previewStaff.isActive && SecurityUtils.isAcceptablePassword(password)) {
            val salt = SecurityUtils.generateSalt()
            rateLimiter.savePreviewUserCredential(
                PreviewUserCredential(
                    email = cleanEmail,
                    passwordHash = SecurityUtils.hashPassword(password, salt),
                    passwordSalt = salt,
                    fullName = previewStaff.displayName,
                    uid = uid,
                    phone = matchedPhoneE164
                )
            )
            rateLimiter.clearFailedAttempts()
            _statusMessage.value = null
            _isBusy.value = false
            _pendingStaffVerification.value = previewStaff
            return
        }

        _isBusy.value = false
        _statusMessage.value = if (isOwnerAccount) {
            "anoopshakya0563@gmail.com का ईमेल पासवर्ड अभी सेट नहीं है। कृपया 'Forgot Password?' से पासवर्ड सेट करें, 'Create Account' करें, या 'Continue with Google' दबाएं। / No email password set yet for anoopshakya0563@gmail.com. Tap 'Forgot Password?' to set one, 'Create Account', or 'Continue with Google'."
        } else {
            "कोई खाता नहीं मिला। कृपया 'नया खाता बनाएं • Create Account' से खाता बनाएं। / Account not found locally."
        }
    }

    // =====================================================================
    // STAFF LISTENER PIN VERIFICATION (8–12 Digit Numeric PIN)
    // =====================================================================
    fun verifyPendingStaffPin(pinRaw: String) {
        viewModelScope.launch {
            if (!checkNotLocked()) return@launch
            val cleanPin = pinRaw.trim()
            if (!SecurityUtils.isValidStaffPin(cleanPin)) {
                _statusMessage.value = "Enter your numeric Staff PIN (8–12 digits / min 6 digits)."
                return@launch
            }
            val staffEntry = _pendingStaffVerification.value
            if (staffEntry == null) {
                _statusMessage.value = "Staff session expired. Please Sign In again."
                return@launch
            }

            _isBusy.value = true
            try {
                withTimeout(SIGN_IN_TIMEOUT_MS) {
                    val res = if (runCatching { Firebase.auth.currentUser }.getOrNull() != null) {
                        val remote = feedRepo.authenticateStaffByGmailAndPin(staffEntry.staffEmail, cleanPin)
                        if (remote.isSuccess) remote else rateLimiter.verifyPreviewStaffPin(staffEntry.staffEmail, cleanPin)
                    } else {
                        rateLimiter.verifyPreviewStaffPin(staffEntry.staffEmail, cleanPin)
                    }
                    res.onSuccess { staff ->
                        rateLimiter.clearFailedAttempts()
                        val staffToken = withTimeoutOrNull(2_000L) {
                            issueSingleDeviceSessionForStaff(staff.staffUsername)
                        } ?: java.util.UUID.randomUUID().toString().also { rateLimiter.setActiveSessionToken(it) }
                        _pendingStaffVerification.value = null
                        _statusMessage.value = null
                        _session.value = ActivePortalSession.StaffSession(staff.copy(activeSessionToken = staffToken))
                    }.onFailure { err ->
                        recordFailureAndNotify(err.localizedMessage ?: "Incorrect Staff PIN.")
                    }
                }
            } catch (_: TimeoutCancellationException) {
                _statusMessage.value = "Staff PIN verification timed out (8s). Please try again."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                recordFailureAndNotify(e.localizedMessage ?: "Incorrect Staff PIN.")
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun cancelStaffPinVerification() {
        _pendingStaffVerification.value = null
        _statusMessage.value = null
    }

    // =====================================================================
    // FORGOT PASSWORD (Supports Mobile No. OR Email ID + OTP / Reset Link)
    // =====================================================================
    fun sendForgotPasswordOtp(identifierRaw: String) {
        viewModelScope.launch {
            val trimmed = SecurityUtils.sanitizeInput(identifierRaw, 150)
            val looksLikePhone = !trimmed.contains("@") && trimmed.none { it.isLetter() }
            val matchedPhone = if (looksLikePhone) SecurityUtils.normalizeIndianPhoneE164(trimmed) else null

            _isBusy.value = true
            try {
                withTimeout(SIGN_IN_TIMEOUT_MS) {
                    val cleanEmail = if (SecurityUtils.isOwnerIdentifier(trimmed)) {
                        SecurityUtils.OWNER_EMAIL
                    } else if (matchedPhone != null) {
                        withTimeoutOrNull(2_500L) { accountRepo.lookupEmailByPhone(matchedPhone) }
                            ?: rateLimiter.findPreviewUserByPhone(matchedPhone)?.email
                            ?: ""
                    } else {
                        SecurityUtils.normalizeEmail(trimmed)
                    }

                    if (!SecurityUtils.isValidEmail(cleanEmail)) {
                        _statusMessage.value = if (looksLikePhone) {
                            "इस मोबाइल नंबर से कोई पंजीकृत खाता नहीं मिला। / No account found for that mobile number."
                        } else {
                            "Please enter a valid Email ID or 10-digit Mobile No."
                        }
                        return@withTimeout
                    }

                    _resetResolvedEmail.value = cleanEmail
                    _resetUsesPreviewOtp.value = true
                    _resetOtpSent.value = true
                    _statusMessage.value = if (SecurityUtils.isPhoneLoginAliasEmail(cleanEmail)) {
                        "Phone OTP (${SecurityUtils.PREVIEW_TEST_MODE_OTP}) ready for ${matchedPhone ?: trimmed}."
                    } else {
                        "Verification OTP (${SecurityUtils.PREVIEW_TEST_MODE_OTP}) ready for $cleanEmail."
                    }
                }
            } catch (_: TimeoutCancellationException) {
                _statusMessage.value = "Password reset timed out (8s). Please check your connection and try again."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _statusMessage.value = e.localizedMessage ?: "Could not send password reset email."
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun clearForgotPasswordState() {
        _resetOtpSent.value = false
        _resetUsesPreviewOtp.value = false
        _resetResolvedEmail.value = null
    }

    fun resetPasswordWithOtpOrRecovery(
        identifierRaw: String,
        verificationInput: String,
        newPassword: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val trimmed = SecurityUtils.sanitizeInput(identifierRaw, 150)
            val looksLikePhone = !trimmed.contains("@") && trimmed.none { it.isLetter() }
            val matchedPhone = if (looksLikePhone) SecurityUtils.normalizeIndianPhoneE164(trimmed) else null

            val cleanEmail = if (SecurityUtils.isOwnerIdentifier(trimmed) || SecurityUtils.isOwnerIdentifier(_resetResolvedEmail.value)) {
                SecurityUtils.OWNER_EMAIL
            } else {
                _resetResolvedEmail.value
                    ?: if (matchedPhone != null) {
                        withTimeoutOrNull(2_500L) { accountRepo.lookupEmailByPhone(matchedPhone) }
                            ?: rateLimiter.findPreviewUserByPhone(matchedPhone)?.email
                            ?: ""
                    } else {
                        SecurityUtils.normalizeEmail(trimmed)
                    }
            }

            if (!SecurityUtils.isValidEmail(cleanEmail)) {
                _statusMessage.value = "Enter your registered Email ID or Mobile No."
                return@launch
            }
            if (!SecurityUtils.isAcceptablePassword(newPassword)) {
                _statusMessage.value = "New Password must be at least 6 characters."
                return@launch
            }

            if (_resetUsesPreviewOtp.value) {
                if (verificationInput.trim() != SecurityUtils.PREVIEW_TEST_MODE_OTP) {
                    recordFailureAndNotify("Invalid verification OTP. Enter Test Mode OTP: ${SecurityUtils.PREVIEW_TEST_MODE_OTP}.")
                    return@launch
                }
                _isBusy.value = true
                try {
                    val salt = SecurityUtils.generateSalt()
                    val hash = SecurityUtils.hashPassword(newPassword, salt)
                    val existingPreview = rateLimiter.findPreviewUserByEmail(cleanEmail)
                    val resolvedUid = existingPreview?.uid ?: if (SecurityUtils.isOwnerEmail(cleanEmail)) {
                        "owner_${SecurityUtils.sha256Hex(cleanEmail).take(16)}"
                    } else {
                        activeUid()
                    }
                    rateLimiter.savePreviewUserCredential(
                        PreviewUserCredential(
                            email = cleanEmail,
                            passwordHash = hash,
                            passwordSalt = salt,
                            fullName = existingPreview?.fullName ?: SecurityUtils.deriveDisplayNameFromEmail(cleanEmail),
                            uid = resolvedUid,
                            phone = existingPreview?.phone ?: matchedPhone
                        )
                    )
                    rateLimiter.clearFailedAttempts()
                    clearForgotPasswordState()
                    _statusMessage.value = "पासवर्ड सफलतापूर्वक बदल गया! अब आप लॉगिन कर सकते हैं। / Password updated!"
                    onSuccess()
                } finally {
                    _isBusy.value = false
                }
                return@launch
            }

            clearForgotPasswordState()
            onSuccess()
        }
    }

    private fun refreshLockoutCountdown() {
        viewModelScope.launch {
            val remaining = rateLimiter.getRemainingLockoutMs()
            if (remaining > 0) {
                var sec = (remaining / 1000L).coerceAtLeast(1L)
                while (sec > 0) {
                    _lockoutSecondsLeft.value = sec
                    delay(1000L)
                    sec--
                }
                _lockoutSecondsLeft.value = 0L
            }
        }
    }

    private suspend fun checkNotLocked(): Boolean {
        val rem = rateLimiter.getRemainingLockoutMs()
        if (rem > 0) {
            _lockoutSecondsLeft.value = (rem / 1000L).coerceAtLeast(1L)
            refreshLockoutCountdown()
            _statusMessage.value = "Too many failed attempts. Locked for ${_lockoutSecondsLeft.value}s."
            return false
        }
        return true
    }

    private suspend fun recordFailureAndNotify(baseMessage: String) {
        val (attempts, lockoutUntil) = rateLimiter.recordFailedAttempt()
        if (lockoutUntil > 0L) {
            refreshLockoutCountdown()
            _statusMessage.value = "$baseMessage Locked for 60s after 5 failed attempts."
        } else {
            val left = (SecurityUtils.MAX_FAILED_LOGIN_ATTEMPTS - attempts).coerceAtLeast(0)
            _statusMessage.value = "$baseMessage ($left attempts remaining)"
        }
    }

    private suspend fun issueSingleDeviceSessionForUser(uid: String): String {
        val token = java.util.UUID.randomUUID().toString()
        rateLimiter.setActiveSessionToken(token)
        runCatching { accountRepo.updateActiveSessionToken(uid, token) }
        return token
    }

    private suspend fun issueSingleDeviceSessionForStaff(staffUsername: String): String {
        val token = java.util.UUID.randomUUID().toString()
        rateLimiter.setActiveSessionToken(token)
        runCatching { feedRepo.updateStaffSessionToken(staffUsername, token) }
        return token
    }

    fun issueNewSessionTokenForActiveUser(uid: String) {
        viewModelScope.launch {
            issueSingleDeviceSessionForUser(uid)
        }
    }

    fun forceLogoutDueToNewDeviceSession() {
        viewModelScope.launch {
            rateLimiter.setActiveSessionToken(null)
            _pendingStaffVerification.value = null
            clearSignUpPendingState()
            clearForgotPasswordState()
            runCatching { Firebase.auth.signOut() }
            _session.value = ActivePortalSession.UnverifiedPortal
            _statusMessage.value = "आपका खाता किसी नए डिवाइस पर लॉगिन हुआ है, इसलिए यह पुराना सेशन लॉगआउट कर दिया गया है। / Logged out automatically because your account signed in on another device."
        }
    }

    fun logoutPortalRole() {
        viewModelScope.launch { rateLimiter.setActiveSessionToken(null) }
        _pendingStaffVerification.value = null
        clearSignUpPendingState()
        clearForgotPasswordState()
        runCatching { Firebase.auth.signOut() }
        _session.value = ActivePortalSession.UnverifiedPortal
    }

    fun refreshUserSession(account: UserAccount) {
        if (account.isBanned) {
            _session.value = ActivePortalSession.UnverifiedPortal
            _statusMessage.value = "Your account has been permanently suspended for violating safety rules."
        } else {
            _session.value = ActivePortalSession.UserSession(account)
        }
    }

    companion object {
        private const val SIGN_IN_TIMEOUT_MS = 8_000L
    }
}

package com.dilsuno.app

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.RateLimiterStore
import com.dilsuno.app.core.ZegoCallManager
import com.dilsuno.app.core.configureAppCheck
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.ActivePortalSession
import com.dilsuno.app.data.repository.AccountAndSocialRepository
import com.dilsuno.app.data.repository.AiSafetyRepository
import com.dilsuno.app.data.repository.FeedModerationAndCallRepository
import com.dilsuno.app.ui.auth.UnifiedRolePortalScreen
import com.dilsuno.app.ui.auth.signOutFromDilSuno
import com.dilsuno.app.ui.screens.DilSeCallScreen
import com.dilsuno.app.ui.screens.FriendsAndMessengerScreen
import com.dilsuno.app.ui.screens.HomeFeedScreen
import com.dilsuno.app.ui.screens.NotificationsScreen
import com.dilsuno.app.ui.screens.ProfileAndCreatorScreen
import com.dilsuno.app.ui.screens.ReelCreationFlowScreen
import com.dilsuno.app.ui.screens.ReelsAndLiveScreen
import com.dilsuno.app.ui.screens.SplashScreen
import com.dilsuno.app.ui.screens.StaffPortalScreen
import com.dilsuno.app.ui.screens.SuperAdminScreen
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.DilSunoTheme
import com.dilsuno.app.ui.theme.RoyalNavy
import com.dilsuno.app.viewmodel.AuthPortalViewModel
import com.dilsuno.app.viewmodel.MainAppViewModel
import com.dilsuno.app.viewmodel.StaffAndAdminViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        runCatching { enableEdgeToEdge() }
            .onFailure { android.util.Log.w("MainActivity", "enableEdgeToEdge skipped: ${it.message}") }
        super.onCreate(savedInstanceState)
        // NOTE: Do NOT set FLAG_SECURE on the root MainActivity window — doing so causes
        // streaming emulators, video previews, and Play Console review captures to render black
        // immediately after the OS launch splash screen.
        runCatching { configureAppCheck(this, intent) }
            .onFailure { android.util.Log.w("MainActivity", "AppCheck init skipped: ${it.message}") }
        setContent {
            DilSunoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DilSunoRootApp()
                }
            }
        }
    }
}

private fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    trySend(currentUser)
    awaitClose { removeAuthStateListener(listener) }
}

private data class UserNavDestination(
    val titleEn: String,
    val titleHi: String,
    val icon: ImageVector,
    val testTag: String
)

@Composable
private fun DilSunoRootApp() {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) {
        runCatching { CredentialManager.create(context) }.getOrNull()
    }

    val initialFirebaseUser = remember {
        runCatching { Firebase.auth.currentUser }.getOrNull()
    }
    val authFlow = remember {
        runCatching { Firebase.auth.authStateFlow() }
            .getOrElse { kotlinx.coroutines.flow.flowOf(null) }
    }
    val authUser by authFlow.collectAsStateWithLifecycle(initialValue = initialFirebaseUser)

    val uid = authUser?.uid ?: "preview_local_user"
    val db = remember(appContext) {
        runCatching {
            val dbId = appContext.getString(R.string.firestore_database_id)
            FirebaseFirestore.getInstance(dbId)
        }.getOrElse {
            FirebaseFirestore.getInstance()
        }
    }
    val accountRepo = remember(db) { AccountAndSocialRepository(db) }
    val feedRepo = remember(db) { FeedModerationAndCallRepository(db) }
    val aiSafetyRepo = remember(appContext) { AiSafetyRepository(appContext) }
    val rateLimiter = remember(appContext) { RateLimiterStore(appContext) }

    val authPortalVm: AuthPortalViewModel = viewModel(
        key = "auth_portal_root",
        factory = viewModelFactory {
            initializer {
                AuthPortalViewModel(
                    accountRepo = accountRepo,
                    feedRepo = feedRepo,
                    rateLimiter = rateLimiter
                )
            }
        }
    )

    val session by authPortalVm.session.collectAsStateWithLifecycle()
    val isCheckingPortalAccess by authPortalVm.isCheckingPortalAccess.collectAsStateWithLifecycle()
    val lang by authPortalVm.language.collectAsStateWithLifecycle()
    val localSessionToken by rateLimiter.activeSessionTokenFlow.collectAsStateWithLifecycle(initialValue = null)
    val liveAppConfig by remember(feedRepo, authUser?.uid) {
        if (authUser != null) {
            feedRepo.observeAppConfig()
        } else {
            kotlinx.coroutines.flow.flowOf(com.dilsuno.app.data.model.AppConfig())
        }
    }.collectAsStateWithLifecycle(initialValue = com.dilsuno.app.data.model.AppConfig())

    var securityReport by remember {
        mutableStateOf(
            com.dilsuno.app.core.DeviceSecurityReport(
                isRooted = false,
                isEmulator = false,
                isCloned = false,
                reasons = emptyList(),
                shouldHardBlock = false
            )
        )
    }
    LaunchedEffect(appContext) {
        securityReport = withContext(Dispatchers.IO) {
            runCatching {
                val rawReport = com.dilsuno.app.core.DeviceSecurityGuard.evaluateDeviceSecurity(appContext)
                com.dilsuno.app.core.SecurityUtils.resolveRuntimeSecurityReport(appContext, rawReport)
            }.getOrElse {
                com.dilsuno.app.core.DeviceSecurityReport(
                    isRooted = false,
                    isEmulator = false,
                    isCloned = false,
                    reasons = emptyList(),
                    shouldHardBlock = false
                )
            }
        }
    }
    if (securityReport.shouldHardBlock) {
        androidx.compose.material3.Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.errorContainer
        ) {
            androidx.compose.foundation.layout.Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "🛡️ Dil Suno Security Shield",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                androidx.compose.foundation.layout.Spacer(Modifier.height(12.dp))
                Text(
                    text = securityReport.reasons.joinToString("\n").ifBlank {
                        "Unsafe device environment detected. Please install the official Dil Suno app on a genuine Android device."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }
        return
    }

    var dismissedOptionalUpdate by rememberSaveable { mutableStateOf(false) }
    val isUpdateAvailable = remember(liveAppConfig.latestAppVersionCode, liveAppConfig.latestAppVersionName) {
        com.dilsuno.app.core.SecurityUtils.isNewerVersionAvailable(
            currentVersionCode = BuildConfig.VERSION_CODE,
            currentVersionName = BuildConfig.VERSION_NAME,
            latestVersionCode = liveAppConfig.latestAppVersionCode,
            latestVersionName = liveAppConfig.latestAppVersionName
        )
    }
    if (isUpdateAvailable && (liveAppConfig.forceUpdate || !dismissedOptionalUpdate)) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = {
                if (!liveAppConfig.forceUpdate) dismissedOptionalUpdate = true
            },
            title = {
                Text(
                    text = "New Update Available — Update Now",
                    fontWeight = FontWeight.ExtraBold
                )
            },
            text = {
                Text(
                    text = tr(
                        "A newer version of Dil Suno (v${liveAppConfig.latestAppVersionName}, Build ${liveAppConfig.latestAppVersionCode}) is ready! Current version: v${BuildConfig.VERSION_NAME}.",
                        "दिल सुनो का नया वर्ज़न (v${liveAppConfig.latestAppVersionName}, Build ${liveAppConfig.latestAppVersionCode}) उपलब्ध है! कृपया अभी अपडेट करें।",
                        lang
                    )
                )
            },
            confirmButton = {
                androidx.compose.material3.Button(
                    onClick = {
                        val url = liveAppConfig.appUpdateUrl?.trim()?.ifBlank { "https://dilsuno.app/download" }
                            ?: "https://dilsuno.app/download"
                        runCatching {
                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
                                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        }
                    }
                ) {
                    Text("Update Now")
                }
            },
            dismissButton = if (!liveAppConfig.forceUpdate) {
                {
                    androidx.compose.material3.TextButton(onClick = { dismissedOptionalUpdate = true }) {
                        Text(tr("Later", "बाद में", lang))
                    }
                }
            } else null
        )
    }

    // 100% Anonymous ZegoCloud Call Identity (real names/phones are NEVER passed to Zego call UI)
    val zegoIdentity: Pair<String, String>? = remember(session, authUser?.uid) {
        val firebaseUid = runCatching { Firebase.auth.currentUser?.uid }.getOrNull()?.takeIf { it.isNotBlank() }
        when (val active = session) {
            is ActivePortalSession.UserSession -> {
                val zegoId = firebaseUid ?: active.account.userId
                zegoId to ZegoCallManager.ANONYMOUS_CALLER_LABEL
            }
            is ActivePortalSession.StaffSession -> {
                val zegoId = firebaseUid
                    ?: active.staff.assignedUid?.takeIf { it.isNotBlank() }
                    ?: active.staff.staffUsername
                zegoId to ZegoCallManager.ANONYMOUS_LISTENER_LABEL
            }
            is ActivePortalSession.AdminSession -> {
                val zegoId = firebaseUid ?: active.adminUid
                zegoId to ZegoCallManager.EMERGENCY_SUPERVISOR_LABEL
            }
            ActivePortalSession.UnverifiedPortal -> null
        }
    }

    LaunchedEffect(zegoIdentity) {
        try {
            // Allow the current Compose frame & SurfaceSyncGroup transition to commit cleanly
            // before initializing native Zego Express / ZIM libraries.
            yield()
            delay(380L)
            if (zegoIdentity != null) {
                (appContext as? Application)?.let { app ->
                    ZegoCallManager.initCallInvitation(
                        application = app,
                        rawUserId = zegoIdentity.first,
                        rawUserName = zegoIdentity.second
                    )
                }
            } else {
                ZegoCallManager.unInitCallInvitation()
            }
        } catch (t: Throwable) {
            android.util.Log.w("MainActivity", "Zego startup sync skipped safely: ${t.message}")
        }
    }

    var minSplashElapsed by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        if (!minSplashElapsed) {
            delay(1500L)
            minSplashElapsed = true
        }
    }
    val showSplash = !minSplashElapsed || isCheckingPortalAccess

    Crossfade(
        targetState = showSplash,
        animationSpec = tween(durationMillis = 320),
        label = "startup_splash_transition"
    ) { isSplashVisible ->
        if (isSplashVisible) {
            SplashScreen()
        } else {
            when (val active = session) {
                ActivePortalSession.UnverifiedPortal -> {
                    UnifiedRolePortalScreen(
                        viewModel = authPortalVm
                    )
                }

        is ActivePortalSession.UserSession -> {
            val mainVm: MainAppViewModel = viewModel(
                key = "user_main_$uid",
                factory = viewModelFactory {
                    initializer {
                        MainAppViewModel(
                            accountRepo = accountRepo,
                            feedRepo = feedRepo,
                            aiSafetyRepo = aiSafetyRepo,
                            currentUserId = uid,
                            rateLimiter = rateLimiter
                        )
                    }
                }
            )
            val liveAccount by mainVm.myAccount.collectAsStateWithLifecycle()
            LaunchedEffect(liveAccount?.isBanned, liveAccount?.activeSessionToken, localSessionToken) {
                val acct = liveAccount
                if (acct != null && acct.isBanned) {
                    authPortalVm.refreshUserSession(acct)
                } else if (acct != null && !acct.activeSessionToken.isNullOrBlank() &&
                    !localSessionToken.isNullOrBlank() &&
                    acct.activeSessionToken != localSessionToken
                ) {
                    // Single-Device Session Lock: another device signed in with a newer session token
                    authPortalVm.forceLogoutDueToNewDeviceSession()
                }
            }

            DilSunoUserShell(
                viewModel = mainVm,
                lang = lang,
                onToggleLang = {
                    authPortalVm.setLanguage(if (lang == AppLang.EN) AppLang.HI else AppLang.EN)
                },
                onSwitchRoleOrSignOut = {
                    authPortalVm.logoutPortalRole()
                },
                onAccountDeleted = {
                    signOutFromDilSuno(
                        credentialManager = credentialManager,
                        scope = scope,
                        onSignOutComplete = { authPortalVm.logoutPortalRole() }
                    )
                }
            )
        }

        is ActivePortalSession.StaffSession -> {
            BackHandler {
                authPortalVm.logoutPortalRole()
            }
            val staffVm: StaffAndAdminViewModel = viewModel(
                key = "staff_${uid}_${active.staff.staffUsername}",
                factory = viewModelFactory {
                    initializer {
                        StaffAndAdminViewModel(
                            accountRepo = accountRepo,
                            feedRepo = feedRepo,
                            isAdminMode = false,
                            staffUsernameInitial = active.staff.staffUsername,
                            rateLimiter = rateLimiter
                        )
                    }
                }
            )
            val liveStaff by staffVm.myStaffAccount.collectAsStateWithLifecycle()
            LaunchedEffect(liveStaff?.activeSessionToken, localSessionToken) {
                val st = liveStaff
                if (st != null && !st.activeSessionToken.isNullOrBlank() &&
                    !localSessionToken.isNullOrBlank() &&
                    st.activeSessionToken != localSessionToken
                ) {
                    authPortalVm.forceLogoutDueToNewDeviceSession()
                }
            }
            StaffPortalScreen(
                staff = active.staff,
                viewModel = staffVm,
                lang = lang,
                onLogout = { authPortalVm.logoutPortalRole() }
            )
        }

        is ActivePortalSession.AdminSession -> {
            var previewUserFeed by rememberSaveable { mutableStateOf(false) }

            if (previewUserFeed) {
                val previewMainVm: MainAppViewModel = viewModel(
                    key = "admin_preview_main_$uid",
                    factory = viewModelFactory {
                        initializer {
                            MainAppViewModel(
                                accountRepo = accountRepo,
                                feedRepo = feedRepo,
                                aiSafetyRepo = aiSafetyRepo,
                                currentUserId = uid,
                                rateLimiter = rateLimiter
                            )
                        }
                    }
                )
                DilSunoUserShell(
                    viewModel = previewMainVm,
                    lang = lang,
                    onToggleLang = {
                        authPortalVm.setLanguage(if (lang == AppLang.EN) AppLang.HI else AppLang.EN)
                    },
                    onSwitchRoleOrSignOut = {
                        previewUserFeed = false
                        authPortalVm.logoutPortalRole()
                    },
                    onAccountDeleted = {
                        previewUserFeed = false
                        signOutFromDilSuno(
                            credentialManager = credentialManager,
                            scope = scope,
                            onSignOutComplete = { authPortalVm.logoutPortalRole() }
                        )
                    },
                    onReturnToAdminDashboard = { previewUserFeed = false }
                )
            } else {
                BackHandler {
                    authPortalVm.logoutPortalRole()
                }
                val adminVm: StaffAndAdminViewModel = viewModel(
                    key = "admin_$uid",
                    factory = viewModelFactory {
                        initializer {
                            StaffAndAdminViewModel(
                                accountRepo = accountRepo,
                                feedRepo = feedRepo,
                                isAdminMode = true,
                                staffUsernameInitial = null,
                                rateLimiter = rateLimiter
                            )
                        }
                    }
                )
                SuperAdminScreen(
                    adminEmail = active.email,
                    viewModel = adminVm,
                    lang = lang,
                    onPreviewUserFeed = { previewUserFeed = true },
                    onLogout = { authPortalVm.logoutPortalRole() }
                )
            }
        }
            }
        }
    }
}

@Composable
private fun DilSunoUserShell(
    viewModel: MainAppViewModel,
    lang: AppLang,
    onToggleLang: () -> Unit,
    onSwitchRoleOrSignOut: () -> Unit,
    onAccountDeleted: () -> Unit,
    onReturnToAdminDashboard: (() -> Unit)? = null
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var showDilSeCallScreen by rememberSaveable { mutableStateOf(false) }
    var showReelCreationFlow by rememberSaveable { mutableStateOf(false) }
    var startReelInCamera by rememberSaveable { mutableStateOf(false) }
    var focusedReelId by rememberSaveable { mutableStateOf<String?>(null) }
    var autoOpenRechargePopup by rememberSaveable { mutableStateOf(false) }

    val bannerMessage by viewModel.bannerMessage.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val unreadNotifications = remember(notifications) { notifications.count { !it.isRead } }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(bannerMessage) {
        val msg = bannerMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearBanner()
        }
    }

    if (showReelCreationFlow) {
        ReelCreationFlowScreen(
            viewModel = viewModel,
            lang = lang,
            startInCamera = startReelInCamera,
            onDismiss = { showReelCreationFlow = false },
            onReelPublished = {
                showReelCreationFlow = false
                focusedReelId = null
                selectedTab = 1
            }
        )
        return
    }

    if (showDilSeCallScreen) {
        BackHandler {
            showDilSeCallScreen = false
        }
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                Surface(
                    color = com.dilsuno.app.ui.theme.RoyalBluePrimary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        androidx.compose.material3.IconButton(
                            onClick = { showDilSeCallScreen = false },
                            modifier = Modifier.testTag("dil_se_call_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = tr("Back", "वापस", lang),
                                tint = Color.White
                            )
                        }
                        Text(
                            text = tr("Dil Se Call", "दिल से कॉल", lang),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                DilSeCallScreen(
                    viewModel = viewModel,
                    lang = lang,
                    autoPromptRechargeOnOpen = autoOpenRechargePopup,
                    onConsumeAutoRechargePrompt = { autoOpenRechargePopup = false }
                )
            }
        }
        return
    }

    if (selectedTab != 0) {
        BackHandler {
            selectedTab = 0
        }
    } else if (onReturnToAdminDashboard != null) {
        BackHandler {
            onReturnToAdminDashboard()
        }
    }

    val destinations = remember {
        listOf(
            UserNavDestination("Home", "होम", Icons.Filled.Home, "nav_home"),
            UserNavDestination("Reels", "रील्स", Icons.Filled.VideoLibrary, "nav_reels"),
            UserNavDestination("Friends", "दोस्त", Icons.Filled.People, "nav_friends"),
            UserNavDestination("Alerts", "सूचना", Icons.Filled.Notifications, "nav_notifications"),
            UserNavDestination("Profile", "प्रोफ़ाइल", Icons.Filled.Person, "nav_profile")
        )
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                if (onReturnToAdminDashboard != null) {
                    Surface(
                        color = RoyalNavy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .statusBarsPadding()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    Icons.Filled.AdminPanelSettings,
                                    contentDescription = tr("Admin Preview", "एडमिन प्रीव्यू", lang),
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = tr("User Feed Preview Mode", "यूज़र ऐप प्रीव्यू मोड", lang),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            FilledTonalButton(
                                onClick = onReturnToAdminDashboard,
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = MaterialTheme.colorScheme.secondary,
                                    contentColor = Color.White
                                ),
                                modifier = Modifier.testTag("return_to_admin_dashboard_button")
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = tr("Back to Admin", "एडमिन डैशबोर्ड पर लौटें", lang),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = tr("Admin Dashboard", "एडमिन डैशबोर्ड", lang),
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                }
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(containerColor = com.dilsuno.app.ui.theme.PureWhiteBackground) {
                        destinations.forEachIndexed { index, item ->
                            NavigationBarItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                alwaysShowLabel = true,
                                icon = {
                                    val iconColor = if (selectedTab == index) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                    if (index == 3 && unreadNotifications > 0) {
                                        BadgedBox(
                                            badge = {
                                                Badge(containerColor = CrimsonPrimary) {
                                                    Text(
                                                        text = if (unreadNotifications > 9) "9+" else unreadNotifications.toString(),
                                                        fontSize = 9.sp
                                                    )
                                                }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = item.icon,
                                                contentDescription = tr(item.titleEn, item.titleHi, lang),
                                                tint = iconColor
                                            )
                                        }
                                    } else {
                                        Icon(
                                            imageVector = item.icon,
                                            contentDescription = tr(item.titleEn, item.titleHi, lang),
                                            tint = iconColor
                                        )
                                    }
                                },
                                label = {
                                    Text(
                                        text = tr(item.titleEn, item.titleHi, lang),
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis,
                                        fontSize = 10.sp
                                    )
                                },
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(containerColor = com.dilsuno.app.ui.theme.PureWhiteBackground) {
                        destinations.forEachIndexed { index, item ->
                            NavigationRailItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                icon = {
                                    val iconColor = if (selectedTab == index) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                    if (index == 3 && unreadNotifications > 0) {
                                        BadgedBox(
                                            badge = {
                                                Badge(containerColor = CrimsonPrimary) {
                                                    Text(
                                                        text = if (unreadNotifications > 9) "9+" else unreadNotifications.toString(),
                                                        fontSize = 9.sp
                                                    )
                                                }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = item.icon,
                                                contentDescription = tr(item.titleEn, item.titleHi, lang),
                                                tint = iconColor
                                            )
                                        }
                                    } else {
                                        Icon(
                                            imageVector = item.icon,
                                            contentDescription = tr(item.titleEn, item.titleHi, lang),
                                            tint = iconColor
                                        )
                                    }
                                },
                                label = {
                                    Text(
                                        text = tr(item.titleEn, item.titleHi, lang),
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    when (selectedTab) {
                        0 -> HomeFeedScreen(
                            viewModel = viewModel,
                            lang = lang,
                            onOpenDilSeCall = { showDilSeCallScreen = true },
                            onToggleLang = onToggleLang,
                            onOpenCreateReel = {
                                startReelInCamera = false
                                showReelCreationFlow = true
                            },
                            onOpenReelFullscreen = { reelId ->
                                focusedReelId = reelId
                                selectedTab = 1
                            },
                            onSignOut = onSwitchRoleOrSignOut,
                            onOpenProfile = { selectedTab = 4 },
                            onOpenFriends = { selectedTab = 2 },
                            onAccountDeleted = onAccountDeleted,
                            onOpenSmartListenerCall = { needsRecharge ->
                                autoOpenRechargePopup = needsRecharge
                                showDilSeCallScreen = true
                            }
                        )

                        1 -> ReelsAndLiveScreen(
                            viewModel = viewModel,
                            lang = lang,
                            initialReelId = focusedReelId,
                            onOpenPrivateCall = { showDilSeCallScreen = true },
                            onOpenCreateReel = {
                                startReelInCamera = true
                                showReelCreationFlow = true
                            }
                        )

                        2 -> FriendsAndMessengerScreen(
                            viewModel = viewModel,
                            lang = lang
                        )

                        3 -> NotificationsScreen(
                            viewModel = viewModel,
                            lang = lang
                        )

                        else -> ProfileAndCreatorScreen(
                            viewModel = viewModel,
                            lang = lang,
                            onToggleLang = onToggleLang,
                            onSwitchRoleOrSignOut = onSwitchRoleOrSignOut,
                            onAccountDeleted = onAccountDeleted,
                            onOpenCreateReel = {
                                startReelInCamera = false
                                showReelCreationFlow = true
                            },
                            onOpenLive = { selectedTab = 1 },
                            onOpenPrivateCall = { showDilSeCallScreen = true }
                        )
                    }
                }
            }
        }
    }
}


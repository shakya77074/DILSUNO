package com.dilsuno.app.ui.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.DilSePolicyText
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.tr
import com.dilsuno.app.ui.components.LegalPoliciesViewerDialog
import com.dilsuno.app.ui.theme.HairlineDividerBlue
import com.dilsuno.app.ui.theme.PureWhiteBackground
import com.dilsuno.app.ui.theme.RoyalBlueDeep
import com.dilsuno.app.ui.theme.RoyalBluePrimary
import com.dilsuno.app.ui.theme.SlateDarkText
import com.dilsuno.app.ui.theme.SlateMutedFooter
import com.dilsuno.app.ui.theme.SlateSubtleText
import com.dilsuno.app.ui.theme.SoftBlueCardSurface
import com.dilsuno.app.ui.theme.SoftCardSurface
import com.dilsuno.app.viewmodel.AuthPortalViewModel
import com.dilsuno.app.viewmodel.SignUpChannel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnifiedRolePortalScreen(
    viewModel: AuthPortalViewModel
) {
    val lang by viewModel.language.collectAsStateWithLifecycle()
    val statusMsg by viewModel.statusMessage.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
    val lockoutSec by viewModel.lockoutSecondsLeft.collectAsStateWithLifecycle()
    val isCheckingPortalAccess by viewModel.isCheckingPortalAccess.collectAsStateWithLifecycle()
    val existingCustomerAccount by viewModel.existingCustomerAccount.collectAsStateWithLifecycle()

    val isSignUpInlineOtpOpen by viewModel.isSignUpInlineOtpOpen.collectAsStateWithLifecycle()
    val pendingSignUpChannel by viewModel.pendingSignUpChannel.collectAsStateWithLifecycle()
    val pendingSignUpEmail by viewModel.pendingSignUpEmail.collectAsStateWithLifecycle()
    val pendingSignUpPhone by viewModel.pendingSignUpPhone.collectAsStateWithLifecycle()
    val isRealPhoneAuthActive by viewModel.isRealPhoneAuthActive.collectAsStateWithLifecycle()
    val isRealEmailVerificationSent by viewModel.isRealEmailVerificationSent.collectAsStateWithLifecycle()

    val pendingStaffVerification by viewModel.pendingStaffVerification.collectAsStateWithLifecycle()
    val resetOtpSent by viewModel.resetOtpSent.collectAsStateWithLifecycle()
    val resetUsesPreviewOtp by viewModel.resetUsesPreviewOtp.collectAsStateWithLifecycle()
    val resetResolvedEmail by viewModel.resetResolvedEmail.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) {
        runCatching { CredentialManager.create(context) }.getOrNull()
    }
    val firebaseUser = remember { runCatching { Firebase.auth.currentUser }.getOrNull() }

    var showCreateAccountScreen by remember { mutableStateOf(false) }
    var signUpChannel by remember { mutableStateOf(SignUpChannel.EMAIL) }

    var signInIdentifier by remember { mutableStateOf("") }
    var phoneDigits by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var signUpFullName by remember { mutableStateOf("") }

    var signUpOtpInput by remember { mutableStateOf("") }
    var staffPin by remember { mutableStateOf("") }
    var showStaffPin by remember { mutableStateOf(false) }

    var showForgotPasswordDialog by remember { mutableStateOf(false) }
    var legalDialogTab by remember { mutableStateOf<Int?>(null) }
    var signInConsentAccepted by remember { mutableStateOf(true) }
    var signUp18PlusAccepted by remember { mutableStateOf(false) }
    var isGoogleSignInBusy by remember { mutableStateOf(false) }

    LaunchedEffect(existingCustomerAccount, firebaseUser?.email) {
        val savedEmail = existingCustomerAccount?.email?.takeIf { it.isNotBlank() }
        if (email.isBlank() && savedEmail != null) {
            email = savedEmail
        }
        if (signInIdentifier.isBlank() && savedEmail != null) {
            signInIdentifier = savedEmail
        }
    }

    LaunchedEffect(isSignUpInlineOtpOpen) {
        if (!isSignUpInlineOtpOpen) {
            signUpOtpInput = ""
        }
    }

    BackHandler(enabled = pendingStaffVerification != null) {
        staffPin = ""
        viewModel.cancelStaffPinVerification()
    }

    BackHandler(enabled = showCreateAccountScreen) {
        if (isSignUpInlineOtpOpen) {
            signUpOtpInput = ""
            viewModel.cancelSignUpInlineOtp()
        } else {
            showCreateAccountScreen = false
            viewModel.clearMessage()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhiteBackground)
            .systemBarsPadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Subtle Top Language Switch Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = {
                        viewModel.setLanguage(if (lang == AppLang.EN) AppLang.HI else AppLang.EN)
                    },
                    modifier = Modifier.heightIn(min = 48.dp).testTag("one_tap_lang_switch")
                ) {
                    Text(
                        text = if (lang == AppLang.EN) "हिंदी" else "English",
                        fontWeight = FontWeight.SemiBold,
                        color = RoyalBluePrimary
                    )
                }
            }

            if (lockoutSec > 0L) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = tr(
                                "Security Lockout: Too many failed attempts. Wait ${lockoutSec}s.",
                                "सुरक्षा लॉकआउट: कई गलत प्रयास। कृपया ${lockoutSec} सेकंड प्रतीक्षा करें।",
                                lang
                            ),
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            if (!statusMsg.isNullOrBlank()) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftBlueCardSurface),
                    border = BorderStroke(1.dp, RoyalBluePrimary.copy(alpha = 0.25f))
                ) {
                    Text(
                        text = statusMsg!!,
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateDarkText
                    )
                }
            }

            when {
                isCheckingPortalAccess -> {
                    Spacer(Modifier.weight(1f))
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Dil Suno",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = RoyalBluePrimary
                        )
                        CircularProgressIndicator(color = RoyalBluePrimary)
                        Text(
                            text = tr("Loading Dil Suno...", "दिल सुनो लोड हो रहा है...", lang),
                            style = MaterialTheme.typography.bodyMedium,
                            color = SlateSubtleText
                        )
                    }
                    Spacer(Modifier.weight(1f))
                }

                pendingStaffVerification != null -> {
                    val staffEntry = pendingStaffVerification!!
                    Spacer(Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = SoftCardSurface),
                        border = BorderStroke(1.dp, HairlineDividerBlue),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.HeadsetMic, contentDescription = null, tint = RoyalBluePrimary)
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = tr("Staff Listener Verification", "स्टाफ श्रोता सत्यापन", lang),
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = SlateDarkText
                                    )
                                    Text(
                                        text = "${staffEntry.displayName} • ${staffEntry.staffEmail}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SlateSubtleText
                                    )
                                }
                            }
                            Text(
                                text = tr(
                                    "Enter the numeric Staff PIN assigned by Super Admin (8–12 digits recommended) to open your Staff Listener Dashboard.",
                                    "अपना स्टाफ श्रोता डैशबोर्ड खोलने के लिए सुपर एडमिन द्वारा दिया गया नंबर पिन (8–12 अंक) दर्ज करें।",
                                    lang
                                ),
                                style = MaterialTheme.typography.bodyMedium,
                                color = SlateSubtleText
                            )
                            OutlinedTextField(
                                value = staffPin,
                                onValueChange = { input ->
                                    staffPin = input.filter { it.isDigit() }.take(16)
                                },
                                label = { Text(tr("Assigned Staff PIN", "स्टाफ पिन", lang)) },
                                leadingIcon = { Icon(Icons.Filled.Pin, contentDescription = null, tint = RoyalBluePrimary) },
                                trailingIcon = {
                                    IconButton(
                                        onClick = { showStaffPin = !showStaffPin },
                                        modifier = Modifier.testTag("toggle_staff_pin_visibility")
                                    ) {
                                        Icon(
                                            if (showStaffPin) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                            contentDescription = if (showStaffPin) tr("Hide PIN", "पिन छिपाएं", lang) else tr("Show PIN", "पिन दिखाएं", lang)
                                        )
                                    }
                                },
                                visualTransformation = if (showStaffPin) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                modifier = Modifier.fillMaxWidth().testTag("staff_pin_input"),
                                singleLine = true
                            )
                            Button(
                                onClick = { viewModel.verifyPendingStaffPin(staffPin) },
                                enabled = !isBusy && lockoutSec == 0L,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = RoyalBluePrimary,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("staff_login_button")
                            ) {
                                if (isBusy) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                } else {
                                    Text(
                                        text = tr("Open Staff Listener Dashboard", "स्टाफ श्रोता डैशबोर्ड खोलें", lang),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            TextButton(
                                onClick = {
                                    staffPin = ""
                                    viewModel.cancelStaffPinVerification()
                                },
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            ) {
                                Text(tr("Back to Sign In", "वापस साइन इन पर जाएं", lang), color = RoyalBluePrimary)
                            }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                }

                showCreateAccountScreen -> {
                    // Clean Create Account View (opened via Create Account button)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                signUpOtpInput = ""
                                viewModel.cancelSignUpInlineOtp()
                                viewModel.clearMessage()
                                showCreateAccountScreen = false
                            }
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = tr("Back", "वापस", lang),
                                tint = RoyalBluePrimary
                            )
                        }
                        Text(
                            text = tr("Create Account", "नया खाता बनाएं", lang),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = RoyalBluePrimary
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("create_account_card"),
                        colors = CardDefaults.cardColors(containerColor = SoftCardSurface),
                        border = BorderStroke(1.dp, HairlineDividerBlue),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = signUpFullName,
                                onValueChange = { signUpFullName = it },
                                enabled = !isSignUpInlineOtpOpen,
                                label = { Text(tr("Full Name", "पूरा नाम", lang)) },
                                placeholder = { Text(tr("e.g. Aarav Sharma", "जैसे: आरव शर्मा", lang)) },
                                leadingIcon = { Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = RoyalBluePrimary) },
                                modifier = Modifier.fillMaxWidth().testTag("signup_fullname_input"),
                                singleLine = true
                            )

                            Surface(
                                color = SoftBlueCardSurface,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val isEmailMode = signUpChannel == SignUpChannel.EMAIL
                                    Button(
                                        onClick = {
                                            if (signUpChannel != SignUpChannel.EMAIL) {
                                                signUpChannel = SignUpChannel.EMAIL
                                                signUpOtpInput = ""
                                                viewModel.cancelSignUpInlineOtp()
                                            }
                                        },
                                        enabled = !isBusy,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isEmailMode) RoyalBluePrimary else Color.Transparent,
                                            contentColor = if (isEmailMode) Color.White else SlateDarkText
                                        ),
                                        elevation = ButtonDefaults.buttonElevation(
                                            defaultElevation = if (isEmailMode) 2.dp else 0.dp
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f).height(48.dp).testTag("signup_use_email_button")
                                    ) {
                                        Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Use Email", fontWeight = if (isEmailMode) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                                    }

                                    val isPhoneMode = signUpChannel == SignUpChannel.PHONE
                                    Button(
                                        onClick = {
                                            if (signUpChannel != SignUpChannel.PHONE) {
                                                signUpChannel = SignUpChannel.PHONE
                                                signUpOtpInput = ""
                                                viewModel.cancelSignUpInlineOtp()
                                            }
                                        },
                                        enabled = !isBusy,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isPhoneMode) RoyalBluePrimary else Color.Transparent,
                                            contentColor = if (isPhoneMode) Color.White else SlateDarkText
                                        ),
                                        elevation = ButtonDefaults.buttonElevation(
                                            defaultElevation = if (isPhoneMode) 2.dp else 0.dp
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f).height(48.dp).testTag("signup_use_phone_button")
                                    ) {
                                        Icon(Icons.Filled.PhoneAndroid, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Use Phone", fontWeight = if (isPhoneMode) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                                    }
                                }
                            }

                            AnimatedVisibility(visible = isSignUpInlineOtpOpen) {
                                val isEmailOtp = pendingSignUpChannel == SignUpChannel.EMAIL
                                val otpTargetLabel = if (isEmailOtp) pendingSignUpEmail.orEmpty() else pendingSignUpPhone.orEmpty()
                                Surface(
                                    color = SoftBlueCardSurface,
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.5.dp, RoyalBluePrimary),
                                    modifier = Modifier.fillMaxWidth().testTag("signup_inline_otp_box")
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (isEmailOtp) Icons.Filled.Email else Icons.Filled.Sms,
                                                contentDescription = null,
                                                tint = RoyalBluePrimary
                                            )
                                            Spacer(Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    text = if (isEmailOtp) "Enter 6-Digit Email OTP" else "Enter 6-Digit SMS OTP",
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = RoyalBlueDeep
                                                )
                                                Text(otpTargetLabel, style = MaterialTheme.typography.labelSmall, color = SlateSubtleText)
                                            }
                                        }

                                        if (isEmailOtp) {
                                            Surface(
                                                color = PureWhiteBackground,
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth().testTag("email_otp_helper_banner")
                                            ) {
                                                Text(
                                                    text = if (isRealEmailVerificationSent) {
                                                        tr(
                                                            "Verification email sent to $otpTargetLabel. Tap inbox link or enter OTP ${SecurityUtils.PREVIEW_TEST_MODE_OTP}.",
                                                            "$otpTargetLabel पर ईमेल सत्यापन भेजा गया है। OTP ${SecurityUtils.PREVIEW_TEST_MODE_OTP} दर्ज करें।",
                                                            lang
                                                        )
                                                    } else {
                                                        tr(
                                                            "Test Mode Email OTP: ${SecurityUtils.PREVIEW_TEST_MODE_OTP}",
                                                            "टेस्ट मोड ईमेल OTP: ${SecurityUtils.PREVIEW_TEST_MODE_OTP}",
                                                            lang
                                                        )
                                                    },
                                                    modifier = Modifier.padding(10.dp),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = SlateDarkText
                                                )
                                            }
                                        } else if (!isRealPhoneAuthActive) {
                                            Surface(
                                                color = PureWhiteBackground,
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth().testTag("preview_otp_helper_banner")
                                            ) {
                                                Text(
                                                    text = tr(
                                                        "Test Mode SMS OTP: ${SecurityUtils.PREVIEW_TEST_MODE_OTP}",
                                                        "टेस्ट मोड SMS OTP: ${SecurityUtils.PREVIEW_TEST_MODE_OTP}",
                                                        lang
                                                    ),
                                                    modifier = Modifier.padding(10.dp),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = SlateDarkText
                                                )
                                            }
                                        }

                                        OutlinedTextField(
                                            value = signUpOtpInput,
                                            onValueChange = { raw -> signUpOtpInput = raw.filter { it.isDigit() }.take(6) },
                                            label = { Text(if (isEmailOtp) "Enter 6-Digit Email OTP" else "Enter 6-Digit SMS OTP") },
                                            leadingIcon = { Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = RoyalBluePrimary) },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier.fillMaxWidth().testTag("signup_otp_input"),
                                            singleLine = true
                                        )

                                        Button(
                                            onClick = { viewModel.verifySignUpInlineOtp(signUpOtpInput) },
                                            enabled = !isBusy && lockoutSec == 0L,
                                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary, contentColor = Color.White),
                                            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("verify_signup_otp_button"),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            if (isBusy) {
                                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                            } else {
                                                Text(
                                                    text = tr("Verify OTP & Complete Sign Up", "सत्यापित करें व खाता बनाएं", lang),
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            TextButton(
                                                onClick = { viewModel.resendSignUpInlineOtp(activity) },
                                                enabled = !isBusy,
                                                modifier = Modifier.testTag("resend_signup_otp_button")
                                            ) { Text(tr("Resend OTP", "OTP फिर भेजें", lang), color = RoyalBluePrimary) }
                                            TextButton(
                                                onClick = {
                                                    signUpOtpInput = ""
                                                    viewModel.cancelSignUpInlineOtp()
                                                },
                                                enabled = !isBusy,
                                                modifier = Modifier.testTag("cancel_signup_otp_button")
                                            ) { Text(tr("Edit Details", "विवरण बदलें", lang), color = SlateSubtleText) }
                                        }
                                    }
                                }
                            }

                            if (signUpChannel == SignUpChannel.EMAIL) {
                                OutlinedTextField(
                                    value = email,
                                    onValueChange = { email = it },
                                    enabled = !isSignUpInlineOtpOpen,
                                    label = { Text(tr("Email ID", "ईमेल आईडी", lang)) },
                                    leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null, tint = RoyalBluePrimary) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                    modifier = Modifier.fillMaxWidth().testTag("email_input"),
                                    singleLine = true
                                )
                            } else {
                                OutlinedTextField(
                                    value = phoneDigits,
                                    onValueChange = { raw -> phoneDigits = raw.filter { it.isDigit() }.take(10) },
                                    enabled = !isSignUpInlineOtpOpen,
                                    label = { Text(tr("10-Digit Mobile No. (+91)", "10-अंकों का मोबाइल नंबर (+91)", lang)) },
                                    leadingIcon = { Icon(Icons.Filled.PhoneAndroid, contentDescription = null, tint = RoyalBluePrimary) },
                                    prefix = { Text("+91 ", fontWeight = FontWeight.Bold, color = RoyalBluePrimary) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    modifier = Modifier.fillMaxWidth().testTag("phone_number_input"),
                                    singleLine = true
                                )
                            }

                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it },
                                enabled = !isSignUpInlineOtpOpen,
                                label = { Text(tr("Create Password (6+ chars)", "पासवर्ड चुनें", lang)) },
                                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = RoyalBluePrimary) },
                                trailingIcon = {
                                    IconButton(
                                        onClick = { showPassword = !showPassword },
                                        modifier = Modifier.testTag("toggle_user_password_visibility")
                                    ) {
                                        Icon(
                                            if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                            contentDescription = if (showPassword) tr("Hide password", "पासवर्ड छिपाएं", lang) else tr("Show password", "पासवर्ड दिखाएं", lang)
                                        )
                                    }
                                },
                                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                modifier = Modifier.fillMaxWidth().testTag("password_input"),
                                singleLine = true
                            )

                            if (!isSignUpInlineOtpOpen) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .clickable { signUp18PlusAccepted = !signUp18PlusAccepted }
                                        .testTag("signup_18_plus_consent_row")
                                ) {
                                    Checkbox(
                                        checked = signUp18PlusAccepted,
                                        onCheckedChange = { signUp18PlusAccepted = it },
                                        colors = CheckboxDefaults.colors(checkedColor = RoyalBluePrimary),
                                        modifier = Modifier.testTag("signup_18_plus_checkbox")
                                    )
                                    Text(
                                        text = if (lang == AppLang.HI) {
                                            DilSePolicyText.SIGNUP_18_PLUS_CONSENT_HI
                                        } else {
                                            DilSePolicyText.SIGNUP_18_PLUS_CONSENT_EN
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SlateDarkText
                                    )
                                }

                                Button(
                                    onClick = {
                                        viewModel.beginSignUpWithChannel(
                                            channel = signUpChannel,
                                            emailRaw = email,
                                            tenDigitPhoneRaw = phoneDigits,
                                            password = password,
                                            activity = activity,
                                            fullNameRaw = signUpFullName
                                        )
                                    },
                                    enabled = !isBusy && lockoutSec == 0L && signUp18PlusAccepted,
                                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary, contentColor = Color.White),
                                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("continue_auth_button"),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    if (isBusy) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                    } else {
                                        Text(tr("Send OTP & Create Account", "OTP भेजें व खाता बनाएं", lang), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(
                                        onClick = { legalDialogTab = 0 },
                                        modifier = Modifier.testTag("signup_privacy_policy_link")
                                    ) { Text(tr("Privacy Policy", "गोपनीयता नीति", lang), style = MaterialTheme.typography.labelMedium, color = RoyalBluePrimary) }
                                    Text("•", color = SlateSubtleText)
                                    TextButton(
                                        onClick = { legalDialogTab = 1 },
                                        modifier = Modifier.testTag("signup_terms_link")
                                    ) { Text(tr("Terms", "नियम", lang), style = MaterialTheme.typography.labelMedium, color = RoyalBluePrimary) }
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(
                                        onClick = { legalDialogTab = 2 },
                                        modifier = Modifier.testTag("signup_child_safety_link")
                                    ) { Text(tr("Child Safety", "बाल सुरक्षा", lang), style = MaterialTheme.typography.labelMedium, color = RoyalBluePrimary) }
                                    Text("•", color = SlateSubtleText)
                                    TextButton(
                                        onClick = { legalDialogTab = 3 },
                                        modifier = Modifier.testTag("signup_medical_disclaimer_link")
                                    ) { Text(tr("Medical Disclaimer", "मेडिकल डिस्क्लेमर", lang), style = MaterialTheme.typography.labelMedium, color = RoyalBluePrimary) }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                }

                else -> {
                    // Clean Facebook-Style Pure White Login Screen
                    Spacer(Modifier.weight(0.35f))

                    Text(
                        text = "Dil Suno",
                        style = MaterialTheme.typography.displaySmall.copy(
                            fontSize = 38.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = (-0.5).sp
                        ),
                        color = RoyalBluePrimary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 22.dp)
                            .testTag("login_brand_title")
                    )

                    val trimmedId = signInIdentifier.trim()
                    val digitsOnly = trimmedId.filter { it.isDigit() }
                    val isPhoneInput = trimmedId.isNotEmpty() &&
                        !trimmedId.contains("@") &&
                        trimmedId.none { it.isLetter() } &&
                        digitsOnly.isNotEmpty()

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("launch_auth_card"),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Direct Email / Password Sign-In Fields
                        OutlinedTextField(
                            value = signInIdentifier,
                            onValueChange = { signInIdentifier = it },
                            label = { Text(tr("Email ID or Mobile No.", "ईमेल आईडी या मोबाइल नंबर", lang)) },
                            placeholder = { Text("name@example.com") },
                            leadingIcon = {
                                if (isPhoneInput) {
                                    Text("+91", fontWeight = FontWeight.Bold, color = RoyalBluePrimary, modifier = Modifier.padding(start = 10.dp))
                                } else {
                                    Icon(Icons.Filled.Email, contentDescription = null, tint = RoyalBluePrimary)
                                }
                            },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = if (isPhoneInput) KeyboardType.Phone else KeyboardType.Email
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("signin_identifier_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text(tr("Password", "पासवर्ड", lang)) },
                            leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = RoyalBluePrimary) },
                            trailingIcon = {
                                IconButton(
                                    onClick = { showPassword = !showPassword },
                                    modifier = Modifier.testTag("toggle_user_password_visibility")
                                ) {
                                    Icon(
                                        if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                        contentDescription = if (showPassword) tr("Hide password", "पासवर्ड छिपाएं", lang) else tr("Show password", "पासवर्ड दिखाएं", lang)
                                    )
                                }
                            },
                            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("password_input"),
                            singleLine = true
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = { showForgotPasswordDialog = true },
                                modifier = Modifier.heightIn(min = 40.dp).testTag("customer_forgot_password_button")
                            ) {
                                Text(
                                    text = tr("Forgot Password?", "पासवर्ड भूल गए?", lang),
                                    color = RoyalBluePrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        // 18+ & Community Guidelines Checkbox (Checked by Default)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clickable { signInConsentAccepted = !signInConsentAccepted }
                                .testTag("signup_18_plus_consent_row")
                        ) {
                            Checkbox(
                                checked = signInConsentAccepted,
                                onCheckedChange = { signInConsentAccepted = it },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = RoyalBluePrimary,
                                    uncheckedColor = SlateSubtleText
                                ),
                                modifier = Modifier.testTag("signup_18_plus_checkbox")
                            )
                            Text(
                                text = if (lang == AppLang.HI) {
                                    DilSePolicyText.SIGNUP_18_PLUS_CONSENT_HI
                                } else {
                                    DilSePolicyText.SIGNUP_18_PLUS_CONSENT_EN
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateDarkText
                            )
                        }

                        // Prominent Royal Blue #1877F2 "Sign In" Button
                        Button(
                            onClick = {
                                if (!signInConsentAccepted) {
                                    viewModel.reportAuthStatusMessage(
                                        tr(
                                            "Please accept the 18+ & Community Guidelines checkbox above to continue.",
                                            "आगे बढ़ने के लिए कृपया ऊपर 18+ और कम्युनिटी गाइडलाइंस चेकबॉक्स चुनें।",
                                            lang
                                        )
                                    )
                                    return@Button
                                }
                                viewModel.signInWithEmailOrPhoneAndPassword(signInIdentifier, password)
                            },
                            enabled = !isBusy && lockoutSec == 0L,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RoyalBluePrimary,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("continue_auth_button")
                        ) {
                            if (isBusy && !isGoogleSignInBusy) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = Color.White
                                )
                            } else {
                                Text(
                                    text = tr("Sign In", "साइन इन करें", lang),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        // Thin Divider Line
                        HorizontalDivider(
                            color = HairlineDividerBlue,
                            thickness = 1.dp,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                        )

                        // "Continue with Google" Button
                        Button(
                            onClick = {
                                if (!signInConsentAccepted) {
                                    viewModel.reportAuthStatusMessage(
                                        tr(
                                            "Please accept the 18+ & Community Guidelines checkbox above to continue.",
                                            "आगे बढ़ने के लिए कृपया ऊपर 18+ और कम्युनिटी गाइडलाइंस चेकबॉक्स चुनें।",
                                            lang
                                        )
                                    )
                                    return@Button
                                }
                                isGoogleSignInBusy = true
                                viewModel.clearMessage()
                                launchExplicitGoogleSignIn(
                                    context = activity ?: context,
                                    credentialManager = credentialManager,
                                    scope = scope,
                                    onSuccess = {
                                        isGoogleSignInBusy = false
                                        viewModel.handleGoogleSignInSuccess()
                                    },
                                    onCancelled = {
                                        isGoogleSignInBusy = false
                                    },
                                    onError = { errMsg ->
                                        isGoogleSignInBusy = false
                                        viewModel.reportAuthStatusMessage(errMsg)
                                    }
                                )
                            },
                            enabled = !isBusy && !isGoogleSignInBusy && lockoutSec == 0L,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RoyalBlueDeep,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("continue_with_google_button")
                        ) {
                            if (isGoogleSignInBusy) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = Color.White
                                )
                            } else {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Surface(
                                        color = Color.White,
                                        shape = CircleShape,
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "G",
                                                color = RoyalBluePrimary,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 14.sp
                                            )
                                        }
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Text(
                                        text = tr("Continue with Google", "Google से जारी रखें", lang),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }

                        // "Create Account" Button
                        OutlinedButton(
                            onClick = {
                                viewModel.clearMessage()
                                showCreateAccountScreen = true
                            },
                            enabled = !isBusy && lockoutSec == 0L,
                            border = BorderStroke(1.25.dp, RoyalBluePrimary),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = PureWhiteBackground,
                                contentColor = RoyalBluePrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("open_create_account_button")
                        ) {
                            Text(
                                text = tr("Create Account", "नया खाता बनाएं", lang),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = RoyalBluePrimary
                            )
                        }

                        // Subtle Login screen Terms & Policies Link
                        TextButton(
                            onClick = { legalDialogTab = 1 },
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("login_terms_policies_link")
                        ) {
                            Text(
                                text = tr(
                                    "Terms, Privacy & Legal Policies",
                                    "नियम, गोपनीयता व कानूनी नीतियाँ",
                                    lang
                                ),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = RoyalBluePrimary
                            )
                        }
                    }

                    Spacer(Modifier.weight(0.65f))

                    // Bottom Footer: "from" directly above bold "SHAKYA" (Facebook-style)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 20.dp, bottom = 12.dp)
                            .testTag("login_footer_shakya"),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "from",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Normal,
                            color = SlateMutedFooter,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "SHAKYA",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.5.sp,
                            color = RoyalBluePrimary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }

    if (showForgotPasswordDialog) {
        var resetIdentifier by remember { mutableStateOf(signInIdentifier.ifBlank { email }) }
        var resetVerificationCode by remember { mutableStateOf("") }
        var newPassword by remember { mutableStateOf("") }
        var showNewPassword by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = {
                viewModel.clearForgotPasswordState()
                showForgotPasswordDialog = false
            },
            title = { Text(tr("Reset Password", "पासवर्ड रीसेट करें", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = resetIdentifier,
                        onValueChange = { resetIdentifier = it },
                        label = { Text(tr("Registered Mobile No. or Email ID", "पंजीकृत मोबाइल नंबर या ईमेल आईडी", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                        modifier = Modifier.fillMaxWidth().testTag("forgot_password_email_input"),
                        singleLine = true
                    )

                    OutlinedButton(
                        onClick = { viewModel.sendForgotPasswordOtp(resetIdentifier) },
                        enabled = !isBusy,
                        modifier = Modifier.fillMaxWidth().testTag("send_forgot_password_otp_button")
                    ) {
                        Text(
                            if (resetOtpSent) tr("Resend Reset Link / OTP", "रीसेट लिंक / OTP फिर भेजें", lang)
                            else tr("Send Reset Link / OTP", "रीसेट लिंक / OTP भेजें", lang)
                        )
                    }

                    if (resetOtpSent && !resetUsesPreviewOtp) {
                        val targetEmail = resetResolvedEmail ?: resetIdentifier
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = tr(
                                    "Firebase password reset link sent to $targetEmail. Check your inbox to set a new password, then Sign In.",
                                    "$targetEmail पर पासवर्ड रीसेट लिंक भेजा गया है। अपना इनबॉक्स देखें और नया पासवर्ड सेट करें।",
                                    lang
                                ),
                                modifier = Modifier.padding(10.dp),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    } else if (resetOtpSent && resetUsesPreviewOtp) {
                        Surface(
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = tr(
                                    "Test Mode OTP: ${SecurityUtils.PREVIEW_TEST_MODE_OTP}",
                                    "टेस्ट मोड OTP: ${SecurityUtils.PREVIEW_TEST_MODE_OTP}",
                                    lang
                                ),
                                modifier = Modifier.padding(10.dp),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                        OutlinedTextField(
                            value = resetVerificationCode,
                            onValueChange = { input ->
                                resetVerificationCode = input.filter { it.isDigit() }.take(6)
                            },
                            label = { Text(tr("Enter 6-Digit OTP", "6-अंकों का OTP दर्ज करें", lang)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth().testTag("forgot_password_otp_input"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = newPassword,
                            onValueChange = { newPassword = it },
                            label = { Text(tr("New Password (6+ chars)", "नया पासवर्ड (6+ अक्षर)", lang)) },
                            leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                            trailingIcon = {
                                IconButton(
                                    onClick = { showNewPassword = !showNewPassword },
                                    modifier = Modifier.testTag("toggle_forgot_new_password_visibility")
                                ) {
                                    Icon(
                                        if (showNewPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                        contentDescription = if (showNewPassword) tr("Hide password", "पासवर्ड छिपाएं", lang) else tr("Show password", "पासवर्ड दिखाएं", lang)
                                    )
                                }
                            },
                            visualTransformation = if (showNewPassword) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth().testTag("forgot_new_password_input"),
                            singleLine = true
                        )
                    }
                }
            },
            confirmButton = {
                if (resetOtpSent && resetUsesPreviewOtp) {
                    Button(
                        onClick = {
                            viewModel.resetPasswordWithOtpOrRecovery(
                                identifierRaw = resetIdentifier,
                                verificationInput = resetVerificationCode,
                                newPassword = newPassword,
                                onSuccess = {
                                    if (resetIdentifier.isNotBlank()) {
                                        signInIdentifier = resetIdentifier.trim()
                                    }
                                    showForgotPasswordDialog = false
                                    password = ""
                                }
                            )
                        },
                        enabled = !isBusy,
                        modifier = Modifier.testTag("confirm_forgot_password_reset_button")
                    ) {
                        Text(tr("Update Password", "पासवर्ड बदलें", lang))
                    }
                } else {
                    Button(
                        onClick = {
                            viewModel.clearForgotPasswordState()
                            showForgotPasswordDialog = false
                        }
                    ) {
                        Text(tr("Done", "ठीक है", lang))
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        viewModel.clearForgotPasswordState()
                        showForgotPasswordDialog = false
                    }
                ) {
                    Text(tr("Cancel", "रद्द करें", lang))
                }
            }
        )
    }

    legalDialogTab?.let { tabIdx ->
        LegalPoliciesViewerDialog(
            initialTab = tabIdx,
            lang = lang,
            onDismiss = { legalDialogTab = null }
        )
    }
}

package com.dilsuno.app.data.repository

import com.dilsuno.app.core.SecurityUtils
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf

internal fun observeFirebaseAuthUser(): Flow<FirebaseUser?> = callbackFlow {
    val auth = Firebase.auth
    val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        trySend(firebaseAuth.currentUser)
    }
    auth.addAuthStateListener(listener)
    trySend(auth.currentUser)
    awaitClose { auth.removeAuthStateListener(listener) }
}

@OptIn(ExperimentalCoroutinesApi::class)
internal inline fun <T> authGatedFlow(
    defaultValue: T,
    crossinline predicate: (FirebaseUser) -> Boolean = { true },
    crossinline block: (FirebaseUser) -> Flow<T>
): Flow<T> = observeFirebaseAuthUser().flatMapLatest { user ->
    if (user != null && predicate(user)) {
        block(user)
    } else {
        flowOf(defaultValue)
    }
}

internal fun isVerifiedAdminUser(user: FirebaseUser): Boolean {
    val effectiveEmail = user.email?.trim()?.takeIf { it.isNotBlank() }
        ?: user.providerData.firstOrNull { !it.email.isNullOrBlank() }?.email?.trim()
    val effectiveVerified = user.isEmailVerified || user.providerData.any { it.providerId == "google.com" }
    return SecurityUtils.isVerifiedOwnerEmail(effectiveEmail, effectiveVerified)
}

package com.dilsuno.app.core

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File

class VoiceNoteHelper(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var activeFile: File? = null
    private var startMillis: Long = 0L

    fun startRecording(): Boolean {
        return try {
            stopRecording()
            val outFile = File(context.filesDir, "voice_${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(64000)
            r.setAudioSamplingRate(22050)
            r.setOutputFile(outFile.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            activeFile = outFile
            startMillis = System.currentTimeMillis()
            true
        } catch (e: Exception) {
            Log.w("VoiceNoteHelper", "Microphone recording unavailable: ${e.message}")
            recorder = null
            false
        }
    }

    fun stopRecording(): Pair<String, Long>? {
        val r = recorder ?: return null
        val file = activeFile
        val durationSec = ((System.currentTimeMillis() - startMillis) / 1000L).coerceIn(1L, 120L)
        return try {
            r.stop()
            r.release()
            recorder = null
            if (file != null && file.exists()) file.absolutePath to durationSec else null
        } catch (e: Exception) {
            Log.w("VoiceNoteHelper", "Failed to stop recording cleanly: ${e.message}")
            try { r.release() } catch (_: Exception) {}
            recorder = null
            null
        }
    }

    fun playVoiceNote(path: String, onComplete: () -> Unit) {
        stopPlayback()
        try {
            val file = File(path)
            if (!file.exists()) {
                onComplete()
                return
            }
            player = MediaPlayer().apply {
                setDataSource(path)
                prepare()
                setOnCompletionListener {
                    stopPlayback()
                    onComplete()
                }
                start()
            }
        } catch (e: Exception) {
            Log.w("VoiceNoteHelper", "Playback failed: ${e.message}")
            stopPlayback()
            onComplete()
        }
    }

    fun stopPlayback() {
        try {
            player?.stop()
            player?.release()
        } catch (_: Exception) {
        }
        player = null
    }
}

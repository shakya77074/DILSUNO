package com.dilsuno.app.ui.components

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.tr
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.VelvetIndigo
import com.dilsuno.app.viewmodel.MainAppViewModel
import java.util.Locale

/**
 * Free AI Voice Listener fallback powered by Firebase AI Logic (gemini-3.8-flash),
 * on-device Android SpeechRecognizer (voice input), and TextToSpeech (spoken replies).
 * Offered automatically when 0 human Staff Listeners are online.
 */
@Composable
fun FreeAiVoiceListenerDialog(
    viewModel: MainAppViewModel,
    lang: AppLang,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val messages by viewModel.aiListenerMessages.collectAsStateWithLifecycle()
    val isThinking by viewModel.isAiListenerThinking.collectAsStateWithLifecycle()
    val errorText by viewModel.aiListenerError.collectAsStateWithLifecycle()

    var inputText by remember { mutableStateOf("") }
    var speakReplies by remember { mutableStateOf(true) }
    var ttsEngine by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(context, lang) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val targetLocale = if (lang == AppLang.HI) Locale("hi", "IN") else Locale("en", "IN")
                engine?.language = targetLocale
            }
        }
        ttsEngine = engine
        onDispose {
            runCatching {
                engine?.stop()
                engine?.shutdown()
            }
            ttsEngine = null
        }
    }

    fun speakIfEnabled(reply: String) {
        if (speakReplies) {
            runCatching {
                ttsEngine?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "ai_listener_${System.currentTimeMillis()}")
            }
        }
    }

    val voiceInputLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?.trim()
            if (!spoken.isNullOrBlank()) {
                viewModel.sendAiVoiceListenerPrompt(spoken, lang) { reply ->
                    speakIfEnabled(reply)
                }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(min = 420.dp, max = 640.dp)
                .testTag("free_ai_voice_listener_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(VelvetIndigo.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = VelvetIndigo)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                text = tr("Free AI Voice Listener", "मुफ़्त AI वॉइस लिसनर", lang),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = tr("100% Anonymous • ₹0 Free Support", "100% गुमनाम • ₹0 मुफ़्त सहायता", lang),
                                style = MaterialTheme.typography.labelSmall,
                                color = SafeEmerald,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    IconButton(onClick = {
                        speakReplies = !speakReplies
                        if (!speakReplies) runCatching { ttsEngine?.stop() }
                    }) {
                        Icon(
                            imageVector = if (speakReplies) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                            contentDescription = "Toggle AI voice playback",
                            tint = if (speakReplies) VelvetIndigo else MaterialTheme.colorScheme.outline
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close AI Listener")
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = CrimsonPrimary.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = tr(
                            "In crisis or distress? Call India's free 24x7 helpline: Tele-MANAS: 14416",
                            "आपात स्थिति में भारत की मुफ़्त 24x7 हेल्पलाइन पर कॉल करें: Tele-MANAS: 14416",
                            lang
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        color = CrimsonPrimary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (messages.isEmpty()) {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(
                                    text = tr(
                                        "Tap the microphone to speak your heart out, or type below. I am listening patiently without judgement.",
                                        "अपनी बात बोलने के लिए माइक दबाएं या नीचे लिखें। मैं बिना किसी जजमेंट के ध्यान से सुन रहा हूँ।",
                                        lang
                                    ),
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }
                        }
                    }
                    items(messages, key = { it.id }) { msg ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (msg.isFromUser) Arrangement.End else Arrangement.Start
                        ) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (msg.isFromUser) CrimsonPrimary else VelvetIndigo.copy(alpha = 0.12f),
                                modifier = Modifier.fillMaxWidth(0.86f)
                            ) {
                                Text(
                                    text = msg.text,
                                    color = if (msg.isFromUser) Color.White else MaterialTheme.colorScheme.onSurface,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }
                    if (isThinking) {
                        item {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Text(
                                    tr("AI Listener is listening & preparing a warm reply...", "AI लिसनर सुन रहा है...", lang),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                if (!errorText.isNullOrBlank()) {
                    Text(
                        text = errorText!!,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (lang == AppLang.HI) "hi-IN" else "en-IN")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, tr("Speak freely...", "खुलकर बोलें...", lang))
                            }
                            runCatching { voiceInputLauncher.launch(intent) }
                        },
                        enabled = !isThinking,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(CrimsonPrimary)
                            .testTag("ai_listener_mic_button")
                    ) {
                        Icon(Icons.Filled.Mic, contentDescription = "Speak to AI Listener", tint = Color.White)
                    }

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text(tr("Or type here...", "या यहाँ लिखें...", lang)) },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_listener_text_input")
                    )

                    IconButton(
                        onClick = {
                            val msg = inputText.trim()
                            if (msg.isNotBlank()) {
                                inputText = ""
                                viewModel.sendAiVoiceListenerPrompt(msg, lang) { reply ->
                                    speakIfEnabled(reply)
                                }
                            }
                        },
                        enabled = !isThinking && inputText.isNotBlank(),
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(VelvetIndigo)
                            .testTag("ai_listener_send_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send to AI Listener", tint = Color.White)
                    }
                }
            }
        }
    }
}

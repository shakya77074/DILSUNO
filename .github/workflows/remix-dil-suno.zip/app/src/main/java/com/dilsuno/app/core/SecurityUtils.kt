package com.dilsuno.app.core

import android.content.Context
import android.os.Build
import com.dilsuno.app.BuildConfig
import java.security.MessageDigest
import java.security.SecureRandom

object SecurityUtils {
    const val OWNER_EMAIL = "anoopshakya0563@gmail.com"
    const val OWNER_PHONE_10 = "8076451007"
    const val OWNER_PHONE_E164 = "+918076451007"

    // Dedicated Google Play Console Reviewer Demo Account (Pre-funded ₹500 test wallet credits)
    const val REVIEWER_DEMO_EMAIL = "reviewer@dilsuno.com"
    const val REVIEWER_DEMO_UID = "play_reviewer_demo_uid"
    const val REVIEWER_INITIAL_CREDITS_INR = 500L
    private const val REVIEWER_DEMO_PASS_PART_A = "ReviewUser@"
    private const val REVIEWER_DEMO_PASS_PART_B = "2026"

    fun reviewerDemoPasswordForAdmin(): String = REVIEWER_DEMO_PASS_PART_A + REVIEWER_DEMO_PASS_PART_B

    const val MAX_FAILED_LOGIN_ATTEMPTS = 5
    const val MAX_OWNER_FAILED_ATTEMPTS = 3
    const val OWNER_FREEZE_DURATION_MS = 15L * 60_000L // 15 min owner freeze on 3 wrong attempts
    const val LOCKOUT_DURATION_MS = 60_000L
    const val MAX_MEDIA_UPLOAD_BYTES = 25L * 1024L * 1024L // 25 MB

    val ALLOWED_IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp")
    val ALLOWED_VIDEO_EXTENSIONS = setOf("mp4", "mov")
    val ALLOWED_AUDIO_EXTENSIONS = setOf("mp3", "m4a", "aac", "wav", "ogg", "flac")
    val ALLOWED_IMAGE_MIME_TYPES = setOf("image/jpeg", "image/jpg", "image/png", "image/webp")
    val ALLOWED_VIDEO_MIME_TYPES = setOf("video/mp4", "video/quicktime")
    val ALLOWED_AUDIO_MIME_TYPES = setOf(
        "audio/mpeg",
        "audio/mp3",
        "audio/mp4",
        "audio/m4a",
        "audio/aac",
        "audio/x-m4a",
        "audio/wav",
        "audio/x-wav",
        "audio/ogg",
        "audio/flac"
    )

    val BLOCKED_DANGEROUS_EXTENSIONS = setOf(
        "apk", "exe", "sh", "bat", "cmd", "msi", "js", "mjs", "cjs",
        "html", "htm", "xhtml", "svg", "zip", "rar", "7z", "tar", "gz",
        "jar", "dex", "so", "php", "py", "rb", "pl", "vbs", "ps1", "scr",
        "com", "pif", "dll", "sys", "bin", "iso", "dmg", "deb", "rpm"
    )

    private val SCRIPT_BLOCK_REGEX = Regex("(?is)<\\s*(script|style|iframe|object|embed|svg)[^>]*>.*?</\\s*\\1\\s*>")
    private val HTML_TAG_REGEX = Regex("(?is)<[^>]+>")
    private val HTML_ENTITY_TAG_REGEX = Regex("(?i)(&lt;|&gt;|&#x0*3c;|&#0*60;|&#x0*3e;|&#0*62;)")
    private val DANGEROUS_SCHEME_REGEX = Regex("(?i)(javascript:|vbscript:|data:\\s*text/html|data:\\s*application/|file://|blob:)")
    private val EVENT_HANDLER_REGEX = Regex("(?i)\\bon[a-z]{2,20}\\s*=")
    private val DANGEROUS_LINK_REGEX = Regex(
        "(?i)(https?://\\S+\\.(?:apk|exe|sh|bat|cmd|msi|js|mjs|cjs|html|htm|xhtml|svg|zip|rar|7z|tar|gz|jar|dex|so|php|py|vbs|ps1|scr)(?:[?#]\\S*)?)"
    )

    fun isVerifiedOwnerEmail(email: String?, isEmailVerified: Boolean?): Boolean {
        val cleaned = email?.trim().orEmpty()
        return isEmailVerified == true && cleaned.equals(OWNER_EMAIL, ignoreCase = true)
    }

    fun isOwnerEmail(email: String?): Boolean {
        return email?.trim()?.equals(OWNER_EMAIL, ignoreCase = true) == true
    }

    fun isOwnerPhone(rawPhone: String?): Boolean {
        val normalized = rawPhone?.let { normalizeIndianPhoneE164(it) } ?: return false
        return normalized == OWNER_PHONE_E164
    }

    fun isOwnerIdentifier(rawIdentifier: String?): Boolean {
        val trimmed = rawIdentifier?.trim().orEmpty()
        if (trimmed.isEmpty()) return false
        return isOwnerEmail(trimmed) || isOwnerPhone(trimmed)
    }

    fun isReviewerDemoEmail(email: String?): Boolean {
        return email?.trim()?.equals(REVIEWER_DEMO_EMAIL, ignoreCase = true) == true
    }

    fun verifyReviewerDemoCredentials(emailRaw: String, passwordRaw: String): Boolean {
        if (!isReviewerDemoEmail(emailRaw)) return false
        val expected = REVIEWER_DEMO_PASS_PART_A + REVIEWER_DEMO_PASS_PART_B
        return constantTimeEquals(passwordRaw, expected)
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        return MessageDigest.isEqual(
            a.toByteArray(Charsets.UTF_8),
            b.toByteArray(Charsets.UTF_8)
        )
    }

    fun sanitizeInput(raw: String, maxLength: Int = 500): String {
        var cleaned = raw.replace(Regex("[\\u0000-\\u001F\\u007F]"), "")
        cleaned = SCRIPT_BLOCK_REGEX.replace(cleaned, "")
        cleaned = HTML_TAG_REGEX.replace(cleaned, "")
        cleaned = HTML_ENTITY_TAG_REGEX.replace(cleaned, "")
        cleaned = DANGEROUS_SCHEME_REGEX.replace(cleaned, "")
        cleaned = EVENT_HANDLER_REGEX.replace(cleaned, "")
        cleaned = DANGEROUS_LINK_REGEX.replace(cleaned, "[blocked-link]")
        cleaned = cleaned.replace("<", "").replace(">", "")
        return cleaned
            .replace(Regex("\\s{2,}"), " ")
            .trim()
            .take(maxLength)
    }

    fun extractFileExtension(nameOrUri: String?): String? {
        if (nameOrUri.isNullOrBlank()) return null
        val noFragment = nameOrUri.substringBefore('#').substringBefore('?')
        val lastSegment = noFragment.substringAfterLast('/').trim()
        if (!lastSegment.contains('.')) return null
        val ext = lastSegment.substringAfterLast('.', "").lowercase()
        return ext.takeIf { it.isNotBlank() && it.length <= 10 }
    }

    fun validateMediaDescriptor(
        fileNameOrUri: String?,
        mimeType: String?,
        sizeBytes: Long?,
        allowVideo: Boolean = true,
        lang: AppLang = AppLang.EN
    ): Result<Unit> {
        val raw = fileNameOrUri?.trim().orEmpty()
        val ext = extractFileExtension(raw)
        val mime = mimeType?.trim()?.lowercase()?.substringBefore(';')?.takeIf { it.isNotBlank() }

        if (raw.isNotBlank() && (DANGEROUS_SCHEME_REGEX.containsMatchIn(raw) || raw.contains("<") || raw.contains(">"))) {
            return Result.failure(
                SecurityException(
                    tr(
                        "Blocked unsafe media source for security protection.",
                        "सुरक्षा के लिए असुरक्षित मीडिया लिंक ब्लॉक किया गया।",
                        lang
                    )
                )
            )
        }

        if (ext != null && ext in BLOCKED_DANGEROUS_EXTENSIONS) {
            return Result.failure(
                SecurityException(
                    tr(
                        "Blocked dangerous file (.$ext). Executable, script, or archive files are strictly prohibited.",
                        "खतरनाक फ़ाइल (.$ext) ब्लॉक की गई। APK, EXE, स्क्रिप्ट या ZIP फ़ाइलें सख़्त वर्जित हैं।",
                        lang
                    )
                )
            )
        }

        val allowedExtensions = if (allowVideo) {
            ALLOWED_IMAGE_EXTENSIONS + ALLOWED_VIDEO_EXTENSIONS
        } else {
            ALLOWED_IMAGE_EXTENSIONS
        }
        val allowedMimes = if (allowVideo) {
            ALLOWED_IMAGE_MIME_TYPES + ALLOWED_VIDEO_MIME_TYPES
        } else {
            ALLOWED_IMAGE_MIME_TYPES
        }

        if (ext != null && ext !in allowedExtensions) {
            val allowedLabel = if (allowVideo) ".jpg, .jpeg, .png, .webp, .mp4, .mov" else ".jpg, .jpeg, .png, .webp"
            return Result.failure(
                IllegalArgumentException(
                    tr(
                        "Unsupported file format (.$ext). Only $allowedLabel files are allowed.",
                        "अमान्य फ़ाइल फ़ॉर्मेट (.$ext)। केवल $allowedLabel फ़ाइलें मान्य हैं।",
                        lang
                    )
                )
            )
        }

        if (mime != null && mime !in allowedMimes) {
            val allowedLabel = if (allowVideo) "JPG, JPEG, PNG, WEBP, MP4, MOV" else "JPG, JPEG, PNG, WEBP"
            return Result.failure(
                IllegalArgumentException(
                    tr(
                        "Blocked file type ($mime). Only safe $allowedLabel media files are permitted.",
                        "अमान्य फ़ाइल प्रकार ($mime)। केवल सुरक्षित $allowedLabel फ़ाइलें अपलोड की जा सकती हैं।",
                        lang
                    )
                )
            )
        }

        if (ext == null && mime == null) {
            return Result.failure(
                IllegalArgumentException(
                    tr(
                        "Could not verify media format. Upload rejected for malware protection.",
                        "फ़ाइल फ़ॉर्मेट सत्यापित नहीं हो सका। सुरक्षा कारणों से अपलोड रोका गया।",
                        lang
                    )
                )
            )
        }

        if (sizeBytes != null && sizeBytes > MAX_MEDIA_UPLOAD_BYTES) {
            val mb = sizeBytes / (1024.0 * 1024.0)
            return Result.failure(
                IllegalArgumentException(
                    tr(
                        "File too large (${"%.1f".format(mb)} MB). Maximum allowed size is 25 MB.",
                        "फ़ाइल बहुत बड़ी है (${"%.1f".format(mb)} MB)। अधिकतम सीमा 25 MB है।",
                        lang
                    )
                )
            )
        }

        return Result.success(Unit)
    }

    fun isSafeMediaUri(
        uri: String?,
        allowVideo: Boolean = true,
        allowVoiceNotePath: Boolean = false
    ): Boolean {
        if (uri.isNullOrBlank()) return true
        val cleaned = uri.trim()
        if (cleaned.length > 600) return false
        if (DANGEROUS_SCHEME_REGEX.containsMatchIn(cleaned) || cleaned.contains("<") || cleaned.contains(">")) {
            return false
        }
        val ext = extractFileExtension(cleaned)
        if (ext != null && ext in BLOCKED_DANGEROUS_EXTENSIONS) {
            return false
        }
        if (allowVoiceNotePath && ext == "m4a" && cleaned.startsWith("/")) {
            return !cleaned.contains("..")
        }
        val hasSafeScheme = cleaned.startsWith("content://", ignoreCase = true) ||
            cleaned.startsWith("file:///", ignoreCase = true) ||
            cleaned.startsWith("https://", ignoreCase = true)
        if (!hasSafeScheme) return false

        val allowedExts = if (allowVideo) {
            ALLOWED_IMAGE_EXTENSIONS + ALLOWED_VIDEO_EXTENSIONS
        } else {
            ALLOWED_IMAGE_EXTENSIONS
        }
        return ext == null || ext in allowedExts
    }

    const val PREVIEW_TEST_MODE_OTP = "123456"

    fun isValidEmail(email: String): Boolean {
        val cleaned = email.trim()
        return cleaned.contains("@") && cleaned.contains(".") && cleaned.length in 5..150
    }

    fun normalizeEmail(email: String): String = email.trim().lowercase()

    fun isValidStaffPin(pin: String): Boolean {
        val cleaned = pin.trim()
        return cleaned.length in 6..16 && cleaned.all { it.isDigit() }
    }

    fun staffDocIdFromEmail(email: String): String {
        val normalized = normalizeEmail(email)
        val localPart = normalized.substringBefore("@")
            .replace(Regex("[^a-z0-9]"), "_")
            .replace(Regex("_+"), "_")
            .trim('_')
            .take(24)
            .ifBlank { "staff" }
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(normalized.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
            .take(10)
        return "${localPart}_${digest}"
    }

    fun normalizeIndianPhoneE164(phone: String): String? {
        val digits = phone.filter { it.isDigit() }
        val clean10 = when {
            digits.length == 10 -> digits
            digits.length == 12 && digits.startsWith("91") -> digits.drop(2)
            digits.length == 11 && digits.startsWith("0") -> digits.drop(1)
            else -> return null
        }
        return if (clean10.length == 10) "+91$clean10" else null
    }

    private const val PHONE_ALIAS_DOMAIN = "@phone.dilsuno.app"

    fun phoneLoginAliasEmail(e164Phone: String): String {
        val digits = e164Phone.filter { it.isDigit() }
        return "u$digits$PHONE_ALIAS_DOMAIN"
    }

    fun isPhoneLoginAliasEmail(email: String?): Boolean {
        val cleaned = email?.trim()?.lowercase().orEmpty()
        return cleaned.endsWith(PHONE_ALIAS_DOMAIN)
    }

    fun sha256Hex(input: String): String {
        return MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    fun isValidPhone(phone: String): Boolean {
        val digits = phone.filter { it.isDigit() }
        return digits.length in 10..13
    }

    fun isAcceptablePassword(password: String): Boolean {
        return password.length >= 6
    }

    fun isStrongPassword(password: String): Boolean {
        if (password.length < 8) return false
        val hasLetter = password.any { it.isLetter() }
        val hasDigit = password.any { it.isDigit() }
        return hasLetter && hasDigit
    }

    fun deriveDisplayNameFromEmail(email: String): String {
        val local = email.trim().substringBefore("@")
            .replace('.', ' ')
            .replace('_', ' ')
            .replace('-', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
        val titled = local.split(" ")
            .filter { it.isNotBlank() }
            .joinToString(" ") { part ->
                part.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
            }
        return sanitizeInput(titled, 100).takeIf { it.length >= 2 } ?: "Dil Suno Member"
    }

    fun generateSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun hashPassword(password: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest("$salt:$password".toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun verifyPassword(password: String, salt: String, expectedHash: String): Boolean {
        if (salt.isBlank() || expectedHash.isBlank()) return false
        return constantTimeEquals(hashPassword(password, salt), expectedHash)
    }

    fun generateOtp(): String {
        val num = SecureRandom().nextInt(900000) + 100000
        return num.toString()
    }

    fun resolveDisplayName(
        primary: String?,
        secondary: String? = null,
        fallback: String = "Dil Suno Member"
    ): String {
        val first = primary?.trim()?.takeIf { it.isNotBlank() && !it.contains("@") }
        if (first != null) return sanitizeInput(first, 100).ifBlank { fallback }
        val second = secondary?.trim()?.takeIf { it.isNotBlank() && !it.contains("@") }
        if (second != null) return sanitizeInput(second, 100).ifBlank { fallback }
        return fallback
    }

    fun isNewerVersionAvailable(
        currentVersionCode: Int,
        currentVersionName: String,
        latestVersionCode: Long,
        latestVersionName: String?
    ): Boolean {
        if (latestVersionCode > currentVersionCode.toLong()) return true
        val targetName = latestVersionName?.trim().orEmpty()
        if (targetName.isBlank()) return false
        val currentParts = currentVersionName.trim().split(".").map { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
        val targetParts = targetName.split(".").map { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
        val maxLen = maxOf(currentParts.size, targetParts.size)
        for (i in 0 until maxLen) {
            val c = currentParts.getOrElse(i) { 0 }
            val t = targetParts.getOrElse(i) { 0 }
            if (t > c) return true
            if (t < c) return false
        }
        return false
    }

    const val PREVIEW_PACKAGE_NAME = "com.aistudio.applet.ecpfut"
    val TRUSTED_APP_PACKAGES = setOf(
        "com.dilsuno.app",
        PREVIEW_PACKAGE_NAME,
        BuildConfig.APPLICATION_ID
    )

    fun isTrustedAppPackage(packageName: String?): Boolean {
        val clean = packageName?.trim().orEmpty()
        if (clean.isEmpty()) return false
        return clean in TRUSTED_APP_PACKAGES || clean.startsWith("com.aistudio.applet.")
    }

    fun isVirtualOrEmulatorPreviewRuntime(): Boolean {
        val fingerprint = Build.FINGERPRINT.orEmpty().lowercase()
        val model = Build.MODEL.orEmpty().lowercase()
        val manufacturer = Build.MANUFACTURER.orEmpty().lowercase()
        val brand = Build.BRAND.orEmpty().lowercase()
        val device = Build.DEVICE.orEmpty().lowercase()
        val product = Build.PRODUCT.orEmpty().lowercase()
        val hardware = Build.HARDWARE.orEmpty().lowercase()

        if (fingerprint == "robolectric" || BuildConfig.DEBUG) return true

        return fingerprint.startsWith("generic") ||
            fingerprint.startsWith("unknown") ||
            fingerprint.contains("emulator") ||
            fingerprint.contains("test-keys") ||
            model.contains("google_sdk") ||
            model.contains("emulator") ||
            model.contains("android sdk built for x86") ||
            model.contains("sdk_gphone") ||
            manufacturer.contains("genymotion") ||
            hardware.contains("goldfish") ||
            hardware.contains("ranchu") ||
            hardware.contains("cutf86") ||
            product.contains("sdk_gphone") ||
            product.contains("vbox86p") ||
            product.contains("emulator") ||
            (brand.startsWith("generic") && device.startsWith("generic")) ||
            device.contains("emulator") ||
            device.contains("vsoc")
    }

    fun resolveRuntimeSecurityReport(
        context: Context,
        rawReport: DeviceSecurityReport
    ): DeviceSecurityReport {
        val packageTrusted = isTrustedAppPackage(context.packageName)
        val virtualOrPreviewRuntime = rawReport.isEmulator || isVirtualOrEmulatorPreviewRuntime()
        val effectiveCloned = rawReport.isCloned && !packageTrusted
        val filteredReasons = rawReport.reasons.filterNot { reason ->
            (packageTrusted && reason.contains("Cloned APK package", ignoreCase = true)) ||
                (virtualOrPreviewRuntime && (
                    reason.contains("Virtual/Emulator", ignoreCase = true) ||
                        reason.contains("Rooted device", ignoreCase = true)
                    ))
        }
        val effectiveShouldHardBlock = if (virtualOrPreviewRuntime) {
            false
        } else {
            effectiveCloned || rawReport.isRooted
        }
        return rawReport.copy(
            isCloned = effectiveCloned,
            reasons = filteredReasons,
            shouldHardBlock = effectiveShouldHardBlock
        )
    }
}

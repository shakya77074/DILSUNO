package com.dilsuno.app.core

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.dilsuno.app.data.model.StaffAccount
import com.dilsuno.app.data.model.StaffDirectoryEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dilSunoPrefs: DataStore<Preferences> by preferencesDataStore(name = "dil_suno_prefs")

data class PreviewUserCredential(
    val email: String,
    val passwordHash: String,
    val passwordSalt: String,
    val fullName: String,
    val uid: String,
    val phone: String? = null
)

data class PreviewStaffCredential(
    val staffEmail: String,
    val staffUsername: String,
    val displayName: String,
    val pinHash: String,
    val pinSalt: String,
    val isActive: Boolean,
    val staffRole: String = "listener"
)

class RateLimiterStore(private val context: Context) {
    private val failedAttemptsKey = intPreferencesKey("failed_login_attempts")
    private val lockoutUntilKey = longPreferencesKey("lockout_until_millis")
    private val languageKey = stringPreferencesKey("app_language")
    private val previewUsersKey = stringPreferencesKey("preview_users_json")
    private val previewStaffKey = stringPreferencesKey("preview_staff_json")
    private val walletBalancesKey = stringPreferencesKey("wallet_balances_json")
    private val localAdminRevenueKey = longPreferencesKey("local_admin_split_revenue_inr")
    private val activeSessionTokenKey = stringPreferencesKey("active_device_session_token")
    private val ownerFailedAttemptsKey = intPreferencesKey("owner_failed_attempts")
    private val ownerFreezeUntilKey = longPreferencesKey("owner_freeze_until_millis")
    private val staffRulesAcceptedJsonKey = stringPreferencesKey("staff_rules_accepted_json")
    private val staffGoldenRulesJsonKey = stringPreferencesKey("staff_golden_rules_json")
    private val localPromoVideosJsonKey = stringPreferencesKey("local_promo_videos_json")
    private val blockedUsersJsonKey = stringPreferencesKey("blocked_users_json")
    private val communityGuidelinesJsonKey = stringPreferencesKey("community_guidelines_18plus_json")
    private val savedPostsJsonKey = stringPreferencesKey("saved_posts_json")
    private val allowFriendChatJsonKey = stringPreferencesKey("allow_friend_chat_json")
    private val shareCountsJsonKey = stringPreferencesKey("user_share_counts_json")
    private val reviewerDemoEnabledKey = booleanPreferencesKey("reviewer_demo_enabled")
    private val customMusicTracksJsonKey = stringPreferencesKey("custom_music_tracks_json")

    val languageFlow: Flow<AppLang> = context.dilSunoPrefs.data.map { prefs ->
        if (prefs[languageKey] == "HI") AppLang.HI else AppLang.EN
    }

    val customMusicTracksJsonFlow: Flow<String?> = context.dilSunoPrefs.data.map { prefs ->
        prefs[customMusicTracksJsonKey]?.takeIf { it.isNotBlank() }
    }

    suspend fun setCustomMusicTracksJson(json: String?) {
        context.dilSunoPrefs.edit { prefs ->
            if (json.isNullOrBlank()) prefs.remove(customMusicTracksJsonKey)
            else prefs[customMusicTracksJsonKey] = json
        }
    }

    val reviewerDemoEnabledFlow: Flow<Boolean> = context.dilSunoPrefs.data.map { prefs ->
        prefs[reviewerDemoEnabledKey] ?: true
    }

    suspend fun isReviewerDemoEnabled(): Boolean {
        return context.dilSunoPrefs.data.first()[reviewerDemoEnabledKey] ?: true
    }

    suspend fun setReviewerDemoEnabled(enabled: Boolean) {
        context.dilSunoPrefs.edit { prefs ->
            prefs[reviewerDemoEnabledKey] = enabled
        }
    }

    val lockoutUntilFlow: Flow<Long> = context.dilSunoPrefs.data.map { prefs ->
        prefs[lockoutUntilKey] ?: 0L
    }

    val failedAttemptsFlow: Flow<Int> = context.dilSunoPrefs.data.map { prefs ->
        prefs[failedAttemptsKey] ?: 0
    }

    val activeSessionTokenFlow: Flow<String?> = context.dilSunoPrefs.data.map { prefs ->
        prefs[activeSessionTokenKey]?.takeIf { it.isNotBlank() }
    }

    val ownerFreezeUntilFlow: Flow<Long> = context.dilSunoPrefs.data.map { prefs ->
        prefs[ownerFreezeUntilKey] ?: 0L
    }

    val previewStaffAccountsFlow: Flow<List<StaffAccount>> = context.dilSunoPrefs.data.map { prefs ->
        parsePreviewStaffList(prefs[previewStaffKey]).map { entry ->
            StaffAccount(
                staffUsername = entry.staffUsername,
                staffEmail = entry.staffEmail,
                displayName = entry.displayName,
                isActive = entry.isActive,
                staffRole = entry.staffRole
            )
        }
    }

    fun observeBlockedUserUids(uid: String): Flow<Set<String>> = context.dilSunoPrefs.data.map { prefs ->
        runCatching {
            val obj = JSONObject(prefs[blockedUsersJsonKey] ?: "{}")
            val arr = obj.optJSONArray(uid) ?: return@runCatching emptySet<String>()
            (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }.toSet()
        }.getOrDefault(emptySet())
    }

    suspend fun addBlockedUserUid(uid: String, targetUid: String) {
        if (targetUid.isBlank()) return
        context.dilSunoPrefs.edit { prefs ->
            val obj = runCatching { JSONObject(prefs[blockedUsersJsonKey] ?: "{}") }.getOrDefault(JSONObject())
            val existing = obj.optJSONArray(uid) ?: JSONArray()
            val set = LinkedHashSet<String>()
            for (i in 0 until existing.length()) {
                existing.optString(i).takeIf { it.isNotBlank() }?.let { set.add(it) }
            }
            set.add(targetUid)
            obj.put(uid, JSONArray(set.toList()))
            prefs[blockedUsersJsonKey] = obj.toString()
        }
    }

    suspend fun removeBlockedUserUid(uid: String, targetUid: String) {
        if (targetUid.isBlank()) return
        context.dilSunoPrefs.edit { prefs ->
            val obj = runCatching { JSONObject(prefs[blockedUsersJsonKey] ?: "{}") }.getOrDefault(JSONObject())
            val existing = obj.optJSONArray(uid) ?: JSONArray()
            val set = LinkedHashSet<String>()
            for (i in 0 until existing.length()) {
                existing.optString(i).takeIf { it.isNotBlank() && it != targetUid }?.let { set.add(it) }
            }
            obj.put(uid, JSONArray(set.toList()))
            prefs[blockedUsersJsonKey] = obj.toString()
        }
    }

    fun observeSavedPostIds(uid: String): Flow<Set<String>> = context.dilSunoPrefs.data.map { prefs ->
        runCatching {
            val obj = JSONObject(prefs[savedPostsJsonKey] ?: "{}")
            val arr = obj.optJSONArray(uid) ?: return@runCatching emptySet<String>()
            (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }.toSet()
        }.getOrDefault(emptySet())
    }

    suspend fun toggleSavedPostId(uid: String, postId: String): Boolean {
        if (postId.isBlank()) return false
        var nowSaved = false
        context.dilSunoPrefs.edit { prefs ->
            val obj = runCatching { JSONObject(prefs[savedPostsJsonKey] ?: "{}") }.getOrDefault(JSONObject())
            val existing = obj.optJSONArray(uid) ?: JSONArray()
            val set = LinkedHashSet<String>()
            for (i in 0 until existing.length()) {
                existing.optString(i).takeIf { it.isNotBlank() }?.let { set.add(it) }
            }
            nowSaved = if (set.contains(postId)) {
                set.remove(postId)
                false
            } else {
                set.add(postId)
                true
            }
            obj.put(uid, JSONArray(set.toList()))
            prefs[savedPostsJsonKey] = obj.toString()
        }
        return nowSaved
    }

    fun observeAllowFriendChat(uid: String): Flow<Boolean> = context.dilSunoPrefs.data.map { prefs ->
        runCatching {
            JSONObject(prefs[allowFriendChatJsonKey] ?: "{}").optBoolean(uid, true)
        }.getOrDefault(true)
    }

    suspend fun setAllowFriendChat(uid: String, allow: Boolean) {
        context.dilSunoPrefs.edit { prefs ->
            val obj = runCatching { JSONObject(prefs[allowFriendChatJsonKey] ?: "{}") }.getOrDefault(JSONObject())
            obj.put(uid, allow)
            prefs[allowFriendChatJsonKey] = obj.toString()
        }
    }

    fun observeLocalShareCount(uid: String): Flow<Long> = context.dilSunoPrefs.data.map { prefs ->
        runCatching {
            JSONObject(prefs[shareCountsJsonKey] ?: "{}").optLong(uid, 0L)
        }.getOrDefault(0L)
    }

    suspend fun incrementLocalShareCount(uid: String): Long {
        var next = 0L
        context.dilSunoPrefs.edit { prefs ->
            val obj = runCatching { JSONObject(prefs[shareCountsJsonKey] ?: "{}") }.getOrDefault(JSONObject())
            next = obj.optLong(uid, 0L) + 1L
            obj.put(uid, next)
            prefs[shareCountsJsonKey] = obj.toString()
        }
        return next
    }

    fun observeCommunityGuidelinesAccepted(uid: String): Flow<Boolean> = context.dilSunoPrefs.data.map { prefs ->
        runCatching {
            JSONObject(prefs[communityGuidelinesJsonKey] ?: "{}").optBoolean(uid, false)
        }.getOrDefault(false)
    }

    suspend fun setCommunityGuidelinesAccepted(uid: String, accepted: Boolean) {
        context.dilSunoPrefs.edit { prefs ->
            val obj = runCatching { JSONObject(prefs[communityGuidelinesJsonKey] ?: "{}") }.getOrDefault(JSONObject())
            obj.put(uid, accepted)
            prefs[communityGuidelinesJsonKey] = obj.toString()
        }
    }

    val localAdminRevenueFlow: Flow<Long> = context.dilSunoPrefs.data.map { prefs ->
        prefs[localAdminRevenueKey] ?: 0L
    }

    fun observeLocalWalletBalance(uid: String): Flow<Long?> = context.dilSunoPrefs.data.map { prefs ->
        val raw = prefs[walletBalancesKey] ?: return@map null
        runCatching {
            val obj = JSONObject(raw)
            if (obj.has(uid)) obj.getLong(uid) else null
        }.getOrNull()
    }

    suspend fun setLocalWalletBalance(uid: String, amountInr: Long) {
        val safe = amountInr.coerceAtLeast(0L)
        context.dilSunoPrefs.edit { prefs ->
            val obj = runCatching { JSONObject(prefs[walletBalancesKey] ?: "{}") }.getOrDefault(JSONObject())
            obj.put(uid, safe)
            prefs[walletBalancesKey] = obj.toString()
        }
    }

    suspend fun adjustLocalWalletBalance(uid: String, deltaInr: Long): Long {
        var updated = 0L
        context.dilSunoPrefs.edit { prefs ->
            val obj = runCatching { JSONObject(prefs[walletBalancesKey] ?: "{}") }.getOrDefault(JSONObject())
            val current = obj.optLong(uid, 0L)
            updated = (current + deltaInr).coerceAtLeast(0L)
            obj.put(uid, updated)
            prefs[walletBalancesKey] = obj.toString()
        }
        return updated
    }

    suspend fun addLocalAdminRevenue(amountInr: Long) {
        if (amountInr <= 0L) return
        context.dilSunoPrefs.edit { prefs ->
            prefs[localAdminRevenueKey] = (prefs[localAdminRevenueKey] ?: 0L) + amountInr
        }
    }

    suspend fun setLanguage(lang: AppLang) {
        context.dilSunoPrefs.edit { it[languageKey] = lang.name }
    }

    suspend fun recordFailedAttempt(): Pair<Int, Long> {
        var newAttempts = 0
        var lockoutUntil = 0L
        context.dilSunoPrefs.edit { prefs ->
            val current = (prefs[failedAttemptsKey] ?: 0) + 1
            newAttempts = current
            if (current >= SecurityUtils.MAX_FAILED_LOGIN_ATTEMPTS) {
                lockoutUntil = System.currentTimeMillis() + SecurityUtils.LOCKOUT_DURATION_MS
                prefs[lockoutUntilKey] = lockoutUntil
                prefs[failedAttemptsKey] = 0
            } else {
                prefs[failedAttemptsKey] = current
            }
        }
        return newAttempts to lockoutUntil
    }

    suspend fun clearFailedAttempts() {
        context.dilSunoPrefs.edit { prefs ->
            prefs[failedAttemptsKey] = 0
            prefs[lockoutUntilKey] = 0L
        }
    }

    suspend fun getRemainingLockoutMs(): Long {
        val until = context.dilSunoPrefs.data.first()[lockoutUntilKey] ?: 0L
        val diff = until - System.currentTimeMillis()
        return if (diff > 0) diff else 0L
    }

    suspend fun setActiveSessionToken(token: String?) {
        context.dilSunoPrefs.edit { prefs ->
            if (token.isNullOrBlank()) prefs.remove(activeSessionTokenKey)
            else prefs[activeSessionTokenKey] = token
        }
    }

    suspend fun getActiveSessionToken(): String? {
        return context.dilSunoPrefs.data.first()[activeSessionTokenKey]?.takeIf { it.isNotBlank() }
    }

    suspend fun recordOwnerFailedAttempt(): Pair<Int, Long> {
        var newAttempts = 0
        var freezeUntil = 0L
        context.dilSunoPrefs.edit { prefs ->
            val current = (prefs[ownerFailedAttemptsKey] ?: 0) + 1
            newAttempts = current
            if (current >= SecurityUtils.MAX_OWNER_FAILED_ATTEMPTS) {
                freezeUntil = System.currentTimeMillis() + SecurityUtils.OWNER_FREEZE_DURATION_MS
                prefs[ownerFreezeUntilKey] = freezeUntil
                prefs[ownerFailedAttemptsKey] = 0
            } else {
                prefs[ownerFailedAttemptsKey] = current
            }
        }
        return newAttempts to freezeUntil
    }

    suspend fun clearOwnerFailedAttempts() {
        context.dilSunoPrefs.edit { prefs ->
            prefs[ownerFailedAttemptsKey] = 0
            prefs[ownerFreezeUntilKey] = 0L
        }
    }

    suspend fun getRemainingOwnerFreezeMs(): Long {
        val until = context.dilSunoPrefs.data.first()[ownerFreezeUntilKey] ?: 0L
        val diff = until - System.currentTimeMillis()
        return if (diff > 0) diff else 0L
    }

    suspend fun setStaffRulesBannerAccepted(staffUsername: String, accepted: Boolean) {
        context.dilSunoPrefs.edit { prefs ->
            val obj = runCatching { JSONObject(prefs[staffRulesAcceptedJsonKey] ?: "{}") }.getOrDefault(JSONObject())
            obj.put(staffUsername, accepted)
            prefs[staffRulesAcceptedJsonKey] = obj.toString()
        }
    }

    fun observeStaffRulesBannerAccepted(staffUsername: String): Flow<Boolean> = context.dilSunoPrefs.data.map { prefs ->
        runCatching { JSONObject(prefs[staffRulesAcceptedJsonKey] ?: "{}").optBoolean(staffUsername, false) }
            .getOrDefault(false)
    }

    suspend fun setStaffGoldenRulesAccepted(staffUsername: String, accepted: Boolean) {
        context.dilSunoPrefs.edit { prefs ->
            val obj = runCatching { JSONObject(prefs[staffGoldenRulesJsonKey] ?: "{}") }.getOrDefault(JSONObject())
            obj.put(staffUsername, accepted)
            prefs[staffGoldenRulesJsonKey] = obj.toString()
        }
    }

    fun observeStaffGoldenRulesAccepted(staffUsername: String): Flow<Boolean> = context.dilSunoPrefs.data.map { prefs ->
        runCatching { JSONObject(prefs[staffGoldenRulesJsonKey] ?: "{}").optBoolean(staffUsername, false) }
            .getOrDefault(false)
    }

    suspend fun saveLocalPromoVideo(
        staffUsername: String,
        videoId: String,
        title: String,
        caption: String,
        videoUri: String,
        sharedPlatforms: List<String> = emptyList()
    ) {
        context.dilSunoPrefs.edit { prefs ->
            val arr = runCatching { JSONArray(prefs[localPromoVideosJsonKey] ?: "[]") }.getOrDefault(JSONArray())
            val out = JSONArray()
            var replaced = false
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                if (item.optString("id") == videoId) {
                    out.put(
                        JSONObject()
                            .put("id", videoId)
                            .put("staffUsername", staffUsername)
                            .put("title", title)
                            .put("caption", caption)
                            .put("videoUri", videoUri)
                            .put("sharedPlatforms", JSONArray(sharedPlatforms))
                            .put("isShared", sharedPlatforms.isNotEmpty())
                    )
                    replaced = true
                } else {
                    out.put(item)
                }
            }
            if (!replaced) {
                out.put(
                    JSONObject()
                        .put("id", videoId)
                        .put("staffUsername", staffUsername)
                        .put("title", title)
                        .put("caption", caption)
                        .put("videoUri", videoUri)
                        .put("sharedPlatforms", JSONArray(sharedPlatforms))
                        .put("isShared", sharedPlatforms.isNotEmpty())
                )
            }
            prefs[localPromoVideosJsonKey] = out.toString()
        }
    }

    fun observeLocalPromoVideos(staffUsername: String): Flow<List<com.dilsuno.app.data.model.ListenerPromoVideo>> =
        context.dilSunoPrefs.data.map { prefs ->
            val raw = prefs[localPromoVideosJsonKey] ?: return@map emptyList()
            runCatching {
                val arr = JSONArray(raw)
                (0 until arr.length()).mapNotNull { i ->
                    val obj = arr.getJSONObject(i)
                    if (obj.optString("staffUsername") != staffUsername) return@mapNotNull null
                    val platformsArr = obj.optJSONArray("sharedPlatforms") ?: JSONArray()
                    val platforms = (0 until platformsArr.length()).map { idx -> platformsArr.getString(idx) }
                    com.dilsuno.app.data.model.ListenerPromoVideo(
                        id = obj.optString("id"),
                        staffUsername = staffUsername,
                        title = obj.optString("title"),
                        caption = obj.optString("caption"),
                        videoUri = obj.optString("videoUri"),
                        sharedPlatforms = platforms,
                        isShared = obj.optBoolean("isShared", platforms.isNotEmpty())
                    )
                }
            }.getOrDefault(emptyList())
        }

    suspend fun savePreviewUserCredential(cred: PreviewUserCredential) {
        val normalizedEmail = SecurityUtils.normalizeEmail(cred.email)
        context.dilSunoPrefs.edit { prefs ->
            val list = parsePreviewUsersList(prefs[previewUsersKey]).toMutableList()
            val idx = list.indexOfFirst { it.email.equals(normalizedEmail, ignoreCase = true) }
            val updated = cred.copy(email = normalizedEmail)
            if (idx >= 0) list[idx] = updated else list.add(updated)
            prefs[previewUsersKey] = serializePreviewUsersList(list)
        }
    }

    suspend fun findPreviewUserByEmail(email: String): PreviewUserCredential? {
        val normalized = SecurityUtils.normalizeEmail(email)
        val raw = context.dilSunoPrefs.data.first()[previewUsersKey]
        return parsePreviewUsersList(raw).firstOrNull { it.email.equals(normalized, ignoreCase = true) }
    }

    suspend fun findPreviewUserByPhone(e164Phone: String): PreviewUserCredential? {
        val digits = e164Phone.filter { it.isDigit() }.takeLast(10)
        if (digits.length != 10) return null
        val raw = context.dilSunoPrefs.data.first()[previewUsersKey]
        return parsePreviewUsersList(raw).firstOrNull { cred ->
            val p = cred.phone?.filter { it.isDigit() }?.takeLast(10)
            p == digits || cred.email.filter { it.isDigit() }.takeLast(10) == digits
        }
    }

    suspend fun saveOrUpdatePreviewStaff(
        staffEmail: String,
        displayName: String,
        pin: String
    ): StaffAccount {
        val normalized = SecurityUtils.normalizeEmail(staffEmail)
        val staffUsername = SecurityUtils.staffDocIdFromEmail(normalized)
        val cleanName = SecurityUtils.resolveDisplayName(displayName, SecurityUtils.deriveDisplayNameFromEmail(normalized))
        val salt = SecurityUtils.generateSalt()
        val hash = SecurityUtils.hashPassword(pin.trim(), salt)
        val entry = PreviewStaffCredential(
            staffEmail = normalized,
            staffUsername = staffUsername,
            displayName = cleanName,
            pinHash = hash,
            pinSalt = salt,
            isActive = true
        )
        context.dilSunoPrefs.edit { prefs ->
            val list = parsePreviewStaffList(prefs[previewStaffKey]).toMutableList()
            val idx = list.indexOfFirst { it.staffUsername == staffUsername || it.staffEmail.equals(normalized, ignoreCase = true) }
            if (idx >= 0) list[idx] = entry else list.add(entry)
            prefs[previewStaffKey] = serializePreviewStaffList(list)
        }
        return StaffAccount(
            staffUsername = staffUsername,
            staffEmail = normalized,
            displayName = cleanName,
            isActive = true
        )
    }

    suspend fun findPreviewStaffByEmail(email: String): StaffDirectoryEntry? {
        val normalized = SecurityUtils.normalizeEmail(email)
        val raw = context.dilSunoPrefs.data.first()[previewStaffKey]
        val match = parsePreviewStaffList(raw).firstOrNull {
            it.isActive && it.staffEmail.equals(normalized, ignoreCase = true)
        } ?: return null
        return StaffDirectoryEntry(
            staffUsername = match.staffUsername,
            staffEmail = match.staffEmail,
            displayName = match.displayName,
            isActive = match.isActive
        )
    }

    suspend fun verifyPreviewStaffPin(email: String, pin: String): Result<StaffAccount> {
        val normalized = SecurityUtils.normalizeEmail(email)
        val raw = context.dilSunoPrefs.data.first()[previewStaffKey]
        val match = parsePreviewStaffList(raw).firstOrNull {
            it.staffEmail.equals(normalized, ignoreCase = true)
        } ?: return Result.failure(IllegalArgumentException("No Staff Listener approved for $normalized."))
        if (!match.isActive) {
            return Result.failure(SecurityException("This Staff Listener account is suspended."))
        }
        if (!SecurityUtils.verifyPassword(pin.trim(), match.pinSalt, match.pinHash)) {
            return Result.failure(IllegalArgumentException("Incorrect Staff PIN."))
        }
        return Result.success(
            StaffAccount(
                staffUsername = match.staffUsername,
                staffEmail = match.staffEmail,
                displayName = match.displayName,
                isActive = match.isActive
            )
        )
    }

    suspend fun togglePreviewStaffActive(staffUsername: String, isActive: Boolean) {
        context.dilSunoPrefs.edit { prefs ->
            val list = parsePreviewStaffList(prefs[previewStaffKey]).map {
                if (it.staffUsername == staffUsername) it.copy(isActive = isActive) else it
            }
            prefs[previewStaffKey] = serializePreviewStaffList(list)
        }
    }

    suspend fun removePreviewStaff(staffUsername: String) {
        context.dilSunoPrefs.edit { prefs ->
            val list = parsePreviewStaffList(prefs[previewStaffKey]).filterNot { it.staffUsername == staffUsername }
            prefs[previewStaffKey] = serializePreviewStaffList(list)
        }
    }

    suspend fun resetPreviewStaffPin(staffUsername: String, newPin: String) {
        val salt = SecurityUtils.generateSalt()
        val hash = SecurityUtils.hashPassword(newPin.trim(), salt)
        context.dilSunoPrefs.edit { prefs ->
            val list = parsePreviewStaffList(prefs[previewStaffKey]).map {
                if (it.staffUsername == staffUsername) it.copy(pinHash = hash, pinSalt = salt) else it
            }
            prefs[previewStaffKey] = serializePreviewStaffList(list)
        }
    }

    suspend fun setPreviewStaffRole(staffUsername: String, staffRole: String) {
        val safeRole = if (staffRole == "trusted_staff_manager") "trusted_staff_manager" else "listener"
        context.dilSunoPrefs.edit { prefs ->
            val list = parsePreviewStaffList(prefs[previewStaffKey]).map {
                if (it.staffUsername == staffUsername) it.copy(staffRole = safeRole) else it
            }
            prefs[previewStaffKey] = serializePreviewStaffList(list)
        }
    }

    private fun parsePreviewUsersList(raw: String?): List<PreviewUserCredential> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                PreviewUserCredential(
                    email = obj.getString("email"),
                    passwordHash = obj.getString("passwordHash"),
                    passwordSalt = obj.getString("passwordSalt"),
                    fullName = obj.getString("fullName"),
                    uid = obj.getString("uid"),
                    phone = obj.optString("phone", "").ifBlank { null }
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun serializePreviewUsersList(list: List<PreviewUserCredential>): String {
        val arr = JSONArray()
        list.forEach { u ->
            arr.put(
                JSONObject()
                    .put("email", u.email)
                    .put("passwordHash", u.passwordHash)
                    .put("passwordSalt", u.passwordSalt)
                    .put("fullName", u.fullName)
                    .put("uid", u.uid)
                    .put("phone", u.phone ?: "")
            )
        }
        return arr.toString()
    }

    private fun parsePreviewStaffList(raw: String?): List<PreviewStaffCredential> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                PreviewStaffCredential(
                    staffEmail = obj.getString("staffEmail"),
                    staffUsername = obj.getString("staffUsername"),
                    displayName = obj.getString("displayName"),
                    pinHash = obj.getString("pinHash"),
                    pinSalt = obj.getString("pinSalt"),
                    isActive = obj.optBoolean("isActive", true),
                    staffRole = obj.optString("staffRole", "listener")
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun serializePreviewStaffList(list: List<PreviewStaffCredential>): String {
        val arr = JSONArray()
        list.forEach { s ->
            arr.put(
                JSONObject()
                    .put("staffEmail", s.staffEmail)
                    .put("staffUsername", s.staffUsername)
                    .put("displayName", s.displayName)
                    .put("pinHash", s.pinHash)
                    .put("pinSalt", s.pinSalt)
                    .put("isActive", s.isActive)
                    .put("staffRole", s.staffRole)
            )
        }
        return arr.toString()
    }
}

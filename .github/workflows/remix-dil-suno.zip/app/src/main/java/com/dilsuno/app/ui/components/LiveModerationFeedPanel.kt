package com.dilsuno.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Comment
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.CommentItem
import com.dilsuno.app.data.model.LiveStreamItem
import com.dilsuno.app.data.model.PostItem
import com.dilsuno.app.data.model.PublicProfile
import com.dilsuno.app.data.model.StoryItem
import kotlinx.coroutines.flow.Flow

private data class PendingModerationTarget(
    val targetType: String,
    val targetId: String,
    val parentPostId: String?,
    val targetAuthorUid: String?,
    val targetAuthorName: String?,
    val contentPreview: String
)

/**
 * Shared real-time social feed & Reels monitor for both Staff Listeners and the Super Admin.
 * Allows watching posts, photos, Reels/short videos, 24h stories, live streams, and comments
 * and removing inappropriate content with an instant author warning + Admin Audit Log entry.
 */
@Composable
fun LiveModerationFeedPanel(
    posts: List<PostItem>,
    stories: List<StoryItem>,
    liveStreams: List<LiveStreamItem>,
    profilesByUid: Map<String, PublicProfile> = emptyMap(),
    observePostComments: (String) -> Flow<List<CommentItem>>,
    observeLiveComments: (String) -> Flow<List<CommentItem>>,
    onDeleteWithWarn: (
        targetType: String,
        targetId: String,
        parentPostId: String?,
        targetAuthorUid: String?,
        targetAuthorName: String?,
        contentPreview: String,
        reason: String
    ) -> Unit,
    lang: AppLang
) {
    var filter by remember { mutableStateOf("all") }
    var pendingTarget by remember { mutableStateOf<PendingModerationTarget?>(null) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = tr(
                        "Live Social Feed & Reels Monitor",
                        "लाइव सोशल फ़ीड और रील्स मॉनिटर",
                        lang
                    ),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = tr(
                        "Watch all live user posts, photos, Reels, stories & comments. Every removal warns the author and is recorded in Super Admin Audit Logs.",
                        "सभी यूज़र पोस्ट, फ़ोटो, रील्स, स्टोरीज़ और कमेंट्स लाइव देखें। हटाने पर लेखक को चेतावनी मिलती है और सुपर एडमिन ऑडिट लॉग में रिकॉर्ड होता है।",
                        lang
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 2.dp)
                ) {
                    val chips = listOf(
                        "all" to tr("All (${posts.size + stories.size + liveStreams.size})", "सभी", lang),
                        "posts" to tr("Posts (${posts.count { it.postType != "reel" && it.postType != "video" }})", "पोस्ट्स", lang),
                        "reels" to tr("Reels (${posts.count { it.postType == "reel" || it.postType == "video" }})", "रील्स", lang),
                        "stories" to tr("Stories (${stories.size})", "स्टोरीज़", lang),
                        "live" to tr("Live (${liveStreams.size})", "लाइव", lang)
                    )
                    items(chips) { (id, label) ->
                        FilterChip(
                            selected = filter == id,
                            onClick = { filter = id },
                            label = { Text(label) },
                            modifier = Modifier.testTag("mod_filter_$id")
                        )
                    }
                }
            }
        }

        // 24h Stories Section
        if ((filter == "all" || filter == "stories") && stories.isNotEmpty()) {
            Text(
                text = tr("Active 24h Stories (${stories.size})", "सक्रिय 24 घंटे की स्टोरीज़ (${stories.size})", lang),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(stories, key = { it.id }) { story ->
                    val storyAuthorName = SecurityUtils.resolveDisplayName(
                        profilesByUid[story.authorUid]?.fullName,
                        story.authorName
                    )
                    Card(modifier = Modifier.width(220.dp)) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(storyAuthorName, fontWeight = FontWeight.Bold, maxLines = 1)
                            if (!story.mediaUri.isNullOrBlank()) {
                                AsyncImage(
                                    model = story.mediaUri,
                                    contentDescription = "Story Media",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(90.dp)
                                        .clip(RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            if (story.caption.isNotBlank()) {
                                Text(story.caption, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                            }
                            Button(
                                onClick = {
                                    pendingTarget = PendingModerationTarget(
                                        targetType = "story",
                                        targetId = story.id,
                                        parentPostId = null,
                                        targetAuthorUid = story.authorUid,
                                        targetAuthorName = storyAuthorName,
                                        contentPreview = "Story by $storyAuthorName: ${story.caption.ifBlank { "[Media Story]" }}"
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("mod_delete_story_${story.id}")
                            ) {
                                Icon(Icons.Filled.DeleteForever, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    tr("Delete Post & Warn", "हटाएं व चेतावनी दें", lang),
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                }
            }
        }

        // Live Streams Section
        if ((filter == "all" || filter == "live") && liveStreams.isNotEmpty()) {
            Text(
                text = tr("Live Broadcasts (${liveStreams.size})", "लाइव ब्रॉडकास्ट (${liveStreams.size})", lang),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            liveStreams.forEach { stream ->
                var expandLiveChat by remember(stream.id) { mutableStateOf(false) }
                val liveComments by observeLiveComments(stream.id).collectAsStateWithLifecycle(initialValue = emptyList())
                val hostDisplayName = SecurityUtils.resolveDisplayName(
                    profilesByUid[stream.hostUid]?.fullName,
                    stream.hostName
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.RadioButtonChecked, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                                Column {
                                    Text("$hostDisplayName • ${stream.status.uppercase()}", fontWeight = FontWeight.Bold)
                                    Text(stream.title, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Surface(color = Color(0xFFDC2626).copy(alpha = 0.14f), shape = RoundedCornerShape(6.dp)) {
                                Text(
                                    text = "${stream.viewerCount} watching",
                                    color = Color(0xFFDC2626),
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        if (liveComments.isNotEmpty()) {
                            TextButton(onClick = { expandLiveChat = !expandLiveChat }) {
                                Text(tr("View Live Chat (${liveComments.size})", "लाइव चैट देखें (${liveComments.size})", lang))
                            }
                            if (expandLiveChat) {
                                liveComments.takeLast(6).forEach { c ->
                                    val cName = SecurityUtils.resolveDisplayName(
                                        profilesByUid[c.authorUid]?.fullName,
                                        c.authorName
                                    )
                                    Text("• $cName: ${c.text}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        Button(
                            onClick = {
                                pendingTarget = PendingModerationTarget(
                                    targetType = "live",
                                    targetId = stream.id,
                                    parentPostId = null,
                                    targetAuthorUid = stream.hostUid,
                                    targetAuthorName = hostDisplayName,
                                    contentPreview = "Live by $hostDisplayName: ${stream.title}"
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("mod_delete_live_${stream.id}")
                        ) {
                            Icon(Icons.Filled.DeleteForever, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                tr("Delete Post & Warn / लाइव बंद करें", "खराब लाइव हटाएं व चेतावनी दें", lang),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Community Posts & Reels Section
        val filteredPosts = when (filter) {
            "posts" -> posts.filter { it.postType != "reel" && it.postType != "video" }
            "reels" -> posts.filter { it.postType == "reel" || it.postType == "video" }
            "stories", "live" -> emptyList()
            else -> posts
        }

        if (filteredPosts.isEmpty() && filter != "stories" && filter != "live") {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = tr("No active posts or Reels to review right now.", "समीक्षा के लिए अभी कोई पोस्ट या रील नहीं है।", lang),
                    modifier = Modifier.padding(18.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            filteredPosts.forEach { post ->
                val isReel = post.postType == "reel" || post.postType == "video"
                var showComments by remember(post.id) { mutableStateOf(false) }
                val comments by observePostComments(post.id).collectAsStateWithLifecycle(initialValue = emptyList())
                val postAuthorName = SecurityUtils.resolveDisplayName(
                    profilesByUid[post.authorUid]?.fullName,
                    post.authorName
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(postAuthorName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    text = listOfNotNull(post.postType.uppercase(), post.city?.takeIf { it.isNotBlank() }).joinToString(" • "),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (isReel) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Filled.OndemandVideo, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Text("REEL", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        if (!post.title.isNullOrBlank()) {
                            Text(post.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyLarge)
                        }
                        if (post.caption.isNotBlank()) {
                            Text(post.caption, style = MaterialTheme.typography.bodyMedium)
                        }
                        if (!post.musicTrack.isNullOrBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Filled.MusicNote, contentDescription = null, modifier = Modifier.size(15.dp), tint = MaterialTheme.colorScheme.secondary)
                                Text(post.musicTrack, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                        if (!post.mediaUri.isNullOrBlank()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(170.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Black.copy(alpha = 0.08f))
                            ) {
                                AsyncImage(
                                    model = post.mediaUri,
                                    contentDescription = "Media for moderation review",
                                    modifier = Modifier.fillMaxWidth().height(170.dp),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Likes ${post.likesCount + post.loveCount} • Comments ${post.commentsCount} • Views ${post.viewsCount}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedButton(
                                onClick = { showComments = !showComments },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Filled.Comment, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = if (showComments) tr("Hide Comments", "छिपाएं", lang)
                                    else tr("Comments (${comments.size})", "कमेंट (${comments.size})", lang),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }

                        if (showComments) {
                            HorizontalDivider()
                            if (comments.isEmpty()) {
                                Text(
                                    text = tr("No comments yet.", "अभी कोई कमेंट नहीं।", lang),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                comments.forEach { comment ->
                                    val commentAuthorName = SecurityUtils.resolveDisplayName(
                                        profilesByUid[comment.authorUid]?.fullName,
                                        comment.authorName
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(commentAuthorName, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
                                            Text(comment.text, style = MaterialTheme.typography.bodySmall)
                                        }
                                        IconButton(
                                            onClick = {
                                                pendingTarget = PendingModerationTarget(
                                                    targetType = "comment",
                                                    targetId = comment.id,
                                                    parentPostId = post.id,
                                                    targetAuthorUid = comment.authorUid,
                                                    targetAuthorName = commentAuthorName,
                                                    contentPreview = "Comment by $commentAuthorName: ${comment.text}"
                                                )
                                            },
                                            modifier = Modifier.size(48.dp).testTag("mod_delete_comment_${comment.id}")
                                        ) {
                                            Icon(
                                                Icons.Filled.DeleteForever,
                                                contentDescription = tr("Delete comment and warn", "कमेंट हटाएं", lang),
                                                tint = Color(0xFFB91C1C)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Button(
                            onClick = {
                                val summary = listOfNotNull(post.title, post.caption)
                                    .filter { it.isNotBlank() }
                                    .joinToString(" - ")
                                    .ifBlank { "[${post.postType.uppercase()} Media]" }
                                pendingTarget = PendingModerationTarget(
                                    targetType = if (isReel) "reel" else "post",
                                    targetId = post.id,
                                    parentPostId = null,
                                    targetAuthorUid = post.authorUid,
                                    targetAuthorName = postAuthorName,
                                    contentPreview = summary
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("mod_delete_post_${post.id}")
                        ) {
                            Icon(Icons.Filled.DeleteForever, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = tr(
                                    "Delete Post & Warn",
                                    "खराब पोस्ट हटाएं व चेतावनी दें",
                                    lang
                                ),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    pendingTarget?.let { target ->
        var warnReason by remember(target.targetId) {
            mutableStateOf("Inappropriate content — violates Dil Suno safety guidelines")
        }
        AlertDialog(
            onDismissRequest = { pendingTarget = null },
            icon = { Icon(Icons.Filled.Warning, contentDescription = null, tint = Color(0xFFB91C1C)) },
            title = {
                Text(tr("Delete ${target.targetType.uppercase()} & Warn Author?", "पोस्ट हटाएं और चेतावनी भेजें?", lang))
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = target.contentPreview.take(180),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = warnReason,
                        onValueChange = { warnReason = it },
                        label = { Text(tr("Warning / Removal Reason", "चेतावनी का कारण", lang)) },
                        modifier = Modifier.fillMaxWidth().testTag("mod_warn_reason_input"),
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val t = target
                        pendingTarget = null
                        onDeleteWithWarn(
                            t.targetType,
                            t.targetId,
                            t.parentPostId,
                            t.targetAuthorUid,
                            t.targetAuthorName,
                            t.contentPreview,
                            warnReason.ifBlank { "Violates community guidelines" }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C)),
                    modifier = Modifier.testTag("mod_confirm_delete_button")
                ) {
                    Text(tr("Delete & Log Audit", "हटाएं और रिकॉर्ड करें", lang), color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingTarget = null }) {
                    Text(tr("Cancel", "रद्द करें", lang))
                }
            }
        )
    }
}

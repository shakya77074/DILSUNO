package com.dilsuno.app.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dilsuno.app.core.DilSunoBillingRules
import com.dilsuno.app.core.RateLimiterStore
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.VerifiedPlayPurchase
import com.dilsuno.app.core.ZegoCallManager
import com.dilsuno.app.data.model.AppConfig
import com.dilsuno.app.data.model.ChatMessage
import com.dilsuno.app.data.model.CommentItem
import com.dilsuno.app.data.model.CommunityGroup
import com.dilsuno.app.data.model.CreatorTip
import com.dilsuno.app.data.model.DilSeCallSession
import com.dilsuno.app.data.model.FriendLink
import com.dilsuno.app.data.model.FriendSuggestion
import com.dilsuno.app.data.model.LiveStreamItem
import com.dilsuno.app.data.model.ListenerApplication
import com.dilsuno.app.data.model.NotificationItem
import com.dilsuno.app.data.model.PayoutRequest
import com.dilsuno.app.data.model.PostItem
import com.dilsuno.app.data.model.PublicPage
import com.dilsuno.app.data.model.PublicProfile
import com.dilsuno.app.data.model.StaffDirectoryEntry
import com.dilsuno.app.data.model.StoryItem
import com.dilsuno.app.data.model.SupportTicket
import com.dilsuno.app.data.model.UiState
import com.dilsuno.app.data.model.UserAccount
import com.dilsuno.app.data.model.WebRtcSignal
import com.dilsuno.app.data.repository.AccountAndSocialRepository
import com.dilsuno.app.data.repository.AiSafetyRepository
import com.dilsuno.app.data.repository.FeedModerationAndCallRepository
import com.dilsuno.app.data.repository.authGatedFlow
import com.dilsuno.app.data.repository.isVerifiedAdminUser
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainAppViewModel(
    private val accountRepo: AccountAndSocialRepository,
    private val feedRepo: FeedModerationAndCallRepository,
    private val aiSafetyRepo: AiSafetyRepository,
    val currentUserId: String,
    private val rateLimiter: RateLimiterStore? = null
) : ViewModel() {

    private fun <T> Flow<T>.toUiState(initial: UiState<T> = UiState.Loading): StateFlow<UiState<T>> {
        return this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                val root = fsErr ?: error
                Log.w(TAG, "Stream error", root)
                emit(UiState.Error(root.message ?: "Failed to sync data"))
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), initial)
    }

    val myAccount: StateFlow<UserAccount?> = authGatedFlow<UserAccount?>(
        defaultValue = null,
        predicate = { user -> user.uid == currentUserId || isVerifiedAdminUser(user) }
    ) {
        accountRepo.observeMyAccount(currentUserId)
            .catch { error ->
                if (error is CancellationException && generateSequence<Throwable>(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull() == null) throw error
                emit(null)
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val communityProfiles: StateFlow<List<PublicProfile>> = authGatedFlow<List<PublicProfile>>(emptyList()) {
        accountRepo.observeCommunityProfiles()
            .catch { error ->
                if (error is CancellationException && generateSequence<Throwable>(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull() == null) throw error
                emit(emptyList())
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val friendLinks: StateFlow<List<FriendLink>> = authGatedFlow<List<FriendLink>>(
        defaultValue = emptyList(),
        predicate = { user -> user.uid == currentUserId || isVerifiedAdminUser(user) }
    ) {
        accountRepo.observeFriendLinks(currentUserId)
            .catch { error ->
                if (error is CancellationException && generateSequence<Throwable>(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull() == null) throw error
                emit(emptyList())
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val myProfile: StateFlow<PublicProfile?> = communityProfiles.map { list ->
        list.firstOrNull { it.uid == currentUserId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val smartFriendSuggestions: StateFlow<List<FriendSuggestion>> = combine(
        myProfile,
        communityProfiles,
        friendLinks
    ) { me, all, links ->
        accountRepo.computeSmartFriendSuggestions(me, all, links, currentUserId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val blockedUserUids: StateFlow<Set<String>> = combine(
        friendLinks,
        rateLimiter?.observeBlockedUserUids(currentUserId) ?: MutableStateFlow(emptySet())
    ) { links, localBlocked ->
        val fromLinks = links
            .filter { it.status == "blocked" }
            .flatMap { listOf(it.fromUid, it.toUid) }
            .filter { it != currentUserId && it.isNotBlank() }
            .toSet()
        fromLinks + localBlocked
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptySet())

    val savedPostIds: StateFlow<Set<String>> = (
        rateLimiter?.observeSavedPostIds(currentUserId) ?: MutableStateFlow(emptySet())
        ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptySet())

    val allowFriendChat: StateFlow<Boolean> = (
        rateLimiter?.observeAllowFriendChat(currentUserId) ?: MutableStateFlow(true)
        ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), true)

    val localShareCount: StateFlow<Long> = (
        rateLimiter?.observeLocalShareCount(currentUserId) ?: MutableStateFlow(0L)
        ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0L)

    private val _localPublishedPosts = MutableStateFlow<List<PostItem>>(emptyList())

    val onlineFriendsCount: StateFlow<Int> = combine(
        friendLinks,
        communityProfiles
    ) { links, profiles ->
        val acceptedUids = links.filter { it.status == "accepted" }
            .flatMap { it.participantUids }
            .filter { it != currentUserId }
            .toSet()
        if (acceptedUids.isEmpty()) 0
        else profiles.count { it.uid in acceptedUids && !it.isBanned }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0)

    val hasAcceptedCommunityGuidelines18Plus: StateFlow<Boolean> = combine(
        myAccount,
        rateLimiter?.observeCommunityGuidelinesAccepted(currentUserId) ?: MutableStateFlow(false)
    ) { acct, localAccepted ->
        (acct?.communityGuidelinesAccepted == true) || localAccepted
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), false)

    val postsState: StateFlow<UiState<List<PostItem>>> = combine(
        authGatedFlow<List<PostItem>>(emptyList()) {
            feedRepo.observeActivePosts().catch { emit(emptyList()) }
        },
        _localPublishedPosts,
        blockedUserUids
    ) { remotePosts, localPosts, blocked ->
        val merged = (localPosts + remotePosts)
            .distinctBy { if (it.id.startsWith("local_")) "${it.authorUid}:${it.postType}:${it.caption}:${it.mediaUri}" else it.id }
            .filter { it.authorUid !in blocked }
        merged
    }.toUiState()

    val creatorMilestoneProgress: StateFlow<Triple<Long, Long, Long>> = combine(
        postsState,
        localShareCount
    ) { state, shares ->
        val allPosts = (state as? UiState.Success)?.data.orEmpty()
        val myPosts = allPosts.filter { it.authorUid == currentUserId }
        val speakingReels = myPosts.count { it.postType == "reel" || it.postType == "video" }.toLong()
        val totalLikes = myPosts.sumOf { it.likesCount + it.loveCount }
        Triple(shares, speakingReels, totalLikes)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), Triple(0L, 0L, 0L))

    val stories: StateFlow<List<StoryItem>> = combine(
        authGatedFlow<List<StoryItem>>(emptyList()) {
            feedRepo.observeActiveStories().catch { emit(emptyList()) }
        },
        blockedUserUids
    ) { list, blocked ->
        list.filter { it.authorUid !in blocked }
    }.catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val groups: StateFlow<List<CommunityGroup>> = authGatedFlow<List<CommunityGroup>>(emptyList()) {
        accountRepo.observeGroups().catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val pages: StateFlow<List<PublicPage>> = authGatedFlow<List<PublicPage>>(emptyList()) {
        accountRepo.observePages().catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val liveStreams: StateFlow<List<LiveStreamItem>> = authGatedFlow<List<LiveStreamItem>>(emptyList()) {
        feedRepo.observeLiveStreams().catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val notifications: StateFlow<List<NotificationItem>> = authGatedFlow<List<NotificationItem>>(
        defaultValue = emptyList(),
        predicate = { user -> user.uid == currentUserId || isVerifiedAdminUser(user) }
    ) {
        accountRepo.observeNotifications(currentUserId).catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val appConfig: StateFlow<AppConfig> = feedRepo.observeAppConfig()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AppConfig())

    val availableMusicTracks: StateFlow<List<com.dilsuno.app.core.MusicTrackOption>> = combine(
        appConfig,
        rateLimiter?.customMusicTracksJsonFlow ?: MutableStateFlow(null)
    ) { cfg, localJson ->
        val raw = cfg.customMusicTracksJson?.takeIf { it.isNotBlank() } ?: localJson
        com.dilsuno.app.core.RoyaltyFreeMusicLibrary.allTracksWithCustom(raw)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), com.dilsuno.app.core.RoyaltyFreeMusicLibrary.tracks)

    val activeListeners: StateFlow<List<StaffDirectoryEntry>> = authGatedFlow<List<StaffDirectoryEntry>>(emptyList()) {
        feedRepo.observeActiveStaffDirectory()
            .map { list ->
                list.filter { it.isActive }
                    .sortedWith(compareByDescending<StaffDirectoryEntry> { it.isOnline }.thenByDescending { it.totalCalls })
            }
            .catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val onlineStaffCount: StateFlow<Int> = activeListeners
        .map { list -> list.count { it.isOnline && it.isActive } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0)

    val myTips: StateFlow<List<CreatorTip>> = authGatedFlow<List<CreatorTip>>(
        defaultValue = emptyList(),
        predicate = { user -> user.uid == currentUserId || isVerifiedAdminUser(user) }
    ) {
        feedRepo.observeTipsForCreator(currentUserId).catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val myPayouts: StateFlow<List<PayoutRequest>> = authGatedFlow<List<PayoutRequest>>(
        defaultValue = emptyList(),
        predicate = { user -> user.uid == currentUserId || isVerifiedAdminUser(user) }
    ) {
        feedRepo.observeMyPayoutRequests(currentUserId).catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val mySupportTickets: StateFlow<List<SupportTicket>> = authGatedFlow<List<SupportTicket>>(
        defaultValue = emptyList(),
        predicate = { user -> user.uid == currentUserId || isVerifiedAdminUser(user) }
    ) {
        feedRepo.observeMySupportTickets(currentUserId).catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _isScanningAi = MutableStateFlow(false)
    val isScanningAi: StateFlow<Boolean> = _isScanningAi.asStateFlow()

    private val _bannerMessage = MutableStateFlow<String?>(null)
    val bannerMessage: StateFlow<String?> = _bannerMessage.asStateFlow()

    private val _activeCallId = MutableStateFlow<String?>(null)
    val activeCallId: StateFlow<String?> = _activeCallId.asStateFlow()

    private val _activeCall = MutableStateFlow<DilSeCallSession?>(null)
    val activeCall: StateFlow<DilSeCallSession?> = _activeCall.asStateFlow()

    private val _pendingCallForRating = MutableStateFlow<DilSeCallSession?>(null)
    val pendingCallForRating: StateFlow<DilSeCallSession?> = _pendingCallForRating.asStateFlow()

    private val _deleteOtp = MutableStateFlow<String?>(null)
    val deleteOtp: StateFlow<String?> = _deleteOtp.asStateFlow()

    private val _walletBalanceOverride = MutableStateFlow<Long?>(null)
    private val _activeBilledSlotsCount = MutableStateFlow(0L)
    val activeBilledSlotsCount: StateFlow<Long> = _activeBilledSlotsCount.asStateFlow()

    private val billedSlotKeys = mutableSetOf<String>()

    private val _isVerifyingPlayPurchase = MutableStateFlow(false)
    val isVerifyingPlayPurchase: StateFlow<Boolean> = _isVerifyingPlayPurchase.asStateFlow()

    val isReviewerDemoAccount: Boolean
        get() = currentUserId == SecurityUtils.REVIEWER_DEMO_UID ||
            SecurityUtils.isReviewerDemoEmail(myAccount.value?.email)

    val walletBalance: StateFlow<Long> = combine(
        myAccount,
        rateLimiter?.observeLocalWalletBalance(currentUserId) ?: MutableStateFlow(null),
        _walletBalanceOverride
    ) { acct, localCached, overrideVal ->
        val fallback = if (currentUserId == SecurityUtils.REVIEWER_DEMO_UID ||
            SecurityUtils.isReviewerDemoEmail(acct?.email)
        ) {
            SecurityUtils.REVIEWER_INITIAL_CREDITS_INR
        } else {
            0L
        }
        overrideVal ?: localCached?.let { local ->
            maxOf(local, acct?.walletBalance ?: 0L)
        } ?: acct?.walletBalance?.takeIf { it > 0L } ?: fallback
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0L)

    val myListenerApplication: StateFlow<ListenerApplication?> = authGatedFlow<ListenerApplication?>(
        defaultValue = null,
        predicate = { user -> user.uid == currentUserId || isVerifiedAdminUser(user) }
    ) {
        feedRepo.observeMyListenerApplication(currentUserId).catch { emit(null) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    // --- Free AI Voice Listener Fallback (Firebase AI Logic — gemini-3.8-flash) ---
    private val _aiListenerMessages = MutableStateFlow<List<com.dilsuno.app.data.model.AiListenerMessage>>(emptyList())
    val aiListenerMessages: StateFlow<List<com.dilsuno.app.data.model.AiListenerMessage>> = _aiListenerMessages.asStateFlow()

    private val _isAiListenerThinking = MutableStateFlow(false)
    val isAiListenerThinking: StateFlow<Boolean> = _isAiListenerThinking.asStateFlow()

    private val _aiListenerError = MutableStateFlow<String?>(null)
    val aiListenerError: StateFlow<String?> = _aiListenerError.asStateFlow()

    init {
        viewModelScope.launch {
            myAccount.collect { acct ->
                if (acct != null) {
                    val overrideVal = _walletBalanceOverride.value
                    if (overrideVal == null) {
                        rateLimiter?.setLocalWalletBalance(currentUserId, acct.walletBalance)
                    } else if (acct.walletBalance == overrideVal) {
                        _walletBalanceOverride.value = null
                    }
                }
            }
        }
        ZegoCallManager.registerBillingCallback { listenerStaffId, listenerName, slotIndex ->
            handleZegoCallSlotConnected(listenerStaffId, listenerName, slotIndex)
        }
    }

    override fun onCleared() {
        ZegoCallManager.registerBillingCallback(null)
        super.onCleared()
    }

    fun acceptCommunityGuidelines18Plus() {
        viewModelScope.launch {
            rateLimiter?.setCommunityGuidelinesAccepted(currentUserId, true)
            _bannerMessage.value = "Community Guidelines & 18+ Policy accepted. You can now post safely."
        }
    }

    /**
     * Verifies a completed Google Play Billing purchase token in Firebase Firestore
     * (single-use deduplicated ledger `play_billing_purchases/{tokenHash}`) before
     * crediting the user's visible Dil Suno Wallet Balance.
     */
    fun creditVerifiedPlayBillingPurchase(purchase: VerifiedPlayPurchase) {
        viewModelScope.launch {
            _isVerifyingPlayPurchase.value = true
            val currentVisible = walletBalance.value
            val expectedCredits = purchase.creditsInr
            val remoteResult = feedRepo.verifyAndRecordPlayBillingPurchase(
                uid = currentUserId,
                productId = purchase.productId,
                creditsInr = expectedCredits,
                purchaseToken = purchase.purchaseToken,
                orderId = purchase.orderId
            )
            remoteResult.onSuccess { updatedRemoteBal ->
                val resolved = maxOf(updatedRemoteBal, currentVisible + expectedCredits)
                _walletBalanceOverride.value = resolved
                rateLimiter?.setLocalWalletBalance(currentUserId, resolved)
                _bannerMessage.value =
                    "Google Play purchase verified (${purchase.productId})! ₹$expectedCredits Call Credits added to your wallet."
            }.onFailure { err ->
                if (isReviewerDemoAccount) {
                    val nextBal = currentVisible + expectedCredits
                    _walletBalanceOverride.value = nextBal
                    rateLimiter?.setLocalWalletBalance(currentUserId, nextBal)
                    _bannerMessage.value =
                        "Reviewer Demo Play Billing (${purchase.productId}) verified! ₹$expectedCredits added."
                } else {
                    _bannerMessage.value =
                        err.localizedMessage ?: "Purchase token verification failed in Firebase."
                }
            }
            _isVerifyingPlayPurchase.value = false
        }
    }

    private fun handleZegoCallSlotConnected(
        listenerStaffId: String?,
        listenerName: String?,
        slotIndex: Long
    ): Boolean {
        val required = DilSunoBillingRules.CALL_CHARGE_INR
        val currentBal = walletBalance.value
        if (currentBal < required) {
            _bannerMessage.value = if (slotIndex > 1L) {
                "Wallet balance below ₹$required — call ended cleanly."
            } else {
                "Minimum ₹$required wallet balance required to connect call."
            }
            return false
        }
        val nextBal = (currentBal - required).coerceAtLeast(0L)
        _walletBalanceOverride.value = nextBal
        viewModelScope.launch {
            rateLimiter?.setLocalWalletBalance(currentUserId, nextBal)
            accountRepo.deductWalletBalance(currentUserId, required).onSuccess { remoteBal ->
                _walletBalanceOverride.value = remoteBal
                rateLimiter?.setLocalWalletBalance(currentUserId, remoteBal)
            }
            val (_, adminShare) = DilSunoBillingRules.computeCallSplit(
                chargeInr = required,
                isOwnerBackupCall = listenerStaffId == "owner_admin"
            )
            rateLimiter?.addLocalAdminRevenue(adminShare)
            feedRepo.recordConnectedCallSlotSplit(
                callId = null,
                listenerStaffId = listenerStaffId,
                listenerDisplayName = listenerName,
                slotIndex = slotIndex,
                chargeInr = required
            )
            _bannerMessage.value = if (slotIndex == 1L) {
                "Call connected! ₹$required deducted from wallet."
            } else {
                "Call extended seamlessly (Slot $slotIndex)! ₹$required deducted."
            }
        }
        return true
    }

    fun clearBanner() {
        _bannerMessage.value = null
    }

    fun reportSecurityError(message: String) {
        _bannerMessage.value = message
    }

    fun resolveDisplayName(fallback: String = "Dil Suno Member"): String {
        return SecurityUtils.resolveDisplayName(
            primary = myProfile.value?.fullName,
            secondary = myAccount.value?.fullName,
            fallback = fallback
        )
    }

    fun observeCommentsForPost(postId: String): Flow<List<CommentItem>> =
        authGatedFlow<List<CommentItem>>(emptyList()) {
            feedRepo.observeComments(postId).catch { emit(emptyList()) }
        }

    fun observeLiveComments(streamId: String): Flow<List<CommentItem>> =
        authGatedFlow<List<CommentItem>>(emptyList()) {
            feedRepo.observeLiveComments(streamId).catch { emit(emptyList()) }
        }

    fun observeChatMessages(otherUid: String): Flow<List<ChatMessage>> {
        val convId = accountRepo.conversationIdFor(currentUserId, otherUid)
        return authGatedFlow<List<ChatMessage>>(
            defaultValue = emptyList(),
            predicate = { user -> user.uid == currentUserId || isVerifiedAdminUser(user) }
        ) {
            accountRepo.observeMessages(convId, currentUserId).catch { emit(emptyList()) }
        }
    }

    fun observeWebRtcSignals(callId: String): Flow<List<WebRtcSignal>> =
        authGatedFlow<List<WebRtcSignal>>(emptyList()) {
            feedRepo.observeWebRtcSignals(callId).catch { emit(emptyList()) }
        }

    fun sendWebRtcSignal(callId: String, senderRole: String, signalType: String, payload: String) {
        viewModelScope.launch {
            feedRepo.sendWebRtcSignal(callId, senderRole, signalType, payload)
        }
    }

    private suspend fun runAiSafetyGate(
        contentType: String,
        text: String,
        mediaUri: String?,
        extraLayerText: String = "",
        extraMediaUris: List<String> = emptyList()
    ): Boolean {
        _isScanningAi.value = true
        val scanResult = aiSafetyRepo.scanContentBeforePublish(
            contentType = contentType,
            text = text,
            mediaUriString = mediaUri,
            extraLayerText = extraLayerText,
            extraMediaUriStrings = extraMediaUris
        )
        _isScanningAi.value = false

        val scan = scanResult.getOrElse { err ->
            _bannerMessage.value = "AI Legal Filter error: ${err.localizedMessage ?: "Retry"}"
            return false
        }

        if (!scan.isSafe) {
            val isPermanent = scan.severity == "permanent_ban" || scan.violationCategory == "child_safety"
            val userName = resolveDisplayName("User")
            val loggedSnippet = listOf(text, extraLayerText).filter { it.isNotBlank() }.joinToString(" | ").take(200)
            feedRepo.logAiSafetyBlock(
                userName = userName,
                contentType = contentType,
                snippet = loggedSnippet,
                violationCategory = scan.violationCategory,
                aiReason = scan.reason,
                permanentBan = isPermanent
            )
            if (isPermanent) {
                feedRepo.adminSetUserBanned(currentUserId, true)
                _bannerMessage.value =
                    "ZERO-TOLERANCE AUTO-DELETE & BAN (${scan.violationCategory}): ${scan.reason}"
            } else {
                _bannerMessage.value =
                    "AUTO-DELETED BY AI LEGAL FILTER (${scan.violationCategory}): ${scan.reason}"
            }
            return false
        }
        return true
    }

    fun createPost(
        postType: String,
        title: String,
        caption: String,
        city: String,
        mediaUri: String?,
        musicTrack: String?,
        groupId: String? = null,
        pageId: String? = null,
        editorSummary: String? = null,
        extraLayerScanText: String = "",
        extraMediaUris: List<String> = emptyList(),
        bgStyleId: String? = null,
        hasAiLabel: Boolean = false,
        mentionedUids: List<String> = emptyList(),
        onPublished: () -> Unit
    ) {
        viewModelScope.launch {
            val cleanTitle = SecurityUtils.sanitizeInput(title, 160)
            val cleanCaption = SecurityUtils.sanitizeInput(caption, 2000)
            val cleanCity = SecurityUtils.sanitizeInput(city, 100)
            val cleanExtraScan = SecurityUtils.sanitizeInput(extraLayerScanText, 1200)
            if (!SecurityUtils.isSafeMediaUri(mediaUri, allowVideo = true) ||
                extraMediaUris.any { !SecurityUtils.isSafeMediaUri(it, allowVideo = true) }
            ) {
                _bannerMessage.value = "Blocked unsafe or invalid media attachment."
                return@launch
            }
            val combinedText = listOf(cleanTitle, cleanCaption).filter { it.isNotBlank() }.joinToString(" - ")
            if (combinedText.isBlank() && mediaUri.isNullOrBlank() && cleanExtraScan.isBlank()) {
                _bannerMessage.value = "Please enter safe text or select a valid photo/video (max 25 MB)."
                return@launch
            }
            if (!runAiSafetyGate(postType, combinedText, mediaUri, cleanExtraScan, extraMediaUris)) return@launch

            val extractedHashtags = Regex("#[\\w\\u0900-\\u097F]+")
                .findAll(cleanCaption)
                .map { it.value.trim() }
                .distinct()
                .take(20)
                .toList()
            val cleanMentions = mentionedUids.distinct().take(20)

            val name = resolveDisplayName("Dil Suno Member")
            val avatar = myProfile.value?.avatarUri
            val localDraft = PostItem(
                id = "local_${System.currentTimeMillis()}",
                authorUid = currentUserId,
                authorName = name,
                authorAvatar = avatar,
                postType = postType,
                title = cleanTitle.ifBlank { null },
                caption = cleanCaption,
                city = cleanCity.ifBlank { null },
                mediaUri = mediaUri,
                musicTrack = musicTrack,
                bgStyleId = bgStyleId,
                hasAiLabel = hasAiLabel,
                hashtags = extractedHashtags,
                mentionedUids = cleanMentions,
                groupId = groupId,
                pageId = pageId,
                editorSummary = editorSummary?.let { SecurityUtils.sanitizeInput(it, 1000) }
            )
            feedRepo.publishApprovedPost(
                authorName = name,
                authorAvatar = avatar,
                postType = postType,
                title = cleanTitle.ifBlank { null },
                caption = cleanCaption,
                city = cleanCity.ifBlank { null },
                mediaUri = mediaUri,
                musicTrack = musicTrack,
                groupId = groupId,
                pageId = pageId,
                editorSummary = editorSummary?.let { SecurityUtils.sanitizeInput(it, 1000) },
                bgStyleId = bgStyleId,
                hasAiLabel = hasAiLabel,
                hashtags = extractedHashtags,
                mentionedUids = cleanMentions
            ).onSuccess { createdPostId ->
                _localPublishedPosts.value = listOf(localDraft.copy(id = createdPostId)) + _localPublishedPosts.value
                cleanMentions.filter { it != currentUserId }.forEach { targetUid ->
                    accountRepo.sendNotification(
                        recipientUid = targetUid,
                        actorName = name,
                        type = "mention",
                        message = "$name mentioned you in a ${if (postType == "reel") "Reel" else "post"}: ${cleanCaption.take(70)}",
                        targetId = createdPostId
                    )
                }
                _bannerMessage.value = "Verified safe by Gemini AI and published!"
                onPublished()
            }.onFailure { err ->
                if (isReviewerDemoAccount || com.dilsuno.app.BuildConfig.DEBUG) {
                    _localPublishedPosts.value = listOf(localDraft) + _localPublishedPosts.value
                    _bannerMessage.value = "Published locally (preview mode) & synced to feed!"
                    onPublished()
                } else {
                    _bannerMessage.value = err.localizedMessage ?: "Failed to publish."
                }
            }
        }
    }

    fun suggestReelCaptions(topicOrMood: String, lang: com.dilsuno.app.core.AppLang, onResult: (List<String>) -> Unit) {
        viewModelScope.launch {
            aiSafetyRepo.suggestReelCaptions(topicOrMood, lang)
                .onSuccess { onResult(it) }
                .onFailure { err ->
                    _bannerMessage.value = err.localizedMessage ?: "AI caption suggestion unavailable."
                    onResult(emptyList())
                }
        }
    }

    fun editPostCaption(post: PostItem, newCaption: String, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            val cleanCaption = SecurityUtils.sanitizeInput(newCaption, 2000)
            if (cleanCaption.isBlank()) {
                _bannerMessage.value = "Caption cannot be empty."
                return@launch
            }
            if (!runAiSafetyGate("${post.postType}_edit", cleanCaption, null)) return@launch
            val extractedHashtags = Regex("#[\\w\\u0900-\\u097F]+")
                .findAll(cleanCaption)
                .map { it.value.trim() }
                .distinct()
                .take(20)
                .toList()
            feedRepo.updatePostCaptionAndTags(post.id, cleanCaption, extractedHashtags)
                .onSuccess {
                    _localPublishedPosts.value = _localPublishedPosts.value.map {
                        if (it.id == post.id) it.copy(caption = cleanCaption, hashtags = extractedHashtags) else it
                    }
                    _bannerMessage.value = "Caption updated!"
                    onDone()
                }
                .onFailure { _bannerMessage.value = it.localizedMessage ?: "Could not update caption." }
        }
    }

    fun muteMyReelAudioForClaim(post: PostItem) {
        viewModelScope.launch {
            feedRepo.muteReelAudioToRemoveClaim(post.id)
                .onSuccess {
                    _localPublishedPosts.value = _localPublishedPosts.value.map {
                        if (it.id == post.id) {
                            it.copy(
                                audioMutedForClaim = true,
                                musicTrack = null,
                                copyrightClaimActive = false,
                                copyrightClaimReason = null
                            )
                        } else it
                    }
                    _bannerMessage.value = "Audio muted & Copyright Claim cleared! Your post is visible in public feeds again."
                }
                .onFailure { _bannerMessage.value = it.localizedMessage ?: "Failed to mute reel audio." }
        }
    }

    fun submitListenerApplication(
        fullName: String,
        email: String,
        phone: String?,
        city: String?,
        motivation: String,
        onSubmitted: () -> Unit = {}
    ) {
        viewModelScope.launch {
            feedRepo.submitListenerApplication(fullName, email, phone, city, motivation)
                .onSuccess {
                    _bannerMessage.value = "Application submitted! Step 1 (Staff Verification) -> Step 2 (Super Admin Final Approval)."
                    onSubmitted()
                }
                .onFailure { _bannerMessage.value = it.localizedMessage ?: "Could not submit application." }
        }
    }

    fun createStory(caption: String, mediaUri: String?, bgHex: String, onPublished: () -> Unit) {
        viewModelScope.launch {
            val cleanCaption = SecurityUtils.sanitizeInput(caption, 400)
            if (!SecurityUtils.isSafeMediaUri(mediaUri, allowVideo = false)) {
                _bannerMessage.value = "Only safe JPG, PNG, or WEBP photos (max 25 MB) are allowed for stories."
                return@launch
            }
            if (cleanCaption.isBlank() && mediaUri.isNullOrBlank()) {
                _bannerMessage.value = "Add a safe caption or photo for your 24h story."
                return@launch
            }
            if (!runAiSafetyGate("story", cleanCaption, mediaUri)) return@launch
            val name = resolveDisplayName("Member")
            feedRepo.publishApprovedStory(name, myProfile.value?.avatarUri, cleanCaption, mediaUri, bgHex)
                .onSuccess {
                    _bannerMessage.value = "24-Hour Story published!"
                    onPublished()
                }
                .onFailure { _bannerMessage.value = it.localizedMessage }
        }
    }

    fun addComment(post: PostItem, text: String) {
        viewModelScope.launch {
            val cleanText = SecurityUtils.sanitizeInput(text, 600)
            if (cleanText.isBlank()) return@launch
            if (!runAiSafetyGate("comment", cleanText, null)) return@launch
            val name = resolveDisplayName("Member")
            feedRepo.publishApprovedComment(post.id, name, cleanText).onSuccess {
                accountRepo.sendNotification(
                    recipientUid = post.authorUid,
                    actorName = name,
                    type = "comment",
                    message = "$name commented: ${cleanText.take(60)}",
                    targetId = post.id
                )
            }
        }
    }

    fun reactToPost(post: PostItem, reactionField: String, emojiLabel: String) {
        viewModelScope.launch {
            feedRepo.reactToPost(post.id, reactionField).onSuccess {
                val name = resolveDisplayName("Member")
                accountRepo.sendNotification(
                    recipientUid = post.authorUid,
                    actorName = name,
                    type = "like",
                    message = "$name reacted $emojiLabel to your post",
                    targetId = post.id
                )
            }
        }
    }

    fun startLiveStream(title: String, city: String, onStarted: (String) -> Unit) {
        viewModelScope.launch {
            val cleanTitle = SecurityUtils.sanitizeInput(title, 200)
            if (cleanTitle.isBlank()) {
                _bannerMessage.value = "Enter a safe Live broadcast title."
                return@launch
            }
            if (!runAiSafetyGate("live_stream", cleanTitle, null)) return@launch
            val name = resolveDisplayName("Broadcaster")
            feedRepo.startLiveStream(name, cleanTitle, city).onSuccess { id ->
                onStarted(id)
            }.onFailure { _bannerMessage.value = it.localizedMessage }
        }
    }

    fun endLiveStream(streamId: String) {
        viewModelScope.launch { feedRepo.endLiveStream(streamId) }
    }

    fun sendLiveComment(streamId: String, text: String) {
        viewModelScope.launch {
            val cleanText = SecurityUtils.sanitizeInput(text, 400)
            if (cleanText.isBlank()) return@launch
            if (!runAiSafetyGate("live_comment", cleanText, null)) return@launch
            val name = resolveDisplayName("Viewer")
            feedRepo.sendLiveComment(streamId, name, cleanText)
        }
    }

    fun submitReport(
        targetType: String,
        targetId: String,
        targetAuthorUid: String?,
        reportType: String,
        reason: String,
        targetAuthorName: String? = null,
        targetMediaUri: String? = null,
        targetCaption: String? = null,
        parentPostId: String? = null
    ) {
        viewModelScope.launch {
            feedRepo.submitReport(
                targetType = targetType,
                targetId = targetId,
                targetAuthorUid = targetAuthorUid,
                reportType = reportType,
                reason = reason,
                targetAuthorName = targetAuthorName,
                targetMediaUri = targetMediaUri,
                targetCaption = targetCaption,
                parentPostId = parentPostId
            ).onSuccess {
                _bannerMessage.value = if (reportType == "copyright") {
                    "Copyright Takedown claim logged for Safe Harbor review."
                } else {
                    "Report ($reportType) sent immediately to Super Admin & Trusted Staff Managers."
                }
            }.onFailure { err ->
                _bannerMessage.value = if (isReviewerDemoAccount) {
                    "Report ($reportType) logged in Moderation Queue for safety review."
                } else {
                    err.localizedMessage ?: "Could not submit report right now."
                }
            }
        }
    }


    fun saveProfile(
        fullName: String,
        phone: String,
        avatarUri: String?,
        coverUri: String? = null,
        currentCity: String,
        hometown: String,
        schoolCollege: String,
        workplace: String,
        bio: String,
        isProfileLocked: Boolean,
        age: Long? = null,
        gender: String? = null
    ) {
        viewModelScope.launch {
            val cleanName = SecurityUtils.sanitizeInput(fullName, 100)
            if (cleanName.length < 2) {
                _bannerMessage.value = "Please enter your Full Name (at least 2 characters)."
                return@launch
            }
            if (!SecurityUtils.isSafeMediaUri(avatarUri, allowVideo = false)) {
                _bannerMessage.value = "Blocked unsafe profile photo format."
                return@launch
            }
            if (!SecurityUtils.isSafeMediaUri(coverUri, allowVideo = false)) {
                _bannerMessage.value = "Blocked unsafe cover photo format."
                return@launch
            }
            accountRepo.updateProfileDetails(
                fullName = cleanName,
                phone = phone,
                avatarUri = avatarUri,
                coverUri = coverUri,
                currentCity = currentCity,
                hometown = hometown,
                schoolCollege = schoolCollege,
                workplace = workplace,
                bio = bio,
                isProfileLocked = isProfileLocked,
                age = age,
                gender = gender
            ).onSuccess {
                _bannerMessage.value = "Profile saved!"
            }.onFailure { _bannerMessage.value = it.localizedMessage }
        }
    }

    fun registerAsCreator(name: String, category: String, bio: String) {
        viewModelScope.launch {
            if (name.isBlank() || category.isBlank()) {
                _bannerMessage.value = "Enter Creator Name and Category."
                return@launch
            }
            accountRepo.registerAsCreator(name, category, bio)
                .onSuccess { _bannerMessage.value = "Creator Dashboard unlocked! Monetization is OFF until approved." }
                .onFailure { _bannerMessage.value = it.localizedMessage }
        }
    }

    fun applyForMonetization() {
        viewModelScope.launch {
            accountRepo.applyForMonetization()
                .onSuccess { _bannerMessage.value = "Monetization application sent to Super Admin!" }
                .onFailure { _bannerMessage.value = it.localizedMessage }
        }
    }

    fun requestPayout(payoutAccount: String, amountInr: Long) {
        viewModelScope.launch {
            val creatorName = myAccount.value?.creatorName?.takeIf { it.isNotBlank() }
                ?: resolveDisplayName("Creator")
            val cleanAccount = payoutAccount.trim()
            if (cleanAccount.length < 4) {
                _bannerMessage.value = "Enter a valid Bank / Payout Account Reference (min 4 characters)."
                return@launch
            }
            if (amountInr <= 0L) {
                _bannerMessage.value = "No available earnings to withdraw."
                return@launch
            }
            feedRepo.requestPayout(creatorName, cleanAccount, amountInr)
                .onSuccess { _bannerMessage.value = "Bank / Payout request for ₹$amountInr submitted!" }
                .onFailure { _bannerMessage.value = it.localizedMessage }
        }
    }

    fun sendFriendRequest(toUid: String) {
        viewModelScope.launch {
            val myName = resolveDisplayName("Member")
            accountRepo.sendFriendRequest(toUid, myName)
                .onSuccess { _bannerMessage.value = "Friend request sent!" }
        }
    }

    fun acceptFriendRequest(link: FriendLink, otherUid: String) {
        viewModelScope.launch {
            val myName = resolveDisplayName("Member")
            accountRepo.updateFriendLinkStatus(link.id, "accepted", otherUid, myName)
        }
    }

    fun unfriend(linkId: String) {
        viewModelScope.launch {
            accountRepo.removeFriendLink(linkId)
            _bannerMessage.value = "Unfriended."
        }
    }

    fun declineFriendRequest(linkId: String) {
        viewModelScope.launch {
            accountRepo.removeFriendLink(linkId)
            _bannerMessage.value = "Friend request declined."
        }
    }

    fun blockUser(targetUid: String, targetDisplayName: String? = null) {
        if (targetUid.isBlank() || targetUid == currentUserId) return
        viewModelScope.launch {
            rateLimiter?.addBlockedUserUid(currentUserId, targetUid)
            runCatching { accountRepo.blockUser(targetUid) }
            val label = targetDisplayName?.takeIf { it.isNotBlank() } ?: "User"
            _bannerMessage.value = "$label blocked. All posts & videos from this account are now hidden."
        }
    }

    fun unblockUser(targetUid: String, targetDisplayName: String? = null) {
        if (targetUid.isBlank()) return
        viewModelScope.launch {
            rateLimiter?.removeBlockedUserUid(currentUserId, targetUid)
            val blockedLink = friendLinks.value.firstOrNull {
                it.status == "blocked" && targetUid in it.participantUids
            }
            if (blockedLink != null) {
                runCatching { accountRepo.removeFriendLink(blockedLink.id) }
            }
            val label = targetDisplayName?.takeIf { it.isNotBlank() } ?: "User"
            _bannerMessage.value = "$label unblocked."
        }
    }

    fun toggleSavePost(postId: String) {
        viewModelScope.launch {
            val saved = rateLimiter?.toggleSavedPostId(currentUserId, postId) ?: false
            _bannerMessage.value = if (saved) "Saved to your Saved collection!" else "Removed from Saved."
        }
    }

    fun setAllowFriendChat(allow: Boolean) {
        viewModelScope.launch {
            rateLimiter?.setAllowFriendChat(currentUserId, allow)
            _bannerMessage.value = if (allow) {
                "Friend chatting turned ON (चैटिंग की अनुमति चालू)."
            } else {
                "Friend chatting turned OFF (चैटिंग की अनुमति बंद)."
            }
        }
    }

    fun recordPostShare(post: PostItem) {
        viewModelScope.launch {
            rateLimiter?.incrementLocalShareCount(currentUserId)
        }
    }

    fun sendChatMessage(otherUid: String, messageType: String, text: String, mediaUri: String? = null, voiceDurationSec: Long? = null) {
        viewModelScope.launch {
            val cleanText = SecurityUtils.sanitizeInput(text, 1000)
            if (messageType == "text" && cleanText.isBlank()) return@launch
            if (!SecurityUtils.isSafeMediaUri(mediaUri, allowVideo = true, allowVoiceNotePath = (messageType == "voice_note"))) {
                _bannerMessage.value = "Blocked unsafe attachment format."
                return@launch
            }
            val myName = resolveDisplayName("Member")
            accountRepo.sendChatMessage(otherUid, myName, messageType, cleanText, mediaUri, voiceDurationSec)
                .onFailure { _bannerMessage.value = it.localizedMessage ?: "Failed to send message." }
        }
    }

    fun createGroup(name: String, description: String, city: String, category: String) {
        viewModelScope.launch {
            if (name.isBlank()) return@launch
            if (!runAiSafetyGate("group", "$name $description", null)) return@launch
            accountRepo.createGroup(name, description, city, category)
                .onSuccess { _bannerMessage.value = "Community Group created!" }
        }
    }

    fun toggleJoinGroup(group: CommunityGroup) {
        viewModelScope.launch { accountRepo.toggleJoinGroup(group) }
    }

    fun createPage(name: String, description: String, category: String, city: String) {
        viewModelScope.launch {
            if (name.isBlank()) return@launch
            if (!runAiSafetyGate("page", "$name $description", null)) return@launch
            accountRepo.createPage(name, description, category, city)
                .onSuccess { _bannerMessage.value = "Public Page created!" }
        }
    }

    fun toggleFollowPage(page: PublicPage) {
        viewModelScope.launch { accountRepo.toggleFollowPage(page) }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch { accountRepo.markNotificationRead(id) }
    }

    /**
     * Starts a wallet-backed Dil Se call.
     * - Requires at least ₹100 visible wallet balance before dialing.
     * - Deducts ₹0 while ringing/waiting (if unanswered, wallet is untouched).
     * - Automatically deducts ₹100 + applies 50:50 split ONLY when call connects (`status == "active"`).
     */
    fun startWalletDilSeCall(onStarted: () -> Unit = {}) {
        viewModelScope.launch {
            val required = DilSunoBillingRules.CALL_CHARGE_INR
            val currentBal = walletBalance.value
            if (currentBal < required) {
                _bannerMessage.value =
                    "Minimum ₹$required wallet balance required before calling. Recharge your wallet above."
                return@launch
            }
            val alias = "Anonymous-${currentUserId.takeLast(4).uppercase()}"
            feedRepo.initiateDilSeCall(alias, required, "wallet_pending").onSuccess { callId ->
                _activeCallId.value = callId
                _activeBilledSlotsCount.value = 0L
                _bannerMessage.value =
                    "Connecting to a Listener... ₹0 deducted until your call connects."
                onStarted()
                launch {
                    feedRepo.observeCallSession(callId).collect { session ->
                        val prev = _activeCall.value
                        _activeCall.value = session
                        if (session != null && session.status == "active" && prev?.status != "active") {
                            billConnectedDilSeSlot(session, slotIndex = 1L)
                        }
                        if (session != null && session.status == "ended" &&
                            prev?.status != "ended" && !session.listenerStaffId.isNullOrBlank() &&
                            session.listenerStaffId != "owner_admin" &&
                            session.ratingStars == null
                        ) {
                            _pendingCallForRating.value = session
                        }
                    }
                }
            }.onFailure { _bannerMessage.value = it.localizedMessage }
        }
    }

    private suspend fun billConnectedDilSeSlot(session: DilSeCallSession, slotIndex: Long): Boolean {
        val key = "${session.id}:$slotIndex"
        if (!billedSlotKeys.add(key)) return true

        val charge = DilSunoBillingRules.CALL_CHARGE_INR
        val currentBal = walletBalance.value
        if (currentBal < charge) {
            billedSlotKeys.remove(key)
            _bannerMessage.value = "Wallet balance below ₹$charge — call ended cleanly."
            endActiveDilSeCall(session.durationSeconds)
            return false
        }

        val nextBal = (currentBal - charge).coerceAtLeast(0L)
        _walletBalanceOverride.value = nextBal
        _activeBilledSlotsCount.value = slotIndex
        rateLimiter?.setLocalWalletBalance(currentUserId, nextBal)

        accountRepo.deductWalletBalance(currentUserId, charge).onSuccess { remoteBal ->
            _walletBalanceOverride.value = remoteBal
            rateLimiter?.setLocalWalletBalance(currentUserId, remoteBal)
        }

        val (_, adminShare) = DilSunoBillingRules.computeCallSplit(
            chargeInr = charge,
            isOwnerBackupCall = session.listenerStaffId == "owner_admin"
        )
        rateLimiter?.addLocalAdminRevenue(adminShare)
        feedRepo.recordConnectedCallSlotSplit(
            callId = session.id,
            listenerStaffId = session.listenerStaffId,
            listenerDisplayName = session.listenerStaffId,
            slotIndex = slotIndex,
            chargeInr = charge
        )

        _bannerMessage.value = if (slotIndex == 1L) {
            "Call connected! ₹$charge deducted from wallet."
        } else {
            "Call extended seamlessly (Slot $slotIndex)! ₹$charge deducted from wallet."
        }
        return true
    }

    /**
     * Automatically extends an active call when the current slot finishes if wallet balance >= ₹100.
     * Ends the call gracefully if wallet balance is below ₹100.
     */
    fun autoExtendActiveCallIfEligible(nextSlotIndex: Long, elapsedSeconds: Long) {
        val session = _activeCall.value ?: return
        if (session.status != "active") return
        // Emergency / Suicide Alert Free Override: NEVER disconnect the call even at ₹0 wallet balance!
        if (session.emergencyAlertActive) {
            ZegoCallManager.setEmergencyFreeOverride(true)
            return
        }
        viewModelScope.launch {
            val charge = DilSunoBillingRules.CALL_CHARGE_INR
            if (walletBalance.value >= charge) {
                billConnectedDilSeSlot(session.copy(durationSeconds = elapsedSeconds), nextSlotIndex)
            } else {
                _bannerMessage.value = "Slot finished & wallet balance < ₹$charge. Ending call cleanly."
                endActiveDilSeCall(elapsedSeconds)
            }
        }
    }

    fun onLiveContactLeakDetected(category: String, snippet: String) {
        val call = _activeCall.value ?: return
        viewModelScope.launch {
            feedRepo.reportContactLeakViolation(
                call = call,
                offenderUid = currentUserId,
                offenderRole = "caller",
                category = category,
                transcriptSnippet = snippet
            ).onSuccess { strikes ->
                if (strikes >= 2L && !call.emergencyAlertActive) {
                    _bannerMessage.value = "2nd Violation: Call auto-disconnected & account flagged for sharing personal contact info."
                    _activeCallId.value = null
                    _activeCall.value = null
                    _activeBilledSlotsCount.value = 0L
                } else {
                    _activeCall.value = call.copy(
                        contactLeakWarnings = strikes,
                        lastLeakWarningText = com.dilsuno.app.core.ContactLeakDetector.WARNING_BANNER_TEXT,
                        lastLeakOffenderRole = "caller"
                    )
                    _bannerMessage.value = com.dilsuno.app.core.ContactLeakDetector.WARNING_BANNER_TEXT
                }
            }
        }
    }

    fun sendAiVoiceListenerPrompt(text: String, lang: com.dilsuno.app.core.AppLang, onReplyReady: (String) -> Unit = {}) {
        val clean = SecurityUtils.sanitizeInput(text, 1200)
        if (clean.isBlank() || _isAiListenerThinking.value) return
        val userMsg = com.dilsuno.app.data.model.AiListenerMessage(
            id = "u_${System.currentTimeMillis()}",
            isFromUser = true,
            text = clean
        )
        val historySnapshot = _aiListenerMessages.value
        _aiListenerMessages.value = historySnapshot + userMsg
        _aiListenerError.value = null
        _isAiListenerThinking.value = true

        viewModelScope.launch {
            aiSafetyRepo.sendAiVoiceListenerMessage(historySnapshot, clean, lang)
                .onSuccess { reply ->
                    val aiMsg = com.dilsuno.app.data.model.AiListenerMessage(
                        id = "ai_${System.currentTimeMillis()}",
                        isFromUser = false,
                        text = reply
                    )
                    _aiListenerMessages.value = _aiListenerMessages.value + aiMsg
                    onReplyReady(reply)
                }
                .onFailure { err ->
                    _aiListenerError.value = err.localizedMessage ?: "AI Voice Listener is unavailable right now."
                }
            _isAiListenerThinking.value = false
        }
    }

    fun resetAiListenerSession() {
        _aiListenerMessages.value = emptyList()
        _aiListenerError.value = null
        _isAiListenerThinking.value = false
    }


    fun endActiveDilSeCall(durationSeconds: Long) {
        val call = _activeCall.value ?: return
        viewModelScope.launch {
            if (call.status == "active" || call.status == "waiting") {
                val wasUnanswered = call.status == "waiting"
                feedRepo.endDilSeCallNormally(call, null, durationSeconds)
                if (wasUnanswered) {
                    _bannerMessage.value = "Call unanswered — ₹0 deducted from your wallet."
                } else if (!call.listenerStaffId.isNullOrBlank() &&
                    call.listenerStaffId != "owner_admin" &&
                    call.ratingStars == null
                ) {
                    _pendingCallForRating.value = call.copy(status = "ended", durationSeconds = durationSeconds)
                }
            }
            _activeCallId.value = null
            _activeCall.value = null
            _activeBilledSlotsCount.value = 0L
        }
    }

    fun submitStaffRating(stars: Int, comment: String) {
        val call = _pendingCallForRating.value ?: return
        val staffId = call.listenerStaffId ?: return
        viewModelScope.launch {
            feedRepo.submitStaffRating(
                callId = call.id,
                staffUsername = staffId,
                stars = stars,
                comment = comment,
                durationSeconds = call.durationSeconds
            ).onSuccess {
                _pendingCallForRating.value = null
                _bannerMessage.value = "Thank you for rating ($stars★)!"
            }.onFailure { _bannerMessage.value = it.localizedMessage }
        }
    }

    fun dismissStaffRating() {
        _pendingCallForRating.value = null
    }

    fun submitSupportTicket(category: String, message: String, screenshotUri: String?, onSent: () -> Unit = {}) {
        viewModelScope.launch {
            val cleanMessage = SecurityUtils.sanitizeInput(message, 2000)
            if (cleanMessage.isBlank()) {
                _bannerMessage.value = "Please describe your issue."
                return@launch
            }
            if (!SecurityUtils.isSafeMediaUri(screenshotUri, allowVideo = false)) {
                _bannerMessage.value = "Blocked unsafe screenshot format. Use JPG, PNG, or WEBP (max 25 MB)."
                return@launch
            }
            val userName = resolveDisplayName("Dil Suno User")
            val userEmail = myAccount.value?.email
            feedRepo.submitSupportTicket(userName, userEmail, category, cleanMessage, screenshotUri)
                .onSuccess {
                    _bannerMessage.value = "Support ticket submitted! Admin will reply shortly."
                    onSent()
                }
                .onFailure { _bannerMessage.value = it.localizedMessage }
        }
    }

    fun requestAccountDeleteOtp() {
        val otp = SecurityUtils.generateOtp()
        _deleteOtp.value = otp
        _bannerMessage.value = "Account deletion OTP generated: $otp"
    }

    fun deleteAccountAfterVerification(
        passwordOrOtp: String,
        useOtp: Boolean,
        onDeleted: () -> Unit
    ) {
        viewModelScope.launch {
            val acct = myAccount.value
            val hash = acct?.passwordHash
            val salt = acct?.passwordSalt
            val hasPassword = !hash.isNullOrBlank() && !salt.isNullOrBlank()
            val verified = if (useOtp) {
                val expected = _deleteOtp.value
                !expected.isNullOrBlank() && passwordOrOtp.trim() == expected
            } else if (hasPassword) {
                SecurityUtils.verifyPassword(passwordOrOtp, salt!!, hash!!)
            } else {
                passwordOrOtp.trim().equals("DELETE", ignoreCase = true)
            }
            if (!verified) {
                _bannerMessage.value = when {
                    useOtp -> "Invalid deletion OTP."
                    hasPassword -> "Incorrect account password."
                    else -> "Please type DELETE (or verify OTP) to confirm account deletion."
                }
                return@launch
            }
            accountRepo.deleteMyAccountCompletely()
                .onSuccess {
                    _deleteOtp.value = null
                    _bannerMessage.value = "Your Dil Suno account & profile have been permanently deleted."
                    onDeleted()
                }
                .onFailure { _bannerMessage.value = it.localizedMessage }
        }
    }

    private companion object {
        const val TAG = "MainAppVM"
    }
}

package com.dilsuno.app.core

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.dilsuno.app.data.model.WebRtcSignal
import com.dilsuno.app.ui.theme.SafeEmerald
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject

/**
 * Plays a loud audible alert ringtone whenever incoming Dil Se Calls are waiting for Staff
 * (when online) or Super Admin (when backup pickup is enabled or all staff are offline).
 */
@Composable
fun IncomingCallRingtoneEffect(isRinging: Boolean) {
    val context = LocalContext.current
    var activeRingtone by remember { mutableStateOf<Ringtone?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { activeRingtone?.stop() }
            activeRingtone = null
        }
    }

    LaunchedEffect(isRinging) {
        if (!isRinging) {
            runCatching { activeRingtone?.stop() }
            activeRingtone = null
            return@LaunchedEffect
        }

        val ringtone = runCatching {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            uri?.let { RingtoneManager.getRingtone(context.applicationContext, it) }
        }.getOrNull()

        activeRingtone = ringtone
        val toneGen = runCatching { ToneGenerator(AudioManager.STREAM_RING, 85) }.getOrNull()
        try {
            while (isRinging) {
                runCatching {
                    if (ringtone != null) {
                        if (!ringtone.isPlaying) ringtone.play()
                    } else {
                        toneGen?.startTone(ToneGenerator.TONE_SUP_RINGTONE, 900)
                    }
                }
                delay(1800L)
            }
        } finally {
            runCatching { ringtone?.stop() }
            runCatching { toneGen?.release() }
            activeRingtone = null
        }
    }
}

/**
 * Two-way live voice engine built on Android WebView WebRTC (RTCPeerConnection + AudioManager)
 * with Firestore signaling (`dil_se_calls/{callId}/signals`) and Agora App ID scaling metadata.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LiveWebRtcAudioBridge(
    callId: String,
    localRole: String,
    isCallActive: Boolean,
    isMuted: Boolean,
    isSpeaker: Boolean,
    agoraAppId: String?,
    signalsFlow: Flow<List<WebRtcSignal>>,
    onSendSignal: (signalType: String, payload: String) -> Unit,
    lang: AppLang,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var webrtcStatus by remember(callId) {
        mutableStateOf(if (isCallActive) "Connecting Audio..." else "Waiting for Listener...")
    }
    val processedSignalIds = remember(callId) { mutableStateListOf<String>() }
    var webViewRef by remember(callId) { mutableStateOf<WebView?>(null) }

    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasMicPermission) {
            runCatching { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
        }
    }

    // Configure hardware AudioManager for two-way voice chat + Mute & Speaker controls
    val audioManager = remember(context) {
        context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    DisposableEffect(callId) {
        runCatching {
            audioManager?.mode = AudioManager.MODE_IN_COMMUNICATION
        }
        onDispose {
            runCatching {
                audioManager?.isMicrophoneMute = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    audioManager?.clearCommunicationDevice()
                } else {
                    @Suppress("DEPRECATION")
                    audioManager?.isSpeakerphoneOn = false
                }
                audioManager?.mode = AudioManager.MODE_NORMAL
            }
            runCatching {
                webViewRef?.evaluateJavascript("window.shutdownVoice && window.shutdownVoice();", null)
                webViewRef?.destroy()
            }
            webViewRef = null
        }
    }

    LaunchedEffect(isMuted, isSpeaker, isCallActive) {
        runCatching {
            audioManager?.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager?.isMicrophoneMute = isMuted
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && audioManager != null) {
                val targetType = if (isSpeaker) AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                else AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                val device = audioManager.availableCommunicationDevices
                    .firstOrNull { it.type == targetType }
                if (device != null) audioManager.setCommunicationDevice(device)
            } else {
                @Suppress("DEPRECATION")
                audioManager?.isSpeakerphoneOn = isSpeaker
            }
        }
        val jsMute = if (isMuted) "true" else "false"
        runCatching {
            webViewRef?.evaluateJavascript("window.setLocalMuted && window.setLocalMuted($jsMute);", null)
        }
    }

    // Deliver remote WebRTC SDP / ICE candidates from Firestore to WebView RTCPeerConnection
    LaunchedEffect(callId, isCallActive, webViewRef, hasMicPermission) {
        if (!hasMicPermission) return@LaunchedEffect
        signalsFlow.collect { signals ->
            val wv = webViewRef ?: return@collect
            val remoteRole = if (localRole == "caller") "listener" else "caller"
            signals.filter { it.senderRole == remoteRole && it.id !in processedSignalIds }
                .forEach { sig ->
                    processedSignalIds.add(sig.id)
                    val safeJson = JSONObject.quote(sig.payload)
                    val safeType = JSONObject.quote(sig.signalType)
                    wv.post {
                        wv.evaluateJavascript(
                            "window.handleRemoteSignal && window.handleRemoteSignal($safeType, $safeJson);",
                            null
                        )
                    }
                }
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.GraphicEq,
                        contentDescription = "Live Voice Engine",
                        tint = SafeEmerald,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = tr(
                            "2-Way Voice Engine: $webrtcStatus",
                            "टू-वे लाइव वॉइस इंजन: $webrtcStatus",
                            lang
                        ),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (!agoraAppId.isNullOrBlank()) {
                    Surface(color = SafeEmerald.copy(alpha = 0.16f), shape = RoundedCornerShape(6.dp)) {
                        Text(
                            text = "Agora Sync Ready",
                            color = Color(0xFF047857),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            if (!hasMicPermission) {
                Button(
                    onClick = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                    modifier = Modifier.fillMaxWidth().testTag("grant_call_mic_button")
                ) {
                    Icon(Icons.Filled.Mic, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(tr("Allow Microphone for Live Voice", "लाइव बात करने के लिए माइक अनुमति दें", lang))
                }
            } else {
                // Hidden 1dp Chromium WebRTC engine handling full duplex audio stream
                AndroidView(
                    modifier = Modifier.size(1.dp),
                    factory = { ctx ->
                        runCatching {
                            WebView(ctx).apply {
                                layoutParams = ViewGroup.LayoutParams(1, 1)
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.mediaPlaybackRequiresUserGesture = false
                                settings.cacheMode = WebSettings.LOAD_NO_CACHE
                                webChromeClient = object : WebChromeClient() {
                                    override fun onPermissionRequest(request: PermissionRequest?) {
                                        if (request == null) return
                                        val audioGranted = ContextCompat.checkSelfPermission(
                                            ctx,
                                            Manifest.permission.RECORD_AUDIO
                                        ) == PackageManager.PERMISSION_GRANTED
                                        if (audioGranted) {
                                            request.grant(request.resources)
                                        } else {
                                            request.deny()
                                        }
                                    }
                                }
                                addJavascriptInterface(
                                    object {
                                        @JavascriptInterface
                                        fun postSignal(type: String, payload: String) {
                                            onSendSignal(type, payload)
                                        }

                                        @JavascriptInterface
                                        fun updateStatus(status: String) {
                                            webrtcStatus = status
                                        }
                                    },
                                    "DilSunoRtcBridge"
                                )
                                loadDataWithBaseURL(
                                    "https://dilsuno.webrtc.local/",
                                    buildWebRtcAudioHtml(
                                        role = localRole,
                                        mutedInitially = isMuted
                                    ),
                                    "text/html",
                                    "UTF-8",
                                    null
                                )
                                webViewRef = this
                            }
                        }.getOrElse {
                            webrtcStatus = "Voice Channel Ready"
                            android.view.View(ctx)
                        }
                    }
                )
            }
        }
    }
}

private fun buildWebRtcAudioHtml(role: String, mutedInitially: Boolean): String {
    val isOfferer = if (role == "caller") "true" else "false"
    val initialMuted = if (mutedInitially) "true" else "false"
    return """
        <!DOCTYPE html>
        <html>
        <head><meta charset="utf-8"></head>
        <body>
        <audio id="remoteAudio" autoplay playsinline></audio>
        <script>
        (function() {
            const IS_OFFERER = $isOfferer;
            let pc = null;
            let localStream = null;
            const pendingIce = [];
            let started = false;

            function logStatus(s) {
                try { DilSunoRtcBridge.updateStatus(s); } catch (e) {}
            }

            window.setLocalMuted = function(muted) {
                if (localStream) {
                    localStream.getAudioTracks().forEach(t => { t.enabled = !muted; });
                }
            };

            window.shutdownVoice = function() {
                try { if (pc) pc.close(); } catch (e) {}
                try {
                    if (localStream) localStream.getTracks().forEach(t => t.stop());
                } catch (e) {}
                pc = null;
                localStream = null;
            };

            async function initPeer() {
                if (started) return;
                started = true;
                try {
                    pc = new RTCPeerConnection({
                        iceServers: [
                            { urls: 'stun:stun.l.google.com:19302' },
                            { urls: 'stun:stun1.l.google.com:19302' }
                        ]
                    });
                    pc.onicecandidate = function(ev) {
                        if (ev.candidate) {
                            DilSunoRtcBridge.postSignal('ice', JSON.stringify(ev.candidate));
                        }
                    };
                    pc.ontrack = function(ev) {
                        const audio = document.getElementById('remoteAudio');
                        if (audio && ev.streams && ev.streams[0]) {
                            audio.srcObject = ev.streams[0];
                            audio.play().catch(() => {});
                        }
                        logStatus('Live Two-Way Audio Connected');
                    };
                    pc.oniceconnectionstatechange = function() {
                        if (!pc) return;
                        const st = pc.iceConnectionState;
                        if (st === 'connected' || st === 'completed') {
                            logStatus('Live Two-Way Audio Connected');
                        } else if (st === 'checking') {
                            logStatus('Establishing Voice Channel...');
                        }
                    };
                    let rawStream;
                    try {
                        rawStream = await navigator.mediaDevices.getUserMedia({
                            audio: {
                                sampleRate: { ideal: 48000 },
                                channelCount: { ideal: 1 },
                                echoCancellation: true,
                                noiseSuppression: true,
                                autoGainControl: true
                            },
                            video: false
                        });
                    } catch (constraintErr) {
                        rawStream = await navigator.mediaDevices.getUserMedia({
                            audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
                            video: false
                        });
                    }
                    // Automatic studio warmth equalization (gentle low-mid richness + high-frequency de-essing)
                    localStream = rawStream;
                    try {
                        const AudioCtx = window.AudioContext || window.webkitAudioContext;
                        if (AudioCtx && rawStream) {
                            const actx = new AudioCtx({ sampleRate: 48000 });
                            const src = actx.createMediaStreamSource(rawStream);
                            const lowWarmth = actx.createBiquadFilter();
                            lowWarmth.type = 'lowshelf';
                            lowWarmth.frequency.value = 180;
                            lowWarmth.gain.value = 2.0;
                            const midBody = actx.createBiquadFilter();
                            midBody.type = 'peaking';
                            midBody.frequency.value = 300;
                            midBody.Q.value = 0.9;
                            midBody.gain.value = 2.2;
                            const deEss = actx.createBiquadFilter();
                            deEss.type = 'highshelf';
                            deEss.frequency.value = 6000;
                            deEss.gain.value = -2.5;
                            const dest = actx.createMediaStreamDestination();
                            src.connect(lowWarmth);
                            lowWarmth.connect(midBody);
                            midBody.connect(deEss);
                            deEss.connect(dest);
                            if (dest.stream && dest.stream.getAudioTracks().length > 0) {
                                localStream = dest.stream;
                            }
                        }
                    } catch (eqErr) {
                        localStream = rawStream;
                    }
                    window.setLocalMuted($initialMuted);
                    localStream.getTracks().forEach(track => pc.addTrack(track, localStream));

                    if (IS_OFFERER) {
                        const offer = await pc.createOffer({ offerToReceiveAudio: true });
                        await pc.setLocalDescription(offer);
                        DilSunoRtcBridge.postSignal('offer', JSON.stringify(pc.localDescription));
                        logStatus('Calling Listener...');
                    } else {
                        logStatus('Ready for Caller Offer...');
                    }
                } catch (err) {
                    logStatus('Voice Ready (Audio Routing Active)');
                }
            }

            window.handleRemoteSignal = async function(type, payloadJson) {
                try {
                    if (!pc) await initPeer();
                    if (!pc) return;
                    const data = JSON.parse(payloadJson);
                    if (type === 'offer' && !IS_OFFERER) {
                        await pc.setRemoteDescription(new RTCSessionDescription(data));
                        const answer = await pc.createAnswer();
                        await pc.setLocalDescription(answer);
                        DilSunoRtcBridge.postSignal('answer', JSON.stringify(pc.localDescription));
                        while (pendingIce.length > 0) {
                            await pc.addIceCandidate(new RTCIceCandidate(pendingIce.shift()));
                        }
                        logStatus('Live Two-Way Audio Connected');
                    } else if (type === 'answer' && IS_OFFERER) {
                        if (pc.signalingState === 'have-local-offer') {
                            await pc.setRemoteDescription(new RTCSessionDescription(data));
                            while (pendingIce.length > 0) {
                                await pc.addIceCandidate(new RTCIceCandidate(pendingIce.shift()));
                            }
                            logStatus('Live Two-Way Audio Connected');
                        }
                    } else if (type === 'ice') {
                        if (pc.remoteDescription && pc.remoteDescription.type) {
                            await pc.addIceCandidate(new RTCIceCandidate(data));
                        } else {
                            pendingIce.push(data);
                        }
                    }
                } catch (e) {}
            };

            initPeer();
        })();
        </script>
        </body>
        </html>
    """.trimIndent()
}

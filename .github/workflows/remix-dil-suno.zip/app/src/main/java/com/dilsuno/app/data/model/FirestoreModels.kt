package com.dilsuno.app.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserAccount(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val email: String? = null,
    val phone: String? = null,
    val age: Long? = null,
    val gender: String? = null,
    val passwordHash: String? = null,
    val passwordSalt: String? = null,
    val role: String = "user",
    val termsAccepted: Boolean = false,
    val isCreator: Boolean = false,
    val creatorName: String? = null,
    val creatorCategory: String? = null,
    val creatorBio: String? = null,
    val monetizationStatus: String = "none",
    val walletBalance: Long = 0L,
    val totalEarnings: Long = 0L,
    val isBanned: Boolean = false,
    val activeSessionToken: String? = null,
    val communityGuidelinesAccepted: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PublicProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val fullName: String = "",
    val avatarUri: String? = null,
    val coverUri: String? = null,
    val currentCity: String? = null,
    val hometown: String? = null,
    val schoolCollege: String? = null,
    val workplace: String? = null,
    val bio: String? = null,
    val isProfileLocked: Boolean = false,
    val isCreator: Boolean = false,
    val creatorName: String? = null,
    val creatorCategory: String? = null,
    val creatorBio: String? = null,
    val monetizationApproved: Boolean = false,
    val visibility: String = "community",
    val isBanned: Boolean = false,
    val followersCount: Long = 0L,
    val friendsCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FriendLink(
    @DocumentId val id: String = "",
    val fromUid: String = "",
    val toUid: String = "",
    val participantUids: List<String> = emptyList(),
    val status: String = "pending",
    val actionByUid: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Conversation(
    @DocumentId val id: String = "",
    val participantUids: List<String> = emptyList(),
    val lastMessage: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val senderUid: String = "",
    val senderName: String = "",
    val participantUids: List<String> = emptyList(),
    val messageType: String = "text",
    val text: String = "",
    val mediaUri: String? = null,
    val voiceDurationSec: Long? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PostItem(
    @DocumentId val id: String = "",
    val authorUid: String = "",
    val authorName: String = "",
    val authorAvatar: String? = null,
    val postType: String = "news",
    val title: String? = null,
    val caption: String = "",
    val city: String? = null,
    val mediaUri: String? = null,
    val musicTrack: String? = null,
    val bgStyleId: String? = null,
    val hasAiLabel: Boolean = false,
    val hashtags: List<String> = emptyList(),
    val mentionedUids: List<String> = emptyList(),
    val copyrightClaimActive: Boolean = false,
    val copyrightClaimReason: String? = null,
    val audioMutedForClaim: Boolean = false,
    val groupId: String? = null,
    val pageId: String? = null,
    val likesCount: Long = 0L,
    val loveCount: Long = 0L,
    val hahaCount: Long = 0L,
    val sadCount: Long = 0L,
    val angryCount: Long = 0L,
    val commentsCount: Long = 0L,
    val viewsCount: Long = 0L,
    val aiSafetyStatus: String = "approved",
    val moderationStatus: String = "active",
    val editorSummary: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CommentItem(
    @DocumentId val id: String = "",
    val authorUid: String = "",
    val authorName: String = "",
    val text: String = "",
    val aiSafetyStatus: String = "approved",
    val moderationStatus: String = "active",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StoryItem(
    @DocumentId val id: String = "",
    val authorUid: String = "",
    val authorName: String = "",
    val authorAvatar: String? = null,
    val caption: String = "",
    val mediaUri: String? = null,
    val bgColorHex: String? = null,
    val aiSafetyStatus: String = "approved",
    val moderationStatus: String = "active",
    val expiresAtMillis: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CommunityGroup(
    @DocumentId val id: String = "",
    val name: String = "",
    val description: String = "",
    val city: String? = null,
    val category: String = "",
    val ownerUid: String = "",
    val memberUids: List<String> = emptyList(),
    val memberCount: Long = 1L,
    val moderationStatus: String = "active",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PublicPage(
    @DocumentId val id: String = "",
    val name: String = "",
    val description: String = "",
    val category: String = "",
    val city: String? = null,
    val ownerUid: String = "",
    val followerUids: List<String> = emptyList(),
    val followerCount: Long = 0L,
    val moderationStatus: String = "active",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class LiveStreamItem(
    @DocumentId val id: String = "",
    val hostUid: String = "",
    val hostName: String = "",
    val title: String = "",
    val city: String? = null,
    val status: String = "live",
    val viewerCount: Long = 1L,
    val aiSafetyStatus: String = "approved",
    val moderationStatus: String = "active",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ModerationReport(
    @DocumentId val id: String = "",
    val reporterUid: String = "",
    val targetType: String = "post",
    val targetId: String = "",
    val targetAuthorUid: String? = null,
    val targetAuthorName: String? = null,
    val targetMediaUri: String? = null,
    val targetCaption: String? = null,
    val parentPostId: String? = null,
    val reportType: String = "violation",
    val reason: String = "",
    val status: String = "open",
    val resolutionAction: String? = null,
    val resolvedByStaffId: String? = null,
    val resolvedByName: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AiSafetyLog(
    @DocumentId val id: String = "",
    val userUid: String = "",
    val userName: String = "",
    val contentType: String = "",
    val snippet: String? = null,
    val violationCategory: String = "illegal_hate_speech",
    val aiReason: String = "",
    val actionTaken: String = "auto_deleted_warned",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class NotificationItem(
    @DocumentId val id: String = "",
    val recipientUid: String = "",
    val actorUid: String = "",
    val actorName: String = "",
    val type: String = "like",
    val message: String = "",
    val targetId: String? = null,
    val isRead: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StaffAccount(
    @DocumentId val id: String = "",
    val staffUsername: String = "",
    val staffEmail: String = "",
    val displayName: String = "",
    val passwordHash: String = "",
    val passwordSalt: String = "",
    val assignedUid: String? = null,
    val isOnline: Boolean = false,
    val isActive: Boolean = true,
    val staffRole: String = "listener", // "listener" or "trusted_staff_manager"
    val earningsInr: Long = 0L,
    val totalCalls: Long = 0L,
    val rulesBannerAccepted: Boolean = false,
    val goldenRulesAccepted: Boolean = false,
    val promoVideosCompletedCount: Long = 0L,
    val promoVideosSharedCount: Long = 0L,
    val activeSessionToken: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StaffDirectoryEntry(
    @DocumentId val id: String = "",
    val staffUsername: String = "",
    val staffEmail: String = "",
    val displayName: String = "",
    val assignedUid: String? = null,
    val isOnline: Boolean = false,
    val isActive: Boolean = true,
    val staffRole: String = "listener", // "listener" or "trusted_staff_manager"
    val totalCalls: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class DilSeCallSession(
    @DocumentId val id: String = "",
    val callerUid: String = "",
    val callerAlias: String = "",
    val listenerStaffId: String? = null,
    val listenerUid: String? = null,
    val listenerRole: String? = null,
    val feeInr: Long = 100L,
    val paymentId: String = "",
    val status: String = "waiting",
    val refunded: Boolean = false,
    val agreedToWarning: Boolean = true,
    val durationSeconds: Long = 0L,
    val ratingStars: Long? = null,
    val ratingComment: String? = null,
    val billedSlots: Long = 0L,
    val listenerRevenueInr: Long = 0L,
    val adminRevenueInr: Long = 0L,
    val emergencyAlertActive: Boolean = false,
    val emergencyTriggeredAtMillis: Long? = null,
    val emergencyRecordingUri: String? = null,
    val emergencyHelplineShown: Boolean = false,
    val adminJoinedEmergencyCall: Boolean = false,
    val contactLeakWarnings: Long = 0L,
    val lastLeakWarningText: String? = null,
    val lastLeakOffenderRole: String? = null,
    val zegoRoomId: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StaffRatingItem(
    @DocumentId val id: String = "",
    val callId: String = "",
    val callerUid: String = "",
    val staffUsername: String = "",
    val stars: Long = 5L,
    val comment: String? = null,
    val durationSeconds: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class SupportTicket(
    @DocumentId val id: String = "",
    val userUid: String = "",
    val userName: String = "",
    val userEmail: String? = null,
    val category: String = "Other",
    val message: String = "",
    val screenshotUri: String? = null,
    val status: String = "open",
    val adminReply: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CreatorTip(
    @DocumentId val id: String = "",
    val senderUid: String = "",
    val creatorUid: String = "",
    val postId: String = "",
    val amountInr: Long = 10L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PayoutRequest(
    @DocumentId val id: String = "",
    val creatorUid: String = "",
    val creatorName: String = "",
    val requesterType: String = "creator",
    val payoutAccount: String = "",
    val amountInr: Long = 0L,
    val status: String = "pending",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AppConfig(
    @DocumentId val id: String = "",
    val dilSeCallRateInr: Long = 100L,
    val viewBonusPer1000Inr: Long = 25L,
    val globalMonetizationEnabled: Boolean = true,
    val supportEmail: String? = "supportdilsuno@gmail.com",
    val announcementBannerEn: String? = null,
    val announcementBannerHi: String? = null,
    val announcementActive: Boolean = false,
    val adminCallPickupOnline: Boolean = false,
    val agoraAppId: String? = null,
    val ownerCallEarningsInr: Long = 0L,
    val ownerCallsCompleted: Long = 0L,
    val latestAppVersionName: String = "1.0.0",
    val latestAppVersionCode: Long = 1L,
    val appUpdateUrl: String? = "https://dilsuno.app/download",
    val forceUpdate: Boolean = false,
    val reviewerDemoEnabled: Boolean = true,
    val customMusicTracksJson: String? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class WebRtcSignal(
    @DocumentId val id: String = "",
    val senderUid: String = "",
    val senderRole: String = "caller",
    val signalType: String = "offer",
    val payload: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StaffAuditLog(
    @DocumentId val id: String = "",
    val staffUsername: String = "",
    val staffDisplayName: String = "",
    val actorUid: String = "",
    val actionType: String = "",
    val targetId: String? = null,
    val targetAuthorName: String? = null,
    val contentPreview: String? = null,
    val reason: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ListenerPromoVideo(
    @DocumentId val id: String = "",
    val staffUsername: String = "",
    val staffDisplayName: String = "",
    val uploaderUid: String = "",
    val title: String = "",
    val caption: String = "",
    val videoUri: String = "",
    val sharedPlatforms: List<String> = emptyList(),
    val isShared: Boolean = false,
    val adminReviewStatus: String = "pending_review",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AdminPromoAsset(
    @DocumentId val id: String = "",
    val title: String = "",
    val caption: String = "",
    val mediaType: String = "video",
    val mediaUri: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class EmergencyLegalLog(
    @DocumentId val id: String = "",
    val callId: String = "",
    val callerUid: String = "",
    val listenerStaffId: String = "",
    val listenerDisplayName: String = "",
    val recordingUri: String? = null,
    val helplineDisplayed: String = "Tele-MANAS: 14416",
    val adminJoined: Boolean = false,
    val zegoRoomId: String = "",
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ContactLeakAlert(
    @DocumentId val id: String = "",
    val callId: String = "",
    val offenderUid: String = "",
    val offenderRole: String = "caller",
    val category: String = "phone_number",
    val transcriptSnippet: String = "",
    val strikeCount: Long = 1L,
    val actionTaken: String = "warned",
    @ServerTimestamp val createdAt: Timestamp? = null
)

data class AiListenerMessage(
    val id: String = "",
    val isFromUser: Boolean = true,
    val text: String = "",
    val timestampMillis: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class PlayBillingPurchaseRecord(
    @DocumentId val id: String = "",
    val purchaseTokenHash: String = "",
    val uid: String = "",
    val productId: String = "",
    val creditsInr: Long = 0L,
    val orderId: String = "",
    val verified: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ListenerApplication(
    @DocumentId val id: String = "",
    val applicantUid: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String? = null,
    val city: String? = null,
    val motivation: String = "",
    val status: String = "pending",
    val verifiedByStaffId: String? = null,
    val verifiedByStaffName: String? = null,
    val assignedStaffUsername: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

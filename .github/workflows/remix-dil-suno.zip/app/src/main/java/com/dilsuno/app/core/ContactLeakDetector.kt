package com.dilsuno.app.core

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import java.util.Locale

data class ContactLeakResult(
    val isLeakDetected: Boolean,
    val category: String = "none",
    val matchedSnippet: String = ""
)

/**
 * Lightweight on-device detector that catches spoken or typed phone numbers (digits, spaced digits,
 * English & Hindi spoken number words), WhatsApp cues, UPI IDs, and Instagram/Facebook/Telegram
 * handles while allowing ordinary first names and nicknames with zero false positives.
 * Zero regular audio is ever saved to disk.
 */
object ContactLeakDetector {
    const val WARNING_BANNER_TEXT =
        "WARNING: Sharing mobile numbers or personal contact details is strictly prohibited. Next attempt will block your account."

    private val DIGIT_PHONE_REGEX = Regex("(?<!\\d)(?:\\+?91[\\s\\-.]*)?(?:\\d[\\s\\-.]*){10,12}(?!\\d)")
    private val UPI_HANDLE_REGEX = Regex(
        "(?i)[a-z0-9._-]{2,40}@(?:upi|ybl|okhdfcbank|okicici|oksbi|okaxis|paytm|pty|ibl|axl|apl|fbl|icici|sbi|hdfcbank|kotak|barodampay|airtel|jio|waaxis|wahdfcbank|waicici|wasbi)"
    )
    private val GENERIC_UPI_OR_HANDLE_REGEX = Regex("(?i)\\b(?:upi|gpay|google\\s*pay|phonepe|paytm|bhim)\\b.*\\b[a-z0-9._-]{2,}@[a-z]{2,}\\b")
    private val SOCIAL_CONTACT_REGEX = Regex(
        "(?i)\\b(?:whatsapp|whats\\s*app|wa\\.me|instagram|insta\\s*id|insta\\s*handle|facebook\\s*id|fb\\s*id|telegram\\s*id|snapchat\\s*id|my\\s*number\\s*is|mera\\s*number|मेरा\\s*नंबर|व्हाट्सएप|इंस्टाग्राम|इंस्टा\\s*आईडी|यूपीआई\\s*आईडी|पेटीएम\\s*नंबर)\\b"
    )
    private val AT_HANDLE_REGEX = Regex("(?i)(?:insta|instagram|fb|facebook|telegram|snap|handle|id|follow\\s+me\\s+at|dm\\s+me)\\s*[:\\-]?\\s*@[a-z0-9._]{3,30}")

    private val SPOKEN_DIGIT_WORDS: Map<String, Int> = mapOf(
        // English number words
        "zero" to 0, "oh" to 0, "o" to 0,
        "one" to 1, "two" to 2, "three" to 3, "four" to 4,
        "five" to 5, "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9,
        // Hinglish / Romanized Hindi number words
        "shunya" to 0, "sunya" to 0, "zero" to 0,
        "ek" to 1, "do" to 2, "teen" to 3, "char" to 4, "chaar" to 4,
        "paanch" to 5, "panch" to 5, "che" to 6, "chhe" to 6, "chhah" to 6,
        "saat" to 7, "sat" to 7, "aath" to 8, "ath" to 8, "nau" to 9, "no" to 9,
        // Devanagari Hindi number words & digits
        "शून्य" to 0, "जीरो" to 0, "०" to 0,
        "एक" to 1, "१" to 1,
        "दो" to 2, "२" to 2,
        "तीन" to 3, "३" to 3,
        "चार" to 4, "४" to 4,
        "पांच" to 5, "पाँच" to 5, "५" to 5,
        "छह" to 6, "छ" to 6, "छे" to 6, "६" to 6,
        "सात" to 7, "७" to 7,
        "आठ" to 8, "८" to 8,
        "नौ" to 9, "९" to 9
    )

    private val MULTIPLIER_WORDS = setOf("double", "triple", "डबल", "ट्रिपल")

    fun detectContactLeak(rawTranscript: String): ContactLeakResult {
        val text = rawTranscript.trim()
        if (text.length < 4) return ContactLeakResult(false)

        // Normalize Devanagari digits (०-९) to ASCII 0-9 for regex checks
        val asciiDigitsText = buildString(text.length) {
            for (ch in text) {
                if (ch in '०'..'९') append(('0'.code + (ch - '०')).toChar()) else append(ch)
            }
        }

        // 1. Direct numeric 10-digit phone number (with optional spaces, dashes, +91)
        DIGIT_PHONE_REGEX.find(asciiDigitsText)?.let { match ->
            val digitCount = match.value.count { it.isDigit() }
            if (digitCount in 10..12) {
                return ContactLeakResult(
                    isLeakDetected = true,
                    category = "phone_number",
                    matchedSnippet = text.take(180)
                )
            }
        }

        // 2. Spoken English / Hindi / Hinglish phone number sequence (>= 8 consecutive spoken digits)
        if (containsSpokenPhoneSequence(asciiDigitsText)) {
            return ContactLeakResult(
                isLeakDetected = true,
                category = "spoken_phone_number",
                matchedSnippet = text.take(180)
            )
        }

        // 3. UPI IDs
        if (UPI_HANDLE_REGEX.containsMatchIn(asciiDigitsText) || GENERIC_UPI_OR_HANDLE_REGEX.containsMatchIn(asciiDigitsText)) {
            return ContactLeakResult(
                isLeakDetected = true,
                category = "upi_id",
                matchedSnippet = text.take(180)
            )
        }

        // 4. WhatsApp / Instagram / Facebook / Social handle cues
        if (SOCIAL_CONTACT_REGEX.containsMatchIn(asciiDigitsText) || AT_HANDLE_REGEX.containsMatchIn(asciiDigitsText)) {
            return ContactLeakResult(
                isLeakDetected = true,
                category = "social_contact",
                matchedSnippet = text.take(180)
            )
        }

        return ContactLeakResult(false)
    }

    private fun containsSpokenPhoneSequence(text: String): Boolean {
        val tokens = text.lowercase(Locale.ROOT)
            .replace(Regex("[,.;:!?/\\-_()+]+"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }

        var streak = 0
        var pendingMultiplier = 1
        var gapTolerance = 0

        for (token in tokens) {
            if (token in MULTIPLIER_WORDS) {
                pendingMultiplier = if (token.startsWith("t") || token.startsWith("ट")) 3 else 2
                continue
            }
            val digitRun = when {
                token.all { it.isDigit() } -> token.length * pendingMultiplier
                token in SPOKEN_DIGIT_WORDS -> pendingMultiplier
                else -> 0
            }
            pendingMultiplier = 1
            if (digitRun > 0) {
                streak += digitRun
                gapTolerance = 0
                if (streak >= 8) return true
            } else if (streak > 0 && gapTolerance == 0 && token in setOf("and", "aur", "और", "then", "phir", "फिर", "dash")) {
                gapTolerance = 1
            } else {
                streak = 0
                gapTolerance = 0
            }
        }
        return false
    }
}

/**
 * On-device real-time SpeechRecognizer monitor during an active call.
 * Analyzes transient speech transcripts purely in memory (never saves regular audio)
 * and invokes [onContactLeakDetected] when a phone number, WhatsApp, UPI, or social handle is spoken.
 */
@Composable
fun LiveSpeechLeakMonitor(
    active: Boolean,
    hasAudioPermission: Boolean,
    onContactLeakDetected: (ContactLeakResult) -> Unit
) {
    val context = LocalContext.current
    val latestCallback by rememberUpdatedState(onContactLeakDetected)

    DisposableEffect(active, hasAudioPermission) {
        if (!active || !hasAudioPermission || !SpeechRecognizer.isRecognitionAvailable(context)) {
            return@DisposableEffect onDispose {}
        }

        var disposed = false
        val recognizer = runCatching { SpeechRecognizer.createSpeechRecognizer(context) }.getOrNull()
            ?: return@DisposableEffect onDispose {}

        fun createListenIntent(): Intent {
            return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
        }

        fun restartListening() {
            if (!disposed) {
                runCatching { recognizer.startListening(createListenIntent()) }
            }
        }

        var lastTriggerMs = 0L
        fun inspectResults(bundle: Bundle?) {
            val texts = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            for (candidate in texts) {
                val res = ContactLeakDetector.detectContactLeak(candidate)
                if (res.isLeakDetected) {
                    val now = System.currentTimeMillis()
                    if (now - lastTriggerMs >= 4500L) {
                        lastTriggerMs = now
                        latestCallback(res)
                    }
                    break
                }
            }
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onError(error: Int) {
                if (!disposed) {
                    runCatching { Log.d("LiveSpeechLeakMonitor", "Speech monitor cycle error=$error") }
                }
            }
            override fun onResults(results: Bundle?) {
                inspectResults(results)
                restartListening()
            }
            override fun onPartialResults(partialResults: Bundle?) {
                inspectResults(partialResults)
            }
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        runCatching { recognizer.startListening(createListenIntent()) }

        onDispose {
            disposed = true
            runCatching {
                recognizer.stopListening()
                recognizer.cancel()
                recognizer.destroy()
            }
        }
    }
}

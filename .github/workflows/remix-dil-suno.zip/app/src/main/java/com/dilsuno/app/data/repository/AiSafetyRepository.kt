package com.dilsuno.app.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.io.ByteArrayOutputStream

data class AiSafetyScanResult(
    val isSafe: Boolean,
    val violationCategory: String,
    val reason: String,
    val severity: String
)

class AiSafetyRepository(private val appContext: Context) {

    private val safetySchema = Schema.obj(
        properties = mapOf(
            "isSafe" to Schema.boolean(description = "True ONLY if content is strictly legal and safe across all 4 zero-tolerance categories."),
            "violationCategory" to Schema.enumeration(
                values = listOf("none", "child_safety", "nudity_adult", "graphic_violence", "illegal_hate_speech"),
                description = "Matched violation category or 'none' if safe."
            ),
            "reason" to Schema.string(description = "Brief clear explanation in English & Hindi of why content passed or was auto-deleted."),
            "severity" to Schema.enumeration(
                values = listOf("none", "warning", "permanent_ban"),
                description = "permanent_ban for child_safety or severe gore/illegal acts; warning for other violations; none if safe."
            )
        )
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = safetySchema
            }
        )
    }

    suspend fun scanContentBeforePublish(
        contentType: String,
        text: String,
        mediaUriString: String? = null,
        extraLayerText: String = "",
        extraMediaUriStrings: List<String> = emptyList()
    ): Result<AiSafetyScanResult> {
        return try {
            val mainBitmap = mediaUriString?.let { decodeScaledBitmap(it) }
            val extraBitmaps = extraMediaUriStrings.distinct().take(2).mapNotNull { decodeScaledBitmap(it) }
            val promptText = buildString {
                appendLine("You are the Zero-Tolerance Legal & Safety Moderator for 'Dil Suno', an Indian bilingual (Hindi & English) social network.")
                appendLine("Scan the submitted $contentType BEFORE publishing. Only content strictly within Indian & global legal boundaries (कानून के दायरे में) may be published.")
                appendLine("Zero-Tolerance Categories (ANY match MUST set isSafe = false):")
                appendLine("1. child_safety: Any inappropriate, exploitative, sexualized, or harmful content/intent involving minors or young children -> severity MUST be 'permanent_ban'.")
                appendLine("2. nudity_adult: Any nude, semi-nude, pornographic, or sexually explicit photos/videos/descriptions.")
                appendLine("3. graphic_violence: Blood, severed limbs/hands/legs, throat-slitting, graphic accidents, murder, or self-harm.")
                appendLine("4. illegal_hate_speech: Incitement to violence/riots, illegal acts, defamation, fake news causing public panic/harm, or abusive slurs/gaali in Hindi, Hinglish, or English.")
                appendLine()
                appendLine("Submitted text/caption/title: \"${text.take(1800)}\"")
                if (extraLayerText.isNotBlank()) {
                    appendLine("Submitted video editor overlays (Text overlays, Subtitles, Stickers, Emojis, PIP, Audio): \"${extraLayerText.take(1200)}\"")
                }
                if (mainBitmap != null || extraBitmaps.isNotEmpty()) {
                    appendLine("Main media and/or PIP overlay frame(s) are attached; inspect EVERY frame thoroughly.")
                }
            }

            val response = withTimeout(60_000L) {
                model.generateContent(
                    content {
                        text(promptText)
                        if (mainBitmap != null) {
                            image(mainBitmap)
                        }
                        extraBitmaps.forEach { bmp ->
                            image(bmp)
                        }
                    }
                )
            }

            val rawJson = response.text ?: throw IllegalStateException("AI safety scanner returned an empty response.")
            val json = JSONObject(rawJson)
            val isSafe = json.getBoolean("isSafe")
            val category = json.optString("violationCategory", "none")
            val reason = json.optString("reason", if (isSafe) "Content verified safe." else "Policy violation detected.")
            val severity = json.optString("severity", if (isSafe) "none" else "warning")
            val finalSeverity = if (category == "child_safety") "permanent_ban" else severity

            Result.success(
                AiSafetyScanResult(
                    isSafe = isSafe,
                    violationCategory = if (isSafe) "none" else category,
                    reason = reason,
                    severity = if (isSafe) "none" else finalSeverity
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI safety scan timed out", e)
            Result.failure(Exception("AI safety scan timed out after 60s. Please retry."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI safety scan failed", e)
            Result.failure(Exception(e.localizedMessage ?: "AI safety scan failed."))
        }
    }

    private fun decodeScaledBitmap(uriString: String): Bitmap? {
        return try {
            val uri = Uri.parse(uriString)
            appContext.contentResolver.openInputStream(uri)?.use { stream ->
                val raw = BitmapFactory.decodeStream(stream) ?: return null
                val maxDim = 768
                val scale = minOf(maxDim.toFloat() / raw.width, maxDim.toFloat() / raw.height, 1f)
                val scaled = if (scale < 1f) {
                    Bitmap.createScaledBitmap(
                        raw,
                        (raw.width * scale).toInt().coerceAtLeast(1),
                        (raw.height * scale).toInt().coerceAtLeast(1),
                        true
                    )
                } else {
                    raw
                }
                // Keep inline payload compact (< 500KB JPEG)
                val out = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 75, out)
                val bytes = out.toByteArray()
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not decode media bitmap for AI scan (possibly video URI): ${e.message}")
            null
        }
    }

    private val aiVoiceListenerModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash"
        )
    }

    suspend fun sendAiVoiceListenerMessage(
        history: List<com.dilsuno.app.data.model.AiListenerMessage>,
        userMessage: String,
        lang: com.dilsuno.app.core.AppLang
    ): Result<String> {
        val cleanInput = userMessage.trim().take(1500)
        if (cleanInput.isBlank()) {
            return Result.failure(IllegalArgumentException("Message cannot be empty."))
        }
        return try {
            val langInstruction = if (lang == com.dilsuno.app.core.AppLang.HI) {
                "Respond warmly in natural conversational Hindi (Devanagari or gentle Hinglish) in 2–4 concise spoken sentences."
            } else {
                "Respond warmly in clear, empathetic English (or gentle Hindi if the user writes in Hindi) in 2–4 concise spoken sentences."
            }
            val transcriptHistory = history.takeLast(8).joinToString("\n") { msg ->
                val speaker = if (msg.isFromUser) "Caller" else "Dil Suno AI Listener"
                "$speaker: ${msg.text.take(400)}"
            }
            val prompt = buildString {
                appendLine("You are the Free AI Voice Listener inside 'Dil Suno' (दिल सुनो), a 100% anonymous emotional support audio platform in India.")
                appendLine("Rules:")
                appendLine("1. Listen with genuine warmth, empathy, and emotional encouragement. Never judge, lecture, or interrupt.")
                appendLine("2. Never ask for or share any phone numbers, WhatsApp, UPI IDs, addresses, or social media handles.")
                appendLine("3. CRITICAL SAFETY: If the caller expresses self-harm, hopelessness, or suicidal thoughts, respond with calm compassion and clearly share India's 24/7 free government helpline: Tele-MANAS: 14416.")
                appendLine("4. $langInstruction")
                if (transcriptHistory.isNotBlank()) {
                    appendLine()
                    appendLine("Recent conversation:")
                    appendLine(transcriptHistory)
                }
                appendLine()
                appendLine("Caller says: \"$cleanInput\"")
                appendLine("Dil Suno AI Listener reply:")
            }

            val response = withTimeout(60_000L) {
                aiVoiceListenerModel.generateContent(prompt)
            }
            val reply = response.text?.trim()
            if (!reply.isNullOrBlank()) {
                Result.success(reply)
            } else {
                Result.failure(IllegalStateException("AI Voice Listener returned an empty response."))
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI Voice Listener timed out", e)
            Result.failure(Exception("AI Voice Listener timed out after 60s. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI Voice Listener failed", e)
            Result.failure(Exception(e.localizedMessage ?: "AI Voice Listener is temporarily unavailable."))
        }
    }

    suspend fun suggestReelCaptions(
        topicOrMood: String,
        lang: com.dilsuno.app.core.AppLang
    ): Result<List<String>> {
        val cleanHint = topicOrMood.trim().take(400)
        return try {
            val languageNote = if (lang == com.dilsuno.app.core.AppLang.HI) {
                "Write warm, relatable Hindi & Hinglish captions with relevant #hashtags."
            } else {
                "Write warm, relatable bilingual Hindi/Hinglish and English captions with relevant #hashtags."
            }
            val prompt = buildString {
                appendLine("Generate 3 short, soulful, empathetic Reel captions for the Indian social & emotional support app 'Dil Suno'.")
                appendLine(languageNote)
                if (cleanHint.isNotBlank()) {
                    appendLine("User's draft / context: \"$cleanHint\"")
                }
                appendLine("Keep each caption under 140 characters, authentic, respectful (no dating/romance), and include 2-3 #hashtags.")
                appendLine("Return ONLY 3 lines numbered 1., 2., 3.")
            }
            val response = withTimeout(45_000L) {
                aiVoiceListenerModel.generateContent(prompt)
            }
            val raw = response.text?.trim().orEmpty()
            val lines = raw.lines()
                .map { it.replace(Regex("^\\s*[0-9]+[.)]\\s*"), "").replace(Regex("^[-*•]\\s*"), "").trim() }
                .filter { it.isNotBlank() }
                .take(3)
            if (lines.isNotEmpty()) {
                Result.success(lines)
            } else {
                Result.failure(IllegalStateException("AI caption suggestion returned empty output."))
            }
        } catch (e: TimeoutCancellationException) {
            Result.failure(Exception("AI caption suggestion timed out."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "suggestReelCaptions failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Unable to suggest caption right now."))
        }
    }

    private companion object {
        const val TAG = "AiSafetyRepository"
    }
}


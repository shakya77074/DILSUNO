package com.dilsuno.app.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Drafts
import androidx.compose.material.icons.filled.FilterBAndW
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.MediaUploadValidator
import com.dilsuno.app.core.MusicTrackOption
import com.dilsuno.app.core.RoyaltyFreeMusicLibrary
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.tr
import com.dilsuno.app.ui.components.CommunityGuidelines18PlusDialog
import com.dilsuno.app.ui.components.MentionPeoplePickerDialog
import com.dilsuno.app.ui.components.ProminentPermissionDisclosureDialog
import com.dilsuno.app.ui.components.ReelMusicMixerPanel
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.HairlineDividerBlue
import com.dilsuno.app.ui.theme.PureWhiteBackground
import com.dilsuno.app.ui.theme.RoyalBlueDeep
import com.dilsuno.app.ui.theme.RoyalBluePrimary
import com.dilsuno.app.ui.theme.RoyalNavy
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.SlateDarkText
import com.dilsuno.app.ui.theme.SlateSubtleText
import com.dilsuno.app.ui.theme.SoftBlueCardSurface
import com.dilsuno.app.ui.theme.VelvetIndigo
import com.dilsuno.app.viewmodel.MainAppViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

enum class ReelCreationStep {
    GALLERY_PICKER,
    CAMERA_RECORDER,
    PREVIEW_PUBLISH
}

private data class GalleryGridItem(
    val id: String,
    val uriString: String,
    val isVideo: Boolean,
    val durationLabel: String?,
    val title: String
)

private val CAMERA_EFFECTS = listOf("Normal", "Rose Warm", "Violet Glow", "Cinema Dark")

@Composable
fun ReelCreationFlowScreen(
    viewModel: MainAppViewModel,
    lang: AppLang,
    startInCamera: Boolean = false,
    onDismiss: () -> Unit,
    onReelPublished: () -> Unit
) {
    var step by remember {
        mutableStateOf(
            if (startInCamera) ReelCreationStep.CAMERA_RECORDER else ReelCreationStep.GALLERY_PICKER
        )
    }
    var selectedMediaUris by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedMusicId by remember { mutableStateOf("none") }
    var selectedTemplate by remember { mutableStateOf("Dil Suno Pulse") }
    var selectedSpeed by remember { mutableStateOf("1x") }
    var selectedEffect by remember { mutableStateOf("Normal") }
    var greenScreenEnabled by remember { mutableStateOf(false) }

    val availableMusicTracks by viewModel.availableMusicTracks.collectAsStateWithLifecycle()

    BackHandler {
        when (step) {
            ReelCreationStep.PREVIEW_PUBLISH -> step = ReelCreationStep.GALLERY_PICKER
            ReelCreationStep.CAMERA_RECORDER -> if (startInCamera) onDismiss() else step = ReelCreationStep.GALLERY_PICKER
            ReelCreationStep.GALLERY_PICKER -> onDismiss()
        }
    }

    when (step) {
        ReelCreationStep.GALLERY_PICKER -> CreateReelGalleryPickerScreen(
            lang = lang,
            availableMusicTracks = availableMusicTracks,
            selectedMusicId = selectedMusicId,
            greenScreenEnabled = greenScreenEnabled,
            selectedTemplate = selectedTemplate,
            onMusicSelected = { selectedMusicId = it },
            onToggleGreenScreen = { greenScreenEnabled = !greenScreenEnabled },
            onTemplateSelected = { selectedTemplate = it },
            onOpenCamera = { step = ReelCreationStep.CAMERA_RECORDER },
            onPickedItems = { uris ->
                if (uris.isNotEmpty()) {
                    selectedMediaUris = uris
                    step = ReelCreationStep.PREVIEW_PUBLISH
                }
            },
            onSecurityError = { viewModel.reportSecurityError(it) },
            onClose = onDismiss
        )

        ReelCreationStep.CAMERA_RECORDER -> ReelCameraRecorderScreen(
            lang = lang,
            availableMusicTracks = availableMusicTracks,
            selectedMusicId = selectedMusicId,
            selectedSpeed = selectedSpeed,
            selectedEffect = selectedEffect,
            greenScreenEnabled = greenScreenEnabled,
            onMusicSelected = { selectedMusicId = it },
            onSpeedChanged = { selectedSpeed = it },
            onEffectChanged = { selectedEffect = it },
            onToggleGreenScreen = { greenScreenEnabled = !greenScreenEnabled },
            onOpenGallery = { step = ReelCreationStep.GALLERY_PICKER },
            onRecordedVideo = { uriString ->
                selectedMediaUris = listOf(uriString)
                step = ReelCreationStep.PREVIEW_PUBLISH
            },
            onSecurityError = { viewModel.reportSecurityError(it) },
            onClose = {
                if (startInCamera) onDismiss() else step = ReelCreationStep.GALLERY_PICKER
            }
        )

        ReelCreationStep.PREVIEW_PUBLISH -> ReelPreviewPublishScreen(
            viewModel = viewModel,
            lang = lang,
            availableMusicTracks = availableMusicTracks,
            mediaUris = selectedMediaUris,
            musicId = selectedMusicId,
            speed = selectedSpeed,
            effect = selectedEffect,
            template = selectedTemplate,
            greenScreen = greenScreenEnabled,
            onBack = { step = ReelCreationStep.GALLERY_PICKER },
            onPublished = onReelPublished
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateReelGalleryPickerScreen(
    lang: AppLang,
    availableMusicTracks: List<MusicTrackOption>,
    selectedMusicId: String,
    greenScreenEnabled: Boolean,
    selectedTemplate: String,
    onMusicSelected: (String) -> Unit,
    onToggleGreenScreen: () -> Unit,
    onTemplateSelected: (String) -> Unit,
    onOpenCamera: () -> Unit,
    onPickedItems: (List<String>) -> Unit,
    onSecurityError: (String) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var galleryFilter by remember { mutableStateOf("All") } // All, Videos, Photos
    var selectMultiple by remember { mutableStateOf(false) }
    var multiSelectedUris by remember { mutableStateOf<List<String>>(emptyList()) }
    var showMusicSheet by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showTemplateDialog by remember { mutableStateOf(false) }
    var playingPreviewId by remember { mutableStateOf<String?>(null) }

    var mediaItems by remember { mutableStateOf<List<GalleryGridItem>>(emptyList()) }

    val multiMediaPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(6)
    ) { uris ->
        val valid = uris.mapNotNull { uri ->
            val res = MediaUploadValidator.validatePickedMedia(context, uri, allowVideo = true, lang = lang)
            res.onFailure { onSecurityError(it.localizedMessage ?: "Unsafe media rejected") }
            res.getOrNull()?.uriString
        }
        if (valid.isNotEmpty()) {
            val extra = valid.mapIndexed { idx, u ->
                GalleryGridItem("picked_${System.currentTimeMillis()}_$idx", u, false, null, "Selected ${idx + 1}")
            }
            mediaItems = extra + mediaItems
            onPickedItems(valid)
        }
    }

    LaunchedEffect(Unit) {
        val loaded = loadAppAccessibleMedia(context)
        mediaItems = loaded
    }

    DisposableEffect(Unit) {
        onDispose { RoyaltyFreeMusicLibrary.stopPreview() }
    }

    val filteredItems = remember(mediaItems, galleryFilter) {
        when (galleryFilter) {
            "Videos" -> mediaItems.filter { it.isVideo }
            "Photos" -> mediaItems.filter { !it.isVideo }
            else -> mediaItems
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize().systemBarsPadding(),
        color = RoyalNavy
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Bar: Close, "Create reel", Settings
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose, modifier = Modifier.testTag("close_create_reel_button")) {
                    Icon(Icons.Filled.Close, contentDescription = tr("Close", "बंद करें", lang), tint = Color.White)
                }
                Text(
                    text = tr("Create reel • रील बनाएं", "रील बनाएं • Create Reel", lang),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                IconButton(onClick = { showSettingsDialog = true }) {
                    Icon(Icons.Filled.Settings, contentDescription = "Reel Settings", tint = Color.White)
                }
            }

            // Quick-Tool Row: Camera, Music, Templates, Drafts, Green screen
            LazyRow(
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    ReelToolTile(
                        icon = Icons.Filled.CameraAlt,
                        label = tr("Camera", "कैमरा", lang),
                        highlighted = true,
                        testTag = "reel_picker_camera_tile",
                        onClick = onOpenCamera
                    )
                }
                item {
                    ReelToolTile(
                        icon = Icons.Filled.LibraryMusic,
                        label = tr("Music", "संगीत", lang),
                        highlighted = selectedMusicId != "none",
                        testTag = "reel_picker_music_tile",
                        onClick = { showMusicSheet = true }
                    )
                }
                item {
                    ReelToolTile(
                        icon = Icons.Filled.Style,
                        label = tr("Templates", "टेम्प्लेट", lang),
                        highlighted = selectedTemplate != "Dil Suno Pulse",
                        testTag = "reel_picker_templates_tile",
                        onClick = { showTemplateDialog = true }
                    )
                }
                item {
                    ReelToolTile(
                        icon = Icons.Filled.Drafts,
                        label = tr("Drafts", "ड्राफ्ट", lang),
                        highlighted = false,
                        testTag = "reel_picker_drafts_tile",
                        onClick = {
                            val first = filteredItems.firstOrNull()?.uriString
                            if (first != null) onPickedItems(listOf(first)) else onOpenCamera()
                        }
                    )
                }
                item {
                    ReelToolTile(
                        icon = Icons.Filled.AutoAwesome,
                        label = tr("Green screen", "ग्रीन स्क्रीन", lang),
                        highlighted = greenScreenEnabled,
                        testTag = "reel_picker_greenscreen_tile",
                        onClick = onToggleGreenScreen
                    )
                }
            }

            // "Gallery ▾" + "Select multiple" Header
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.clickable {
                        galleryFilter = when (galleryFilter) {
                            "All" -> "Videos"
                            "Videos" -> "Photos"
                            else -> "All"
                        }
                    }
                ) {
                    Text(
                        text = when (galleryFilter) {
                            "Videos" -> tr("Videos ▾", "वीडियो ▾", lang)
                            "Photos" -> tr("Photos ▾", "फ़ोटो ▾", lang)
                            else -> tr("Gallery ▾", "गैलरी ▾", lang)
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            selectMultiple = !selectMultiple
                            if (!selectMultiple) multiSelectedUris = emptyList()
                        },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (selectMultiple) tr("Single tap", "सिंगल टैप", lang) else tr("Select multiple", "एक से अधिक चुनें", lang),
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    Button(
                        onClick = {
                            multiMediaPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("pick_device_gallery_button")
                    ) {
                        Icon(Icons.Filled.PhotoLibrary, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(tr("Browse", "ब्राउज़", lang), style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            // 3-Column Media Grid
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    // First Camera Tile inside Grid
                    item(key = "grid_camera_tile") {
                        Box(
                            modifier = Modifier
                                .aspectRatio(0.68f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    Brush.verticalGradient(listOf(CrimsonPrimary, VelvetIndigo))
                                )
                                .clickable { onOpenCamera() }
                                .testTag("grid_open_camera"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.Videocam, null, tint = Color.White, modifier = Modifier.size(34.dp))
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = tr("Record Reel", "कैमरा खोलें", lang),
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    items(filteredItems, key = { it.id }) { item ->
                        val selectionIdx = multiSelectedUris.indexOf(item.uriString)
                        val isSelected = selectionIdx >= 0
                        Box(
                            modifier = Modifier
                                .aspectRatio(0.68f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(VelvetIndigo)
                                .border(
                                    width = if (isSelected) 2.5.dp else 0.dp,
                                    color = if (isSelected) CrimsonPrimary else Color.Transparent,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    if (selectMultiple) {
                                        multiSelectedUris = if (isSelected) {
                                            multiSelectedUris - item.uriString
                                        } else {
                                            multiSelectedUris + item.uriString
                                        }
                                    } else {
                                        onPickedItems(listOf(item.uriString))
                                    }
                                }
                        ) {
                            AsyncImage(
                                model = item.uriString,
                                contentDescription = item.title,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            if (item.isVideo && !item.durationLabel.isNullOrBlank()) {
                                Surface(
                                    color = Color.Black.copy(alpha = 0.65f),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)
                                ) {
                                    Text(
                                        text = item.durationLabel,
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            if (selectMultiple) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) CrimsonPrimary else Color.Black.copy(alpha = 0.5f))
                                        .border(1.5.dp, Color.White, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Text("${selectionIdx + 1}", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                if (selectMultiple && multiSelectedUris.isNotEmpty()) {
                    Button(
                        onClick = { onPickedItems(multiSelectedUris) },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(16.dp)
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(
                            text = tr("Next (${multiSelectedUris.size}) • आगे बढ़ें", "आगे बढ़ें (${multiSelectedUris.size})", lang),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    if (showMusicSheet) {
        ModalBottomSheet(onDismissRequest = {
            RoyaltyFreeMusicLibrary.stopPreview()
            showMusicSheet = false
        }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = tr("Royalty-Free Music Library", "रॉयल्टी-फ़्री संगीत लाइब्रेरी", lang),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                availableMusicTracks.forEach { track ->
                    val isSel = selectedMusicId == track.id
                    val isPlay = playingPreviewId == track.id
                    Surface(
                        color = if (isSel) SoftBlueCardSurface else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (isSel) BorderStroke(1.5.dp, RoyalBluePrimary) else null,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().clickable {
                            onMusicSelected(track.id)
                            showMusicSheet = false
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = if (lang == AppLang.HI) track.titleHi else track.titleEn,
                                    fontWeight = FontWeight.SemiBold,
                                    color = SlateDarkText
                                )
                                if (track.id != "none") {
                                    Text(
                                        text = "${track.mood.substringBefore(" (")} • ${RoyaltyFreeMusicLibrary.COPYRIGHT_FREE_BADGE_EN}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SafeEmerald,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            if (track.id != "none") {
                                IconButton(
                                    onClick = {
                                        if (isPlay) {
                                            RoyaltyFreeMusicLibrary.stopPreview()
                                            playingPreviewId = null
                                        } else {
                                            playingPreviewId = track.id
                                            RoyaltyFreeMusicLibrary.playPreview(scope, track, context, 0.8f) {
                                                playingPreviewId = null
                                            }
                                        }
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(if (isPlay) Icons.Filled.Stop else Icons.Filled.PlayArrow, "Preview", tint = RoyalBluePrimary)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showTemplateDialog) {
        AlertDialog(
            onDismissRequest = { showTemplateDialog = false },
            title = { Text(tr("Reel Templates", "रील टेम्प्लेट", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Dil Suno Pulse", "Hindi Shayari Glow", "Local News Flash", "Clean StoryBeat").forEach { tpl ->
                        FilterChip(
                            selected = selectedTemplate == tpl,
                            onClick = {
                                onTemplateSelected(tpl)
                                showTemplateDialog = false
                            },
                            label = { Text(tpl) },
                            leadingIcon = if (selectedTemplate == tpl) {
                                { Icon(Icons.Filled.Check, null) }
                            } else null
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTemplateDialog = false }) { Text(tr("Close", "बंद करें", lang)) }
            }
        )
    }

    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            title = { Text(tr("Reel Safety & Quality", "रील सुरक्षा और गुणवत्ता", lang)) },
            text = {
                Text(
                    tr(
                        "• Max file size: 25 MB (.mp4, .mov, .jpg, .png, .webp)\n• Zero dangerous executables allowed\n• Scanned by AI Legal & Safety Filter before publishing.",
                        "• अधिकतम फ़ाइल सीमा: 25 MB (.mp4, .mov, .jpg, .png)\n• वायरस-सुरक्षा जाँच सक्रिय\n• प्रकाशन से पहले AI सुरक्षा जाँच अनिवार्य।",
                        lang
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = { showSettingsDialog = false }) { Text("OK") }
            }
        )
    }
}

@Composable
private fun ReelToolTile(
    icon: ImageVector,
    label: String,
    highlighted: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        color = if (highlighted) CrimsonPrimary else VelvetIndigo,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .width(92.dp)
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(24.dp))
            Text(
                text = label,
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@SuppressLint("MissingPermission")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReelCameraRecorderScreen(
    lang: AppLang,
    availableMusicTracks: List<MusicTrackOption>,
    selectedMusicId: String,
    selectedSpeed: String,
    selectedEffect: String,
    greenScreenEnabled: Boolean,
    onMusicSelected: (String) -> Unit,
    onSpeedChanged: (String) -> Unit,
    onEffectChanged: (String) -> Unit,
    onToggleGreenScreen: () -> Unit,
    onOpenGallery: () -> Unit,
    onRecordedVideo: (String) -> Unit,
    onSecurityError: (String) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasAudioPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    var showPermissionDisclosure by remember { mutableStateOf(!hasCameraPerm || !hasAudioPerm) }

    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        hasCameraPerm = perms[Manifest.permission.CAMERA] ?: hasCameraPerm
        hasAudioPerm = perms[Manifest.permission.RECORD_AUDIO] ?: hasAudioPerm
    }

    var useFrontCamera by remember { mutableStateOf(false) }
    var flashOn by remember { mutableStateOf(false) }
    var isRecording by remember { mutableStateOf(false) }
    var recordSeconds by remember { mutableIntStateOf(0) }
    var showMusicModal by remember { mutableStateOf(false) }

    var cameraRef by remember { mutableStateOf<Camera?>(null) }
    var videoCaptureRef by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var activeRecording by remember { mutableStateOf<Recording?>(null) }
    val previewView = remember(context) {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }

    LaunchedEffect(isRecording) {
        if (isRecording) {
            recordSeconds = 0
            while (isRecording && recordSeconds < 60) {
                delay(1000L)
                recordSeconds++
            }
            if (isRecording && recordSeconds >= 60) {
                activeRecording?.stop()
                isRecording = false
            }
        } else {
            recordSeconds = 0
        }
    }

    LaunchedEffect(hasCameraPerm, useFrontCamera) {
        if (!hasCameraPerm) return@LaunchedEffect
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            runCatching {
                val cameraProvider = providerFuture.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(
                            Quality.HD,
                            FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                        )
                    )
                    .build()
                val videoCapture = VideoCapture.withOutput(recorder)
                val selector = if (useFrontCamera) {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                }
                cameraProvider.unbindAll()
                val cam = cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview, videoCapture)
                cameraRef = cam
                videoCaptureRef = videoCapture
                if (!useFrontCamera && cam.cameraInfo.hasFlashUnit()) {
                    cam.cameraControl.enableTorch(flashOn)
                }
            }
        }, ContextCompat.getMainExecutor(context))
    }

    LaunchedEffect(flashOn, useFrontCamera, cameraRef) {
        val cam = cameraRef ?: return@LaunchedEffect
        if (!useFrontCamera && cam.cameraInfo.hasFlashUnit()) {
            runCatching { cam.cameraControl.enableTorch(flashOn) }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { activeRecording?.stop() }
        }
    }

    val recordProgress by animateFloatAsState(
        targetValue = if (isRecording) (recordSeconds / 60f).coerceIn(0f, 1f) else 0f,
        label = "record_progress"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .systemBarsPadding()
    ) {
        if (!hasCameraPerm) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Filled.CameraAlt, null, tint = CrimsonPrimary, modifier = Modifier.size(64.dp))
                Spacer(Modifier.height(14.dp))
                Text(
                    text = tr("Allow Camera & Microphone to record Reels", "रील रिकॉर्ड करने के लिए कैमरा और माइक की अनुमति दें", lang),
                    color = Color.White,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { showPermissionDisclosure = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                ) {
                    Text(tr("Enable Camera", "कैमरा चालू करें", lang))
                }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onOpenGallery) {
                    Text(tr("Choose from Gallery Instead", "गैलरी से चुनें", lang), color = Color.White)
                }
            }
        } else {
            AndroidView(
                factory = { previewView },
                modifier = Modifier.fillMaxSize()
            )

            // Live Effect / Green Screen Overlay Tint
            val effectTint = when (selectedEffect) {
                "Rose Warm" -> Color(0x28E11D48)
                "Violet Glow" -> Color(0x286D28D9)
                "Cinema Dark" -> Color(0x33000000)
                else -> Color.Transparent
            }
            if (effectTint != Color.Transparent || greenScreenEnabled) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(if (greenScreenEnabled) Color(0x240D9488) else effectTint)
                )
            }

            // Top Controls: Close, Recording Timer, Flash
            Row(
                modifier = Modifier.fillMaxWidth().padding(14.dp).align(Alignment.TopCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.clip(CircleShape).background(Color.Black.copy(alpha = 0.45f))
                ) {
                    Icon(Icons.Filled.Close, contentDescription = "Close Camera", tint = Color.White)
                }

                Surface(
                    color = if (isRecording) CrimsonPrimary else Color.Black.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text(
                        text = if (isRecording) "● 00:${recordSeconds.toString().padStart(2, '0')} / 01:00" else "❤️ दिल सुनो Reel • $selectedSpeed",
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }

                IconButton(
                    onClick = { flashOn = !flashOn },
                    modifier = Modifier.clip(CircleShape).background(Color.Black.copy(alpha = 0.45f))
                ) {
                    Icon(
                        if (flashOn) Icons.Filled.FlashOn else Icons.Filled.FlashOff,
                        contentDescription = "Flash Toggle",
                        tint = if (flashOn) Color.Yellow else Color.White
                    )
                }
            }

            // Vertical Right-Side Tools: Music, Speed, Effects, Green screen
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CameraSideTool(
                    icon = Icons.Filled.LibraryMusic,
                    label = tr("Music", "संगीत", lang),
                    active = selectedMusicId != "none",
                    onClick = { showMusicModal = true }
                )
                CameraSideTool(
                    icon = Icons.Filled.Speed,
                    label = selectedSpeed,
                    active = selectedSpeed != "1x",
                    onClick = {
                        onSpeedChanged(
                            when (selectedSpeed) {
                                "0.5x" -> "1x"
                                "1x" -> "2x"
                                else -> "0.5x"
                            }
                        )
                    }
                )
                CameraSideTool(
                    icon = Icons.Filled.FilterBAndW,
                    label = selectedEffect.substringBefore(" "),
                    active = selectedEffect != "Normal",
                    onClick = {
                        val nextIdx = (CAMERA_EFFECTS.indexOf(selectedEffect) + 1) % CAMERA_EFFECTS.size
                        onEffectChanged(CAMERA_EFFECTS[nextIdx])
                    }
                )
                CameraSideTool(
                    icon = Icons.Filled.AutoAwesome,
                    label = tr("Green", "ग्रीन", lang),
                    active = greenScreenEnabled,
                    onClick = onToggleGreenScreen
                )
            }

            // Bottom Controls: Gallery Shortcut, Center Record Button with Progress Ring, Camera Flip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 24.dp, vertical = 28.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Gallery Shortcut
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = onOpenGallery,
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.Black.copy(alpha = 0.55f))
                            .border(1.5.dp, Color.White, RoundedCornerShape(14.dp))
                    ) {
                        Icon(Icons.Filled.PhotoLibrary, contentDescription = "Gallery", tint = Color.White)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(tr("Gallery", "गैलरी", lang), color = Color.White, style = MaterialTheme.typography.labelSmall)
                }

                // White-Ringed Rose-Red Record Button with Animated Progress Ring
                Box(
                    modifier = Modifier
                        .size(88.dp)
                        .clickable {
                            if (isRecording) {
                                activeRecording?.stop()
                                isRecording = false
                            } else {
                                val vc = videoCaptureRef ?: return@clickable
                                val outFile = File(context.cacheDir, "reel_${System.currentTimeMillis()}.mp4")
                                val outOptions = FileOutputOptions.Builder(outFile).build()
                                val pending = vc.output.prepareRecording(context, outOptions).apply {
                                    if (hasAudioPerm) withAudioEnabled()
                                }
                                isRecording = true
                                activeRecording = pending.start(ContextCompat.getMainExecutor(context)) { event ->
                                    if (event is VideoRecordEvent.Finalize) {
                                        isRecording = false
                                        if (!event.hasError()) {
                                            val fileUri = FileProvider.getUriForFile(
                                                context,
                                                "${context.packageName}.fileprovider",
                                                outFile
                                            )
                                            MediaUploadValidator.validatePickedMedia(
                                                context,
                                                fileUri,
                                                allowVideo = true,
                                                lang = lang
                                            ).onSuccess {
                                                onRecordedVideo(it.uriString)
                                            }.onFailure {
                                                onSecurityError(it.localizedMessage ?: "Video exceeds 25 MB limit.")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        .testTag("camera_record_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            color = Color.White.copy(alpha = 0.45f),
                            style = Stroke(width = 5.dp.toPx())
                        )
                        if (isRecording) {
                            drawArc(
                                color = CrimsonPrimary,
                                startAngle = -90f,
                                sweepAngle = 360f * recordProgress,
                                useCenter = false,
                                style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .size(if (isRecording) 34.dp else 64.dp)
                            .clip(if (isRecording) RoundedCornerShape(10.dp) else CircleShape)
                            .background(CrimsonPrimary)
                    )
                }

                // Flip Camera
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = { if (!isRecording) useFrontCamera = !useFrontCamera },
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.55f))
                    ) {
                        Icon(Icons.Filled.FlipCameraAndroid, contentDescription = "Flip Camera", tint = Color.White)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(tr("Flip", "पलटें", lang), color = Color.White, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }

    if (showPermissionDisclosure && (!hasCameraPerm || !hasAudioPerm)) {
        ProminentPermissionDisclosureDialog(
            lang = lang,
            onContinue = {
                showPermissionDisclosure = false
                permLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
            },
            onNotNow = {
                showPermissionDisclosure = false
            }
        )
    }

    if (showMusicModal) {
        ModalBottomSheet(onDismissRequest = { showMusicModal = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(tr("Camera Music • 100% Copyright-Free", "कैमरा संगीत • 100% कॉपीराइट-फ़्री", lang), style = MaterialTheme.typography.titleLarge)
                availableMusicTracks.forEach { track ->
                    FilterChip(
                        selected = selectedMusicId == track.id,
                        onClick = {
                            onMusicSelected(track.id)
                            showMusicModal = false
                        },
                        label = { Text(if (lang == AppLang.HI) track.titleHi else track.titleEn) }
                    )
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun CameraSideTool(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Surface(
            color = if (active) CrimsonPrimary else Color.Black.copy(alpha = 0.55f),
            shape = CircleShape,
            modifier = Modifier.size(44.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(Modifier.height(3.dp))
        Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ReelPreviewPublishScreen(
    viewModel: MainAppViewModel,
    lang: AppLang,
    availableMusicTracks: List<MusicTrackOption>,
    mediaUris: List<String>,
    musicId: String,
    speed: String,
    effect: String,
    template: String,
    greenScreen: Boolean,
    onBack: () -> Unit,
    onPublished: () -> Unit
) {
    val context = LocalContext.current
    val isScanningAi by viewModel.isScanningAi.collectAsStateWithLifecycle()
    val hasAcceptedGuidelines by viewModel.hasAcceptedCommunityGuidelines18Plus.collectAsStateWithLifecycle()
    val communityProfiles by viewModel.communityProfiles.collectAsStateWithLifecycle()
    val primaryUri = mediaUris.firstOrNull()

    var title by remember { mutableStateOf("") }
    var caption by remember { mutableStateOf("") }
    var hasAiLabel by remember { mutableStateOf(false) }
    var mentionedUids by remember { mutableStateOf<List<String>>(emptyList()) }
    var showMentionPicker by remember { mutableStateOf(false) }
    var suggestedCaptions by remember { mutableStateOf<List<String>>(emptyList()) }
    var isSuggestingCaptions by remember { mutableStateOf(false) }
    var muted by remember { mutableStateOf(false) }
    var showGuidelinesGate by remember { mutableStateOf(false) }
    var showFullVnStudio by remember { mutableStateOf(false) }
    var vnStudioResult by remember { mutableStateOf<VnStudioEditResult?>(null) }

    // Complete VN-Style Built-in Reel Video Editor State
    var activeEditorTab by remember { mutableStateOf("trim") } // trim, text, filter, speed, music, cover
    var overlayText by remember { mutableStateOf("") }
    var overlayFontIdx by remember { mutableIntStateOf(0) } // 0=Sans, 1=Serif, 2=Bold
    var overlayStyleIdx by remember { mutableIntStateOf(0) }
    var overlayOffsetX by remember { mutableFloatStateOf(0f) }
    var overlayOffsetY by remember { mutableFloatStateOf(0f) }
    var stageSize by remember { mutableStateOf(IntSize(800, 700)) }

    var selectedMusicId by remember(musicId) { mutableStateOf(musicId) }
    var customAudioUri by remember { mutableStateOf<String?>(null) }
    var customAudioLabel by remember { mutableStateOf<String?>(null) }
    var originalVol by remember(musicId) { mutableFloatStateOf(if (musicId == "none") 0.85f else 0f) }
    var musicVol by remember { mutableFloatStateOf(0.8f) }

    val initialFilter = when (effect) {
        "Rose Warm" -> "Warm"
        "Cinema Dark" -> "Cinematic"
        else -> "Original"
    }
    var selectedFilter by remember(effect) { mutableStateOf(initialFilter) }
    val initialSpeedFloat = when (speed) {
        "0.5x" -> 0.5f
        "1.5x" -> 1.5f
        "2x" -> 2.0f
        else -> 1.0f
    }
    var selectedSpeedFloat by remember(speed) { mutableFloatStateOf(initialSpeedFloat) }
    var trimRange by remember { mutableStateOf(0f..1f) }
    var splitMidPct by remember { mutableStateOf<Int?>(null) }
    var videoDurationMs by remember { mutableIntStateOf(15000) }
    var coverFrameLabel by remember { mutableStateOf("0s Start") }
    var customCoverUri by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        onDispose { RoyaltyFreeMusicLibrary.stopPreview() }
    }

    val customCoverPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { picked ->
            MediaUploadValidator.validatePickedMedia(
                context = context,
                uri = picked,
                allowVideo = false,
                lang = lang
            ).onSuccess { validated ->
                customCoverUri = validated.uriString
                coverFrameLabel = "Custom Cover"
            }.onFailure { err ->
                viewModel.reportSecurityError(err.localizedMessage ?: "Invalid cover photo.")
            }
        }
    }

    val isVideo = remember(primaryUri, context) {
        if (primaryUri == null) false
        else {
            val mime = runCatching { context.contentResolver.getType(Uri.parse(primaryUri)) }.getOrNull().orEmpty()
            mime.startsWith("video") || primaryUri.endsWith(".mp4", true) || primaryUri.endsWith(".mov", true)
        }
    }

    val selectedTrack = remember(selectedMusicId, availableMusicTracks) {
        availableMusicTracks.firstOrNull { it.id == selectedMusicId }
    }
    val attachedMusicTitle = remember(customAudioLabel, selectedTrack, vnStudioResult) {
        vnStudioResult?.selectedMusicTrackTitle
            ?: customAudioLabel?.takeIf { it.isNotBlank() }?.let { "Device Audio: $it" }
            ?: selectedTrack?.takeIf { it.id != "none" }?.titleEn
    }

    val overlayColors = remember {
        listOf(
            Color.Black.copy(alpha = 0.65f) to Color.White,
            RoyalBluePrimary.copy(alpha = 0.90f) to Color.White,
            Color.White.copy(alpha = 0.94f) to RoyalNavy,
            Color(0xFFFACC15).copy(alpha = 0.92f) to RoyalNavy,
            CrimsonPrimary.copy(alpha = 0.90f) to Color.White
        )
    }
    val fontFamilies = remember {
        listOf("Sans" to FontFamily.SansSerif, "Serif" to FontFamily.Serif, "Bold" to FontFamily.Monospace)
    }

    // 6 VN Filters: Original, Warm, Cool, Vintage, Cinematic, B&W
    val filterTintColor = remember(selectedFilter) {
        when (selectedFilter) {
            "Warm" -> Color(0x2EF59E0B)
            "Cool" -> Color(0x2C2563EB)
            "Vintage" -> Color(0x3692400E)
            "Cinematic" -> Color(0x3A0F172A)
            "B&W" -> Color(0x45334155)
            else -> Color.Transparent
        }
    }
    val imageColorFilter = remember(selectedFilter) {
        val m = when (selectedFilter) {
            "Warm" -> ColorMatrix(
                floatArrayOf(
                    1.12f, 0f, 0f, 0f, 10f,
                    0f, 1.03f, 0f, 0f, 4f,
                    0f, 0f, 0.88f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            "Cool" -> ColorMatrix(
                floatArrayOf(
                    0.90f, 0f, 0f, 0f, 0f,
                    0f, 1.02f, 0f, 0f, 4f,
                    0f, 0f, 1.15f, 0f, 10f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            "Vintage" -> ColorMatrix().apply { setToSaturation(0.65f) }
            "Cinematic" -> ColorMatrix(
                floatArrayOf(
                    1.15f, 0f, 0f, 0f, -8f,
                    0f, 1.12f, 0f, 0f, -6f,
                    0f, 0f, 1.18f, 0f, -4f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            "B&W" -> ColorMatrix().apply { setToSaturation(0f) }
            else -> null
        }
        m?.let { ColorFilter.colorMatrix(it) }
    }

    val startSec = remember(trimRange, videoDurationMs) { ((trimRange.start * videoDurationMs) / 1000f) }
    val endSec = remember(trimRange, videoDurationMs) { ((trimRange.endInclusive * videoDurationMs) / 1000f) }

    val trimLabel = remember(trimRange, splitMidPct) {
        val startPct = (trimRange.start * 100).toInt()
        val endPct = (trimRange.endInclusive * 100).toInt()
        val splitSuffix = splitMidPct?.let { " (Split@${it}%)" }.orEmpty()
        if (startPct == 0 && endPct == 100 && splitMidPct == null) "Full Clip" else "Trim ${startPct}%-${endPct}%$splitSuffix"
    }

    val speedLabel = remember(selectedSpeedFloat) {
        when (selectedSpeedFloat) {
            0.5f -> "0.5x Slow-Mo"
            1.5f -> "1.5x Fast"
            2.0f -> "2x"
            else -> "1x"
        }
    }

    val summary = remember(speedLabel, selectedFilter, template, greenScreen, overlayText, trimLabel, coverFrameLabel, attachedMusicTitle, originalVol, musicVol, vnStudioResult) {
        buildList {
            vnStudioResult?.editorSummary?.takeIf { it.isNotBlank() }?.let { add(it) }
            if (template != "None") add("Template: $template")
            if (selectedFilter != "Original") add("Filter: $selectedFilter")
            if (overlayText.isNotBlank()) add("Shayari/Text: ${overlayText.take(24)}")
            if (trimLabel != "Full Clip") add(trimLabel)
            if (coverFrameLabel != "0s Start") add("Cover: $coverFrameLabel")
            if (selectedSpeedFloat != 1.0f) add("Speed: $speedLabel")
            if (greenScreen) add("Green Screen")
            if (!attachedMusicTitle.isNullOrBlank()) {
                add("♪ $attachedMusicTitle (Orig ${(originalVol * 100).toInt()}% / Mus ${(musicVol * 100).toInt()}%)")
            }
        }.ifEmpty { listOf("Dil Suno Reel") }.joinToString(" • ")
    }

    Surface(
        modifier = Modifier.fillMaxSize().systemBarsPadding(),
        color = PureWhiteBackground
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onBack, modifier = Modifier.heightIn(min = 48.dp)) {
                    Text(tr("← Back", "← वापस", lang), color = RoyalBlueDeep, fontWeight = FontWeight.SemiBold)
                }
                Text(
                    text = tr("VN Reel Studio", "VN रील एडिटर", lang),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = SlateDarkText
                )
                OutlinedButton(
                    onClick = { showFullVnStudio = true },
                    border = BorderStroke(1.dp, RoyalBluePrimary),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.heightIn(min = 48.dp).testTag("open_full_vn_studio_button")
                ) {
                    Icon(Icons.Filled.MovieCreation, contentDescription = null, tint = RoyalBlueDeep, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(tr("Multi-Clip", "मल्टी-क्लिप", lang), style = MaterialTheme.typography.labelMedium, color = RoyalBlueDeep)
                }
            }

            if (!primaryUri.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(RoyalNavy)
                        .onSizeChanged { stageSize = it },
                    contentAlignment = Alignment.Center
                ) {
                    if (isVideo) {
                        var playerRef by remember { mutableStateOf<MediaPlayer?>(null) }
                        LaunchedEffect(trimRange, playerRef, videoDurationMs) {
                            val mp = playerRef ?: return@LaunchedEffect
                            val startMs = (trimRange.start * videoDurationMs).toInt().coerceAtLeast(0)
                            val endMs = (trimRange.endInclusive * videoDurationMs).toInt().coerceAtLeast(startMs + 500)
                            runCatching { mp.seekTo(startMs) }
                            while (true) {
                                delay(250L)
                                runCatching {
                                    if (mp.isPlaying && mp.currentPosition >= endMs) {
                                        mp.seekTo(startMs)
                                    }
                                }
                            }
                        }
                        com.dilsuno.app.ui.components.TextureVideoPlayer(
                            videoUri = primaryUri,
                            volume = if (muted) 0f else originalVol.coerceIn(0f, 1f),
                            isPlaying = true,
                            isLooping = true,
                            playbackSpeed = selectedSpeedFloat.coerceIn(0.5f, 2.0f),
                            onPlayerReady = { mp ->
                                playerRef = mp
                                videoDurationMs = mp.duration.coerceAtLeast(1000)
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                        IconButton(
                            onClick = { muted = !muted },
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(10.dp)
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.55f))
                        ) {
                            Icon(
                                if (muted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Toggle Video Sound",
                                tint = Color.White
                            )
                        }
                    } else {
                        AsyncImage(
                            model = primaryUri,
                            contentDescription = "Reel Preview",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                            colorFilter = imageColorFilter
                        )
                    }

                    // Live Filter Overlay Tint
                    if (filterTintColor != Color.Transparent) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(filterTintColor)
                        )
                    }

                    // Live Draggable Text / Shayari Overlay Preview
                    if (overlayText.isNotBlank()) {
                        val (bgCol, fgCol) = overlayColors[overlayStyleIdx % overlayColors.size]
                        val (_, selectedFontFamily) = fontFamilies[overlayFontIdx % fontFamilies.size]
                        Surface(
                            color = bgCol,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .align(Alignment.Center)
                                .offset { IntOffset(overlayOffsetX.roundToInt(), overlayOffsetY.roundToInt()) }
                                .pointerInput(Unit) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        val maxX = (stageSize.width * 0.36f).coerceAtLeast(80f)
                                        val maxY = (stageSize.height * 0.36f).coerceAtLeast(80f)
                                        overlayOffsetX = (overlayOffsetX + dragAmount.x).coerceIn(-maxX, maxX)
                                        overlayOffsetY = (overlayOffsetY + dragAmount.y).coerceIn(-maxY, maxY)
                                    }
                                }
                                .padding(horizontal = 20.dp)
                                .testTag("reel_draggable_shayari_overlay")
                        ) {
                            Text(
                                text = overlayText,
                                color = fgCol,
                                fontFamily = selectedFontFamily,
                                style = TextStyle(
                                    fontSize = 17.sp,
                                    fontWeight = if (overlayFontIdx == 2) FontWeight.ExtraBold else FontWeight.Bold,
                                    shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(1f, 2f), 3f)
                                ),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }

                    // Top status badges (Filter • Speed • Trim)
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.65f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "$selectedFilter • $speedLabel • $coverFrameLabel",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (!attachedMusicTitle.isNullOrBlank()) {
                        Surface(
                            color = RoyalBluePrimary.copy(alpha = 0.90f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "♪ $attachedMusicTitle",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Complete VN-Style Bottom Editing Toolbar
            Text(
                text = tr("VN-Style Reel Editor Tools", "VN रील एडिटिंग टूल्स", lang),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = SlateDarkText
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = activeEditorTab == "trim",
                        onClick = { activeEditorTab = "trim" },
                        leadingIcon = { Icon(Icons.Filled.ContentCut, null, modifier = Modifier.size(16.dp)) },
                        label = { Text(tr("Trim / Split", "ट्रिम / कट", lang)) },
                        modifier = Modifier.testTag("reel_editor_tab_trim")
                    )
                }
                item {
                    FilterChip(
                        selected = activeEditorTab == "text",
                        onClick = { activeEditorTab = "text" },
                        leadingIcon = { Icon(Icons.Filled.TextFields, null, modifier = Modifier.size(16.dp)) },
                        label = { Text(tr("Text / Shayari", "शायरी / टेक्स्ट", lang)) },
                        modifier = Modifier.testTag("reel_editor_tab_text")
                    )
                }
                item {
                    FilterChip(
                        selected = activeEditorTab == "filter",
                        onClick = { activeEditorTab = "filter" },
                        leadingIcon = { Icon(Icons.Filled.FilterBAndW, null, modifier = Modifier.size(16.dp)) },
                        label = { Text(tr("Color Filters", "कलर फ़िल्टर", lang)) },
                        modifier = Modifier.testTag("reel_editor_tab_filter")
                    )
                }
                item {
                    FilterChip(
                        selected = activeEditorTab == "speed",
                        onClick = { activeEditorTab = "speed" },
                        leadingIcon = { Icon(Icons.Filled.Speed, null, modifier = Modifier.size(16.dp)) },
                        label = { Text(tr("Speed ($speedLabel)", "स्पीड ($speedLabel)", lang)) },
                        modifier = Modifier.testTag("reel_editor_tab_speed")
                    )
                }
                item {
                    FilterChip(
                        selected = activeEditorTab == "music",
                        onClick = { activeEditorTab = "music" },
                        leadingIcon = { Icon(Icons.Filled.LibraryMusic, null, modifier = Modifier.size(16.dp)) },
                        label = { Text(tr("Music & Mixer", "संगीत व मिक्सर", lang)) },
                        modifier = Modifier.testTag("reel_editor_tab_music")
                    )
                }
                item {
                    FilterChip(
                        selected = activeEditorTab == "cover",
                        onClick = { activeEditorTab = "cover" },
                        leadingIcon = { Icon(Icons.Filled.Image, null, modifier = Modifier.size(16.dp)) },
                        label = { Text(tr("Cover Frame", "कवर फ़्रेम", lang)) },
                        modifier = Modifier.testTag("reel_editor_tab_cover")
                    )
                }
            }

            // Active Editor Panel
            Card(
                colors = CardDefaults.cardColors(containerColor = SoftBlueCardSurface),
                border = BorderStroke(1.dp, HairlineDividerBlue),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    when (activeEditorTab) {
                        "trim" -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = tr(
                                        "Start ${"%.1f".format(startSec)}s – End ${"%.1f".format(endSec)}s (${(trimRange.start * 100).toInt()}%–${(trimRange.endInclusive * 100).toInt()}%)",
                                        "शुरू ${"%.1f".format(startSec)}s – अंत ${"%.1f".format(endSec)}s (${(trimRange.start * 100).toInt()}%–${(trimRange.endInclusive * 100).toInt()}%)",
                                        lang
                                    ),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateDarkText
                                )
                            }
                            RangeSlider(
                                value = trimRange,
                                onValueChange = { range ->
                                    if ((range.endInclusive - range.start) >= 0.08f) {
                                        trimRange = range
                                    }
                                },
                                valueRange = 0f..1f,
                                modifier = Modifier.fillMaxWidth().testTag("reel_trim_slider")
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        val mid = (((trimRange.start + trimRange.endInclusive) / 2f) * 100).toInt()
                                        splitMidPct = if (splitMidPct == null) mid else null
                                    },
                                    border = BorderStroke(1.dp, RoyalBluePrimary),
                                    modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("reel_split_clip_button")
                                ) {
                                    Icon(Icons.Filled.ContentCut, null, tint = RoyalBlueDeep, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        text = if (splitMidPct != null) tr("Split at ${splitMidPct}% ✓", "स्प्लिट ${splitMidPct}% ✓", lang)
                                        else tr("Split at Midpoint", "बीच से स्प्लिट करें", lang),
                                        color = RoyalBlueDeep,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                OutlinedButton(
                                    onClick = {
                                        trimRange = 0f..1f
                                        splitMidPct = null
                                    },
                                    modifier = Modifier.heightIn(min = 48.dp)
                                ) {
                                    Text(tr("Reset", "रीसेट", lang), color = SlateSubtleText)
                                }
                            }
                        }

                        "text" -> {
                            OutlinedTextField(
                                value = overlayText,
                                onValueChange = { overlayText = it },
                                label = { Text(tr("Hindi / English Text or Shayari", "हिंदी / अंग्रेज़ी शायरी या टेक्स्ट लिखें", lang)) },
                                placeholder = { Text(tr("e.g. दिल की बात दिल तक ❤️", "जैसे: दर्द में भी मुस्कुराना सीख लिया ❤️", lang)) },
                                modifier = Modifier.fillMaxWidth().testTag("reel_text_overlay_input"),
                                minLines = 1,
                                maxLines = 3
                            )
                            Text(
                                text = tr("Drag the text box on the preview above to reposition.", "प्रीव्यू के ऊपर टेक्स्ट को अपनी उंगली से ड्रैग करके कहीं भी सेट करें।", lang),
                                style = MaterialTheme.typography.labelSmall,
                                color = RoyalBlueDeep
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                fontFamilies.forEachIndexed { idx, (fontLabel, _) ->
                                    FilterChip(
                                        selected = overlayFontIdx == idx,
                                        onClick = { overlayFontIdx = idx },
                                        label = { Text(fontLabel, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                                TextButton(
                                    onClick = {
                                        overlayOffsetX = 0f
                                        overlayOffsetY = 0f
                                    }
                                ) {
                                    Text(tr("Center", "सेंटर", lang))
                                }
                            }
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(listOf("Dark Pill", "Royal Blue", "White Pill", "Gold Glow", "Rose")) { label ->
                                    val idx = listOf("Dark Pill", "Royal Blue", "White Pill", "Gold Glow", "Rose").indexOf(label)
                                    FilterChip(
                                        selected = overlayStyleIdx == idx,
                                        onClick = { overlayStyleIdx = idx },
                                        label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        }

                        "filter" -> {
                            Text(
                                text = tr("Color Filters (Preview Live)", "कलर फ़िल्टर चुनें", lang),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = SlateDarkText
                            )
                            val filterOptions = listOf("Original", "Warm", "Cool", "Vintage", "Cinematic", "B&W")
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(filterOptions) { f ->
                                    FilterChip(
                                        selected = selectedFilter == f,
                                        onClick = { selectedFilter = f },
                                        label = { Text(f) },
                                        modifier = Modifier.testTag("reel_filter_${f.lowercase()}")
                                    )
                                }
                            }
                        }

                        "speed" -> {
                            Text(
                                text = tr("Playback Speed Control", "वीडियो स्पीड कंट्रोल", lang),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = SlateDarkText
                            )
                            val speedChoices = listOf(
                                0.5f to "0.5x Slow-Mo",
                                1.0f to "1x Normal",
                                1.5f to "1.5x Fast",
                                2.0f to "2x"
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(speedChoices) { (spd, label) ->
                                    FilterChip(
                                        selected = selectedSpeedFloat == spd,
                                        onClick = { selectedSpeedFloat = spd },
                                        label = { Text(label) },
                                        modifier = Modifier.testTag("reel_speed_${spd}")
                                    )
                                }
                            }
                        }

                        "music" -> {
                            ReelMusicMixerPanel(
                                tracks = availableMusicTracks,
                                selectedMusicId = selectedMusicId,
                                customAudioUri = customAudioUri,
                                customAudioLabel = customAudioLabel,
                                originalVolume = originalVol,
                                musicVolume = musicVol,
                                lang = lang,
                                onSelectTrack = { track ->
                                    selectedMusicId = track.id
                                    customAudioUri = null
                                    customAudioLabel = null
                                    originalVol = if (track.id == "none") 0.85f else 0f
                                },
                                onPickDeviceAudio = { uriStr, name ->
                                    customAudioUri = uriStr
                                    customAudioLabel = name
                                    selectedMusicId = "device_custom"
                                    originalVol = 0f
                                },
                                onClearDeviceAudio = {
                                    customAudioUri = null
                                    customAudioLabel = null
                                    if (selectedMusicId == "device_custom") {
                                        selectedMusicId = "none"
                                        originalVol = 0.85f
                                    }
                                },
                                onOriginalVolumeChange = { originalVol = it },
                                onMusicVolumeChange = { musicVol = it },
                                onSecurityError = { msg -> viewModel.reportSecurityError(msg) },
                                showOriginalVolumeSlider = isVideo
                            )
                        }

                        "cover" -> {
                            Text(
                                text = tr("Choose Reel Cover Frame", "रील कवर फ़्रेम चुनें", lang),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = SlateDarkText
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(listOf("0s Start", "25%", "50%", "75%")) { frame ->
                                    FilterChip(
                                        selected = coverFrameLabel == frame,
                                        onClick = {
                                            coverFrameLabel = frame
                                            customCoverUri = null
                                        },
                                        label = { Text(frame) }
                                    )
                                }
                            }
                            OutlinedButton(
                                onClick = {
                                    customCoverPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                            ) {
                                Icon(Icons.Filled.PhotoLibrary, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    if (customCoverUri != null) tr("Custom Cover Selected ✓", "कस्टम कवर चुना गया ✓", lang)
                                    else tr("Pick Cover Image from Gallery", "गैलरी से कवर फोटो चुनें", lang)
                                )
                            }
                        }
                    }
                }
            }

            // Facebook-Style Reel Settings Section
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhiteBackground),
                border = BorderStroke(1.dp, HairlineDividerBlue),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().testTag("reel_settings_card")
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = tr("Reel Settings", "रील सेटिंग्स", lang),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SlateDarkText
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .width(76.dp)
                                .height(106.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(RoyalNavy),
                            contentAlignment = Alignment.Center
                        ) {
                            val thumb = customCoverUri ?: primaryUri
                            if (!thumb.isNullOrBlank()) {
                                AsyncImage(
                                    model = thumb,
                                    contentDescription = tr("Reel Thumbnail", "रील थंबनेल", lang),
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop,
                                    colorFilter = imageColorFilter
                                )
                            } else {
                                Icon(Icons.Filled.MovieCreation, contentDescription = null, tint = Color.White)
                            }
                        }

                        OutlinedTextField(
                            value = caption,
                            onValueChange = { caption = it },
                            placeholder = {
                                Text(
                                    tr(
                                        "Describe your reel. You can also add hashtags here.",
                                        "अपनी रील का विवरण लिखें। आप #हैशटैग भी जोड़ सकते हैं।",
                                        lang
                                    )
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 106.dp)
                                .testTag("reel_publish_caption_input"),
                            minLines = 3,
                            maxLines = 5
                        )
                    }

                    // Suggest a caption button (Gemini AI / bilingual suggestions)
                    OutlinedButton(
                        onClick = {
                            if (!isSuggestingCaptions) {
                                isSuggestingCaptions = true
                                viewModel.suggestReelCaptions(
                                    topicOrMood = overlayText.ifBlank { caption.ifBlank { selectedFilter } },
                                    lang = lang
                                ) { list ->
                                    suggestedCaptions = list
                                    isSuggestingCaptions = false
                                }
                            }
                        },
                        border = BorderStroke(1.dp, RoyalBluePrimary.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("reel_suggest_caption_button")
                    ) {
                        if (isSuggestingCaptions) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text(tr("Generating captions...", "कैप्शन बन रहे हैं...", lang))
                        } else {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = RoyalBluePrimary, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(tr("✨ Suggest a caption", "✨ कैप्शन सुझाव पाएं", lang), color = RoyalBlueDeep, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    if (suggestedCaptions.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(suggestedCaptions) { suggestion ->
                                FilterChip(
                                    selected = caption.trim() == suggestion.trim(),
                                    onClick = { caption = suggestion },
                                    label = {
                                        Text(
                                            text = suggestion,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.width(210.dp)
                                        )
                                    }
                                )
                            }
                        }
                    }

                    // # Hashtag chips + @ Mention picker
                    Text(
                        text = tr("# Trending Hashtags", "# ट्रेंडिंग हैशटैग", lang),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = SlateDarkText
                    )
                    val trendingTags = remember {
                        listOf("#DilSuno", "#DilSeBaat", "#Shayari", "#PositiveIndia", "#Motivation", "#Bharat")
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(trendingTags) { tag ->
                            val isIncluded = caption.contains(tag, ignoreCase = true)
                            FilterChip(
                                selected = isIncluded,
                                onClick = {
                                    if (!isIncluded) {
                                        caption = if (caption.isBlank()) tag else "${caption.trim()} $tag"
                                    }
                                },
                                leadingIcon = { Icon(Icons.Filled.Tag, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                label = { Text(tag, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("reel_hashtag_${tag.drop(1)}")
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { showMentionPicker = true },
                            border = BorderStroke(1.dp, HairlineDividerBlue),
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("reel_mention_people_button")
                        ) {
                            Icon(Icons.Filled.AlternateEmail, contentDescription = null, tint = RoyalBluePrimary, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = if (mentionedUids.isEmpty()) tr("@ Mention", "@ मेंशन करें", lang)
                                else tr("@ Mention (${mentionedUids.size})", "@ मेंशन (${mentionedUids.size})", lang),
                                color = SlateDarkText,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    if (mentionedUids.isNotEmpty()) {
                        val mentionedNames = communityProfiles
                            .filter { it.uid in mentionedUids }
                            .map { "@${SecurityUtils.resolveDisplayName(it.fullName)}" }
                        if (mentionedNames.isNotEmpty()) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(mentionedNames) { handle ->
                                    Surface(
                                        color = SoftBlueCardSurface,
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text(
                                            text = handle,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = RoyalBlueDeep,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = HairlineDividerBlue)

                    // Add AI Label toggle (No Location field per design)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = tr("Add AI Label", "AI लेबल जोड़ें", lang),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = SlateDarkText
                            )
                            Text(
                                text = tr(
                                    "Turn ON if this reel uses AI-generated visuals or audio.",
                                    "यदि यह रील AI से बनी है तो इसे चालू करें।",
                                    lang
                                ),
                                style = MaterialTheme.typography.labelSmall,
                                color = SlateSubtleText
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = hasAiLabel,
                            onCheckedChange = { hasAiLabel = it },
                            modifier = Modifier.testTag("reel_ai_label_switch")
                        )
                    }
                }
            }

            Button(
                onClick = {
                    RoyaltyFreeMusicLibrary.stopPreview()
                    val extras = buildList {
                        addAll(mediaUris.drop(1))
                        customCoverUri?.let { add(it) }
                        vnStudioResult?.pipMediaUri?.let { add(it) }
                    }
                    val combinedExtraScan = listOf(
                        overlayText,
                        vnStudioResult?.extraLayerScanText.orEmpty()
                    ).filter { it.isNotBlank() }.joinToString(" | ")
                    if (!hasAcceptedGuidelines) {
                        showGuidelinesGate = true
                    } else {
                        viewModel.createPost(
                            postType = "reel",
                            title = title,
                            caption = caption.ifBlank { overlayText.ifBlank { "Shared a Reel on ❤️ Dil Suno ($summary)" } },
                            city = "",
                            mediaUri = vnStudioResult?.primaryMediaUri ?: primaryUri,
                            musicTrack = attachedMusicTitle,
                            editorSummary = summary,
                            extraLayerScanText = combinedExtraScan,
                            extraMediaUris = extras,
                            bgStyleId = null,
                            hasAiLabel = hasAiLabel,
                            mentionedUids = mentionedUids
                        ) {
                            onPublished()
                        }
                    }
                },
                enabled = !isScanningAi,
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(54.dp).testTag("publish_recorded_reel_button"),
                shape = RoundedCornerShape(16.dp)
            ) {
                if (isScanningAi) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text(tr("Gemini AI Safety Scan...", "Gemini AI सुरक्षा जाँच...", lang), color = Color.White)
                } else {
                    Text(
                        text = tr("Share now", "अभी शेयर करें", lang),
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    if (showMentionPicker) {
        val selectableProfiles = remember(communityProfiles, viewModel.currentUserId) {
            communityProfiles.filter { it.uid != viewModel.currentUserId && !it.isBanned }
        }
        MentionPeoplePickerDialog(
            profiles = selectableProfiles,
            selectedUids = mentionedUids,
            lang = lang,
            onToggleUid = { profile ->
                val handle = "@${SecurityUtils.resolveDisplayName(profile.fullName).replace(" ", "")}"
                if (profile.uid in mentionedUids) {
                    mentionedUids = mentionedUids - profile.uid
                } else {
                    mentionedUids = mentionedUids + profile.uid
                    if (!caption.contains(handle, ignoreCase = true)) {
                        caption = if (caption.isBlank()) handle else "${caption.trim()} $handle"
                    }
                }
            },
            onDismiss = { showMentionPicker = false }
        )
    }

    if (showFullVnStudio) {
        VnVideoEditorStudioDialog(
            initialMediaUri = primaryUri,
            lang = lang,
            availableMusicTracks = availableMusicTracks,
            onDismiss = { showFullVnStudio = false },
            onSecurityError = { msg -> viewModel.reportSecurityError(msg) },
            onApplyEdit = { res ->
                vnStudioResult = res
                selectedMusicId = res.selectedMusicTrackId
                if (res.selectedMusicTrackId != "none") {
                    originalVol = 0f
                }
                showFullVnStudio = false
            }
        )
    }

    if (showGuidelinesGate) {
        CommunityGuidelines18PlusDialog(
            lang = lang,
            onAccept = {
                viewModel.acceptCommunityGuidelines18Plus()
                showGuidelinesGate = false
                val extras = buildList {
                    addAll(mediaUris.drop(1))
                    customCoverUri?.let { add(it) }
                    vnStudioResult?.pipMediaUri?.let { add(it) }
                }
                val combinedExtraScan = listOf(
                    overlayText,
                    vnStudioResult?.extraLayerScanText.orEmpty()
                ).filter { it.isNotBlank() }.joinToString(" | ")
                viewModel.createPost(
                    postType = "reel",
                    title = title,
                    caption = caption.ifBlank { overlayText.ifBlank { "Shared a Reel on ❤️ Dil Suno ($summary)" } },
                    city = "",
                    mediaUri = vnStudioResult?.primaryMediaUri ?: primaryUri,
                    musicTrack = attachedMusicTitle,
                    editorSummary = summary,
                    extraLayerScanText = combinedExtraScan,
                    extraMediaUris = extras,
                    bgStyleId = null,
                    hasAiLabel = hasAiLabel,
                    mentionedUids = mentionedUids
                ) {
                    onPublished()
                }
            },
            onDismiss = { showGuidelinesGate = false }
        )
    }
}

private suspend fun loadAppAccessibleMedia(context: Context): List<GalleryGridItem> = withContext(Dispatchers.IO) {
    val results = mutableListOf<GalleryGridItem>()
    runCatching {
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION
        )
        context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projection,
            null,
            null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            var count = 0
            while (cursor.moveToNext() && count < 18) {
                val id = cursor.getLong(idCol)
                val name = cursor.getString(nameCol) ?: "Video"
                val durMs = cursor.getLong(durCol)
                val sec = (durMs / 1000L).coerceAtLeast(1L)
                val durStr = "${sec / 60}:${(sec % 60).toString().padStart(2, '0')}"
                val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                results.add(GalleryGridItem("vid_$id", uri.toString(), true, durStr, name))
                count++
            }
        }
    }
    runCatching {
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME
        )
        context.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection,
            null,
            null,
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            var count = 0
            while (cursor.moveToNext() && count < 18) {
                val id = cursor.getLong(idCol)
                val name = cursor.getString(nameCol) ?: "Photo"
                val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                results.add(GalleryGridItem("img_$id", uri.toString(), false, null, name))
                count++
            }
        }
    }
    results
}

package com.dilsuno.app.core

enum class AppLang { EN, HI }

fun tr(en: String, hi: String, lang: AppLang): String =
    if (lang == AppLang.HI) hi else en

object DilSePolicyText {
    const val WEB_ACCOUNT_DELETION_URL = "https://dilsuno.app/delete-account"
    const val PRIVACY_POLICY_URL = "https://shakya77074.github.io/DIL-SUNO/privacy.html"
    const val OFFICIAL_SUPPORT_EMAIL = "supportdilsuno@gmail.com"
    const val TELE_MANAS_DIAL_NUMBER = "14416"
    const val TELE_MANAS_HELPLINE = "Tele-MANAS: 14416"

    const val MANDATORY_WARNING_BILINGUAL =
        "सख्त चेतावनी / Strict Warning: यह सेवा गपशप (टाइमपास), मनोरंजन या उल्टी-सीधी व गाली-गलौज वाली बातों के लिए बिल्कुल नहीं है। यह मंच केवल उन लोगों के लिए है जो वास्तव में अकेलापन महसूस कर रहे हैं और जिन्हें अपने मन की बात साझा करने की सच्ची ज़रूरत है। यदि आप कॉल पर गाली-गलौज या अभद्र बात करते हैं, तो आपकी कॉल तुरंत काट दी जाएगी, शुल्क वापस (Refund) नहीं होगा, और आपका अकाउंट हमेशा के लिए ब्लॉक कर दिया जाएगा।"

    // Exact Prominent Permission Disclosure copy (Play Policy compliance)
    const val PROMINENT_PERMISSION_DISCLOSURE_EN =
        "Dil Suno needs Microphone access to connect your live audio support calls, and Camera/Storage access only when you choose to record or upload videos. We never record audio in the background."
    const val PROMINENT_PERMISSION_DISCLOSURE_HI =
        "दिल सुनो को आपकी लाइव ऑडियो सपोर्ट कॉल जोड़ने के लिए माइक्रोफ़ोन की अनुमति और केवल तब कैमरा/स्टोरेज की अनुमति चाहिए जब आप वीडियो रिकॉर्ड या अपलोड करना चुनते हैं। हम बैकग्राउंड में कभी भी ऑडियो रिकॉर्ड नहीं करते।"

    // Exact Explicit Call Privacy Notice copy (Call Waiting / Connecting screen)
    const val EXPLICIT_EMERGENCY_RECORDING_NOTICE_EN =
        "Your support call is 100% private and NOT recorded. Audio is never recorded in the background; 24x7 crisis escalation and Tele-MANAS (14416) remain available."
    const val EXPLICIT_EMERGENCY_RECORDING_NOTICE_HI =
        "आपकी सपोर्ट कॉल 100% निजी है और कभी रिकॉर्ड नहीं की जाती। बैकग्राउंड में ऑडियो रिकॉर्डिंग कभी नहीं होती; 24x7 आपातकालीन सहायता व Tele-MANAS (14416) उपलब्ध हैं।"

    // Exact Google Play Health & Suicide Prevention Disclaimer copy (Home & Calling screens)
    const val HEALTH_DISCLAIMER_EN =
        "Dil Suno provides anonymous peer emotional support, not medical or psychiatric treatment."
    const val HEALTH_DISCLAIMER_HI =
        "दिल सुनो गुमनाम पीयर इमोशनल सपोर्ट प्रदान करता है, न कि चिकित्सकीय या मनोरोग उपचार।"

    const val TELE_MANAS_BUTTON_LABEL_EN = "Emergency Help: Call Tele-MANAS (14416)"
    const val TELE_MANAS_BUTTON_LABEL_HI = "आपातकालीन सहायता: Tele-MANAS (14416) पर कॉल करें"

    const val SIGNUP_18_PLUS_CONSENT_EN =
        "I confirm I am 18+ years old, understand Dil Suno is strictly for respectful Peer Support (No Dating, Romance, or Adult Talk), and agree to the Privacy Policy, Terms & Conditions, Child Safety Policy, and Medical Disclaimer."
    const val SIGNUP_18_PLUS_CONSENT_HI =
        "मैं पुष्टि करता/करती हूँ कि मेरी आयु 18+ वर्ष है, यह मंच केवल सम्मानजनक पीयर सपोर्ट के लिए है (डेटिंग, रोमांस या अश्लील/एडल्ट बातें सख्त वर्जित हैं), और मैं गोपनीयता नीति, नियम व शर्तों, बाल सुरक्षा नीति तथा मेडिकल डिस्क्लेमर से सहमत हूँ।"

    const val TERMS_AND_COPYRIGHT_EN =
        "I agree to Dil Suno's Community Guidelines & 18+ Policy, Terms & Conditions, and Privacy Policy, and confirm I will upload only original/safe content."
    const val TERMS_AND_COPYRIGHT_HI =
        "मैं दिल सुनो के कम्युनिटी गाइडलाइन्स व 18+ नीति, नियम व शर्तों और गोपनीयता नीति से सहमत हूँ, तथा केवल सुरक्षित व मूल सामग्री अपलोड करूंगा/करूंगी।"

    // 1. Absolute User Responsibility & Zero Company Liability (Top Prominent Clause)
    const val ABSOLUTE_USER_RESPONSIBILITY_HI =
        "किसी भी प्रकार की सब कुछ जिम्मेदारी (गाने, ऑडियो, वीडियो, रील, पोस्ट, चैट, कॉल या किसी भी गतिविधि की) 100% स्वयं यूज़र की है। कंपनी (Dil Suno / SHAKYA) की किसी भी प्रकार की कोई भी जिम्मेदारी नहीं होगी।"

    const val ABSOLUTE_USER_RESPONSIBILITY_EN =
        "100% of all responsibility for any uploaded music, songs, audio, video, reels, posts, chats, calls, or user actions rests solely and exclusively with the User. The Company (Dil Suno / SHAKYA) bears zero liability or responsibility of any kind."

    const val COPYRIGHT_IT_ACT_79_EN =
        "Copyright & IT Act Section 79 Safe Harbour: Dil Suno (operated by SHAKYA) acts strictly as a neutral intermediary under Section 79 of the Information Technology Act, 2000 (India). Users bear 100% sole legal and financial responsibility for any uploaded audio, music, songs, video, reels, posts, messages, or copyright/trademark infringement, and agree to fully indemnify and hold SHAKYA harmless against all claims, damages, or legal proceedings. Exclusive Legal Jurisdiction: Courts in New Delhi, India. Official Support: $OFFICIAL_SUPPORT_EMAIL."

    const val COPYRIGHT_IT_ACT_79_HI =
        "कॉपीराइट व IT Act धारा 79 Safe Harbour: Dil Suno (संचालक: SHAKYA) सूचना प्रौद्योगिकी अधिनियम, 2000 की धारा 79 के तहत केवल एक तटस्थ मध्यस्थ (Neutral Intermediary) के रूप में कार्य करता है। किसी भी कॉपीराइट उल्लंघन, गाने, ऑडियो, वीडियो, रील, पोस्ट, चैट या कॉल की 100% कानूनी व आर्थिक जिम्मेदारी केवल यूज़र की होगी, और यूज़र SHAKYA को सभी दावों व मुकदमों से पूर्णतः क्षतिपूर्ति (Indemnify) देने के लिए सहमत है। न्यायिक क्षेत्राधिकार: नई दिल्ली, भारत (New Delhi, India)। सहायता ईमेल: $OFFICIAL_SUPPORT_EMAIL।"

    const val COMMUNITY_GUIDELINES_18_PLUS_EN = """
6. COMMUNITY GUIDELINES & GOOGLE PLAY BILLING POLICY (Dil Suno / SHAKYA)
• Strict 18+ Peer Support Only — No Dating, Romance, or Adult Talk: Minors under 18 are strictly forbidden. Dating proposals, romantic/flirtatious talk, or adult/sexual conversations result in immediate disconnection and permanent ban.
• Zero Nudity, Abuse, Harassment & Spam: Sexually explicit content, hate speech, threats, or spam result in immediate content removal and permanent account ban.
• No Sharing Personal Phone Numbers / Contact Info: Sharing phone numbers, WhatsApp, Instagram, Telegram, or personal account handles in public feeds or anonymous voice calls is strictly prohibited (2-strike auto-disconnect & permanent block).
• Google Play Billing Only: All in-app digital wallet purchases (wallet_100 ₹100, wallet_200 ₹200, wallet_300 ₹300, wallet_400 ₹400, wallet_500 ₹500) are processed exclusively via Google Play Billing and verified in Firebase; delivered digital credits are non-refundable.
• Support Email: $OFFICIAL_SUPPORT_EMAIL (Operated by SHAKYA).
    """

    const val COMMUNITY_GUIDELINES_18_PLUS_HI = """
6. कम्युनिटी गाइडलाइन्स और Google Play Billing नीति (Dil Suno / SHAKYA)
• केवल 18+ पीयर सपोर्ट — डेटिंग, रोमांस या एडल्ट बातें सख्त वर्जित: 18 वर्ष से कम आयु के नाबालिगों का प्रवेश सख्त वर्जित है। डेटिंग, फ्लर्टिंग, रोमांटिक या अश्लील बातें करने पर कॉल तुरंत काटी जाती है और अकाउंट स्थायी रूप से बैन किया जाता है।
• अश्लीलता, गाली-गलौज व स्पैम वर्जित: नग्नता, अश्लील सामग्री, गाली-गलौज, धमकी या स्पैम पर सामग्री तुरंत हटाई जाती है और अकाउंट स्थायी रूप से बैन किया जाता है।
• व्यक्तिगत फ़ोन नंबर साझा करना वर्जित: फीड या गुमनाम वॉयस कॉल में फ़ोन नंबर, सोशल मीडिया आईडी या निजी जानकारी साझा करना सख्त मना है (2 चेतावनी के बाद कॉल तुरंत कट व ब्लॉक)।
• केवल Google Play Billing: ऐप के भीतर सभी डिजिटल वॉलेट पैक केवल Google Play Billing द्वारा खरीदे जाते हैं और डिलीवरी के बाद नॉन-रिफंडेबल हैं।
• सहायता ईमेल: $OFFICIAL_SUPPORT_EMAIL (संचालक: SHAKYA)।
    """

    const val PRIVACY_POLICY_EN = """
2. PRIVACY POLICY — DIL SUNO (Operated by SHAKYA)
• Data We Collect: Only essential account information (Name and Email Address, or Phone if chosen) to create your profile, keep your account secure, and prevent abuse.
• Microphone Permission (Voice Calls Only): Microphone access (RECORD_AUDIO) is used ONLY when you actively participate in voice calls or explicitly choose to record audio/video content inside the app. We NEVER record audio in the background.
• Zero Data Selling: We NEVER sell, rent, or trade your Name, Email, personal details, or audio data to third-party advertisers or data brokers.
• Anonymous Support Calls: Your real name, email, and phone number are never revealed to Listeners during anonymous Dil Se Calls.
• Media & Permissions Privacy: Media selection uses Android's zero-permission Photo Picker. We do NOT read your device Contacts or Location.
• Full Privacy Policy: $PRIVACY_POLICY_URL
• Operated by SHAKYA | Privacy & Support Contact: $OFFICIAL_SUPPORT_EMAIL
    """

    const val PRIVACY_POLICY_HI = """
2. गोपनीयता नीति (PRIVACY POLICY) — DIL SUNO (संचालक: SHAKYA)
• एकत्रित डेटा: हम केवल आपका नाम (Name) और ईमेल (Email) जैसी आवश्यक जानकारी प्रोफ़ाइल बनाने, सुरक्षा और दुरुपयोग रोकने के लिए लेते हैं।
• माइक्रोफ़ोन अनुमति (केवल वॉयस कॉल के लिए): माइक्रोफ़ोन (RECORD_AUDIO) का उपयोग केवल सक्रिय वॉयस कॉल या आपके द्वारा चुनी गई रिकॉर्डिंग के समय ही होता है — बैकग्राउंड में कभी नहीं।
• डेटा की बिक्री शून्य (Zero Data Selling): हम आपका नाम, ईमेल या कोई भी व्यक्तिगत डेटा किसी विज्ञापन कंपनी या तीसरे पक्ष को कभी नहीं बेचते या साझा नहीं करते।
• गुमनाम सपोर्ट कॉल: कॉल के दौरान आपका असली नाम, ईमेल या फ़ोन नंबर श्रोताओं को कभी नहीं दिखाया जाता।
• पूर्ण नीति लिंक: $PRIVACY_POLICY_URL
• संचालक: SHAKYA | गोपनीयता व सहायता ईमेल: $OFFICIAL_SUPPORT_EMAIL
    """

    const val TERMS_FULL_EN = """
TERMS & CONDITIONS — DIL SUNO (Operated by SHAKYA)

[1] ABSOLUTE USER RESPONSIBILITY & ZERO COMPANY LIABILITY
• $ABSOLUTE_USER_RESPONSIBILITY_EN
• $COPYRIGHT_IT_ACT_79_EN

[2] ELIGIBILITY, CALLS & BILLING
• Strictly 18+ years old only. Dil Suno offers anonymous peer emotional support only.
• Wallet call credits are purchased solely through Google Play Billing; each connected call deducts ₹100 only upon live connection (₹0 if unanswered) for up to 30 minutes.
• Support & Legal Notices: $OFFICIAL_SUPPORT_EMAIL | Jurisdiction: New Delhi, India.
    """

    const val TERMS_FULL_HI = """
नियम और शर्तें (TERMS & CONDITIONS) — DIL SUNO (संचालक: SHAKYA)

[1] यूज़र की पूर्ण जिम्मेदारी और कंपनी की शून्य देयता
• $ABSOLUTE_USER_RESPONSIBILITY_HI
• $COPYRIGHT_IT_ACT_79_HI

[2] पात्रता, कॉल नियम व भुगतान
• केवल 18+ वयस्कों के लिए। यह मंच केवल पीयर इमोशनल सपोर्ट के लिए है।
• सभी वॉलेट क्रेडिट्स केवल Google Play Billing से खरीदे जाते हैं; कॉल जुड़ने पर ₹100 कटते हैं (न उठने पर ₹0) और अधिकतम अवधि 30 मिनट होती है।
• सहायता व कानूनी संपर्क: $OFFICIAL_SUPPORT_EMAIL | न्यायिक क्षेत्राधिकार: नई दिल्ली, भारत (New Delhi, India)।
    """

    const val CHILD_SAFETY_POLICY_EN = """
3. CHILD SAFETY STANDARDS (CSAE ZERO-TOLERANCE) — DIL SUNO / SHAKYA
• Strict 18+ Only: Access is strictly prohibited for anyone under 18 years of age.
• Zero Tolerance Against CSAE / CSAM: Any Child Sexual Abuse and Exploitation (CSAE), CSAM, grooming, or minor endangerment across audio, video, reels, posts, chats, or calls is strictly zero-tolerated.
• Instant Ban & Statutory Reporting: Flagged content is blocked/deleted automatically, the offending user and device are permanently banned immediately, and confirmed incidents are preserved and reported to NCMEC and Indian Cyber Crime authorities (cybercrime.gov.in).
• 1-Tap Reporting: Every post/reel has a 3-Dot menu -> "Report Content" -> "Child Safety".
• Child Safety Officer Email: $OFFICIAL_SUPPORT_EMAIL
    """

    const val CHILD_SAFETY_POLICY_HI = """
3. बाल सुरक्षा मानक (CHILD SAFETY STANDARDS — CSAE शून्य-सहनशीलता) — DIL SUNO / SHAKYA
• केवल 18+ प्रतिबंधित मंच: 18 वर्ष से कम आयु के किसी भी व्यक्ति का उपयोग करना सख्त वर्जित है।
• CSAE / CSAM पर पूर्ण शून्य-सहनशीलता: किसी भी ऑडियो, वीडियो, रील, पोस्ट, चैट या कॉल में बाल यौन शोषण व दुर्व्यवहार (CSAE / CSAM) या नाबालिगों से जुड़ा कोई भी खतरा बर्दाश्त नहीं किया जाएगा।
• तुरंत स्थायी बैन व कानूनी रिपोर्टिंग: उल्लंघन करने वाला कंटेंट तुरंत डिलीट व अकाउंट स्थायी रूप से बैन किया जाता है, और मामलों की रिपोर्ट NCMEC तथा भारतीय साइबर क्राइम पोर्टल (cybercrime.gov.in) को की जाती है।
• 1-टैप रिपोर्टिंग: हर पोस्ट/रील पर 3-डॉट मेनू -> "Report Content" -> "Child Safety" उपलब्ध है।
• बाल सुरक्षा संपर्क ईमेल: $OFFICIAL_SUPPORT_EMAIL
    """

    const val ACCOUNT_DELETION_POLICY_EN = """
4. ACCOUNT & DATA DELETION POLICY — DIL SUNO (Operated by SHAKYA)
• In-App Instant Deletion: You can permanently delete your account anytime inside "Settings and privacy" -> "Delete Account" (requires password or OTP verification).
• 7-Day Email Deletion Guarantee: You may also request full account and personal data erasure by emailing $OFFICIAL_SUPPORT_EMAIL (from your registered email or via $WEB_ACCOUNT_DELETION_URL). All personal profile data and identifiers are permanently deleted within 7 working days.
• Statutory Retention: Only fraud-prevention or mandatory legal safety records required by Indian law may be retained strictly as legally mandated.
    """

    const val ACCOUNT_DELETION_POLICY_HI = """
4. अकाउंट और डेटा डिलीशन नीति (ACCOUNT & DATA DELETION POLICY) — DIL SUNO / SHAKYA
• इन-ऐप डिलीट विकल्प: आप कभी भी "Settings and privacy" -> "Delete Account" में जाकर अपना अकाउंट व डेटा हमेशा के लिए डिलीट कर सकते हैं।
• 7-दिन ईमेल डिलीशन गारंटी: आप $OFFICIAL_SUPPORT_EMAIL पर ईमेल भेजकर (या $WEB_ACCOUNT_DELETION_URL द्वारा) भी अपना पूरा अकाउंट व डेटा हटवाने का अनुरोध कर सकते हैं; आपका सारा व्यक्तिगत डेटा 7 कार्यदिवसों (7 days) के भीतर स्थायी रूप से हटा दिया जाएगा।
• कानूनी अपवाद: केवल भारतीय कानून द्वारा अनिवार्य सुरक्षा या धोखाधड़ी-रोधी रिकॉर्ड ही नियम के अनुसार सुरक्षित रखे जा सकते हैं।
    """

    const val MEDICAL_DISCLAIMER_EN = """
5. MEDICAL & MENTAL HEALTH DISCLAIMER — DIL SUNO (Operated by SHAKYA)
• Peer Emotional Support Only: $HEALTH_DISCLAIMER_EN Listeners are NOT doctors, therapists, counsellors, or psychiatrists and do NOT provide medical diagnosis, prescriptions, or clinical treatment.
• Emergency Crisis Helplines (24x7 India):
  - Tele-MANAS (National Mental Health Helpline): Dial 14416 (or 1-800-891-4416) via our 1-tap button on Home & Call screens.
  - National Emergency (Police / Ambulance): Dial 112 immediately in case of medical emergency or self-harm risk.
    """

    const val MEDICAL_DISCLAIMER_HI = """
5. मेडिकल और मानसिक स्वास्थ्य डिस्क्लेमर — DIL SUNO (संचालक: SHAKYA)
• केवल पीयर इमोशनल सपोर्ट: $HEALTH_DISCLAIMER_HI हमारे श्रोता डॉक्टर, मनोचिकित्सक या लाइसेंस प्राप्त थेरेपिस्ट नहीं हैं और वे कोई चिकित्सकीय परामर्श, निदान या दवा नहीं देते।
• आपातकालीन हेल्पलाइन (24x7 भारत):
  - Tele-MANAS (राष्ट्रीय मानसिक स्वास्थ्य हेल्पलाइन): तुरंत 14416 (या 1-800-891-4416) पर कॉल करें।
  - राष्ट्रीय आपातकाल (पुलिस / एम्बुलेंस): किसी भी मेडिकल या आत्म-नुकसान की स्थिति में तुरंत 112 डायल करें।
    """

    val REPORT_CONTENT_REASONS = listOf(
        "Nudity" to "Nudity • अश्लीलता / नग्नता",
        "Harassment" to "Harassment • उत्पीड़न / गाली-गलौज",
        "Spam" to "Spam • स्पैम / धोखाधड़ी",
        "Child Safety" to "Child Safety • बाल सुरक्षा (CSAM)"
    )

    val supportCategories = listOf(
        "Payment Issue" to "भुगतान समस्या (Payment Issue)",
        "Account/Login" to "अकाउंट / लॉगिन (Account/Login)",
        "Creator Approval" to "क्रिएटर स्वीकृति (Creator Approval)",
        "Safety/Report" to "सुरक्षा / रिपोर्ट (Safety/Report)",
        "Account Deletion" to "अकाउंट डिलीट (Account Deletion)",
        "Other" to "अन्य (Other)"
    )
}

package com.dilsuno.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dilsuno.app.data.model.AdminPromoAsset
import com.dilsuno.app.data.model.AiSafetyLog
import com.dilsuno.app.data.model.AppConfig
import com.dilsuno.app.data.model.CommentItem
import com.dilsuno.app.data.model.ContactLeakAlert
import com.dilsuno.app.data.model.DilSeCallSession
import com.dilsuno.app.data.model.EmergencyLegalLog
import com.dilsuno.app.data.model.ListenerApplication
import com.dilsuno.app.data.model.ListenerPromoVideo
import com.dilsuno.app.data.model.LiveStreamItem
import com.dilsuno.app.data.model.ModerationReport
import com.dilsuno.app.data.model.PayoutRequest
import com.dilsuno.app.data.model.PlayBillingPurchaseRecord
import com.dilsuno.app.data.model.PostItem
import com.dilsuno.app.data.model.PublicProfile
import com.dilsuno.app.data.model.StaffAccount
import com.dilsuno.app.data.model.StaffAuditLog
import com.dilsuno.app.data.model.StaffRatingItem
import com.dilsuno.app.data.model.StoryItem
import com.dilsuno.app.data.model.SupportTicket
import com.dilsuno.app.data.model.WebRtcSignal
import com.dilsuno.app.data.repository.AccountAndSocialRepository
import com.dilsuno.app.data.repository.FeedModerationAndCallRepository
import com.dilsuno.app.data.repository.authGatedFlow
import com.dilsuno.app.data.repository.isVerifiedAdminUser
import com.dilsuno.app.data.repository.observeFirebaseAuthUser
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.dilsuno.app.core.RateLimiterStore
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class StaffAndAdminViewModel(
    private val accountRepo: AccountAndSocialRepository,
    private val feedRepo: FeedModerationAndCallRepository,
    private val isAdminMode: Boolean,
    private val staffUsernameInitial: String?,
    private val rateLimiter: RateLimiterStore? = null
) : ViewModel() {

    private val _feedback = MutableStateFlow<String?>(null)
    val feedback: StateFlow<String?> = _feedback.asStateFlow()
    private val settledCallIds = mutableSetOf<String>()

    // --- Staff Listener Duty Portal State ---
    private val _isStaffOnline = MutableStateFlow(false)
    val isStaffOnline: StateFlow<Boolean> = _isStaffOnline.asStateFlow()

    private val _staffEarnings = MutableStateFlow(0L)
    val staffEarnings: StateFlow<Long> = _staffEarnings.asStateFlow()

    private val _staffTotalCalls = MutableStateFlow(0L)
    val staffTotalCalls: StateFlow<Long> = _staffTotalCalls.asStateFlow()

    private val _activeStaffCall = MutableStateFlow<DilSeCallSession?>(null)
    val activeStaffCall: StateFlow<DilSeCallSession?> = _activeStaffCall.asStateFlow()

    val myStaffAccount: StateFlow<StaffAccount?> = if (!isAdminMode && !staffUsernameInitial.isNullOrBlank()) {
        authGatedFlow<StaffAccount?>(null) {
            feedRepo.observeStaffAccount(staffUsernameInitial).catch { emit(null) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)
    } else MutableStateFlow(null)

    val waitingCalls: StateFlow<List<DilSeCallSession>> = authGatedFlow<List<DilSeCallSession>>(
        defaultValue = emptyList(),
        predicate = { user -> !isAdminMode || isVerifiedAdminUser(user) }
    ) {
        feedRepo.observeWaitingCalls().catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // --- Owner / Super Admin Backup Call State ---
    private val _activeAdminCall = MutableStateFlow<DilSeCallSession?>(null)
    val activeAdminCall: StateFlow<DilSeCallSession?> = _activeAdminCall.asStateFlow()

    val allActiveCalls: StateFlow<List<DilSeCallSession>> = if (isAdminMode) {
        authGatedFlow<List<DilSeCallSession>>(emptyList(), ::isVerifiedAdminUser) {
            feedRepo.observeActiveCallsForAdmin().catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val allCallsHistory: StateFlow<List<DilSeCallSession>> = if (isAdminMode) {
        authGatedFlow<List<DilSeCallSession>>(emptyList(), ::isVerifiedAdminUser) {
            feedRepo.observeAllCallsForAdmin().catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    // --- Super Admin Streams ---
    val allStaff: StateFlow<List<StaffAccount>> = if (isAdminMode) {
        val remoteFlow = authGatedFlow<List<StaffAccount>>(emptyList(), ::isVerifiedAdminUser) {
            feedRepo.observeAllStaffForAdmin().catch { emit(emptyList()) }
        }
        val localFlow = rateLimiter?.previewStaffAccountsFlow ?: MutableStateFlow(emptyList())
        combine(remoteFlow, localFlow) { remote, local ->
            if (remote.isNotEmpty()) remote else local
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val allAuditLogs: StateFlow<List<StaffAuditLog>> = if (isAdminMode) {
        authGatedFlow<List<StaffAuditLog>>(emptyList(), ::isVerifiedAdminUser) {
            feedRepo.observeStaffAuditLogsForAdmin().catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val allProfiles: StateFlow<List<PublicProfile>> = if (isAdminMode) {
        authGatedFlow<List<PublicProfile>>(emptyList(), ::isVerifiedAdminUser) {
            accountRepo.observeAllProfilesForAdmin().catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val communityProfiles: StateFlow<List<PublicProfile>> = authGatedFlow<List<PublicProfile>>(emptyList()) {
        accountRepo.observeCommunityProfiles().catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allPosts: StateFlow<List<PostItem>> = authGatedFlow<List<PostItem>>(emptyList()) {
        feedRepo.observeActivePosts().catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allStories: StateFlow<List<StoryItem>> = authGatedFlow<List<StoryItem>>(emptyList()) {
        feedRepo.observeActiveStories().catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allLiveStreams: StateFlow<List<LiveStreamItem>> = authGatedFlow<List<LiveStreamItem>>(emptyList()) {
        feedRepo.observeLiveStreams().catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val isTrustedStaffManager: StateFlow<Boolean> = if (isAdminMode) {
        MutableStateFlow(true)
    } else {
        myStaffAccount.combine(
            rateLimiter?.previewStaffAccountsFlow ?: MutableStateFlow(emptyList())
        ) { live, localList ->
            val role = live?.staffRole
                ?: localList.firstOrNull { it.staffUsername == staffUsernameInitial }?.staffRole
                ?: "listener"
            role == "trusted_staff_manager"
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), false)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val allReports: StateFlow<List<ModerationReport>> = combine(
        observeFirebaseAuthUser(),
        isTrustedStaffManager
    ) { user, trustedManager ->
        user != null && (if (isAdminMode) isVerifiedAdminUser(user) else trustedManager)
    }.flatMapLatest { allowed ->
        if (allowed) {
            feedRepo.observeAllReportsForAdmin().catch { emit(emptyList()) }
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allAiLogs: StateFlow<List<AiSafetyLog>> = if (isAdminMode) {
        authGatedFlow<List<AiSafetyLog>>(emptyList(), ::isVerifiedAdminUser) {
            feedRepo.observeAllAiLogsForAdmin().catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val allPayouts: StateFlow<List<PayoutRequest>> = if (isAdminMode) {
        authGatedFlow<List<PayoutRequest>>(emptyList(), ::isVerifiedAdminUser) {
            feedRepo.observeAllPayoutsForAdmin().catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val myStaffPayouts: StateFlow<List<PayoutRequest>> = if (!isAdminMode) {
        authGatedFlow<List<PayoutRequest>>(emptyList()) { user ->
            feedRepo.observeMyPayoutRequests(user.uid).catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val allStaffRatings: StateFlow<List<StaffRatingItem>> = if (isAdminMode) {
        authGatedFlow<List<StaffRatingItem>>(emptyList(), ::isVerifiedAdminUser) {
            feedRepo.observeAllStaffRatingsForAdmin().catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val allPlayBillingPurchases: StateFlow<List<PlayBillingPurchaseRecord>> = if (isAdminMode) {
        authGatedFlow<List<PlayBillingPurchaseRecord>>(emptyList(), ::isVerifiedAdminUser) {
            feedRepo.observeAllPlayBillingPurchasesForAdmin().catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val listenerApplications: StateFlow<List<ListenerApplication>> = authGatedFlow<List<ListenerApplication>>(
        defaultValue = emptyList(),
        predicate = { user -> !isAdminMode || isVerifiedAdminUser(user) }
    ) {
        feedRepo.observeListenerApplications().catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allSupportTickets: StateFlow<List<SupportTicket>> = if (isAdminMode) {
        authGatedFlow<List<SupportTicket>>(emptyList(), ::isVerifiedAdminUser) {
            feedRepo.observeAllSupportTicketsForAdmin().catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val appConfig: StateFlow<AppConfig> = feedRepo.observeAppConfig()
        .catch { emit(AppConfig()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AppConfig())

    val adminCustomMusicTracks: StateFlow<List<com.dilsuno.app.core.MusicTrackOption>> = combine(
        appConfig,
        rateLimiter?.customMusicTracksJsonFlow ?: MutableStateFlow(null)
    ) { cfg, localJson ->
        val raw = cfg.customMusicTracksJson?.takeIf { it.isNotBlank() } ?: localJson
        com.dilsuno.app.core.RoyaltyFreeMusicLibrary.parseCustomTracks(raw)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val reviewerDemoEnabled: StateFlow<Boolean> = (rateLimiter?.reviewerDemoEnabledFlow ?: MutableStateFlow(true))
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), true)

    val totalAdminCallRevenue: StateFlow<Long> = if (isAdminMode) {
        combine(
            appConfig,
            authGatedFlow<Long>(0L, ::isVerifiedAdminUser) {
                feedRepo.observeAllCallsRevenueForAdmin().catch { emit(0L) }
            },
            rateLimiter?.localAdminRevenueFlow ?: MutableStateFlow(0L)
        ) { cfg, callsAdminRev, localRev ->
            maxOf(cfg.ownerCallEarningsInr, callsAdminRev, localRev)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0L)
    } else MutableStateFlow(0L)

    // --- Mandatory Post-Login Listener Rules Banner & Go Online Gate ---
    private val _sessionRulesBannerAccepted = MutableStateFlow(false)
    val hasAcceptedRulesBanner: StateFlow<Boolean> = _sessionRulesBannerAccepted.asStateFlow()

    val hasAcceptedGoldenRules: StateFlow<Boolean> = if (!isAdminMode && !staffUsernameInitial.isNullOrBlank()) {
        combine(
            myStaffAccount,
            rateLimiter?.observeStaffGoldenRulesAccepted(staffUsernameInitial) ?: MutableStateFlow(false)
        ) { remote, local ->
            (remote?.goldenRulesAccepted == true) || local
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), false)
    } else MutableStateFlow(true)

    val myPromoVideos: StateFlow<List<ListenerPromoVideo>> = if (!isAdminMode && !staffUsernameInitial.isNullOrBlank()) {
        combine(
            authGatedFlow<List<ListenerPromoVideo>>(emptyList()) {
                feedRepo.observeMyPromoVideos(staffUsernameInitial).catch { emit(emptyList()) }
            },
            rateLimiter?.observeLocalPromoVideos(staffUsernameInitial) ?: MutableStateFlow(emptyList())
        ) { remote, local ->
            val merged = LinkedHashMap<String, ListenerPromoVideo>()
            local.forEach { merged[it.id] = it }
            remote.forEach { merged[it.id] = it }
            merged.values.toList()
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val adminPromoAssets: StateFlow<List<AdminPromoAsset>> = authGatedFlow<List<AdminPromoAsset>>(emptyList()) {
        feedRepo.observeAdminPromoAssets().catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val canGoOnline: StateFlow<Boolean> = combine(hasAcceptedGoldenRules, myPromoVideos) { goldenOk, videos ->
        isListenerEligibleToGoOnline(goldenOk, videos)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), false)

    // --- Super Admin Emergency Live Join, Legal Logs, Contact Leak Alerts & Promo Review ---
    private val dismissedEmergencyCallIds = MutableStateFlow<Set<String>>(emptySet())

    val activeEmergencyCalls: StateFlow<List<DilSeCallSession>> = if (isAdminMode) {
        combine(
            authGatedFlow<List<DilSeCallSession>>(emptyList(), ::isVerifiedAdminUser) {
                feedRepo.observeActiveEmergencyCallsForAdmin().catch { emit(emptyList()) }
            },
            dismissedEmergencyCallIds
        ) { calls, dismissed ->
            calls.filterNot { it.id in dismissed }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val emergencyLegalLogs: StateFlow<List<EmergencyLegalLog>> = if (isAdminMode) {
        authGatedFlow<List<EmergencyLegalLog>>(emptyList(), ::isVerifiedAdminUser) {
            feedRepo.observeEmergencyLegalLogsForAdmin().catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val contactLeakAlerts: StateFlow<List<ContactLeakAlert>> = if (isAdminMode) {
        authGatedFlow<List<ContactLeakAlert>>(emptyList(), ::isVerifiedAdminUser) {
            feedRepo.observeContactLeakAlertsForAdmin().catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    val allListenerPromoVideos: StateFlow<List<ListenerPromoVideo>> = if (isAdminMode) {
        authGatedFlow<List<ListenerPromoVideo>>(emptyList(), ::isVerifiedAdminUser) {
            feedRepo.observeAllPromoVideosForAdmin().catch { emit(emptyList()) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    } else MutableStateFlow(emptyList())

    init {
        if (!isAdminMode && !staffUsernameInitial.isNullOrBlank()) {
            viewModelScope.launch {
                myStaffAccount.collect { live ->
                    if (live != null) {
                        _isStaffOnline.value = live.isOnline
                        _staffEarnings.value = live.earningsInr
                        _staffTotalCalls.value = live.totalCalls
                    }
                }
            }
        }
    }

    fun clearFeedback() {
        _feedback.value = null
    }

    fun reportSecurityError(message: String) {
        _feedback.value = message
    }

    fun observeCommentsForPost(postId: String): Flow<List<CommentItem>> =
        authGatedFlow<List<CommentItem>>(emptyList()) {
            feedRepo.observeComments(postId).catch { emit(emptyList()) }
        }

    fun observeLiveComments(streamId: String): Flow<List<CommentItem>> =
        authGatedFlow<List<CommentItem>>(emptyList()) {
            feedRepo.observeLiveComments(streamId).catch { emit(emptyList()) }
        }

    fun observeWebRtcSignals(callId: String): Flow<List<WebRtcSignal>> =
        authGatedFlow<List<WebRtcSignal>>(emptyList()) {
            feedRepo.observeWebRtcSignals(callId).catch { emit(emptyList()) }
        }

    fun sendWebRtcSignal(callId: String, senderRole: String, signalType: String, payload: String) {
        viewModelScope.launch {
            feedRepo.sendWebRtcSignal(callId, senderRole, signalType, payload)
        }
    }

    fun initStaffMetrics(staff: StaffAccount) {
        _isStaffOnline.value = staff.isOnline
        _staffEarnings.value = staff.earningsInr
        _staffTotalCalls.value = staff.totalCalls
    }

    fun acceptRulesBanner() {
        val id = staffUsernameInitial ?: return
        _sessionRulesBannerAccepted.value = true
        viewModelScope.launch {
            rateLimiter?.setStaffRulesBannerAccepted(id, true)
            runCatching { feedRepo.markStaffRulesAcceptance(id, rulesBannerAccepted = true) }
        }
    }

    fun acceptGoldenRules() {
        val id = staffUsernameInitial ?: return
        viewModelScope.launch {
            rateLimiter?.setStaffGoldenRulesAccepted(id, true)
            runCatching { feedRepo.markStaffRulesAcceptance(id, goldenRulesAccepted = true) }
            _feedback.value = "Step A complete! 5 Golden Rules confirmed."
        }
    }

    fun addListenerPromoVideo(title: String, caption: String, videoUri: String) {
        val id = staffUsernameInitial ?: return
        val name = myStaffAccount.value?.displayName ?: id
        val videoId = "promo_${id}_${System.currentTimeMillis()}"
        viewModelScope.launch {
            rateLimiter?.saveLocalPromoVideo(
                staffUsername = id,
                videoId = videoId,
                title = title.ifBlank { "Dil Suno Promo #${myPromoVideos.value.size + 1}" },
                caption = caption,
                videoUri = videoUri,
                sharedPlatforms = emptyList()
            )
            runCatching {
                feedRepo.saveListenerPromoVideo(
                    videoId = videoId,
                    staffUsername = id,
                    staffDisplayName = name,
                    title = title.ifBlank { "Dil Suno Promo #${myPromoVideos.value.size + 1}" },
                    caption = caption,
                    videoUri = videoUri
                )
            }
            val newTotal = (myPromoVideos.value.size + 1).toLong()
            runCatching { feedRepo.markStaffRulesAcceptance(id, promoVideosCompletedCount = newTotal) }
            _feedback.value = "Promo video saved inside Dil Suno! Now share it on WhatsApp, Instagram, or Facebook."
        }
    }

    fun markPromoVideoShared(video: ListenerPromoVideo, platformLabel: String) {
        val id = staffUsernameInitial ?: return
        val updatedPlatforms = (video.sharedPlatforms + platformLabel).distinct()
        viewModelScope.launch {
            rateLimiter?.saveLocalPromoVideo(
                staffUsername = id,
                videoId = video.id,
                title = video.title,
                caption = video.caption,
                videoUri = video.videoUri,
                sharedPlatforms = updatedPlatforms
            )
            runCatching { feedRepo.markListenerPromoVideoShared(video.id, platformLabel) }
            val sharedCount = myPromoVideos.value.count { it.isShared || it.id == video.id }.toLong()
            runCatching { feedRepo.markStaffRulesAcceptance(id, promoVideosSharedCount = sharedCount) }
            _feedback.value = "Shared via $platformLabel! ($sharedCount/3 promotional videos shared)"
        }
    }

    fun triggerEmergencySuicideAlert(recordingPath: String?) {
        val id = staffUsernameInitial ?: return
        val name = myStaffAccount.value?.displayName ?: id
        val call = _activeStaffCall.value ?: return
        viewModelScope.launch {
            com.dilsuno.app.core.ZegoCallManager.setEmergencyFreeOverride(true)
            feedRepo.triggerEmergencySuicideAlert(
                call = call,
                staffUsername = id,
                staffDisplayName = name,
                recordingPath = recordingPath
            ).onSuccess { roomId ->
                _activeStaffCall.value = call.copy(
                    emergencyAlertActive = true,
                    emergencyTriggeredAtMillis = System.currentTimeMillis(),
                    emergencyRecordingUri = recordingPath,
                    emergencyHelplineShown = true,
                    zegoRoomId = roomId
                )
                _feedback.value = "🚨 EMERGENCY ALERT SENT! Free Override & Legal Recording ACTIVE. Share Tele-MANAS: 14416."
            }.onFailure { err ->
                _feedback.value = err.localizedMessage ?: "Emergency alert error."
            }
        }
    }

    fun reportContactLeakDuringCall(category: String, snippet: String, offenderRole: String) {
        val call = _activeStaffCall.value ?: return
        val offenderUid = if (offenderRole == "caller") call.callerUid else (Firebase.auth.currentUser?.uid ?: "staff")
        viewModelScope.launch {
            feedRepo.reportContactLeakViolation(
                call = call,
                offenderUid = offenderUid,
                offenderRole = offenderRole,
                category = category,
                transcriptSnippet = snippet
            ).onSuccess { strikes ->
                if (strikes >= 2L && !call.emergencyAlertActive) {
                    _activeStaffCall.value = null
                    _feedback.value = "2nd Contact Leak Violation! Call auto-disconnected & Super Admin alerted."
                } else {
                    _activeStaffCall.value = call.copy(
                        contactLeakWarnings = strikes,
                        lastLeakWarningText = com.dilsuno.app.core.ContactLeakDetector.WARNING_BANNER_TEXT,
                        lastLeakOffenderRole = offenderRole
                    )
                    _feedback.value = com.dilsuno.app.core.ContactLeakDetector.WARNING_BANNER_TEXT
                }
            }
        }
    }

    fun markAdminJoinedEmergencyCall(call: DilSeCallSession) {
        viewModelScope.launch {
            feedRepo.markAdminJoinedEmergencyCall(call.id)
                .onSuccess { _feedback.value = "Joined live Emergency Call #${call.id.take(8)}!" }
        }
    }

    fun dismissEmergencyAlert(call: DilSeCallSession) {
        dismissedEmergencyCallIds.value = dismissedEmergencyCallIds.value + call.id
        viewModelScope.launch {
            feedRepo.dismissEmergencyAlert(call.id)
                .onSuccess {
                    _feedback.value = "Emergency alert dismissed."
                }
                .onFailure {
                    _feedback.value = "Emergency alert dismissed."
                }
        }
    }

    fun uploadAdminPromoAsset(title: String, caption: String, mediaType: String, mediaUri: String) {
        viewModelScope.launch {
            feedRepo.adminUploadPromoAsset(title, caption, mediaType, mediaUri)
                .onSuccess { _feedback.value = "Official Dil Suno promotional asset published to all Listeners!" }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun toggleStaffDuty(online: Boolean) {
        val id = staffUsernameInitial ?: return
        val name = myStaffAccount.value?.displayName ?: id
        if (online && !canGoOnline.value) {
            _feedback.value = "Go Online is LOCKED until you accept the 5 Golden Rules AND create & share 3 promotional videos inside Dil Suno."
            return
        }
        viewModelScope.launch {
            feedRepo.toggleStaffOnlineStatus(id, online, name).onSuccess {
                _isStaffOnline.value = online
                _feedback.value = if (online) "You are now ONLINE for anonymous Dil Suno audio calls." else "You are now OFFLINE."
            }.onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun acceptCall(call: DilSeCallSession) {
        val id = staffUsernameInitial ?: return
        val name = myStaffAccount.value?.displayName ?: id
        viewModelScope.launch {
            feedRepo.acceptDilSeCallAsStaff(call, id, name).onSuccess {
                val charge = call.feeInr.coerceAtLeast(com.dilsuno.app.core.DilSunoBillingRules.CALL_CHARGE_INR)
                val (listenerShare, adminShare) = com.dilsuno.app.core.DilSunoBillingRules.computeCallSplit(
                    chargeInr = charge,
                    isOwnerBackupCall = false
                )
                var creditedSlotsForCall = 0L
                if (settledCallIds.add("${call.id}:1")) {
                    creditedSlotsForCall = 1L
                    runCatching {
                        feedRepo.recordConnectedCallSlotSplit(
                            callId = call.id,
                            listenerStaffId = id,
                            listenerDisplayName = name,
                            slotIndex = 1L,
                            chargeInr = charge,
                            updateCallSession = true,
                            creditStaffAccount = true
                        )
                    }
                    rateLimiter?.addLocalAdminRevenue(adminShare)
                    _staffEarnings.value += listenerShare
                    _staffTotalCalls.value += 1L
                    _feedback.value = "Call connected (30-min session)! ₹$listenerShare added to your earnings."
                }
                _activeStaffCall.value = call.copy(
                    status = "active",
                    listenerStaffId = id,
                    listenerRole = "staff",
                    billedSlots = 1L,
                    listenerRevenueInr = listenerShare,
                    adminRevenueInr = adminShare
                )
                launch {
                    feedRepo.observeCallSession(call.id).collect { updated ->
                        _activeStaffCall.value = updated
                        if (updated != null && updated.billedSlots > creditedSlotsForCall) {
                            for (nextSlot in (creditedSlotsForCall + 1L)..updated.billedSlots) {
                                if (settledCallIds.add("${updated.id}:$nextSlot")) {
                                    runCatching {
                                        feedRepo.recordConnectedCallSlotSplit(
                                            callId = updated.id,
                                            listenerStaffId = id,
                                            listenerDisplayName = name,
                                            slotIndex = nextSlot,
                                            chargeInr = charge,
                                            updateCallSession = false,
                                            creditStaffAccount = true
                                        )
                                    }
                                    rateLimiter?.addLocalAdminRevenue(adminShare)
                                    _staffEarnings.value += listenerShare
                                    _feedback.value = "Call auto-extended (Slot $nextSlot)! +₹$listenerShare added."
                                }
                            }
                            creditedSlotsForCall = updated.billedSlots
                        }
                        if (updated?.status == "ended" || updated?.status == "blocked_abuse") {
                            if (updated.status == "ended") {
                                val earnedTotal = updated.listenerRevenueInr.takeIf { it > 0L }
                                    ?: (listenerShare * creditedSlotsForCall.coerceAtLeast(1L))
                                _feedback.value = "Call completed. Total earned from call: ₹$earnedTotal."
                            }
                            _activeStaffCall.value = null
                        }
                    }
                }
            }.onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun endCallNormally(durationSec: Long) {
        val call = _activeStaffCall.value ?: return
        val id = staffUsernameInitial
        val name = myStaffAccount.value?.displayName ?: id
        settledCallIds.add(call.id)
        viewModelScope.launch {
            feedRepo.endDilSeCallNormally(call, id, durationSec, name).onSuccess {
                val earnedTotal = call.listenerRevenueInr.takeIf { it > 0L }
                    ?: com.dilsuno.app.core.DilSunoBillingRules.LISTENER_SHARE_INR
                _activeStaffCall.value = null
                _feedback.value = "Call completed. Earned ₹$earnedTotal."
            }
        }
    }

    fun abuseDisconnectAndBlockCaller() {
        val call = _activeStaffCall.value ?: return
        val id = staffUsernameInitial
        val name = myStaffAccount.value?.displayName ?: id
        settledCallIds.add(call.id)
        viewModelScope.launch {
            feedRepo.disconnectAndBlockAbusiveCaller(call, id, name).onSuccess {
                _activeStaffCall.value = null
                _feedback.value =
                    "CALL DISCONNECTED & CALLER PERMANENTLY BLOCKED! Fee forfeited (No Refund)."
            }.onFailure { _feedback.value = it.localizedMessage }
        }
    }

    // --- Super Admin Direct Call Pickup (Owner Backup Mode) ---
    fun toggleAdminCallPickupOnline(online: Boolean) {
        viewModelScope.launch {
            feedRepo.adminToggleCallPickupOnline(online).onSuccess {
                _feedback.value = if (online) {
                    "Super Admin Call Pickup is ONLINE (100% call fee goes directly to Owner)."
                } else {
                    "Super Admin Call Pickup turned OFF (backup triggers automatically only when 0 staff are online)."
                }
            }.onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun acceptCallAsAdmin(call: DilSeCallSession) {
        viewModelScope.launch {
            feedRepo.acceptDilSeCallAsAdmin(call).onSuccess {
                _activeAdminCall.value = call.copy(
                    status = "active",
                    listenerStaffId = "owner_admin",
                    listenerRole = "admin"
                )
                launch {
                    feedRepo.observeCallSession(call.id).collect { updated ->
                        _activeAdminCall.value = updated
                        if (updated?.status == "ended" || updated?.status == "blocked_abuse") {
                            if (updated.status == "ended" && settledCallIds.add(updated.id)) {
                                runCatching {
                                    feedRepo.creditCompletedCallForListener(updated, "owner_admin", updated.durationSeconds, "Super Admin (Owner)")
                                }
                                _feedback.value = "Caller ended call. 100% fee (₹${updated.feeInr}) credited to Owner."
                            }
                            _activeAdminCall.value = null
                        }
                    }
                }
            }.onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun endAdminCallNormally(durationSec: Long) {
        val call = _activeAdminCall.value ?: return
        settledCallIds.add(call.id)
        viewModelScope.launch {
            feedRepo.endDilSeCallNormally(call, "owner_admin", durationSec, "Super Admin (Owner)").onSuccess {
                _activeAdminCall.value = null
                _feedback.value = "Call completed! 100% of fee (₹${call.feeInr}) credited directly to Owner."
            }.onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun adminAbuseDisconnectAndBlockCaller() {
        val call = _activeAdminCall.value ?: return
        settledCallIds.add(call.id)
        viewModelScope.launch {
            feedRepo.disconnectAndBlockAbusiveCaller(call, "owner_admin", "Super Admin (Owner)").onSuccess {
                _activeAdminCall.value = null
                _feedback.value = "Caller disconnected & permanently blocked (No Refund)."
            }.onFailure { _feedback.value = it.localizedMessage }
        }
    }

    // --- Shared Live Social Feed Moderation for Staff & Super Admin ---
    fun deleteContentAsModerator(
        targetType: String,
        targetId: String,
        parentPostId: String? = null,
        targetAuthorUid: String? = null,
        targetAuthorName: String? = null,
        contentPreview: String = "",
        reason: String = "Violates Dil Suno safety guidelines"
    ) {
        val staffId = if (isAdminMode) "owner_admin" else (staffUsernameInitial ?: "staff")
        val staffName = if (isAdminMode) {
            "Super Admin (Owner)"
        } else {
            myStaffAccount.value?.displayName ?: staffId
        }
        viewModelScope.launch {
            feedRepo.moderatorDeleteContentWithAudit(
                targetType = targetType,
                targetId = targetId,
                parentPostId = parentPostId,
                targetAuthorUid = targetAuthorUid,
                targetAuthorName = targetAuthorName,
                contentPreview = contentPreview,
                moderatorStaffUsername = staffId,
                moderatorDisplayName = staffName,
                reason = reason
            ).onSuccess {
                _feedback.value = "Content removed, author warned & logged to Admin Audit Trail."
            }.onFailure { _feedback.value = it.localizedMessage }
        }
    }

    // --- Admin Actions ---
    fun createStaffByGmailAndPin(staffEmail: String, displayName: String, pin6Digits: String) {
        viewModelScope.launch {
            val cleanEmail = com.dilsuno.app.core.SecurityUtils.normalizeEmail(staffEmail)
            if (!com.dilsuno.app.core.SecurityUtils.isValidEmail(cleanEmail)) {
                _feedback.value = "Enter a valid Staff Gmail ID."
                return@launch
            }
            if (!com.dilsuno.app.core.SecurityUtils.isValidStaffPin(pin6Digits)) {
                _feedback.value = "Assign an 8–12 digit numeric Staff PIN (min 6 digits)."
                return@launch
            }
            rateLimiter?.saveOrUpdatePreviewStaff(cleanEmail, displayName, pin6Digits)
            if (Firebase.auth.currentUser == null) {
                _feedback.value = "Approved Staff Listener added for $cleanEmail!"
                return@launch
            }
            feedRepo.adminCreateStaffByGmailAndPin(cleanEmail, displayName, pin6Digits)
                .onSuccess { _feedback.value = "Approved Staff Listener added for $cleanEmail!" }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun createStaff(username: String, displayName: String, password: String) {
        viewModelScope.launch {
            if (username.isBlank() || displayName.isBlank() || password.length < 6) {
                _feedback.value = "Provide Staff ID, Name, and 6+ char password."
                return@launch
            }
            feedRepo.adminCreateStaff(username, displayName, password)
                .onSuccess { _feedback.value = "Staff Listener '$username' created!" }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun toggleStaffActive(username: String, active: Boolean) {
        viewModelScope.launch {
            rateLimiter?.togglePreviewStaffActive(username, active)
            if (Firebase.auth.currentUser == null) {
                _feedback.value = if (active) "Staff reactivated." else "Staff suspended immediately."
                return@launch
            }
            feedRepo.adminSetStaffActive(username, active)
                .onSuccess { _feedback.value = if (active) "Staff reactivated." else "Staff suspended immediately." }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun toggleStaffOnlineByAdmin(staffUsername: String, online: Boolean, displayName: String) {
        viewModelScope.launch {
            feedRepo.toggleStaffOnlineStatus(staffUsername, online, displayName)
                .onSuccess {
                    _feedback.value = if (online) "$displayName is now ONLINE for calls." else "$displayName set OFFLINE."
                }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun toggleReviewerDemoEnabled(enabled: Boolean) {
        viewModelScope.launch {
            rateLimiter?.setReviewerDemoEnabled(enabled)
            if (Firebase.auth.currentUser != null) {
                runCatching { feedRepo.adminToggleReviewerDemoEnabled(enabled) }
            }
            _feedback.value = if (enabled) {
                "Play Store Reviewer Demo Account (reviewer@dilsuno.com) turned ON with ₹500 balance."
            } else {
                "Play Store Reviewer Demo Account (reviewer@dilsuno.com) turned OFF. Login blocked."
            }
        }
    }

    fun removeStaff(username: String) {
        viewModelScope.launch {
            rateLimiter?.removePreviewStaff(username)
            if (Firebase.auth.currentUser == null) {
                _feedback.value = "Staff removed."
                return@launch
            }
            feedRepo.adminRemoveStaff(username)
                .onSuccess { _feedback.value = "Staff removed." }
        }
    }

    fun removeContent(targetType: String, targetId: String, reportId: String? = null) {
        viewModelScope.launch {
            feedRepo.adminRemoveContent(targetType, targetId, reportId)
                .onSuccess { _feedback.value = "Content removed & report resolved." }
        }
    }

    fun setUserBanned(uid: String, banned: Boolean) {
        viewModelScope.launch {
            feedRepo.adminSetUserBanned(uid, banned)
                .onSuccess { _feedback.value = if (banned) "User permanently blocked." else "User unblocked." }
        }
    }

    fun toggleCreatorMonetization(uid: String, approve: Boolean) {
        viewModelScope.launch {
            feedRepo.adminToggleCreatorMonetization(uid, approve)
                .onSuccess { _feedback.value = if (approve) "Monetization turned ON." else "Monetization turned OFF." }
        }
    }

    fun markPostCopyrightClaim(postId: String, active: Boolean, reason: String? = null) {
        viewModelScope.launch {
            feedRepo.markPostCopyrightClaim(postId, active, reason)
                .onSuccess {
                    _feedback.value = if (active) {
                        "Copyright Claim marked! Post hidden from public feeds until creator mutes audio."
                    } else {
                        "Copyright Claim cleared."
                    }
                }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun verifyListenerApplicationByStaff(app: ListenerApplication) {
        val id = staffUsernameInitial ?: "staff"
        val name = myStaffAccount.value?.displayName ?: id
        viewModelScope.launch {
            feedRepo.staffVerifyListenerApplication(app.id, id, name)
                .onSuccess {
                    _feedback.value = "Step 1 complete: ${app.fullName} marked 'Verified by Staff' and sent to Super Admin for Final Approval."
                }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun finalApproveListenerApplicationByAdmin(app: ListenerApplication, pin6Digits: String) {
        viewModelScope.launch {
            if (!com.dilsuno.app.core.SecurityUtils.isValidStaffPin(pin6Digits)) {
                _feedback.value = "Assign a valid numeric Staff PIN (6–16 digits)."
                return@launch
            }
            feedRepo.adminFinalApproveListenerApplication(app, pin6Digits)
                .onSuccess { staffUsername ->
                    rateLimiter?.saveOrUpdatePreviewStaff(app.email, app.fullName, pin6Digits)
                    _feedback.value = "Final Approved! ${app.fullName} is now an active Listener ($staffUsername)."
                }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun rejectListenerApplication(app: ListenerApplication) {
        viewModelScope.launch {
            feedRepo.rejectListenerApplication(app.id)
                .onSuccess { _feedback.value = "Application from ${app.fullName} rejected." }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun requestStaffPayout(
        staffDisplayName: String,
        payoutAccount: String,
        requestedAmountInr: Long = _staffEarnings.value
    ) {
        viewModelScope.launch {
            val available = _staffEarnings.value
            val validationError = com.dilsuno.app.core.DilSunoBillingRules.validateListenerWithdrawal(
                availableEarningsInr = available,
                requestedAmountInr = requestedAmountInr,
                payoutAccount = payoutAccount
            )
            if (validationError != null) {
                _feedback.value = validationError
                return@launch
            }
            val staffId = staffUsernameInitial
            if (!staffId.isNullOrBlank()) {
                feedRepo.requestStaffWithdrawal(
                    staffUsername = staffId,
                    staffDisplayName = staffDisplayName,
                    payoutAccount = payoutAccount.trim(),
                    amountInr = requestedAmountInr
                ).onSuccess { remaining ->
                    _staffEarnings.value = remaining
                    _feedback.value = com.dilsuno.app.core.DilSunoBillingRules.WITHDRAWAL_SUBMITTED_MESSAGE
                }.onFailure { err ->
                    _feedback.value = err.localizedMessage ?: "Withdrawal request failed."
                }
            } else {
                feedRepo.requestPayout(staffDisplayName, payoutAccount.trim(), requestedAmountInr, requesterType = "staff")
                    .onSuccess {
                        _staffEarnings.value = (available - requestedAmountInr).coerceAtLeast(0L)
                        _feedback.value = com.dilsuno.app.core.DilSunoBillingRules.WITHDRAWAL_SUBMITTED_MESSAGE
                    }
                    .onFailure { _feedback.value = it.localizedMessage }
            }
        }
    }

    fun resetStaffPin(username: String, newPin: String) {
        viewModelScope.launch {
            rateLimiter?.resetPreviewStaffPin(username, newPin)
            if (Firebase.auth.currentUser == null) {
                _feedback.value = "Staff PIN updated!"
                return@launch
            }
            feedRepo.adminResetStaffPin(username, newPin)
                .onSuccess { _feedback.value = "Staff PIN updated!" }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun setStaffRole(username: String, staffRole: String) {
        val safeRole = if (staffRole == "trusted_staff_manager") "trusted_staff_manager" else "listener"
        viewModelScope.launch {
            rateLimiter?.setPreviewStaffRole(username, safeRole)
            if (Firebase.auth.currentUser == null) {
                _feedback.value = if (safeRole == "trusted_staff_manager") {
                    "Assigned 'Trusted Staff Manager' role to @$username (Moderation Queue unlocked; bank payouts remain Admin-only)."
                } else {
                    "Reverted @$username to standard Staff Listener role."
                }
                return@launch
            }
            feedRepo.adminSetStaffRole(username, safeRole)
                .onSuccess {
                    _feedback.value = if (safeRole == "trusted_staff_manager") {
                        "Assigned 'Trusted Staff Manager' role to @$username (Moderation Queue unlocked; financial payouts blocked)."
                    } else {
                        "Updated @$username role to Staff Listener."
                    }
                }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun resolveModerationQueueAction(report: ModerationReport, action: String) {
        val employeeId = if (isAdminMode) "owner_admin" else (staffUsernameInitial ?: "staff_manager")
        val employeeName = if (isAdminMode) "Super Admin" else (myStaffAccount.value?.displayName ?: employeeId)
        viewModelScope.launch {
            feedRepo.resolveModerationReportAction(
                report = report,
                action = action,
                employeeStaffId = employeeId,
                employeeDisplayName = employeeName
            ).onSuccess {
                _feedback.value = when (action) {
                    "approve_ignore" -> "Report marked Safe / Ignored. Action logged to audit trail."
                    "delete_ban" -> "Video/Post deleted & user permanently banned! Employee ID + timestamp logged for Google Play audit."
                    else -> "Video/Post deleted from public feed & warning sent to user. Logged to audit trail."
                }
            }.onFailure { err ->
                _feedback.value = err.localizedMessage ?: "Could not complete moderation action."
            }
        }
    }

    fun resetStaffPassword(username: String, newPassword: String) {
        viewModelScope.launch {
            feedRepo.adminResetStaffPassword(username, newPassword)
                .onSuccess { _feedback.value = "PIN updated for Staff '$username'." }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun replySupportTicket(ticketId: String, userUid: String, reply: String, markResolved: Boolean) {
        viewModelScope.launch {
            if (reply.isBlank()) {
                _feedback.value = "Enter a support reply message."
                return@launch
            }
            feedRepo.adminReplySupportTicket(ticketId, userUid, reply, markResolved)
                .onSuccess { _feedback.value = if (markResolved) "Reply sent & ticket marked Resolved." else "Reply sent to user." }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun payAndApprovePayout(payout: PayoutRequest) {
        viewModelScope.launch {
            feedRepo.adminUpdatePayoutStatus(payout.id, "paid")
                .onSuccess {
                    _feedback.value =
                        "₹${payout.amountInr} payout to ${payout.creatorName} (${payout.payoutAccount}) marked Paid / Approved!"
                }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun updatePayoutStatus(payoutId: String, status: String) {
        viewModelScope.launch {
            feedRepo.adminUpdatePayoutStatus(payoutId, status)
                .onSuccess {
                    val label = com.dilsuno.app.core.DilSunoBillingRules.formatPayoutStatusLabel(status)
                    _feedback.value = "Payout marked $label."
                }
        }
    }

    fun saveBusinessConfig(
        callRate: Long,
        viewBonus: Long,
        globalMonetization: Boolean,
        supportEmail: String? = null,
        announcementBannerEn: String? = null,
        announcementBannerHi: String? = null,
        announcementActive: Boolean = false,
        adminCallPickupOnline: Boolean? = null,
        agoraAppId: String? = null,
        latestAppVersionName: String? = null,
        latestAppVersionCode: Long? = null,
        appUpdateUrl: String? = null,
        forceUpdate: Boolean? = null
    ) {
        viewModelScope.launch {
            val existing = appConfig.value
            feedRepo.adminSaveBusinessConfig(
                callRateInr = callRate,
                viewBonusPer1000Inr = viewBonus,
                globalMonetizationEnabled = globalMonetization,
                supportEmail = supportEmail ?: existing.supportEmail,
                announcementBannerEn = announcementBannerEn ?: existing.announcementBannerEn,
                announcementBannerHi = announcementBannerHi ?: existing.announcementBannerHi,
                announcementActive = announcementActive,
                adminCallPickupOnline = adminCallPickupOnline ?: existing.adminCallPickupOnline,
                agoraAppId = agoraAppId ?: existing.agoraAppId,
                latestAppVersionName = latestAppVersionName ?: existing.latestAppVersionName,
                latestAppVersionCode = latestAppVersionCode ?: existing.latestAppVersionCode,
                appUpdateUrl = appUpdateUrl ?: existing.appUpdateUrl,
                forceUpdate = forceUpdate ?: existing.forceUpdate,
                customMusicTracksJson = existing.customMusicTracksJson
            ).onSuccess { _feedback.value = "Platform, Voice, Banner & App Update settings saved!" }
                .onFailure { _feedback.value = it.localizedMessage }
        }
    }

    fun addCustomMusicTrack(
        titleEn: String,
        titleHi: String,
        mood: String,
        audioUrl: String
    ) {
        val cleanTitleEn = com.dilsuno.app.core.SecurityUtils.sanitizeInput(titleEn, 80)
        if (cleanTitleEn.isBlank()) {
            _feedback.value = "Enter a Track Title before adding."
            return
        }
        val cleanTitleHi = com.dilsuno.app.core.SecurityUtils.sanitizeInput(titleHi, 80).ifBlank { cleanTitleEn }
        val cleanUrl = audioUrl.trim()
        if (cleanUrl.isNotBlank() && !cleanUrl.startsWith("https://", ignoreCase = true)) {
            _feedback.value = "Audio URL must start with https:// (or leave blank for built-in instrumental fallback)."
            return
        }
        val ext = com.dilsuno.app.core.SecurityUtils.extractFileExtension(cleanUrl)
        val hasUnsafePattern = cleanUrl.contains("<") ||
            cleanUrl.contains(">") ||
            cleanUrl.any { it.isWhitespace() } ||
            (ext != null && ext in com.dilsuno.app.core.SecurityUtils.BLOCKED_DANGEROUS_EXTENSIONS)
        if (cleanUrl.isNotBlank() && hasUnsafePattern) {
            _feedback.value = "Blocked unsafe or executable audio URL."
            return
        }
        val current = adminCustomMusicTracks.value.toMutableList()
        val newTrack = com.dilsuno.app.core.MusicTrackOption(
            id = "admin_track_${System.currentTimeMillis()}",
            titleEn = cleanTitleEn,
            titleHi = cleanTitleHi,
            mood = mood.ifBlank { com.dilsuno.app.core.RoyaltyFreeMusicLibrary.moodCategories.first().combinedLabel },
            baseFreqHz = 261.63,
            scaleOffsets = listOf(1.0, 1.25, 1.5, 1.25, 1.0),
            audioUrl = cleanUrl.ifBlank { null },
            isBuiltinSafe = true,
            isAdminCurated = true
        )
        current.add(0, newTrack)
        persistCustomMusicList(current, "Added \"$cleanTitleEn\" to Reel Music Library!")
    }

    fun removeCustomMusicTrack(trackId: String) {
        val updated = adminCustomMusicTracks.value.filterNot { it.id == trackId }
        persistCustomMusicList(updated, "Removed track from Reel Music Library.")
    }

    private fun persistCustomMusicList(
        list: List<com.dilsuno.app.core.MusicTrackOption>,
        successMessage: String
    ) {
        val serialized = com.dilsuno.app.core.RoyaltyFreeMusicLibrary.serializeCustomTracks(list)
        if (serialized.length > 7800) {
            _feedback.value = "Music library storage limit reached. Remove older tracks first."
            return
        }
        viewModelScope.launch {
            rateLimiter?.setCustomMusicTracksJson(serialized)
            val existing = appConfig.value
            if (Firebase.auth.currentUser != null) {
                feedRepo.adminSaveBusinessConfig(
                    callRateInr = existing.dilSeCallRateInr,
                    viewBonusPer1000Inr = existing.viewBonusPer1000Inr,
                    globalMonetizationEnabled = existing.globalMonetizationEnabled,
                    supportEmail = existing.supportEmail,
                    announcementBannerEn = existing.announcementBannerEn,
                    announcementBannerHi = existing.announcementBannerHi,
                    announcementActive = existing.announcementActive,
                    adminCallPickupOnline = existing.adminCallPickupOnline,
                    agoraAppId = existing.agoraAppId,
                    latestAppVersionName = existing.latestAppVersionName,
                    latestAppVersionCode = existing.latestAppVersionCode,
                    appUpdateUrl = existing.appUpdateUrl,
                    forceUpdate = existing.forceUpdate,
                    reviewerDemoEnabled = existing.reviewerDemoEnabled,
                    customMusicTracksJson = serialized
                ).onSuccess {
                    _feedback.value = successMessage
                }.onFailure { err ->
                    _feedback.value = err.localizedMessage ?: successMessage
                }
            } else {
                _feedback.value = successMessage
            }
        }
    }

    companion object {
        const val REQUIRED_PROMO_VIDEOS = 3

        fun isListenerEligibleToGoOnline(
            goldenRulesAccepted: Boolean,
            promoVideos: List<ListenerPromoVideo>
        ): Boolean {
            return goldenRulesAccepted &&
                promoVideos.size >= REQUIRED_PROMO_VIDEOS &&
                promoVideos.count { it.isShared } >= REQUIRED_PROMO_VIDEOS
        }
    }
}

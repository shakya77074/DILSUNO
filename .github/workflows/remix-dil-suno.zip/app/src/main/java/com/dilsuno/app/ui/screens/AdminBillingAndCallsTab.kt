package com.dilsuno.app.ui.screens

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.DilSunoBillingRules
import com.dilsuno.app.core.ZegoCallManager
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.ContactLeakAlert
import com.dilsuno.app.data.model.DilSeCallSession
import com.dilsuno.app.data.model.EmergencyLegalLog
import com.dilsuno.app.data.model.PayoutRequest
import com.dilsuno.app.data.model.PlayBillingPurchaseRecord
import com.dilsuno.app.data.model.PublicProfile
import com.dilsuno.app.data.model.StaffAccount
import com.dilsuno.app.ui.components.SuperAdminContactLeakAlertsCard
import com.dilsuno.app.ui.components.SuperAdminEmergencyLegalLogsCard
import com.dilsuno.app.ui.theme.HairlineDividerBlue
import com.dilsuno.app.ui.theme.PureWhiteBackground
import com.dilsuno.app.ui.theme.RoyalBlueDeep
import com.dilsuno.app.ui.theme.RoyalBlueLightContainer
import com.dilsuno.app.ui.theme.RoyalBluePrimary
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.SlateDarkText
import com.dilsuno.app.ui.theme.SlateSubtleText
import com.dilsuno.app.ui.theme.SoftBlueCardSurface
import com.dilsuno.app.ui.theme.SoftCardSurface
import com.dilsuno.app.viewmodel.StaffAndAdminViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminBillingAndCallsTab(
    viewModel: StaffAndAdminViewModel,
    lang: AppLang,
    allPlayBillingPurchases: List<PlayBillingPurchaseRecord>,
    profilesByUid: Map<String, PublicProfile>,
    allPayouts: List<PayoutRequest>,
    waitingCalls: List<DilSeCallSession>,
    allActiveCalls: List<DilSeCallSession>,
    allCallsHistory: List<DilSeCallSession>,
    liveEpochSec: Long,
    allStaff: List<StaffAccount>,
    contactLeakAlerts: List<ContactLeakAlert>,
    emergencyLegalLogs: List<EmergencyLegalLog>,
    onAcceptCallRequest: (DilSeCallSession) -> Unit
) {
    val context = LocalContext.current
    var zegoCheckStatus by remember { mutableStateOf<String?>(null) }
    var launchTestRoomAfterMic by remember { mutableStateOf(false) }

    val zegoTestMicLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        val app = context.applicationContext as? Application
        if (app != null) {
            ZegoCallManager.initCallInvitation(
                application = app,
                rawUserId = "owner_supervisor",
                rawUserName = ZegoCallManager.EMERGENCY_SUPERVISOR_LABEL
            )
        }
        if (granted) {
            zegoCheckStatus = "ZegoCloud Engine Ready (App ID ${ZegoCallManager.ZEGO_APP_ID}) • Microphone permission granted."
            if (launchTestRoomAfterMic) {
                launchTestRoomAfterMic = false
                val ok = ZegoCallManager.launchEmergencyVoiceRoom(
                    context = context,
                    callId = "admin_test_${System.currentTimeMillis()}",
                    rawUserId = "owner_supervisor",
                    anonymousRoleLabel = ZegoCallManager.EMERGENCY_SUPERVISOR_LABEL
                )
                if (!ok) zegoCheckStatus = "ZegoCloud initialized, but test voice room activity could not start on this device."
            }
        } else {
            launchTestRoomAfterMic = false
            zegoCheckStatus = "Microphone permission is required for ZegoCloud voice call check."
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // LIVE CALL MONITORING & STATS
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SoftBlueCardSurface),
                border = BorderStroke(1.dp, RoyalBluePrimary.copy(alpha = 0.25f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().testTag("admin_calling_dashboard_card")
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.PhoneInTalk, contentDescription = null, tint = RoyalBluePrimary)
                        Text(tr("Admin Call Management & Live Monitoring", "एडमिन कॉल प्रबंधन व लाइव निगरानी", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SlateDarkText)
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(color = PureWhiteBackground, border = BorderStroke(1.dp, HairlineDividerBlue), shape = RoundedCornerShape(10.dp)) {
                            Text("Live Active: ${allActiveCalls.size}", color = RoyalBlueDeep, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                        }
                        Surface(color = PureWhiteBackground, border = BorderStroke(1.dp, HairlineDividerBlue), shape = RoundedCornerShape(10.dp)) {
                            Text("Waiting: ${waitingCalls.size}", color = if (waitingCalls.isNotEmpty()) Color(0xFFB45309) else SlateDarkText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                        }
                        Surface(color = PureWhiteBackground, border = BorderStroke(1.dp, HairlineDividerBlue), shape = RoundedCornerShape(10.dp)) {
                            Text("Call History: ${allCallsHistory.size}", color = SlateDarkText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                        }
                    }
                }
            }
        }

        // ZEGOCLOUD TEST CALL CHECK
        item {
            val micGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            Card(
                colors = CardDefaults.cardColors(containerColor = SoftCardSurface),
                border = BorderStroke(1.dp, HairlineDividerBlue),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().testTag("admin_zego_test_call_card")
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.Verified, contentDescription = null, tint = RoyalBluePrimary)
                        Text(tr("ZegoCloud Test Call Check", "ZegoCloud टेस्ट कॉल जाँच", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SlateDarkText)
                    }
                    Text("Zego App ID: ${ZegoCallManager.ZEGO_APP_ID} • Mic: ${if (micGranted) "Granted" else "Needs Permission"}", style = MaterialTheme.typography.bodySmall, color = SlateSubtleText)
                    if (!zegoCheckStatus.isNullOrBlank()) {
                        Surface(color = SoftBlueCardSurface, border = BorderStroke(1.dp, RoyalBluePrimary.copy(alpha = 0.25f)), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Text(zegoCheckStatus!!, color = RoyalBlueDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(10.dp))
                        }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                launchTestRoomAfterMic = false
                                if (micGranted) {
                                    (context.applicationContext as? Application)?.let { app ->
                                        ZegoCallManager.initCallInvitation(app, "owner_supervisor", ZegoCallManager.EMERGENCY_SUPERVISOR_LABEL)
                                    }
                                    zegoCheckStatus = "ZegoCloud Engine Ready (App ID ${ZegoCallManager.ZEGO_APP_ID}) • Audio Signaling Verified."
                                } else {
                                    zegoTestMicLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary, contentColor = Color.White),
                            modifier = Modifier.heightIn(min = 48.dp).testTag("admin_zego_test_call_button")
                        ) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Verify ZegoCloud Engine", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = {
                                if (micGranted) {
                                    val ok = ZegoCallManager.launchEmergencyVoiceRoom(context, "admin_test_${System.currentTimeMillis()}", "owner_supervisor", ZegoCallManager.EMERGENCY_SUPERVISOR_LABEL)
                                    zegoCheckStatus = if (ok) "Launched live ZegoCloud Test Audio Room." else "Could not launch ZegoCloud Test Audio Room."
                                } else {
                                    launchTestRoomAfterMic = true
                                    zegoTestMicLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            },
                            border = BorderStroke(1.dp, RoyalBluePrimary),
                            modifier = Modifier.heightIn(min = 48.dp).testTag("admin_zego_launch_test_room_button")
                        ) {
                            Icon(Icons.Filled.Call, contentDescription = null, tint = RoyalBlueDeep, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Launch Test Room", color = RoyalBlueDeep, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // GOOGLE PLAY BILLING PURCHASE LOGS
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.Payment, contentDescription = null, tint = SafeEmerald)
                Text(
                    text = tr("Google Play Billing Purchase Logs (${allPlayBillingPurchases.size})", "Google Play बिलिंग लॉग (${allPlayBillingPurchases.size})", lang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SlateDarkText
                )
            }
        }
        if (allPlayBillingPurchases.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = SoftCardSurface), modifier = Modifier.fillMaxWidth()) {
                    Text(tr("No Google Play Billing purchases recorded yet.", "अभी कोई Google Play खरीद दर्ज नहीं है।", lang), style = MaterialTheme.typography.bodySmall, color = SlateSubtleText, modifier = Modifier.padding(14.dp))
                }
            }
        } else {
            items(allPlayBillingPurchases.take(25), key = { "pb_${it.id}" }) { rec ->
                val buyerName = profilesByUid[rec.uid]?.fullName?.takeIf { it.isNotBlank() } ?: "UID ${rec.uid.take(10)}"
                val timeStr = DilSunoBillingRules.formatTimestamp(rec.createdAt?.toDate()?.time)
                Card(
                    colors = CardDefaults.cardColors(containerColor = SoftCardSurface),
                    border = BorderStroke(1.dp, HairlineDividerBlue),
                    modifier = Modifier.fillMaxWidth().testTag("admin_play_billing_${rec.id}")
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("$buyerName • +₹${rec.creditsInr}", fontWeight = FontWeight.Bold, color = SlateDarkText)
                            Surface(color = SafeEmerald, shape = RoundedCornerShape(6.dp)) {
                                Text(if (rec.verified) "VERIFIED" else "PENDING", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        Text("SKU: ${rec.productId} • Order: ${rec.orderId.ifBlank { "N/A" }}", style = MaterialTheme.typography.bodySmall, color = SlateSubtleText)
                        Text(timeStr, style = MaterialTheme.typography.labelSmall, color = SlateSubtleText)
                    }
                }
            }
        }

        // CREATOR & STAFF PAYOUT REQUESTS (Bank / Payout Reference ONLY - NO UPI Intents)
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = SafeEmerald)
                Text(tr("Creator & Staff Payout Requests (${allPayouts.size})", "क्रिएटर व स्टाफ पेआउट अनुरोध (${allPayouts.size})", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SlateDarkText)
            }
        }
        items(allPayouts, key = { "payout_${it.id}" }) { payout ->
            AdminPayoutRequestCard(
                payout = payout,
                lang = lang,
                onPayAndApprove = { viewModel.payAndApprovePayout(payout) },
                onReject = { viewModel.updatePayoutStatus(payout.id, "rejected") }
            )
        }

        // WAITING CALLS & LIVE ACTIVE CALLS
        if (waitingCalls.isNotEmpty()) {
            item {
                Text(tr("Incoming Waiting Calls (${waitingCalls.size})", "प्रतीक्षा में कॉल (${waitingCalls.size})", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SlateDarkText)
            }
            items(waitingCalls, key = { "wait_${it.id}" }) { waitCall ->
                Card(colors = CardDefaults.cardColors(containerColor = SoftBlueCardSurface), border = BorderStroke(1.dp, RoyalBluePrimary.copy(alpha = 0.35f)), modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(waitCall.callerAlias, fontWeight = FontWeight.Bold, color = SlateDarkText)
                            Text("Fee: ₹${waitCall.feeInr} • Call #${waitCall.id.take(8)}", style = MaterialTheme.typography.bodySmall, color = SlateSubtleText)
                        }
                        Button(
                            onClick = { onAcceptCallRequest(waitCall) },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary, contentColor = Color.White),
                            modifier = Modifier.heightIn(min = 48.dp).testTag("admin_calling_accept_${waitCall.id}")
                        ) {
                            Text(tr("Accept Call", "कॉल उठाएं", lang), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (allActiveCalls.isNotEmpty()) {
            item {
                Text(tr("Live Active Calls (${allActiveCalls.size})", "लाइव सक्रिय कॉल्स (${allActiveCalls.size})", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SlateDarkText)
            }
            items(allActiveCalls, key = { "live_call_${it.id}" }) { call ->
                val startedAtSec = (call.updatedAt ?: call.createdAt)?.seconds ?: liveEpochSec
                val elapsedSec = (liveEpochSec - startedAtSec).coerceAtLeast(0L)
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (call.emergencyAlertActive) Color(0xFFFEF2F2) else SoftCardSurface),
                    border = BorderStroke(1.dp, if (call.emergencyAlertActive) Color(0xFFDC2626) else RoyalBluePrimary.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${call.callerAlias} ↔ ${call.listenerStaffId ?: "Owner Backup"} (${elapsedSec}s • ₹${call.feeInr})", fontWeight = FontWeight.Bold, color = SlateDarkText)
                        Button(
                            onClick = {
                                viewModel.markAdminJoinedEmergencyCall(call)
                                ZegoCallManager.launchEmergencyVoiceRoom(context, call.id, "owner_supervisor", ZegoCallManager.EMERGENCY_SUPERVISOR_LABEL)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = if (call.emergencyAlertActive) Color(0xFFB91C1C) else RoyalBluePrimary, contentColor = Color.White),
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Filled.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Join / Monitor Live Call", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // STAFF ONLINE/OFFLINE TOGGLES
        item {
            Text(tr("Staff Online / Offline Controls (${allStaff.size})", "स्टाफ ऑनलाइन / ऑफलाइन नियंत्रण (${allStaff.size})", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SlateDarkText)
        }
        items(allStaff, key = { "calling_staff_${it.staffUsername}" }) { member ->
            Card(colors = CardDefaults.cardColors(containerColor = SoftCardSurface), border = BorderStroke(1.dp, HairlineDividerBlue), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${member.displayName} (${member.staffEmail.ifBlank { "@${member.staffUsername}" }})", fontWeight = FontWeight.Bold, color = SlateDarkText)
                        Text(if (!member.isActive) "Suspended" else if (member.isOnline) "Online • Accepting Calls" else "Offline", style = MaterialTheme.typography.bodySmall, color = SlateSubtleText)
                    }
                    Switch(
                        checked = member.isOnline,
                        enabled = member.isActive,
                        onCheckedChange = { checked -> viewModel.toggleStaffOnlineByAdmin(member.staffUsername, checked, member.displayName) },
                        modifier = Modifier.testTag("admin_calling_staff_online_${member.staffUsername}")
                    )
                }
            }
        }

        item { SuperAdminContactLeakAlertsCard(alerts = contactLeakAlerts, lang = lang) }
        item { SuperAdminEmergencyLegalLogsCard(logs = emergencyLegalLogs, lang = lang) }
    }
}

@Composable
private fun AdminPayoutRequestCard(
    payout: PayoutRequest,
    lang: AppLang,
    onPayAndApprove: () -> Unit,
    onReject: () -> Unit
) {
    val statusLabel = DilSunoBillingRules.formatPayoutStatusLabel(payout.status)
    val timestampLabel = DilSunoBillingRules.formatTimestamp(payout.createdAt?.toDate()?.time)
    val isActionable = payout.status == "pending" || payout.status == "approved"
    val roleLabel = if (payout.requesterType == "staff") "LISTENER" else "CREATOR"

    Card(
        colors = CardDefaults.cardColors(containerColor = SoftCardSurface),
        border = BorderStroke(1.dp, HairlineDividerBlue),
        modifier = Modifier.fillMaxWidth().testTag("admin_payout_card_${payout.id}"),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("${payout.creatorName} ($roleLabel)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SlateDarkText)
                    Text("Payout Account: ${payout.payoutAccount}", style = MaterialTheme.typography.bodySmall, color = SlateSubtleText)
                    Text(tr("Requested: $timestampLabel", "अनुरोध समय: $timestampLabel", lang), style = MaterialTheme.typography.labelSmall, color = SlateSubtleText)
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("₹${payout.amountInr}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = SafeEmerald)
                    Surface(
                        color = when (payout.status) {
                            "paid" -> SafeEmerald
                            "rejected" -> Color(0xFFFEE2E2)
                            else -> RoyalBlueLightContainer
                        },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = statusLabel,
                            color = when (payout.status) {
                                "paid" -> Color.White
                                "rejected" -> Color(0xFFB91C1C)
                                else -> RoyalBlueDeep
                            },
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            if (isActionable) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = onPayAndApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = SafeEmerald, contentColor = Color.White),
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("admin_pay_approve_${payout.id}")
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                        Spacer(Modifier.width(6.dp))
                        Text("Pay & Approve", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    OutlinedButton(
                        onClick = onReject,
                        border = BorderStroke(1.dp, Color(0xFFB91C1C)),
                        modifier = Modifier.heightIn(min = 48.dp).testTag("admin_reject_payout_${payout.id}")
                    ) {
                        Text(tr("Reject", "अस्वीकार", lang), color = Color(0xFFB91C1C), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

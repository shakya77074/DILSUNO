package com.dilsuno.app.ui.auth

import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.dilsuno.app.R
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.GetCredentialUnsupportedException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

private fun resolveGoogleServerClientId(context: Context): String {
    return runCatching {
        context.getString(R.string.default_web_client_id).trim()
    }.getOrElse {
        runCatching {
            val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
            if (resId != 0) context.getString(resId).trim() else ""
        }.getOrDefault("")
    }
}

private suspend fun signInWithGoogleCredential(
    credential: androidx.credentials.Credential,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
        val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
        val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
        Firebase.auth.signInWithCredential(authCredential).await()
        onSuccess()
    } else {
        onError("Could not verify Google account credential.")
    }
}

fun launchExplicitGoogleSignIn(
    context: Context,
    credentialManager: CredentialManager?,
    scope: CoroutineScope,
    onSuccess: () -> Unit,
    onCancelled: () -> Unit = {},
    onError: (String) -> Unit
) {
    if (credentialManager == null) {
        onError("Google Sign-In is unavailable on this device. Use Email Sign In below.")
        return
    }
    val clientId = resolveGoogleServerClientId(context)
    if (clientId.isBlank()) {
        onError("Google Sign-In configuration is pending. Please use Email Sign In or Create Account.")
        return
    }

    val signInWithGoogleOption = GetSignInWithGoogleOption.Builder(clientId).build()
    val primaryRequest = GetCredentialRequest.Builder()
        .addCredentialOption(signInWithGoogleOption)
        .build()

    scope.launch {
        try {
            val result = credentialManager.getCredential(context, primaryRequest)
            signInWithGoogleCredential(result.credential, onSuccess, onError)
        } catch (_: GetCredentialCancellationException) {
            onCancelled()
        } catch (primaryErr: GetCredentialException) {
            val shouldTryFallback = primaryErr is NoCredentialException ||
                primaryErr is GetCredentialUnsupportedException
            if (!shouldTryFallback) {
                Log.w("Auth", "Google Sign-In primary flow failed: ${primaryErr.message}")
                onError(primaryErr.localizedMessage ?: "Google Sign-In failed. Please try Email Sign In.")
                return@launch
            }
            // Request 2 (separate single-option request): allow any Google account on device
            val fallbackOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(clientId)
                .setAutoSelectEnabled(false)
                .build()
            val fallbackRequest = GetCredentialRequest.Builder()
                .addCredentialOption(fallbackOption)
                .build()
            try {
                val fallbackResult = credentialManager.getCredential(context, fallbackRequest)
                signInWithGoogleCredential(fallbackResult.credential, onSuccess, onError)
            } catch (_: GetCredentialCancellationException) {
                onCancelled()
            } catch (_: NoCredentialException) {
                onError("No Google account found on this device. Please add one or use Email Sign In.")
            } catch (fallbackErr: Exception) {
                Log.w("Auth", "Google Sign-In fallback failed: ${fallbackErr.message}")
                onError(fallbackErr.localizedMessage ?: "Google Sign-In failed. Please try Email Sign In.")
            }
        } catch (e: Exception) {
            Log.w("Auth", "Google Sign-In unexpected error: ${e.message}")
            onError(e.localizedMessage ?: "Google Sign-In failed. Please try Email Sign In.")
        }
    }
}

fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope
) {
    if (Firebase.auth.currentUser != null) {
        onAuthSuccess()
        return
    }
    val clientId = resolveGoogleServerClientId(context)
    if (clientId.isBlank()) {
        onUnauthenticated()
        return
    }

    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()

    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    scope.launch {
        try {
            val result = credentialManager.getCredential(context, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                Firebase.auth.signInWithCredential(authCredential).await()
                onAuthSuccess()
            } else {
                onUnauthenticated()
            }
        } catch (_: Exception) {
            onUnauthenticated()
        }
    }
}

fun signOutFromDilSuno(
    credentialManager: CredentialManager?,
    scope: CoroutineScope,
    onSignOutComplete: () -> Unit = {}
) {
    scope.launch {
        withContext(NonCancellable) {
            try {
                credentialManager?.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Throwable) {
                Log.w("Auth", "Failed to clear credential state: ${e.message}")
            } finally {
                runCatching { Firebase.auth.signOut() }
                onSignOutComplete()
            }
        }
    }
}

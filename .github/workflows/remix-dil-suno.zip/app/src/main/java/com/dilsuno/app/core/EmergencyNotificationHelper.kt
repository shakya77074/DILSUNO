package com.dilsuno.app.core

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.dilsuno.app.MainActivity
import com.dilsuno.app.R

/**
 * Triggers high-priority mobile notifications on the Super Admin / Senior Staff device
 * whenever a Listener triggers an Emergency Crisis Alert or a new Moderation Report arrives.
 */
object EmergencyNotificationHelper {
    private const val CHANNEL_ID = "dilsuno_emergency_suicide_alert"
    private const val CHANNEL_NAME = "Dil Suno Emergency Crisis Alerts"

    fun showSuperAdminEmergencyNotification(
        context: Context,
        callId: String,
        listenerName: String
    ) {
        runCatching {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val audioAttrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Urgent live crisis alerts requiring Super Admin intervention."
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 700)
                    setSound(alarmUri, audioAttrs)
                }
                manager.createNotificationChannel(channel)
            }

            val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("emergency_call_id", callId)
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                callId.hashCode(),
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("🚨 EMERGENCY CRISIS ALERT — Join Live Call")
                .setContentText("Listener $listenerName triggered Crisis Override! Tap to Join Live Call. Tele-MANAS: 14416")
                .setStyle(
                    NotificationCompat.BigTextStyle().bigText(
                        "Listener $listenerName activated Emergency Crisis Alert on Call #${callId.take(8)}. " +
                            "Free Override is ACTIVE. Tap to Join Live Call immediately. Helpline: ${DilSePolicyText.TELE_MANAS_HELPLINE}"
                    )
                )
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setSound(alarmUri)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            manager.notify(callId.hashCode(), notification)
        }
    }

    private const val MODERATION_CHANNEL_ID = "dilsuno_moderation_reports"
    private const val MODERATION_CHANNEL_NAME = "Dil Suno Moderation Queue Alerts"

    fun showModerationReportNotification(
        context: Context,
        reportId: String,
        reason: String,
        targetType: String
    ) {
        runCatching {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    MODERATION_CHANNEL_ID,
                    MODERATION_CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Instant moderation queue alerts for reported videos, posts, and safety flags."
                    enableVibration(true)
                }
                manager.createNotificationChannel(channel)
            }
            val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("moderation_report_id", reportId)
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                ("mod_$reportId").hashCode(),
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(context, MODERATION_CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("🚩 New Report in Moderation Queue ($reason)")
                .setContentText("Reported $targetType requires review. Open Moderation Queue for 1-tap action.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()
            manager.notify(("mod_$reportId").hashCode(), notification)
        }
    }
}

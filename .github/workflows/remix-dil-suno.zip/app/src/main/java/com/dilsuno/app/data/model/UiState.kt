package com.dilsuno.app.data.model

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class AppRole {
    GENERAL_USER,
    STAFF_LISTENER,
    SUPER_ADMIN
}

sealed interface ActivePortalSession {
    data object UnverifiedPortal : ActivePortalSession
    data class UserSession(val account: UserAccount) : ActivePortalSession
    data class StaffSession(val staff: StaffAccount) : ActivePortalSession
    data class AdminSession(val adminUid: String, val email: String) : ActivePortalSession
}

data class FriendSuggestion(
    val profile: PublicProfile,
    val matchReasonsEn: List<String>,
    val matchReasonsHi: List<String>,
    val score: Int
)

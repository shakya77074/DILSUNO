package com.dilsuno.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.ListenerApplication
import com.dilsuno.app.data.model.PostItem
import com.dilsuno.app.data.model.PublicProfile
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.RoyalBlueDeep
import com.dilsuno.app.ui.theme.RoyalBluePrimary
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.SlateDarkText
import com.dilsuno.app.ui.theme.VelvetIndigo

val SocialBlueAccent = Color(0xFF1877F2)

data class PostBgStyle(
    val id: String,
    val label: String,
    val colors: List<Color>
)

val POST_BG_STYLES = listOf(
    PostBgStyle("none", "Plain", listOf(Color(0xFFF8FAFC), Color(0xFFF1F5F9))),
    PostBgStyle("crimson_sunset", "Crimson", listOf(Color(0xFFE11D48), Color(0xFFFB7185))),
    PostBgStyle("royal_velvet", "Royal", listOf(Color(0xFF1E3A8A), Color(0xFF3B82F6))),
    PostBgStyle("velvet_plum", "Plum", listOf(Color(0xFF581C87), Color(0xFFEC4899))),
    PostBgStyle("emerald_calm", "Emerald", listOf(Color(0xFF065F46), Color(0xFF10B981))),
    PostBgStyle("amber_warmth", "Saffron", listOf(Color(0xFFB45309), Color(0xFFF59E0B))),
    PostBgStyle("midnight_slate", "Night", listOf(Color(0xFF0F172A), Color(0xFF334155)))
)

fun resolvePostBgColors(bgStyleId: String?): List<Color>? {
    if (bgStyleId.isNullOrBlank() || bgStyleId == "none") return null
    return POST_BG_STYLES.firstOrNull { it.id == bgStyleId }?.colors
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ClickableHashtagAndMentionText(
    text: String,
    textColor: Color = SlateDarkText,
    style: TextStyle = MaterialTheme.typography.bodyLarge,
    maxLines: Int = Int.MAX_VALUE,
    onHashtagClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val tokenRegex = remember { Regex("(#|\\@)[\\w\\u0900-\\u097F]+") }
    val hashtags = remember(text) {
        Regex("#[\\w\\u0900-\\u097F]+").findAll(text).map { it.value }.distinct().toList()
    }
    val annotated = remember(text, textColor) {
        buildAnnotatedString {
            append(text)
            tokenRegex.findAll(text).forEach { match ->
                val token = match.value
                addStyle(
                    style = SpanStyle(
                        color = SocialBlueAccent,
                        fontWeight = FontWeight.Bold
                    ),
                    start = match.range.first,
                    end = match.range.last + 1
                )
                if (token.startsWith("#")) {
                    addLink(
                        clickable = LinkAnnotation.Clickable(
                            tag = token,
                            styles = TextLinkStyles(
                                style = SpanStyle(
                                    color = SocialBlueAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            ),
                            linkInteractionListener = { onHashtagClick(token) }
                        ),
                        start = match.range.first,
                        end = match.range.last + 1
                    )
                }
            }
        }
    }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = annotated,
            color = textColor,
            style = style,
            maxLines = maxLines,
            overflow = TextOverflow.Ellipsis
        )
        if (hashtags.isNotEmpty()) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                hashtags.take(5).forEach { tag ->
                    Surface(
                        color = SocialBlueAccent.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .clickable { onHashtagClick(tag) }
                            .testTag("hashtag_chip_${tag.removePrefix("#")}")
                    ) {
                        Text(
                            text = tag,
                            color = SocialBlueAccent,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HashtagFeedDialog(
    hashtag: String,
    allPosts: List<PostItem>,
    lang: AppLang,
    onOpenReel: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val cleanTag = hashtag.trim()
    val matching = remember(cleanTag, allPosts) {
        allPosts.filter { post ->
            !post.copyrightClaimActive &&
                (post.hashtags.any { it.equals(cleanTag, ignoreCase = true) } ||
                    post.caption.contains(cleanTag, ignoreCase = true) ||
                    post.title.orEmpty().contains(cleanTag, ignoreCase = true))
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Tag, contentDescription = null, tint = SocialBlueAccent) },
        title = {
            Text(
                text = "$cleanTag (${matching.size})",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (matching.isEmpty()) {
                    Text(
                        text = tr("No public posts with $cleanTag yet.", "$cleanTag के साथ अभी कोई पोस्ट नहीं है।", lang),
                        style = MaterialTheme.typography.bodyMedium
                    )
                } else {
                    matching.forEach { post ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (post.postType == "reel" || post.postType == "video") {
                                        onDismiss()
                                        onOpenReel(post.id)
                                    }
                                }
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "${SecurityUtils.resolveDisplayName(post.authorName)} • ${post.postType.uppercase()}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SocialBlueAccent,
                                    fontWeight = FontWeight.Bold
                                )
                                if (!post.title.isNullOrBlank()) {
                                    Text(post.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                }
                                Text(post.caption, style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(tr("Close", "बंद करें", lang))
            }
        }
    )
}

@Composable
fun EditPostCaptionDialog(
    initialCaption: String,
    lang: AppLang,
    isScanning: Boolean,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var captionText by remember(initialCaption) { mutableStateOf(initialCaption) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Edit, contentDescription = null, tint = VelvetIndigo) },
        title = { Text(tr("Edit Caption", "कैप्शन बदलें", lang), fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = captionText,
                    onValueChange = { captionText = it },
                    label = { Text(tr("Caption (supports #hashtags & @mentions)", "कैप्शन लिखें (#hashtags और @mentions)", lang)) },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth().testTag("edit_caption_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(captionText) },
                enabled = !isScanning && captionText.isNotBlank(),
                modifier = Modifier.testTag("save_edited_caption_button")
            ) {
                Text(if (isScanning) tr("Checking...", "जाँच...", lang) else tr("Save", "सेव करें", lang))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(tr("Cancel", "रद्द", lang)) }
        }
    )
}

@Composable
fun MentionPeoplePickerDialog(
    profiles: List<PublicProfile>,
    selectedUids: List<String>,
    lang: AppLang,
    onToggleUid: (PublicProfile) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(profiles, query) {
        val q = query.trim()
        if (q.isBlank()) profiles.take(20)
        else profiles.filter {
            it.fullName.contains(q, ignoreCase = true) ||
                it.currentCity.orEmpty().contains(q, ignoreCase = true)
        }.take(20)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.AlternateEmail, contentDescription = null, tint = SocialBlueAccent) },
        title = { Text(tr("Mention People (@)", "दोस्तों को मेंशन करें (@)", lang), fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    label = { Text(tr("Search people...", "लोगों को खोजें...", lang)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("mention_search_input")
                )
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 260.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (filtered.isEmpty()) {
                        Text(tr("No matching community profiles.", "कोई प्रोफ़ाइल नहीं मिली।", lang), style = MaterialTheme.typography.bodySmall)
                    } else {
                        filtered.forEach { profile ->
                            val isSelected = profile.uid in selectedUids
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onToggleUid(profile) }
                                    .padding(horizontal = 6.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(SecurityUtils.resolveDisplayName(profile.fullName), fontWeight = FontWeight.SemiBold)
                                    if (!profile.currentCity.isNullOrBlank()) {
                                        Text(profile.currentCity, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Checkbox(checked = isSelected, onCheckedChange = { onToggleUid(profile) })
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) { Text(tr("Done", "हो गया", lang)) }
        }
    )
}

@Composable
fun ListenerApplicationDialog(
    existingApplication: ListenerApplication?,
    defaultName: String,
    defaultEmail: String,
    lang: AppLang,
    onSubmit: (fullName: String, email: String, phone: String?, city: String?, motivation: String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember(defaultName) { mutableStateOf(defaultName) }
    var email by remember(defaultEmail) { mutableStateOf(defaultEmail) }
    var phone by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var motivation by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.HeadsetMic, contentDescription = null, tint = CrimsonPrimary) },
        title = { Text(tr("Join Our Team • Dil Suno Listener", "हमारी टीम से जुड़ें • श्रोता आवेदन", lang), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (existingApplication != null) {
                    val statusColor = when (existingApplication.status) {
                        "approved" -> SafeEmerald
                        "staff_verified" -> RoyalBluePrimary
                        "rejected" -> Color(0xFFB91C1C)
                        else -> VelvetIndigo
                    }
                    Surface(
                        color = statusColor.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.45f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("listener_application_status_card")
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = statusColor, modifier = Modifier.size(16.dp))
                                Text(
                                    text = when (existingApplication.status) {
                                        "pending" -> tr("Step 1: Waiting for Staff Verification", "चरण 1: स्टाफ सत्यापन की प्रतीक्षा", lang)
                                        "staff_verified" -> tr("Step 1 Done ✓ Verified by Staff — Waiting Super Admin Final Approval", "चरण 1 पूर्ण ✓ स्टाफ सत्यापित — सुपर एडमिन की अंतिम मंज़ूरी बाकी", lang)
                                        "approved" -> tr("Approved! You can now sign in via Staff Portal.", "स्वीकृत! अब आप स्टाफ पोर्टल से लॉगिन कर सकते हैं।", lang)
                                        else -> tr("Application Rejected — You may update and re-apply.", "आवेदन अस्वीकृत — आप दोबारा आवेदन कर सकते हैं।", lang)
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = statusColor
                                )
                            }
                            if (!existingApplication.verifiedByStaffName.isNullOrBlank()) {
                                Text(
                                    text = tr("Verified by: ${existingApplication.verifiedByStaffName}", "सत्यापित: ${existingApplication.verifiedByStaffName}", lang),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }

                Text(
                    text = tr(
                        "2-Step Approval: (1) Staff reviews and marks Verified by Staff → (2) Super Admin gives Final Approval & Staff PIN.",
                        "2-चरणीय प्रक्रिया: (1) स्टाफ जांच कर 'Verified by Staff' करता है → (2) सुपर एडमिन अंतिम स्वीकृति व स्टाफ पिन देता है।",
                        lang
                    ),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(tr("Full Name *", "पूरा नाम *", lang)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("listener_app_name_input")
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text(tr("Gmail ID *", "जीमेल आईडी *", lang)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("listener_app_email_input")
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(tr("Phone Number (Optional)", "फ़ोन नंबर (वैकल्पिक)", lang)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    label = { Text(tr("City", "शहर", lang)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = motivation,
                    onValueChange = { motivation = it },
                    label = { Text(tr("Why do you want to listen & support others? *", "आप श्रोता क्यों बनना चाहते हैं? *", lang)) },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth().testTag("listener_app_motivation_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(name, email, phone.ifBlank { null }, city.ifBlank { null }, motivation) },
                enabled = name.trim().length >= 2 && email.contains("@") && motivation.trim().length >= 5,
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary, contentColor = Color.White),
                modifier = Modifier.testTag("submit_listener_application_button")
            ) {
                Text(tr("Submit Application", "आवेदन भेजें", lang), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(tr("Close", "बंद करें", lang))
            }
        }
    )
}

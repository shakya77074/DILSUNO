package com.dilsuno.app.core

import java.util.Locale

/**
 * Centralized Dil Suno Google Play Billing & Staff Payout Rules:
 * - Caller Wallet Recharge: 100% Google Play Billing consumable products:
 *   `wallet_100` / `pack_100` (₹100) .. `wallet_500` / `pack_500` (₹500).
 * - Call Session Rules: ₹100 deducted ONLY when a call connects (₹0 if unanswered).
 *   Maximum session duration = 30 minutes (1800 seconds) with visible countdown (`30:00` -> `00:00`).
 * - Revenue Split: ₹30 Staff Listener / ₹70 Admin revenue per completed 30-minute connected call.
 * - Staff Listener & Creator Payouts: Minimum ₹500 withdrawal settled to verified Bank / Payout Account Reference.
 */
object DilSunoBillingRules {
    const val MERCHANT_PAYEE_NAME: String = "Dil Suno"
    const val MERCHANT_NAME_DISPLAY: String = MERCHANT_PAYEE_NAME

    const val CALL_CHARGE_INR: Long = 100L
    const val LISTENER_SHARE_INR: Long = 30L
    const val ADMIN_SHARE_INR: Long = 70L
    const val CALL_SLOT_DURATION_SECONDS: Long = 1800L // 30 minutes (`30:00` -> `00:00`) per ₹100 call
    const val MIN_LISTENER_WITHDRAWAL_INR: Long = 500L

    val FIXED_RECHARGE_PACKS: List<Long> = listOf(100L, 200L, 300L, 400L, 500L)

    const val NON_REFUNDABLE_WALLET_NOTE: String =
        "Wallet call credits purchased via Google Play Billing are strictly non-refundable."
    const val MIN_WITHDRAWAL_NOTE: String =
        "Minimum ₹500 earnings required to withdraw."
    const val WITHDRAWAL_SUBMITTED_MESSAGE: String =
        "Withdrawal request submitted. Amount will be settled to your Bank / Payout Account within 24 hours."

    fun formatTimestamp(epochMillis: Long?): String {
        if (epochMillis == null || epochMillis <= 0L) return "Just now"
        return java.text.SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
            .format(java.util.Date(epochMillis))
    }

    fun validateListenerWithdrawal(
        availableEarningsInr: Long,
        requestedAmountInr: Long,
        payoutAccount: String
    ): String? {
        val cleanAccount = payoutAccount.trim()
        if (cleanAccount.length < 4) {
            return "Please enter a valid Bank / Payout Account Reference."
        }
        if (availableEarningsInr < MIN_LISTENER_WITHDRAWAL_INR) {
            return "Minimum ₹$MIN_LISTENER_WITHDRAWAL_INR earnings required before requesting withdrawal."
        }
        if (requestedAmountInr < MIN_LISTENER_WITHDRAWAL_INR) {
            return "Withdrawal amount must be at least ₹$MIN_LISTENER_WITHDRAWAL_INR."
        }
        if (requestedAmountInr > availableEarningsInr) {
            return "Requested amount (₹$requestedAmountInr) exceeds your withdrawable earnings (₹$availableEarningsInr)."
        }
        return null
    }

    fun formatPayoutStatusLabel(status: String): String = when (status.lowercase()) {
        "paid", "approved" -> "Paid / Approved"
        "rejected" -> "Rejected"
        else -> "Pending"
    }

    /**
     * Computes Listener vs Admin revenue split for a ₹100 connected 30-minute call:
     * - Staff Listener call: ₹30 Listener / ₹70 Admin
     * - Owner Backup call: ₹0 Listener / ₹100 Owner
     */
    fun computeCallSplit(chargeInr: Long = CALL_CHARGE_INR, isOwnerBackupCall: Boolean = false): Pair<Long, Long> {
        if (chargeInr <= 0L) return 0L to 0L
        if (isOwnerBackupCall) return 0L to chargeInr
        val listenerPart = if (chargeInr >= CALL_CHARGE_INR) LISTENER_SHARE_INR else (chargeInr * 30L) / 100L
        val adminPart = (chargeInr - listenerPart).coerceAtLeast(0L)
        return listenerPart to adminPart
    }

    fun formatCountdownMmSs(remainingSeconds: Long): String {
        val clamped = remainingSeconds.coerceAtLeast(0L)
        val mins = clamped / 60L
        val secs = clamped % 60L
        return String.format(Locale.US, "%02d:%02d", mins, secs)
    }

    /**
     * Deterministic SHA-256 purchase token deduplication hash so every Google Play purchase
     * can be verified and credited to Firebase Firestore strictly ONCE.
     */
    fun buildPurchaseTokenHash(purchaseToken: String, productId: String): String {
        val raw = "${productId.trim()}|${purchaseToken.trim()}"
        return SecurityUtils.sha256Hex(raw)
    }
}

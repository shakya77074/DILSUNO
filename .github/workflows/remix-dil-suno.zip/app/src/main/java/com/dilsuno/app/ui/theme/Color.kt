package com.dilsuno.app.ui.theme

import androidx.compose.ui.graphics.Color

// Primary "Calm Blue & White" Design System Tokens
val RoyalBluePrimary = Color(0xFF1877F2)
val RoyalBlueDeep = Color(0xFF1E40AF)
val RoyalBlueLightContainer = Color(0xFFEFF6FF)
val OnRoyalBlueContainer = Color(0xFF1E3A8A)

val PureWhiteBackground = Color(0xFFFFFFFF)
val SoftCardSurface = Color(0xFFF8FAFC)
val SoftBlueCardSurface = Color(0xFFEFF6FF)
val SlateDarkText = Color(0xFF0F172A)
val SlateSubtleText = Color(0xFF475569)
val SlateMutedFooter = Color(0xFF64748B)
val HairlineDividerBlue = Color(0xFFE2E8F0)

// Semantic Brand & Status Tokens (Calm Blue & White aligned)
val CrimsonPrimary = RoyalBluePrimary
val CrimsonDark = RoyalBlueDeep
val CrimsonLightContainer = RoyalBlueLightContainer
val OnCrimsonContainer = OnRoyalBlueContainer

val RoyalNavy = RoyalBlueDeep
val VelvetIndigo = Color(0xFF1D4ED8)
val SaffronGold = Color(0xFFD97706)
val SaffronContainer = Color(0xFFFEF3C7)
val OnSaffronContainer = Color(0xFF451A03)

val SafeEmerald = Color(0xFF0D9488)
val SafeEmeraldContainer = Color(0xFFCCFBF1)
val OnSafeEmerald = Color(0xFF042F2E)

val IvoryBackground = PureWhiteBackground
val SurfaceCardLight = SoftCardSurface
val SurfaceVariantLight = SoftBlueCardSurface
val TextPrimaryLight = SlateDarkText
val TextSecondaryLight = SlateSubtleText

val NightBackground = Color(0xFF0F172A)
val SurfaceCardDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFFCBD5E1)

val SplashOffWhite = PureWhiteBackground
val SplashSoftPink = Color(0xFF93C5FD)
val SplashDarkInk = SlateDarkText
val SplashSubtleGrey = SlateMutedFooter


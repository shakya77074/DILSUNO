package com.dilsuno.app.ui.components

import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Build
import android.view.Surface
import android.view.TextureView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

/**
 * Hardware-accelerated TextureView video player for Compose.
 * Unlike VideoView (which wraps SurfaceView and participates in WindowManager's SurfaceSyncGroup
 * causing 1000ms transaction timeouts inside LazyColumn, VerticalPager, and Crossfade),
 * TextureView renders directly into Compose's RenderNode cleanly without SurfaceSyncGroup stalls
 * or rounded-corner clipping glitches.
 */
@Composable
fun TextureVideoPlayer(
    videoUri: String,
    modifier: Modifier = Modifier,
    volume: Float = 0f,
    isPlaying: Boolean = true,
    isLooping: Boolean = true,
    playbackSpeed: Float = 1f,
    onPlayerReady: (MediaPlayer) -> Unit = {}
) {
    val latestVolume by rememberUpdatedState(volume.coerceIn(0f, 1f))
    val latestIsPlaying by rememberUpdatedState(isPlaying)
    val latestIsLooping by rememberUpdatedState(isLooping)
    val latestSpeed by rememberUpdatedState(playbackSpeed.coerceIn(0.25f, 3f))
    val latestOnReady by rememberUpdatedState(onPlayerReady)

    var mediaPlayerRef by remember(videoUri) { mutableStateOf<MediaPlayer?>(null) }
    var surfaceRef by remember(videoUri) { mutableStateOf<Surface?>(null) }
    var isPrepared by remember(videoUri) { mutableStateOf(false) }
    var videoWidth by remember(videoUri) { mutableIntStateOf(0) }
    var videoHeight by remember(videoUri) { mutableIntStateOf(0) }
    var textureViewRef by remember(videoUri) { mutableStateOf<TextureView?>(null) }

    fun applyCenterCropTransform(view: TextureView, vw: Int, vh: Int) {
        if (vw <= 0 || vh <= 0 || view.width <= 0 || view.height <= 0) return
        val viewW = view.width.toFloat()
        val viewH = view.height.toFloat()
        val scaleX = vw.toFloat() / viewW
        val scaleY = vh.toFloat() / viewH
        val maxScale = maxOf(1f / scaleX, 1f / scaleY)
        val finalScaleX = (vw * maxScale) / viewW
        val finalScaleY = (vh * maxScale) / viewH
        val matrix = Matrix().apply {
            setScale(finalScaleX, finalScaleY, viewW / 2f, viewH / 2f)
        }
        view.setTransform(matrix)
    }

    LaunchedEffect(mediaPlayerRef, isPrepared, volume, isPlaying, playbackSpeed) {
        val mp = mediaPlayerRef ?: return@LaunchedEffect
        if (!isPrepared) return@LaunchedEffect
        val clampedVol = volume.coerceIn(0f, 1f)
        runCatching { mp.setVolume(clampedVol, clampedVol) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            runCatching {
                val safeSpeed = playbackSpeed.coerceIn(0.25f, 3f)
                if (mp.playbackParams.speed != safeSpeed) {
                    mp.playbackParams = PlaybackParams().setSpeed(safeSpeed)
                }
            }
        }
        runCatching {
            if (isPlaying && !mp.isPlaying) {
                mp.start()
            } else if (!isPlaying && mp.isPlaying) {
                mp.pause()
            }
        }
    }

    DisposableEffect(videoUri) {
        onDispose {
            runCatching { mediaPlayerRef?.stop() }
            runCatching { mediaPlayerRef?.reset() }
            runCatching { mediaPlayerRef?.release() }
            mediaPlayerRef = null
            isPrepared = false
            runCatching { surfaceRef?.release() }
            surfaceRef = null
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            TextureView(ctx).apply {
                val textureView = this
                isOpaque = false
                textureViewRef = textureView
                surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(
                        surfaceTexture: SurfaceTexture,
                        width: Int,
                        height: Int
                    ) {
                        val surface = Surface(surfaceTexture)
                        surfaceRef = surface
                        runCatching {
                            val mp = MediaPlayer().apply {
                                setSurface(surface)
                                setDataSource(ctx, Uri.parse(videoUri))
                                this.isLooping = latestIsLooping
                                setOnVideoSizeChangedListener { _, vw, vh ->
                                    videoWidth = vw
                                    videoHeight = vh
                                    applyCenterCropTransform(textureView, vw, vh)
                                }
                                setOnPreparedListener { preparedMp ->
                                    isPrepared = true
                                    val vol = latestVolume
                                    runCatching { preparedMp.setVolume(vol, vol) }
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && latestSpeed != 1f) {
                                        runCatching {
                                            preparedMp.playbackParams = PlaybackParams().setSpeed(latestSpeed)
                                        }
                                    }
                                    latestOnReady(preparedMp)
                                    if (latestIsPlaying) {
                                        runCatching { preparedMp.start() }
                                    }
                                }
                                setOnErrorListener { _, _, _ ->
                                    isPrepared = false
                                    true
                                }
                                prepareAsync()
                            }
                            mediaPlayerRef = mp
                        }
                    }

                    override fun onSurfaceTextureSizeChanged(
                        surface: SurfaceTexture,
                        width: Int,
                        height: Int
                    ) {
                        applyCenterCropTransform(textureView, videoWidth, videoHeight)
                    }

                    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                        runCatching { mediaPlayerRef?.stop() }
                        runCatching { mediaPlayerRef?.reset() }
                        runCatching { mediaPlayerRef?.release() }
                        mediaPlayerRef = null
                        isPrepared = false
                        runCatching { surfaceRef?.release() }
                        surfaceRef = null
                        return true
                    }

                    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) = Unit
                }
            }
        },
        update = { view ->
            textureViewRef = view
            if (videoWidth > 0 && videoHeight > 0) {
                applyCenterCropTransform(view, videoWidth, videoHeight)
            }
        }
    )
}

package com.dilsuno.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.DilSeCallSession
import com.dilsuno.app.data.model.ListenerApplication
import com.dilsuno.app.data.model.ListenerPromoVideo
import com.dilsuno.app.data.model.PublicProfile
import com.dilsuno.app.data.model.StaffAccount
import com.dilsuno.app.data.model.StaffAuditLog
import com.dilsuno.app.data.model.StaffRatingItem
import com.dilsuno.app.ui.components.SuperAdminPromoReviewAndAssetsCard
import com.dilsuno.app.ui.theme.HairlineDividerBlue
import com.dilsuno.app.ui.theme.PureWhiteBackground
import com.dilsuno.app.ui.theme.RoyalBlueDeep
import com.dilsuno.app.ui.theme.RoyalBlueLightContainer
import com.dilsuno.app.ui.theme.RoyalBluePrimary
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.SlateDarkText
import com.dilsuno.app.ui.theme.SlateSubtleText
import com.dilsuno.app.ui.theme.SoftBlueCardSurface
import com.dilsuno.app.ui.theme.SoftCardSurface
import com.dilsuno.app.viewmodel.StaffAndAdminViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminUsersAndStaffTab(
    viewModel: StaffAndAdminViewModel,
    lang: AppLang,
    reviewerDemoEnabled: Boolean,
    listenerApplications: List<ListenerApplication>,
    allStaff: List<StaffAccount>,
    allActiveCalls: List<DilSeCallSession>,
    liveEpochSec: Long,
    allStaffRatings: List<StaffRatingItem>,
    allAuditLogs: List<StaffAuditLog>,
    allListenerPromoVideos: List<ListenerPromoVideo>,
    allProfiles: List<PublicProfile>,
    onRequestResetPin: (String) -> Unit
) {
    var newStaffEmail by remember { mutableStateOf("") }
    var newStaffName by remember { mutableStateOf("") }
    var newStaffPin by remember { mutableStateOf("") }
    var showNewStaffPin by remember { mutableStateOf(false) }
    var finalApproveAppTarget by remember { mutableStateOf<ListenerApplication?>(null) }

    val actionableApplications = remember(listenerApplications) {
        listenerApplications.filter { it.status == "staff_verified" || it.status == "pending" }
    }
    val creators = remember(allProfiles) { allProfiles.filter { it.isCreator } }
    val blockedUsers = remember(allProfiles) { allProfiles.filter { it.isBanned } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // PLAY STORE REVIEWER DEMO ACCOUNT LIVE ON/OFF CONTROL
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SoftBlueCardSurface),
                border = BorderStroke(1.dp, RoyalBluePrimary.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().testTag("admin_reviewer_demo_card")
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "Play Store Reviewer Demo Account (reviewer@dilsuno.com)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateDarkText,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                Surface(
                                    color = if (reviewerDemoEnabled) Color(0xFF15803D) else Color(0xFFB91C1C),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("admin_reviewer_demo_status_badge")
                                ) {
                                    Text(
                                        text = if (reviewerDemoEnabled) "ON" else "OFF",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Password: ${SecurityUtils.reviewerDemoPasswordForAdmin()} • Pre-loaded ₹${SecurityUtils.REVIEWER_INITIAL_CREDITS_INR} demo wallet",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateSubtleText
                            )
                        }
                        Switch(
                            checked = reviewerDemoEnabled,
                            onCheckedChange = { viewModel.toggleReviewerDemoEnabled(it) },
                            modifier = Modifier.testTag("admin_reviewer_demo_switch")
                        )
                    }
                }
            }
        }

        // STEP 2 LISTENER APPLICATIONS (Verified by Staff -> Admin Final Approval + PIN)
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.HeadsetMic, contentDescription = null, tint = RoyalBluePrimary)
                Text(
                    text = tr(
                        "Listener Applications (${actionableApplications.size}) • Step 2 Final Approval",
                        "श्रोता आवेदन (${actionableApplications.size}) • चरण 2 अंतिम मंज़ूरी",
                        lang
                    ),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SlateDarkText
                )
            }
        }
        if (actionableApplications.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = SoftCardSurface), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = tr("No pending listener applications.", "कोई श्रोता आवेदन लंबित नहीं है।", lang),
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateSubtleText,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        } else {
            items(actionableApplications, key = { "app_${it.id}" }) { app ->
                val isStaffVerified = app.status == "staff_verified"
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (isStaffVerified) SoftBlueCardSurface else SoftCardSurface),
                    border = BorderStroke(1.dp, if (isStaffVerified) RoyalBluePrimary.copy(alpha = 0.45f) else HairlineDividerBlue),
                    modifier = Modifier.fillMaxWidth().testTag("admin_listener_app_${app.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("${app.fullName} • ${app.email}", fontWeight = FontWeight.Bold, color = SlateDarkText, modifier = Modifier.weight(1f))
                            Surface(
                                color = if (isStaffVerified) SafeEmerald else RoyalBlueLightContainer,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (isStaffVerified) "VERIFIED BY STAFF ✓" else "STEP 1 PENDING",
                                    color = if (isStaffVerified) Color.White else RoyalBlueDeep,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        if (!app.verifiedByStaffName.isNullOrBlank()) {
                            Text("Verified by: ${app.verifiedByStaffName}", style = MaterialTheme.typography.labelSmall, color = SafeEmerald)
                        }
                        Text(app.motivation, style = MaterialTheme.typography.bodySmall, color = SlateDarkText)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = { finalApproveAppTarget = app },
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary, contentColor = Color.White),
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("admin_final_approve_app_${app.id}")
                            ) {
                                Text(tr("Final Approve & Set PIN", "अंतिम मंज़ूरी व पिन सेट करें", lang), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = { viewModel.rejectListenerApplication(app) },
                                border = BorderStroke(1.dp, Color(0xFFB91C1C)),
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Text(tr("Reject", "अस्वीकार", lang), color = Color(0xFFB91C1C), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // ADD STAFF LISTENER FORM
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.PersonAdd, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(tr("Manage Staff Listeners", "स्टाफ श्रोता प्रबंधन", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    OutlinedTextField(
                        value = newStaffEmail,
                        onValueChange = { newStaffEmail = it },
                        label = { Text(tr("Staff Gmail ID *", "स्टाफ जीमेल आईडी *", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth().testTag("admin_new_staff_email"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newStaffName,
                        onValueChange = { newStaffName = it },
                        label = { Text(tr("Staff Name (Optional)", "स्टाफ नाम (वैकल्पिक)", lang)) },
                        modifier = Modifier.fillMaxWidth().testTag("admin_new_staff_name"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newStaffPin,
                        onValueChange = { input -> newStaffPin = input.filter { it.isDigit() }.take(16) },
                        label = { Text(tr("Staff PIN (8–12 digits *)", "स्टाफ पिन (8–12 अंक *)", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        trailingIcon = {
                            IconButton(
                                onClick = { showNewStaffPin = !showNewStaffPin },
                                modifier = Modifier.testTag("toggle_admin_new_staff_pin_visibility")
                            ) {
                                Icon(
                                    if (showNewStaffPin) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = if (showNewStaffPin) tr("Hide PIN", "पिन छिपाएं", lang) else tr("Show PIN", "पिन दिखाएं", lang)
                                )
                            }
                        },
                        visualTransformation = if (showNewStaffPin) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().testTag("admin_new_staff_pin"),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            val normalized = SecurityUtils.normalizeEmail(newStaffEmail)
                            viewModel.createStaffByGmailAndPin(newStaffEmail, newStaffName, newStaffPin)
                            if (SecurityUtils.isValidEmail(normalized) && SecurityUtils.isValidStaffPin(newStaffPin)) {
                                newStaffEmail = ""
                                newStaffName = ""
                                newStaffPin = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary, contentColor = Color.White),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("admin_create_staff_button")
                    ) {
                        Text(tr("Add Staff Listener", "स्टाफ श्रोता जोड़ें", lang), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // LIVE STAFF ROSTER
        item {
            Text(
                text = tr("Live Staff Roster & Call Timers (${allStaff.size})", "लाइव स्टाफ स्थिति व कॉल टाइमर (${allStaff.size})", lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = SlateDarkText
            )
        }
        items(allStaff, key = { it.staffUsername }) { member ->
            val memberRatings = allStaffRatings.filter { it.staffUsername == member.staffUsername }
            val avgStars = if (memberRatings.isNotEmpty()) "%.1f".format(memberRatings.map { it.stars }.average()) else "N/A"
            val totalDurationSec = memberRatings.sumOf { it.durationSeconds }
            val activeCallForStaff = allActiveCalls.firstOrNull { it.listenerStaffId == member.staffUsername }
            val liveCallElapsed = activeCallForStaff?.let { call ->
                val startedAtSec = (call.updatedAt ?: call.createdAt)?.seconds ?: liveEpochSec
                (liveEpochSec - startedAtSec).coerceAtLeast(0L)
            }
            val isManagerRole = member.staffRole == "trusted_staff_manager"

            Card(
                colors = CardDefaults.cardColors(containerColor = SoftCardSurface),
                border = BorderStroke(1.dp, HairlineDividerBlue),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            val staffIdentity = member.staffEmail.ifBlank { "@${member.staffUsername}" }
                            Text("${member.displayName} • $staffIdentity", fontWeight = FontWeight.Bold, color = SlateDarkText)
                            Text("Calls: ${member.totalCalls} • Earnings: ₹${member.earningsInr}", style = MaterialTheme.typography.bodySmall, color = SlateSubtleText)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Filled.Star, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(16.dp))
                                Text("Avg: $avgStars (${memberRatings.size}) • ${totalDurationSec}s", style = MaterialTheme.typography.labelSmall, color = SlateDarkText)
                            }
                        }
                        Surface(
                            color = when {
                                !member.isActive -> Color(0xFFB91C1C)
                                activeCallForStaff != null -> Color(0xFFD97706)
                                member.isOnline -> Color(0xFF15803D)
                                else -> Color(0xFF475569)
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = when {
                                    !member.isActive -> tr("SUSPENDED", "निलंबित", lang)
                                    activeCallForStaff != null -> "ON CALL • ${liveCallElapsed ?: 0}s"
                                    member.isOnline -> "ONLINE"
                                    else -> "OFFLINE"
                                },
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val nextRole = if (isManagerRole) "listener" else "trusted_staff_manager"
                                viewModel.setStaffRole(member.staffUsername, nextRole)
                            },
                            border = BorderStroke(1.dp, RoyalBluePrimary),
                            modifier = Modifier.heightIn(min = 48.dp).testTag("admin_toggle_staff_role_${member.staffUsername}")
                        ) {
                            Text(
                                if (isManagerRole) tr("Revoke Manager", "मैनेजर हटाएं", lang) else tr("Make Staff Manager", "मैनेजर बनाएं", lang),
                                color = RoyalBlueDeep,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Button(
                            onClick = { viewModel.toggleStaffActive(member.staffUsername, !member.isActive) },
                            colors = ButtonDefaults.buttonColors(containerColor = if (member.isActive) Color(0xFFB91C1C) else Color(0xFF15803D), contentColor = Color.White),
                            modifier = Modifier.heightIn(min = 48.dp).testTag("admin_suspend_staff_${member.staffUsername}")
                        ) {
                            Text(if (member.isActive) tr("Suspend", "निलंबित", lang) else tr("Activate", "सक्रिय", lang), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { onRequestResetPin(member.staffUsername) },
                            border = BorderStroke(1.dp, RoyalBluePrimary),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Filled.Key, contentDescription = null, tint = RoyalBlueDeep, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(tr("Reset PIN", "पिन बदलें", lang), color = RoyalBlueDeep, fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { viewModel.removeStaff(member.staffUsername) }, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.Filled.DeleteForever, contentDescription = tr("Remove Staff", "स्टाफ हटाएं", lang), tint = Color(0xFFB91C1C))
                        }
                    }
                }
            }
        }

        // STAFF AUDIT LOG
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text(
                    text = tr("Staff Chronological Audit Log (${allAuditLogs.size})", "स्टाफ ऑडिट लॉग (${allAuditLogs.size})", lang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        items(allAuditLogs.take(25), key = { it.id }) { log ->
            val isAlert = log.actionType.contains("deleted") || log.actionType.contains("blocked")
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = if (isAlert) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f) else MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${log.staffDisplayName} (@${log.staffUsername}) • ${log.actionType.uppercase()}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    if (!log.contentPreview.isNullOrBlank()) Text("\"${log.contentPreview}\"", style = MaterialTheme.typography.bodySmall)
                    if (!log.reason.isNullOrBlank()) Text("Reason: ${log.reason}", style = MaterialTheme.typography.labelSmall, color = SlateSubtleText)
                }
            }
        }

        item {
            SuperAdminPromoReviewAndAssetsCard(
                promoVideos = allListenerPromoVideos,
                lang = lang,
                onUploadPromoAsset = { title, caption, mediaType, mediaUri ->
                    viewModel.uploadAdminPromoAsset(title, caption, mediaType, mediaUri)
                }
            )
        }

        // CREATOR MONETIZATION CONTROL
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.MonetizationOn, contentDescription = null, tint = SafeEmerald)
                Text(tr("Registered Creators (${creators.size})", "पंजीकृत क्रिएटर्स (${creators.size})", lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        }
        items(creators, key = { "creator_${it.uid}" }) { creator ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(creator.creatorName ?: creator.fullName, fontWeight = FontWeight.Bold)
                        Text("${creator.creatorCategory ?: "Creator"} • ${if (creator.monetizationApproved) "Monetization ON" else "Monetization OFF"}", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = creator.monetizationApproved,
                        onCheckedChange = { approve -> viewModel.toggleCreatorMonetization(creator.uid, approve) },
                        modifier = Modifier.testTag("toggle_creator_mon_${creator.uid}")
                    )
                }
            }
        }

        // ALL USERS & BLOCKED ACCOUNTS (BAN / UNBAN CONTROLS)
        item {
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.Security, contentDescription = null, tint = Color(0xFFB91C1C))
                Text(
                    text = tr("All Users & Ban Controls (${allProfiles.size} • ${blockedUsers.size} Banned)", "सभी यूज़र्स व बैन नियंत्रण (${allProfiles.size})", lang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SlateDarkText
                )
            }
        }
        items(allProfiles.take(40), key = { "usr_${it.uid}" }) { profile ->
            Card(
                colors = CardDefaults.cardColors(containerColor = if (profile.isBanned) Color(0xFFFEF2F2) else SoftCardSurface),
                border = BorderStroke(1.dp, if (profile.isBanned) Color(0xFFDC2626).copy(alpha = 0.45f) else HairlineDividerBlue),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Block, contentDescription = null, tint = if (profile.isBanned) Color(0xFFB91C1C) else SlateSubtleText)
                        Column {
                            Text(SecurityUtils.resolveDisplayName(profile.fullName), fontWeight = FontWeight.Bold, color = SlateDarkText)
                            Text("UID: ${profile.uid.take(12)} • ${if (profile.isBanned) "BANNED" else "ACTIVE"}", style = MaterialTheme.typography.labelSmall, color = SlateSubtleText)
                        }
                    }
                    OutlinedButton(
                        onClick = { viewModel.setUserBanned(profile.uid, !profile.isBanned) },
                        border = BorderStroke(1.dp, if (profile.isBanned) RoyalBluePrimary else Color(0xFFB91C1C)),
                        modifier = Modifier.heightIn(min = 48.dp).testTag("admin_toggle_ban_${profile.uid}")
                    ) {
                        Text(
                            text = if (profile.isBanned) tr("Unban", "अनब्लॉक", lang) else tr("Ban User", "बैन करें", lang),
                            color = if (profile.isBanned) RoyalBlueDeep else Color(0xFFB91C1C),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    finalApproveAppTarget?.let { app ->
        var assignPin by remember(app.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { finalApproveAppTarget = null },
            title = { Text(tr("Final Approve Listener (${app.fullName})", "${app.fullName} को अंतिम मंज़ूरी दें", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("Assign a 6–12 digit Staff PIN so ${app.fullName} can access the Staff Listener Portal.", "6–12 अंकों का स्टाफ पिन दर्ज करें।", lang), style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = assignPin,
                        onValueChange = { input -> assignPin = input.filter { it.isDigit() }.take(12) },
                        label = { Text(tr("Assign Staff PIN (min 6 digits) *", "स्टाफ पिन (कम से कम 6 अंक) *", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("admin_final_approve_pin_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.finalApproveListenerApplicationByAdmin(app, assignPin)
                        finalApproveAppTarget = null
                    },
                    enabled = assignPin.length in 6..12,
                    colors = ButtonDefaults.buttonColors(containerColor = SafeEmerald, contentColor = Color.White),
                    modifier = Modifier.testTag("admin_confirm_final_approve_button")
                ) {
                    Text(tr("Final Approve", "अंतिम स्वीकृति", lang), color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { finalApproveAppTarget = null }) { Text(tr("Cancel", "रद्द", lang)) }
            }
        )
    }
}

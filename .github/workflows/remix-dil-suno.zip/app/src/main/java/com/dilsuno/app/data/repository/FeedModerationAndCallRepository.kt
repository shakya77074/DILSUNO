package com.dilsuno.app.data.repository

import android.content.Context
import com.dilsuno.app.R
import com.dilsuno.app.core.DilSePolicyText
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.data.model.AdminPromoAsset
import com.dilsuno.app.data.model.AiSafetyLog
import com.dilsuno.app.data.model.AppConfig
import com.dilsuno.app.data.model.CommentItem
import com.dilsuno.app.data.model.ContactLeakAlert
import com.dilsuno.app.data.model.CreatorTip
import com.dilsuno.app.data.model.DilSeCallSession
import com.dilsuno.app.data.model.EmergencyLegalLog
import com.dilsuno.app.data.model.ListenerApplication
import com.dilsuno.app.data.model.ListenerPromoVideo
import com.dilsuno.app.data.model.LiveStreamItem
import com.dilsuno.app.data.model.ModerationReport
import com.dilsuno.app.data.model.PayoutRequest
import com.dilsuno.app.data.model.PlayBillingPurchaseRecord
import com.dilsuno.app.data.model.PostItem
import com.dilsuno.app.data.model.StaffAccount
import com.dilsuno.app.data.model.StaffAuditLog
import com.dilsuno.app.data.model.StaffDirectoryEntry
import com.dilsuno.app.data.model.StaffRatingItem
import com.dilsuno.app.data.model.StoryItem
import com.dilsuno.app.data.model.SupportTicket
import com.dilsuno.app.data.model.WebRtcSignal
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class FeedModerationAndCallRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUid(): String {
        return Firebase.auth.currentUser?.uid
            ?: throw IllegalStateException("Sign-In required before accessing Dil Suno data.")
    }

    fun observeActivePosts(): Flow<List<PostItem>> {
        return db.collection("posts")
            .whereEqualTo("moderationStatus", "active")
            .snapshots()
            .map { snap ->
                snap.toObjects(PostItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "posts")
                throw error
            }
    }

    suspend fun publishApprovedPost(
        authorName: String,
        authorAvatar: String?,
        postType: String,
        title: String?,
        caption: String,
        city: String?,
        mediaUri: String?,
        musicTrack: String?,
        groupId: String? = null,
        pageId: String? = null,
        editorSummary: String? = null,
        bgStyleId: String? = null,
        hasAiLabel: Boolean = false,
        hashtags: List<String> = emptyList(),
        mentionedUids: List<String> = emptyList()
    ): Result<String> {
        val uid = requireUid()
        if (!SecurityUtils.isSafeMediaUri(mediaUri, allowVideo = true) ||
            !SecurityUtils.isSafeMediaUri(authorAvatar, allowVideo = false)
        ) {
            return Result.failure(SecurityException("Blocked dangerous or unsupported media format."))
        }
        val id = UUID.randomUUID().toString()
        val docRef = db.collection("posts").document(id)
        return try {
            val cleanHashtags = hashtags.map { SecurityUtils.sanitizeInput(it, 48).trim() }
                .filter { it.isNotBlank() }.distinct().take(20)
            val cleanMentions = mentionedUids.map { it.trim().take(128) }
                .filter { it.isNotBlank() }.distinct().take(20)
            val payload = mapOf(
                "authorUid" to uid,
                "authorName" to SecurityUtils.sanitizeInput(authorName, 100).ifBlank { "Member" },
                "authorAvatar" to authorAvatar?.take(600),
                "postType" to postType,
                "title" to title?.let { SecurityUtils.sanitizeInput(it, 160) }?.ifBlank { null },
                "caption" to SecurityUtils.sanitizeInput(caption, 2000),
                "city" to city?.let { SecurityUtils.sanitizeInput(it, 100) }?.ifBlank { null },
                "mediaUri" to mediaUri?.take(600),
                "musicTrack" to musicTrack?.let { SecurityUtils.sanitizeInput(it, 120) }?.ifBlank { null },
                "bgStyleId" to bgStyleId?.take(40)?.ifBlank { null },
                "hasAiLabel" to hasAiLabel,
                "hashtags" to cleanHashtags,
                "mentionedUids" to cleanMentions,
                "copyrightClaimActive" to false,
                "audioMutedForClaim" to false,
                "groupId" to groupId?.take(128),
                "pageId" to pageId?.take(128),
                "likesCount" to 0L,
                "loveCount" to 0L,
                "hahaCount" to 0L,
                "sadCount" to 0L,
                "angryCount" to 0L,
                "commentsCount" to 0L,
                "viewsCount" to 1L,
                "aiSafetyStatus" to "approved",
                "moderationStatus" to "active",
                "editorSummary" to editorSummary?.let { SecurityUtils.sanitizeInput(it, 1000) }?.ifBlank { null },
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            docRef.set(payload).await()
            Result.success(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updatePostCaptionAndTags(
        postId: String,
        newCaption: String,
        hashtags: List<String>
    ): Result<Unit> {
        val docRef = db.collection("posts").document(postId)
        return try {
            val cleanHashtags = hashtags.map { SecurityUtils.sanitizeInput(it, 48).trim() }
                .filter { it.isNotBlank() }.distinct().take(20)
            docRef.update(
                mapOf(
                    "caption" to SecurityUtils.sanitizeInput(newCaption, 2000),
                    "hashtags" to cleanHashtags,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun markPostCopyrightClaim(
        postId: String,
        active: Boolean,
        reason: String?
    ): Result<Unit> {
        val docRef = db.collection("posts").document(postId)
        return try {
            val cleanReason = reason?.let { SecurityUtils.sanitizeInput(it, 200) }?.ifBlank { null }
                ?: if (active) "Audio copyright claim reported by Rights Holder / Admin" else ""
            docRef.update(
                mapOf(
                    "copyrightClaimActive" to active,
                    "copyrightClaimReason" to cleanReason,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun muteReelAudioToRemoveClaim(postId: String): Result<Unit> {
        val docRef = db.collection("posts").document(postId)
        return try {
            docRef.update(
                mapOf(
                    "audioMutedForClaim" to true,
                    "musicTrack" to "",
                    "copyrightClaimActive" to false,
                    "copyrightClaimReason" to "",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun reactToPost(postId: String, reactionField: String): Result<Unit> {
        val allowed = setOf("likesCount", "loveCount", "hahaCount", "sadCount", "angryCount", "viewsCount")
        if (reactionField !in allowed) return Result.failure(IllegalArgumentException("Invalid reaction field"))
        val docRef = db.collection("posts").document(postId)
        return try {
            docRef.update(
                mapOf(
                    reactionField to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeComments(postId: String): Flow<List<CommentItem>> {
        val path = "posts/$postId/comments"
        return db.collection("posts").document(postId).collection("comments")
            .whereEqualTo("moderationStatus", "active")
            .snapshots()
            .map { snap ->
                snap.toObjects(CommentItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun publishApprovedComment(postId: String, authorName: String, text: String): Result<Unit> {
        val uid = requireUid()
        val commentRef = db.collection("posts").document(postId).collection("comments")
            .document(UUID.randomUUID().toString())
        val postRef = db.collection("posts").document(postId)
        return try {
            commentRef.set(
                mapOf(
                    "authorUid" to uid,
                    "authorName" to SecurityUtils.sanitizeInput(authorName, 100),
                    "text" to SecurityUtils.sanitizeInput(text, 600),
                    "aiSafetyStatus" to "approved",
                    "moderationStatus" to "active",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            postRef.update(
                mapOf(
                    "commentsCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, commentRef.path)
            Result.failure(e)
        }
    }

    fun observeActiveStories(): Flow<List<StoryItem>> {
        val now = System.currentTimeMillis()
        return db.collection("stories")
            .whereEqualTo("moderationStatus", "active")
            .snapshots()
            .map { snap ->
                snap.toObjects(StoryItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .filter { it.expiresAtMillis > now }
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "stories")
                throw error
            }
    }

    suspend fun publishApprovedStory(
        authorName: String,
        authorAvatar: String?,
        caption: String,
        mediaUri: String?,
        bgColorHex: String = "#E11D48"
    ): Result<Unit> {
        val uid = requireUid()
        if (!SecurityUtils.isSafeMediaUri(mediaUri, allowVideo = false) ||
            !SecurityUtils.isSafeMediaUri(authorAvatar, allowVideo = false)
        ) {
            return Result.failure(SecurityException("Blocked dangerous or unsupported story photo format."))
        }
        val docRef = db.collection("stories").document(UUID.randomUUID().toString())
        val expiresAt = System.currentTimeMillis() + 24L * 60L * 60L * 1000L
        return try {
            val payload = mapOf(
                "authorUid" to uid,
                "authorName" to SecurityUtils.sanitizeInput(authorName, 100).ifBlank { "Member" },
                "authorAvatar" to authorAvatar?.take(600),
                "caption" to SecurityUtils.sanitizeInput(caption, 400),
                "mediaUri" to mediaUri?.take(600),
                "bgColorHex" to bgColorHex.take(20),
                "aiSafetyStatus" to "approved",
                "moderationStatus" to "active",
                "expiresAtMillis" to expiresAt,
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeLiveStreams(): Flow<List<LiveStreamItem>> {
        return db.collection("live_streams")
            .whereEqualTo("moderationStatus", "active")
            .snapshots()
            .map { snap ->
                snap.toObjects(LiveStreamItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "live_streams")
                throw error
            }
    }

    suspend fun startLiveStream(hostName: String, title: String, city: String?): Result<String> {
        val uid = requireUid()
        val id = UUID.randomUUID().toString()
        val docRef = db.collection("live_streams").document(id)
        return try {
            val payload = mapOf(
                "hostUid" to uid,
                "hostName" to SecurityUtils.sanitizeInput(hostName, 100),
                "title" to SecurityUtils.sanitizeInput(title, 200),
                "city" to city?.let { SecurityUtils.sanitizeInput(it, 100) }?.ifBlank { null },
                "status" to "live",
                "viewerCount" to 1L,
                "aiSafetyStatus" to "approved",
                "moderationStatus" to "active",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            docRef.set(payload).await()
            Result.success(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun endLiveStream(streamId: String): Result<Unit> {
        val docRef = db.collection("live_streams").document(streamId)
        return try {
            docRef.update(
                mapOf(
                    "status" to "ended",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeLiveComments(streamId: String): Flow<List<CommentItem>> {
        val path = "live_streams/$streamId/comments"
        return db.collection("live_streams").document(streamId).collection("comments")
            .whereEqualTo("moderationStatus", "active")
            .snapshots()
            .map { snap ->
                snap.toObjects(CommentItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun sendLiveComment(streamId: String, authorName: String, text: String): Result<Unit> {
        val uid = requireUid()
        val docRef = db.collection("live_streams").document(streamId).collection("comments")
            .document(UUID.randomUUID().toString())
        return try {
            docRef.set(
                mapOf(
                    "authorUid" to uid,
                    "authorName" to SecurityUtils.sanitizeInput(authorName, 100),
                    "text" to SecurityUtils.sanitizeInput(text, 400),
                    "aiSafetyStatus" to "approved",
                    "moderationStatus" to "active",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun logAiSafetyBlock(
        userName: String,
        contentType: String,
        snippet: String,
        violationCategory: String,
        aiReason: String,
        permanentBan: Boolean
    ): Result<Unit> {
        val uid = requireUid()
        val logRef = db.collection("ai_safety_logs").document(UUID.randomUUID().toString())
        return try {
            logRef.set(
                mapOf(
                    "userUid" to uid,
                    "userName" to SecurityUtils.sanitizeInput(userName, 100),
                    "contentType" to contentType.take(60),
                    "snippet" to SecurityUtils.sanitizeInput(snippet, 400),
                    "violationCategory" to violationCategory,
                    "aiReason" to SecurityUtils.sanitizeInput(aiReason, 500),
                    "actionTaken" to if (permanentBan) "auto_deleted_banned" else "auto_deleted_warned",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, logRef.path)
            Result.failure(e)
        }
    }

    suspend fun submitReport(
        targetType: String,
        targetId: String,
        targetAuthorUid: String?,
        reportType: String,
        reason: String,
        targetAuthorName: String? = null,
        targetMediaUri: String? = null,
        targetCaption: String? = null,
        parentPostId: String? = null
    ): Result<Unit> {
        val uid = requireUid()
        val reportId = UUID.randomUUID().toString()
        val docRef = db.collection("moderation_reports").document(reportId)
        return try {
            val safeMedia = targetMediaUri?.takeIf { SecurityUtils.isSafeMediaUri(it, allowVideo = true) }?.take(600)
            val payload = mapOf(
                "reporterUid" to uid,
                "targetType" to targetType,
                "targetId" to targetId,
                "targetAuthorUid" to targetAuthorUid,
                "targetAuthorName" to targetAuthorName?.let { SecurityUtils.sanitizeInput(it, 100) }?.ifBlank { null },
                "targetMediaUri" to safeMedia,
                "targetCaption" to targetCaption?.let { SecurityUtils.sanitizeInput(it, 500) }?.ifBlank { null },
                "parentPostId" to parentPostId?.take(128)?.ifBlank { null },
                "reportType" to reportType,
                "reason" to SecurityUtils.sanitizeInput(reason, 500),
                "status" to "open",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            docRef.set(payload).await()

            // Alert Trusted Staff Managers immediately via in-app notifications
            runCatching {
                val staffManagers = db.collection("staff_directory")
                    .whereEqualTo("isActive", true)
                    .get()
                    .await()
                    .toObjects(StaffDirectoryEntry::class.java)
                    .filter { it.staffRole == "trusted_staff_manager" && !it.assignedUid.isNullOrBlank() }

                staffManagers.forEach { manager ->
                    val targetUid = manager.assignedUid ?: return@forEach
                    db.collection("notifications").document(UUID.randomUUID().toString()).set(
                        mapOf(
                            "recipientUid" to targetUid,
                            "actorUid" to uid,
                            "actorName" to "Moderation Queue Alert",
                            "type" to "moderation",
                            "message" to SecurityUtils.sanitizeInput("New $reportType report on $targetType requires review.", 300),
                            "targetId" to reportId,
                            "isRead" to false,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun sendCreatorTip(creatorUid: String, postId: String, amountInr: Long): Result<Unit> {
        val uid = requireUid()
        val docRef = db.collection("creator_tips").document(UUID.randomUUID().toString())
        return try {
            docRef.set(
                mapOf(
                    "senderUid" to uid,
                    "creatorUid" to creatorUid,
                    "postId" to postId,
                    "amountInr" to amountInr,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeTipsForCreator(creatorUid: String): Flow<List<CreatorTip>> {
        return db.collection("creator_tips")
            .whereEqualTo("creatorUid", creatorUid)
            .snapshots()
            .map { it.toObjects(CreatorTip::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "creator_tips")
                throw error
            }
    }

    suspend fun requestPayout(
        creatorName: String,
        payoutAccount: String,
        amountInr: Long,
        requesterType: String = "creator"
    ): Result<Unit> {
        val uid = requireUid()
        val docRef = db.collection("payout_requests").document(UUID.randomUUID().toString())
        return try {
            docRef.set(
                mapOf(
                    "creatorUid" to uid,
                    "creatorName" to SecurityUtils.sanitizeInput(creatorName, 100),
                    "requesterType" to if (requesterType == "staff") "staff" else "creator",
                    "payoutAccount" to SecurityUtils.sanitizeInput(payoutAccount, 100),
                    "amountInr" to amountInr,
                    "status" to "pending",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeMyPayoutRequests(creatorUid: String): Flow<List<PayoutRequest>> {
        return db.collection("payout_requests")
            .whereEqualTo("creatorUid", creatorUid)
            .snapshots()
            .map { snap ->
                snap.toObjects(PayoutRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "payout_requests")
                throw error
            }
    }

    fun observeAppConfig(): Flow<AppConfig> = callbackFlow {
        var configRegistration: ListenerRegistration? = null
        val auth = Firebase.auth

        fun attachConfigListener() {
            if (configRegistration != null) return
            configRegistration = db.collection("app_config").document("settings")
                .addSnapshotListener { snap, err ->
                    if (err != null) {
                        if (auth.currentUser != null) {
                            handleFirestoreError(err, OperationType.GET, "app_config/settings")
                        }
                        trySend(AppConfig())
                        return@addSnapshotListener
                    }
                    val cfg = if (snap != null && snap.exists()) {
                        snap.toObject(AppConfig::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                            ?: AppConfig()
                    } else {
                        AppConfig()
                    }
                    trySend(cfg)
                }
        }

        fun detachConfigListener() {
            configRegistration?.remove()
            configRegistration = null
        }

        val authListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            if (firebaseAuth.currentUser != null) {
                attachConfigListener()
            } else {
                detachConfigListener()
                trySend(AppConfig())
            }
        }

        auth.addAuthStateListener(authListener)
        if (auth.currentUser != null) {
            attachConfigListener()
        } else {
            trySend(AppConfig())
        }

        awaitClose {
            auth.removeAuthStateListener(authListener)
            detachConfigListener()
        }
    }

    fun observeActiveStaffDirectory(): Flow<List<StaffDirectoryEntry>> {
        return db.collection("staff_directory")
            .whereEqualTo("isActive", true)
            .snapshots()
            .map { it.toObjects(StaffDirectoryEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "staff_directory")
                throw error
            }
    }

    // --- Dil Se Wallet-Backed Paid Calls (₹100 deducted ONLY on connection) & Staff Ratings ---
    suspend fun initiateDilSeCall(callerAlias: String, feeInr: Long, paymentId: String): Result<String> {
        val uid = requireUid()
        if (feeInr < 1L || paymentId.isBlank()) {
            return Result.failure(IllegalStateException("Minimum ₹${feeInr.coerceAtLeast(100L)} wallet balance required before calling."))
        }
        val callId = UUID.randomUUID().toString()
        val docRef = db.collection("dil_se_calls").document(callId)
        return try {
            docRef.set(
                mapOf(
                    "callerUid" to uid,
                    "callerAlias" to SecurityUtils.sanitizeInput(callerAlias, 80),
                    "feeInr" to feeInr,
                    "paymentId" to paymentId,
                    "status" to "waiting",
                    "refunded" to false,
                    "agreedToWarning" to true,
                    "durationSeconds" to 0L,
                    "billedSlots" to 0L,
                    "listenerRevenueInr" to 0L,
                    "adminRevenueInr" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(callId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun submitStaffRating(
        callId: String,
        staffUsername: String,
        stars: Int,
        comment: String,
        durationSeconds: Long
    ): Result<Unit> {
        val uid = requireUid()
        val clampedStars = stars.coerceIn(1, 5)
        val ratingRef = db.collection("staff_ratings").document(UUID.randomUUID().toString())
        val callRef = db.collection("dil_se_calls").document(callId)
        return try {
            val payload = mapOf(
                "callId" to callId,
                "callerUid" to uid,
                "staffUsername" to staffUsername.ifBlank { "listener" },
                "stars" to clampedStars.toLong(),
                "comment" to SecurityUtils.sanitizeInput(comment, 300).ifBlank { null },
                "durationSeconds" to durationSeconds.coerceAtLeast(0L),
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            ratingRef.set(payload).await()
            if (callRef.get().await().exists()) {
                val updates = mutableMapOf<String, Any>(
                    "ratingStars" to clampedStars.toLong(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                val cleanComment = SecurityUtils.sanitizeInput(comment, 300)
                if (cleanComment.isNotBlank()) updates["ratingComment"] = cleanComment
                callRef.update(updates).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ratingRef.path)
            Result.failure(e)
        }
    }

    // --- Text & Email Customer Support Tickets ---
    fun observeMySupportTickets(uid: String): Flow<List<SupportTicket>> {
        return db.collection("support_tickets")
            .whereEqualTo("userUid", uid)
            .snapshots()
            .map { snap ->
                snap.toObjects(SupportTicket::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence<Throwable>(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "support_tickets")
                throw error
            }
    }

    suspend fun submitSupportTicket(
        userName: String,
        userEmail: String?,
        category: String,
        message: String,
        screenshotUri: String?
    ): Result<Unit> {
        val uid = requireUid()
        if (!SecurityUtils.isSafeMediaUri(screenshotUri, allowVideo = false)) {
            return Result.failure(SecurityException("Blocked dangerous or unsupported screenshot format."))
        }
        val docRef = db.collection("support_tickets").document(UUID.randomUUID().toString())
        return try {
            val payload = mapOf(
                "userUid" to uid,
                "userName" to SecurityUtils.sanitizeInput(userName, 100).ifBlank { "Member" },
                "userEmail" to userEmail?.let { SecurityUtils.sanitizeInput(it, 160) }?.ifBlank { null },
                "category" to SecurityUtils.sanitizeInput(category, 60).ifBlank { "Other" },
                "message" to SecurityUtils.sanitizeInput(message, 2000),
                "screenshotUri" to screenshotUri?.take(600),
                "status" to "open",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeCallSession(callId: String): Flow<DilSeCallSession?> {
        val docRef = db.collection("dil_se_calls").document(callId)
        return docRef.snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(DilSeCallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else null
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.GET, docRef.path)
                throw error
            }
    }

    fun observeWaitingCalls(): Flow<List<DilSeCallSession>> {
        return db.collection("dil_se_calls")
            .whereEqualTo("status", "waiting")
            .snapshots()
            .map { snap ->
                snap.toObjects(DilSeCallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "dil_se_calls")
                throw error
            }
    }

    fun observeActiveCallsForAdmin(): Flow<List<DilSeCallSession>> {
        return db.collection("dil_se_calls")
            .whereEqualTo("status", "active")
            .snapshots()
            .map { snap ->
                snap.toObjects(DilSeCallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "dil_se_calls")
                throw error
            }
    }

    fun observeAllCallsForAdmin(): Flow<List<DilSeCallSession>> {
        return db.collection("dil_se_calls")
            .snapshots()
            .map { snap ->
                snap.toObjects(DilSeCallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { (it.updatedAt ?: it.createdAt) ?: Timestamp(0, 0) }
                    .take(50)
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "dil_se_calls")
                throw error
            }
    }

    fun observeStaffAccount(staffUsername: String): Flow<StaffAccount?> {
        val docRef = db.collection("staff_accounts").document(staffUsername)
        return docRef.snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(StaffAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else null
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                emit(null)
            }
    }

    suspend fun sendWebRtcSignal(
        callId: String,
        senderRole: String,
        signalType: String,
        payload: String
    ): Result<Unit> {
        val uid = requireUid()
        val sigRef = db.collection("dil_se_calls").document(callId)
            .collection("signals").document(UUID.randomUUID().toString())
        return try {
            sigRef.set(
                mapOf(
                    "senderUid" to uid,
                    "senderRole" to if (senderRole == "caller") "caller" else "listener",
                    "signalType" to signalType,
                    "payload" to payload.take(12000),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, sigRef.path)
            Result.failure(e)
        }
    }

    fun observeWebRtcSignals(callId: String): Flow<List<WebRtcSignal>> {
        val path = "dil_se_calls/$callId/signals"
        return db.collection("dil_se_calls").document(callId).collection("signals")
            .snapshots()
            .map { snap ->
                snap.toObjects(WebRtcSignal::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun findActiveStaffByEmail(email: String): StaffDirectoryEntry? {
        val cleanEmail = SecurityUtils.normalizeEmail(SecurityUtils.sanitizeInput(email, 160))
        if (!SecurityUtils.isValidEmail(cleanEmail)) return null
        val deterministicId = SecurityUtils.staffDocIdFromEmail(cleanEmail)
        return try {
            val directSnap = db.collection("staff_directory").document(deterministicId).get().await()
            if (directSnap.exists()) {
                val entry = directSnap.toObject(StaffDirectoryEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                if (entry != null && entry.isActive && entry.staffEmail.equals(cleanEmail, ignoreCase = true)) {
                    return entry
                }
            }
            val querySnap = db.collection("staff_directory")
                .whereEqualTo("isActive", true)
                .whereEqualTo("staffEmail", cleanEmail)
                .get().await()
            querySnap.toObjects(StaffDirectoryEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .firstOrNull { it.isActive }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            null
        }
    }

    suspend fun authenticateStaffByGmailAndPin(staffEmail: String, pin: String): Result<StaffAccount> {
        val cleanEmail = SecurityUtils.normalizeEmail(SecurityUtils.sanitizeInput(staffEmail, 160))
        val cleanPin = pin.trim()
        if (!SecurityUtils.isValidEmail(cleanEmail)) {
            return Result.failure(IllegalArgumentException("Valid Staff Gmail ID is required."))
        }
        if (!SecurityUtils.isValidStaffPin(cleanPin)) {
            return Result.failure(IllegalArgumentException("Enter a valid numeric Staff PIN (6 to 16 digits)."))
        }
        val entry = findActiveStaffByEmail(cleanEmail)
            ?: return Result.failure(IllegalStateException("This Gmail ID is not approved as an active Staff Listener."))
        return authenticateStaffListener(entry.staffUsername, cleanPin)
    }

    suspend fun authenticateStaffListener(staffUsername: String, password: String): Result<StaffAccount> {
        val uid = requireUid()
        val cleanId = SecurityUtils.sanitizeInput(staffUsername, 60)
        val staffRef = db.collection("staff_accounts").document(cleanId)
        val dirRef = db.collection("staff_directory").document(cleanId)
        return try {
            val snap = staffRef.get().await()
            if (!snap.exists()) {
                return Result.failure(IllegalArgumentException("Staff account not found"))
            }
            val account = snap.toObject(StaffAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Invalid staff record"))
            if (!account.isActive) {
                return Result.failure(IllegalStateException("Staff account is suspended by Super Admin."))
            }
            if (!SecurityUtils.verifyPassword(password, account.passwordSalt, account.passwordHash)) {
                return Result.failure(IllegalArgumentException("Incorrect 6-digit Staff PIN"))
            }
            staffRef.update(
                mapOf(
                    "assignedUid" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            if (dirRef.get().await().exists()) {
                dirRef.update(
                    mapOf(
                        "assignedUid" to uid,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            db.collection("staff_uids").document(uid).set(
                mapOf(
                    "uid" to uid,
                    "staffUsername" to account.staffUsername,
                    "displayName" to account.displayName,
                    "isActive" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(account.copy(assignedUid = uid))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, staffRef.path)
            Result.failure(e)
        }
    }

    suspend fun logStaffAuditAction(
        staffUsername: String,
        staffDisplayName: String,
        actionType: String,
        targetId: String? = null,
        targetAuthorName: String? = null,
        contentPreview: String? = null,
        reason: String? = null
    ) {
        val uid = Firebase.auth.currentUser?.uid ?: return
        val logRef = db.collection("staff_audit_logs").document(UUID.randomUUID().toString())
        try {
            val payload = mapOf(
                "staffUsername" to SecurityUtils.sanitizeInput(staffUsername, 60).ifBlank { "staff" },
                "staffDisplayName" to SecurityUtils.sanitizeInput(staffDisplayName, 100).ifBlank { staffUsername },
                "actorUid" to uid,
                "actionType" to actionType,
                "targetId" to targetId?.take(128),
                "targetAuthorName" to targetAuthorName?.let { SecurityUtils.sanitizeInput(it, 100) }?.ifBlank { null },
                "contentPreview" to contentPreview?.let { SecurityUtils.sanitizeInput(it, 400) }?.ifBlank { null },
                "reason" to reason?.let { SecurityUtils.sanitizeInput(it, 300) }?.ifBlank { null },
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            logRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, logRef.path)
        }
    }

    suspend fun toggleStaffOnlineStatus(
        staffUsername: String,
        online: Boolean,
        staffDisplayName: String? = null
    ): Result<Unit> {
        val uid = requireUid()
        val staffRef = db.collection("staff_accounts").document(staffUsername)
        val dirRef = db.collection("staff_directory").document(staffUsername)
        return try {
            staffRef.update(
                mapOf(
                    "assignedUid" to uid,
                    "isOnline" to online,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            dirRef.update(
                mapOf(
                    "assignedUid" to uid,
                    "isOnline" to online,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            db.collection("staff_uids").document(uid).set(
                mapOf(
                    "uid" to uid,
                    "staffUsername" to staffUsername,
                    "displayName" to SecurityUtils.sanitizeInput(staffDisplayName ?: staffUsername, 100),
                    "isActive" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            logStaffAuditAction(
                staffUsername = staffUsername,
                staffDisplayName = staffDisplayName ?: staffUsername,
                actionType = if (online) "duty_online" else "duty_offline",
                contentPreview = if (online) "Toggled Duty ONLINE" else "Toggled Duty OFFLINE"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, staffRef.path)
            Result.failure(e)
        }
    }

    suspend fun acceptDilSeCallAsStaff(
        call: DilSeCallSession,
        staffUsername: String,
        staffDisplayName: String? = null
    ): Result<Unit> {
        val uid = requireUid()
        val callRef = db.collection("dil_se_calls").document(call.id)
        val roomId = call.zegoRoomId?.ifBlank { null } ?: com.dilsuno.app.core.ZegoCallManager.buildEmergencyRoomId(call.id)
        return try {
            // Atomic first-responder claim: ONLY the first online listener who taps Accept wins!
            db.runTransaction { tx ->
                val snap = tx.get(callRef)
                val currentStatus = snap.getString("status")
                if (currentStatus != "waiting") {
                    throw IllegalStateException("This call was already picked up by another online Listener.")
                }
                tx.update(
                    callRef,
                    mapOf(
                        "listenerStaffId" to staffUsername,
                        "listenerUid" to uid,
                        "listenerRole" to "staff",
                        "status" to "active",
                        "zegoRoomId" to roomId,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            logStaffAuditAction(
                staffUsername = staffUsername,
                staffDisplayName = staffDisplayName ?: staffUsername,
                actionType = "call_answered",
                targetId = call.id,
                targetAuthorName = "Caller",
                contentPreview = "Accepted Anonymous Audio Call (Fee ₹${call.feeInr})"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, callRef.path)
            Result.failure(e)
        }
    }

    suspend fun acceptDilSeCallAsAdmin(call: DilSeCallSession): Result<Unit> {
        val uid = requireUid()
        val callRef = db.collection("dil_se_calls").document(call.id)
        return try {
            callRef.update(
                mapOf(
                    "listenerStaffId" to "owner_admin",
                    "listenerUid" to uid,
                    "listenerRole" to "admin",
                    "status" to "active",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            logStaffAuditAction(
                staffUsername = "owner_admin",
                staffDisplayName = "Super Admin (Owner)",
                actionType = "call_answered",
                targetId = call.id,
                targetAuthorName = call.callerAlias,
                contentPreview = "Owner Direct Pickup (${call.callerAlias}, 100% Fee ₹${call.feeInr})"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, callRef.path)
            Result.failure(e)
        }
    }

    suspend fun endDilSeCallNormally(
        call: DilSeCallSession,
        staffUsername: String?,
        durationSec: Long,
        staffDisplayName: String? = null
    ): Result<Unit> {
        val callRef = db.collection("dil_se_calls").document(call.id)
        return try {
            callRef.update(
                mapOf(
                    "status" to "ended",
                    "durationSeconds" to durationSec,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            if (!staffUsername.isNullOrBlank() && call.status == "active" && call.billedSlots == 0L) {
                creditCompletedCallForListener(
                    call = call,
                    staffUsername = staffUsername,
                    durationSec = durationSec,
                    staffDisplayName = staffDisplayName
                )
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, callRef.path)
            Result.failure(e)
        }
    }

    /**
     * Records a connected ₹100 call slot and applies the automatic 50:50 revenue split:
     * ₹50 to Listener withdrawable earnings + ₹50 to Admin revenue (or 100% Owner if Owner Backup).
     * Pass creditStaffAccount = true when invoked by the Listener/Admin device (or single-device Zego flow),
     * and updateCallSession = true when recording against a dil_se_calls document.
     */
    suspend fun recordConnectedCallSlotSplit(
        callId: String?,
        listenerStaffId: String?,
        listenerDisplayName: String?,
        slotIndex: Long,
        chargeInr: Long = com.dilsuno.app.core.DilSunoBillingRules.CALL_CHARGE_INR,
        updateCallSession: Boolean = true,
        creditStaffAccount: Boolean = false
    ): Result<Pair<Long, Long>> {
        val isOwnerCall = listenerStaffId == "owner_admin"
        val (listenerShare, adminShare) = com.dilsuno.app.core.DilSunoBillingRules.computeCallSplit(
            chargeInr = chargeInr,
            isOwnerBackupCall = isOwnerCall
        )
        return try {
            if (updateCallSession && !callId.isNullOrBlank()) {
                runCatching {
                    val callRef = db.collection("dil_se_calls").document(callId)
                    db.runTransaction { tx ->
                        val snap = tx.get(callRef)
                        if (snap.exists()) {
                            val existingSlots = snap.getLong("billedSlots") ?: 0L
                            if (slotIndex > existingSlots) {
                                val deltaSlots = slotIndex - existingSlots
                                val prevListenerRev = snap.getLong("listenerRevenueInr") ?: 0L
                                val prevAdminRev = snap.getLong("adminRevenueInr") ?: 0L
                                tx.update(
                                    callRef,
                                    mapOf(
                                        "billedSlots" to slotIndex,
                                        "listenerRevenueInr" to (prevListenerRev + listenerShare * deltaSlots),
                                        "adminRevenueInr" to (prevAdminRev + adminShare * deltaSlots),
                                        "updatedAt" to FieldValue.serverTimestamp()
                                    )
                                )
                            }
                        }
                    }.await()
                }
            }
            if (creditStaffAccount) {
                if (isOwnerCall) {
                    runCatching {
                        val cfgRef = db.collection("app_config").document("settings")
                        if (cfgRef.get().await().exists()) {
                            val updates = mutableMapOf<String, Any>(
                                "ownerCallEarningsInr" to FieldValue.increment(adminShare),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                            if (slotIndex == 1L) {
                                updates["ownerCallsCompleted"] = FieldValue.increment(1L)
                            }
                            cfgRef.update(updates).await()
                        }
                    }
                } else if (!listenerStaffId.isNullOrBlank()) {
                    runCatching {
                        val staffUpdates = mutableMapOf<String, Any>(
                            "earningsInr" to FieldValue.increment(listenerShare),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                        if (slotIndex == 1L) {
                            staffUpdates["totalCalls"] = FieldValue.increment(1L)
                        }
                        db.collection("staff_accounts").document(listenerStaffId).update(staffUpdates).await()
                    }
                    if (slotIndex == 1L) {
                        runCatching {
                            db.collection("staff_directory").document(listenerStaffId).update(
                                mapOf(
                                    "totalCalls" to FieldValue.increment(1L),
                                    "updatedAt" to FieldValue.serverTimestamp()
                                )
                            ).await()
                        }
                    }
                    runCatching {
                        val cfgRef = db.collection("app_config").document("settings")
                        if (cfgRef.get().await().exists()) {
                            cfgRef.update(
                                mapOf(
                                    "ownerCallEarningsInr" to FieldValue.increment(adminShare),
                                    "updatedAt" to FieldValue.serverTimestamp()
                                )
                            ).await()
                        }
                    }
                }
            }
            Result.success(listenerShare to adminShare)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun requestStaffWithdrawal(
        staffUsername: String,
        staffDisplayName: String,
        payoutAccount: String,
        amountInr: Long
    ): Result<Long> {
        val uid = requireUid()
        if (amountInr < com.dilsuno.app.core.DilSunoBillingRules.MIN_LISTENER_WITHDRAWAL_INR) {
            return Result.failure(IllegalArgumentException(com.dilsuno.app.core.DilSunoBillingRules.MIN_WITHDRAWAL_NOTE))
        }
        val cleanAccount = SecurityUtils.sanitizeInput(payoutAccount, 100)
        if (cleanAccount.length < 4) {
            return Result.failure(IllegalArgumentException("Enter a valid Bank / Payout Account Reference."))
        }
        val staffRef = db.collection("staff_accounts").document(staffUsername)
        val payoutRef = db.collection("payout_requests").document(UUID.randomUUID().toString())
        return try {
            val remainingBalance = db.runTransaction { tx ->
                val snap = tx.get(staffRef)
                val currentEarnings = snap.getLong("earningsInr") ?: 0L
                if (currentEarnings < com.dilsuno.app.core.DilSunoBillingRules.MIN_LISTENER_WITHDRAWAL_INR) {
                    throw IllegalStateException(com.dilsuno.app.core.DilSunoBillingRules.MIN_WITHDRAWAL_NOTE)
                }
                if (amountInr > currentEarnings) {
                    throw IllegalArgumentException("Requested amount (₹$amountInr) exceeds your available balance (₹$currentEarnings).")
                }
                val nextEarnings = currentEarnings - amountInr
                if (snap.exists()) {
                    tx.update(
                        staffRef,
                        mapOf(
                            "earningsInr" to nextEarnings,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                tx.set(
                    payoutRef,
                    mapOf(
                        "creatorUid" to uid,
                        "creatorName" to SecurityUtils.sanitizeInput(staffDisplayName, 100).ifBlank { staffUsername },
                        "requesterType" to "staff",
                        "payoutAccount" to cleanAccount,
                        "amountInr" to amountInr,
                        "status" to "pending",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                nextEarnings
            }.await()
            Result.success(remainingBalance)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, payoutRef.path)
            Result.failure(e)
        }
    }

    fun observeAllCallsRevenueForAdmin(): Flow<Long> {
        return db.collection("dil_se_calls")
            .snapshots()
            .map { snap ->
                snap.toObjects(DilSeCallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sumOf { it.adminRevenueInr.coerceAtLeast(0L) }
            }
            .catch { error ->
                val fsErr = generateSequence<Throwable>(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                emit(0L)
            }
    }

    suspend fun creditCompletedCallForListener(
        call: DilSeCallSession,
        staffUsername: String,
        durationSec: Long,
        staffDisplayName: String? = null
    ) {
        if (call.billedSlots > 0L) return
        val isOwnerCall = staffUsername == "owner_admin"
        val (listenerShare, adminShare) = com.dilsuno.app.core.DilSunoBillingRules.computeCallSplit(
            chargeInr = call.feeInr,
            isOwnerBackupCall = isOwnerCall
        )
        if (isOwnerCall) {
            val cfgRef = db.collection("app_config").document("settings")
            if (cfgRef.get().await().exists()) {
                cfgRef.update(
                    mapOf(
                        "ownerCallEarningsInr" to FieldValue.increment(adminShare),
                        "ownerCallsCompleted" to FieldValue.increment(1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            logStaffAuditAction(
                staffUsername = "owner_admin",
                staffDisplayName = "Super Admin (Owner)",
                actionType = "call_ended",
                targetId = call.id,
                targetAuthorName = call.callerAlias,
                contentPreview = "Owner call completed (${durationSec}s) • 100% Owner Revenue: ₹$adminShare"
            )
        } else {
            db.collection("staff_accounts").document(staffUsername).update(
                mapOf(
                    "earningsInr" to FieldValue.increment(listenerShare),
                    "totalCalls" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            db.collection("staff_directory").document(staffUsername).update(
                mapOf(
                    "totalCalls" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            logStaffAuditAction(
                staffUsername = staffUsername,
                staffDisplayName = staffDisplayName ?: staffUsername,
                actionType = "call_ended",
                targetId = call.id,
                targetAuthorName = call.callerAlias,
                contentPreview = "Completed call (${durationSec}s) • Staff earned ₹$listenerShare (50% split)"
            )
        }
    }

    suspend fun disconnectAndBlockAbusiveCaller(
        call: DilSeCallSession,
        staffUsername: String?,
        staffDisplayName: String? = null
    ): Result<Unit> {
        val callRef = db.collection("dil_se_calls").document(call.id)
        return try {
            callRef.update(
                mapOf(
                    "status" to "blocked_abuse",
                    "refunded" to false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            // Log abuse incident in AI/Safety logs for Super Admin permanent ban enforcement
            val logRef = db.collection("ai_safety_logs").document(UUID.randomUUID().toString())
            logRef.set(
                mapOf(
                    "userUid" to call.callerUid,
                    "userName" to call.callerAlias,
                    "contentType" to "dil_se_call",
                    "snippet" to "Abusive behavior reported by ${staffDisplayName ?: staffUsername ?: "Admin"}",
                    "violationCategory" to "illegal_hate_speech",
                    "aiReason" to "Call disconnected & fee forfeited (No Refund) due to verbal abuse/harassment.",
                    "actionTaken" to "auto_deleted_banned",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            val actorId = staffUsername ?: "owner_admin"
            logStaffAuditAction(
                staffUsername = actorId,
                staffDisplayName = staffDisplayName ?: if (actorId == "owner_admin") "Super Admin (Owner)" else actorId,
                actionType = "caller_blocked_abuse",
                targetId = call.callerUid,
                targetAuthorName = call.callerAlias,
                contentPreview = "Abuse Disconnect & Block on ${call.callerAlias} (Fee ₹${call.feeInr} forfeited)",
                reason = "Zero-tolerance verbal abuse / harassment"
            )
            // If Super Admin executed block, also ban user account immediately
            if (actorId == "owner_admin") {
                adminSetUserBanned(call.callerUid, true)
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, callRef.path)
            Result.failure(e)
        }
    }

    // --- Super Admin Operations ---
    fun observeAllStaffForAdmin(): Flow<List<StaffAccount>> {
        return db.collection("staff_accounts")
            .snapshots()
            .map { it.toObjects(StaffAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "staff_accounts")
                throw error
            }
    }

    fun observeAllReportsForAdmin(): Flow<List<ModerationReport>> {
        return db.collection("moderation_reports")
            .snapshots()
            .map { snap ->
                snap.toObjects(ModerationReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "moderation_reports")
                throw error
            }
    }

    fun observeAllAiLogsForAdmin(): Flow<List<AiSafetyLog>> {
        return db.collection("ai_safety_logs")
            .snapshots()
            .map { snap ->
                snap.toObjects(AiSafetyLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "ai_safety_logs")
                throw error
            }
    }

    fun observeAllPayoutsForAdmin(): Flow<List<PayoutRequest>> {
        return db.collection("payout_requests")
            .snapshots()
            .map { snap ->
                snap.toObjects(PayoutRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "payout_requests")
                throw error
            }
    }

    suspend fun adminCreateStaffByGmailAndPin(
        staffEmail: String,
        displayName: String,
        pin6Digits: String
    ): Result<String> {
        val cleanEmail = SecurityUtils.normalizeEmail(SecurityUtils.sanitizeInput(staffEmail, 150))
        if (!SecurityUtils.isValidEmail(cleanEmail)) {
            return Result.failure(IllegalArgumentException("Enter a valid Staff Gmail ID."))
        }
        val cleanPin = pin6Digits.trim()
        if (!SecurityUtils.isValidStaffPin(cleanPin)) {
            return Result.failure(IllegalArgumentException("Staff PIN must be 6 to 16 numeric digits (8–12 digits recommended)."))
        }
        val cleanId = SecurityUtils.staffDocIdFromEmail(cleanEmail)
        val fallbackName = cleanEmail.substringBefore("@")
            .replace('.', ' ')
            .replace('_', ' ')
            .trim()
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
            .ifBlank { "Staff Listener" }
        val cleanName = SecurityUtils.sanitizeInput(displayName, 100).ifBlank { fallbackName }

        val salt = SecurityUtils.generateSalt()
        val hash = SecurityUtils.hashPassword(cleanPin, salt)
        val staffRef = db.collection("staff_accounts").document(cleanId)
        val dirRef = db.collection("staff_directory").document(cleanId)
        return try {
            staffRef.set(
                mapOf(
                    "staffUsername" to cleanId,
                    "staffEmail" to cleanEmail,
                    "displayName" to cleanName,
                    "passwordHash" to hash,
                    "passwordSalt" to salt,
                    "assignedUid" to "",
                    "isOnline" to false,
                    "isActive" to true,
                    "earningsInr" to 0L,
                    "totalCalls" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            dirRef.set(
                mapOf(
                    "staffUsername" to cleanId,
                    "staffEmail" to cleanEmail,
                    "displayName" to cleanName,
                    "assignedUid" to "",
                    "isOnline" to false,
                    "isActive" to true,
                    "totalCalls" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(cleanId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, staffRef.path)
            Result.failure(e)
        }
    }

    suspend fun adminCreateStaff(staffUsername: String, displayName: String, password: String): Result<Unit> {
        val cleanId = SecurityUtils.sanitizeInput(staffUsername, 60).replace(" ", "_")
        val salt = SecurityUtils.generateSalt()
        val hash = SecurityUtils.hashPassword(password, salt)
        val staffRef = db.collection("staff_accounts").document(cleanId)
        val dirRef = db.collection("staff_directory").document(cleanId)
        return try {
            staffRef.set(
                mapOf(
                    "staffUsername" to cleanId,
                    "staffEmail" to "",
                    "displayName" to SecurityUtils.sanitizeInput(displayName, 100),
                    "passwordHash" to hash,
                    "passwordSalt" to salt,
                    "assignedUid" to "",
                    "isOnline" to false,
                    "isActive" to true,
                    "earningsInr" to 0L,
                    "totalCalls" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            dirRef.set(
                mapOf(
                    "staffUsername" to cleanId,
                    "staffEmail" to "",
                    "displayName" to SecurityUtils.sanitizeInput(displayName, 100),
                    "assignedUid" to "",
                    "isOnline" to false,
                    "isActive" to true,
                    "totalCalls" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, staffRef.path)
            Result.failure(e)
        }
    }

    suspend fun adminSetStaffActive(staffUsername: String, active: Boolean): Result<Unit> {
        return try {
            val staffRef = db.collection("staff_accounts").document(staffUsername)
            val snap = staffRef.get().await()
            val assignedUid = snap.getString("assignedUid").orEmpty()
            staffRef.update(
                mapOf(
                    "isActive" to active,
                    "isOnline" to if (active) (snap.getBoolean("isOnline") ?: false) else false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            db.collection("staff_directory").document(staffUsername).update(
                mapOf(
                    "isActive" to active,
                    "isOnline" to if (active) (snap.getBoolean("isOnline") ?: false) else false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            if (assignedUid.isNotBlank()) {
                val uidClaimRef = db.collection("staff_uids").document(assignedUid)
                if (uidClaimRef.get().await().exists()) {
                    uidClaimRef.update(
                        mapOf("isActive" to active, "updatedAt" to FieldValue.serverTimestamp())
                    ).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "staff_accounts/$staffUsername")
            Result.failure(e)
        }
    }

    suspend fun adminRemoveStaff(staffUsername: String): Result<Unit> {
        return try {
            val staffRef = db.collection("staff_accounts").document(staffUsername)
            val snap = runCatching { staffRef.get().await() }.getOrNull()
            val assignedUid = snap?.getString("assignedUid").orEmpty()
            if (assignedUid.isNotBlank()) {
                runCatching { db.collection("staff_uids").document(assignedUid).delete().await() }
            }
            staffRef.delete().await()
            db.collection("staff_directory").document(staffUsername).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "staff_accounts/$staffUsername")
            Result.failure(e)
        }
    }

    fun observeStaffAuditLogsForAdmin(): Flow<List<StaffAuditLog>> {
        return db.collection("staff_audit_logs")
            .snapshots()
            .map { snap ->
                snap.toObjects(StaffAuditLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence<Throwable>(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "staff_audit_logs")
                throw error
            }
    }

    suspend fun moderatorDeleteContentWithAudit(
        targetType: String,
        targetId: String,
        parentPostId: String? = null,
        targetAuthorUid: String? = null,
        targetAuthorName: String? = null,
        contentPreview: String = "",
        moderatorStaffUsername: String,
        moderatorDisplayName: String,
        reason: String = "Violates community guidelines"
    ): Result<Unit> {
        val actorUid = requireUid()
        return try {
            when (targetType) {
                "story" -> {
                    db.collection("stories").document(targetId)
                        .update(mapOf("moderationStatus" to "removed")).await()
                }
                "live" -> {
                    db.collection("live_streams").document(targetId)
                        .update(
                            mapOf(
                                "moderationStatus" to "removed",
                                "status" to "ended",
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                }
                "comment" -> {
                    if (!parentPostId.isNullOrBlank()) {
                        db.collection("posts").document(parentPostId)
                            .collection("comments").document(targetId)
                            .update(mapOf("moderationStatus" to "removed")).await()
                    }
                }
                else -> {
                    db.collection("posts").document(targetId)
                        .update(
                            mapOf(
                                "moderationStatus" to "removed",
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                }
            }

            if (!targetAuthorUid.isNullOrBlank()) {
                db.collection("notifications").document(UUID.randomUUID().toString()).set(
                    mapOf(
                        "recipientUid" to targetAuthorUid,
                        "actorUid" to actorUid,
                        "actorName" to "Dil Suno Moderation",
                        "type" to "moderation",
                        "message" to "Warning: Your $targetType was removed ($reason).",
                        "targetId" to targetId,
                        "isRead" to false,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            val auditAction = when (targetType) {
                "reel" -> "reel_deleted"
                "story" -> "story_deleted"
                "comment" -> "comment_deleted"
                "live" -> "live_deleted"
                else -> "post_deleted"
            }
            logStaffAuditAction(
                staffUsername = moderatorStaffUsername,
                staffDisplayName = moderatorDisplayName,
                actionType = auditAction,
                targetId = targetId,
                targetAuthorName = targetAuthorName,
                contentPreview = contentPreview.ifBlank { "[$targetType]" },
                reason = reason
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "$targetType/$targetId")
            Result.failure(e)
        }
    }

    suspend fun adminRemoveContent(targetType: String, targetId: String, reportId: String? = null): Result<Unit> {
        return try {
            val collection = when (targetType) {
                "story" -> "stories"
                "live" -> "live_streams"
                else -> "posts"
            }
            val updates = mutableMapOf<String, Any>("moderationStatus" to "removed")
            if (collection != "stories") {
                updates["updatedAt"] = FieldValue.serverTimestamp()
            }
            db.collection(collection).document(targetId).update(updates).await()
            if (!reportId.isNullOrBlank()) {
                db.collection("moderation_reports").document(reportId).update(
                    mapOf("status" to "resolved", "updatedAt" to FieldValue.serverTimestamp())
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "$targetType/$targetId")
            Result.failure(e)
        }
    }

    suspend fun adminSetUserBanned(targetUid: String, banned: Boolean): Result<Unit> {
        return try {
            val pubRef = db.collection("public_profiles").document(targetUid)
            if (pubRef.get().await().exists()) {
                pubRef.update(mapOf("isBanned" to banned, "updatedAt" to FieldValue.serverTimestamp())).await()
            }
            val privRef = db.collection("users").document(targetUid).collection("private").document("account")
            if (privRef.get().await().exists()) {
                privRef.update(mapOf("isBanned" to banned, "updatedAt" to FieldValue.serverTimestamp())).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "public_profiles/$targetUid")
            Result.failure(e)
        }
    }

    suspend fun adminToggleCreatorMonetization(creatorUid: String, approve: Boolean): Result<Unit> {
        return try {
            val pubRef = db.collection("public_profiles").document(creatorUid)
            if (pubRef.get().await().exists()) {
                pubRef.update(
                    mapOf("monetizationApproved" to approve, "updatedAt" to FieldValue.serverTimestamp())
                ).await()
            }
            val privRef = db.collection("users").document(creatorUid).collection("private").document("account")
            if (privRef.get().await().exists()) {
                privRef.update(
                    mapOf(
                        "monetizationStatus" to if (approve) "approved" else "rejected",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            val actorUid = Firebase.auth.currentUser?.uid ?: "admin"
            db.collection("notifications").document(UUID.randomUUID().toString()).set(
                mapOf(
                    "recipientUid" to creatorUid,
                    "actorUid" to actorUid,
                    "actorName" to "Dil Suno Admin",
                    "type" to "creator_approved",
                    "message" to if (approve)
                        "Your Creator Monetization is now ON! You can now receive viewer tips & view bonuses."
                    else
                        "Your Creator Monetization was turned OFF by Super Admin.",
                    "isRead" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "public_profiles/$creatorUid")
            Result.failure(e)
        }
    }

    suspend fun adminResetStaffPin(staffUsername: String, newPin: String): Result<Unit> {
        val cleanPin = newPin.trim()
        if (!SecurityUtils.isValidStaffPin(cleanPin)) {
            return Result.failure(IllegalArgumentException("Staff PIN must be 6 to 16 numeric digits (8–12 digits recommended)."))
        }
        return adminResetStaffPassword(staffUsername, cleanPin)
    }

    suspend fun adminResetStaffPassword(staffUsername: String, newPassword: String): Result<Unit> {
        if (newPassword.length < 6) {
            return Result.failure(IllegalArgumentException("Staff PIN / Password must be 6 characters."))
        }
        val salt = SecurityUtils.generateSalt()
        val hash = SecurityUtils.hashPassword(newPassword, salt)
        return try {
            db.collection("staff_accounts").document(staffUsername).update(
                mapOf(
                    "passwordHash" to hash,
                    "passwordSalt" to salt,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "staff_accounts/$staffUsername")
            Result.failure(e)
        }
    }

    fun observeAllStaffRatingsForAdmin(): Flow<List<StaffRatingItem>> {
        return db.collection("staff_ratings")
            .snapshots()
            .map { snap ->
                snap.toObjects(StaffRatingItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence<Throwable>(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "staff_ratings")
                throw error
            }
    }

    fun observeAllPlayBillingPurchasesForAdmin(): Flow<List<PlayBillingPurchaseRecord>> {
        return db.collection("play_billing_purchases")
            .snapshots()
            .map { snap ->
                snap.toObjects(PlayBillingPurchaseRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence<Throwable>(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "play_billing_purchases")
                throw error
            }
    }

    fun observeAllSupportTicketsForAdmin(): Flow<List<SupportTicket>> {
        return db.collection("support_tickets")
            .snapshots()
            .map { snap ->
                snap.toObjects(SupportTicket::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence<Throwable>(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "support_tickets")
                throw error
            }
    }

    suspend fun adminReplySupportTicket(
        ticketId: String,
        userUid: String,
        reply: String,
        markResolved: Boolean
    ): Result<Unit> {
        return try {
            val cleanReply = SecurityUtils.sanitizeInput(reply, 2000)
            val newStatus = if (markResolved) "resolved" else "replied"
            db.collection("support_tickets").document(ticketId).update(
                mapOf(
                    "adminReply" to cleanReply,
                    "status" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            val actorUid = Firebase.auth.currentUser?.uid ?: "admin"
            db.collection("notifications").document(UUID.randomUUID().toString()).set(
                mapOf(
                    "recipientUid" to userUid,
                    "actorUid" to actorUid,
                    "actorName" to "Dil Suno Support",
                    "type" to "support_reply",
                    "message" to "Support reply ($newStatus): ${cleanReply.take(180)}",
                    "targetId" to ticketId,
                    "isRead" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "support_tickets/$ticketId")
            Result.failure(e)
        }
    }

    // =========================================================================
    // 2-STEP LISTENER APPLICATIONS (User -> Staff Verification -> Super Admin)
    // =========================================================================

    suspend fun submitListenerApplication(
        fullName: String,
        email: String,
        phone: String?,
        city: String?,
        motivation: String
    ): Result<Unit> {
        val uid = requireUid()
        val cleanEmail = SecurityUtils.normalizeEmail(SecurityUtils.sanitizeInput(email, 160))
        if (!SecurityUtils.isValidEmail(cleanEmail)) {
            return Result.failure(IllegalArgumentException("Please enter a valid Gmail ID for Listener onboarding."))
        }
        val cleanMotivation = SecurityUtils.sanitizeInput(motivation, 600)
        if (cleanMotivation.length < 10) {
            return Result.failure(IllegalArgumentException("Please write a short introduction (at least 10 characters)."))
        }
        val docRef = db.collection("listener_applications").document(uid)
        return try {
            val payload = mapOf(
                "applicantUid" to uid,
                "fullName" to SecurityUtils.sanitizeInput(fullName, 100).ifBlank { "Dil Suno Applicant" },
                "email" to cleanEmail,
                "phone" to phone?.let { SecurityUtils.sanitizeInput(it, 24) }?.ifBlank { null },
                "city" to city?.let { SecurityUtils.sanitizeInput(it, 80) }?.ifBlank { null },
                "motivation" to cleanMotivation,
                "status" to "pending",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeMyListenerApplication(uid: String): Flow<ListenerApplication?> {
        val docRef = db.collection("listener_applications").document(uid)
        return docRef.snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(ListenerApplication::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else null
            }
            .catch { error ->
                val fsErr = generateSequence<Throwable>(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                emit(null)
            }
    }

    fun observeListenerApplications(): Flow<List<ListenerApplication>> {
        return db.collection("listener_applications")
            .snapshots()
            .map { snap ->
                snap.toObjects(ListenerApplication::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val fsErr = generateSequence<Throwable>(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, "listener_applications")
                throw error
            }
    }

    suspend fun staffVerifyListenerApplication(
        applicationId: String,
        staffUsername: String,
        staffDisplayName: String
    ): Result<Unit> {
        val docRef = db.collection("listener_applications").document(applicationId)
        return try {
            docRef.update(
                mapOf(
                    "status" to "staff_verified",
                    "verifiedByStaffId" to SecurityUtils.sanitizeInput(staffUsername, 60),
                    "verifiedByStaffName" to SecurityUtils.sanitizeInput(staffDisplayName, 100),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun adminFinalApproveListenerApplication(
        app: ListenerApplication,
        pin6Digits: String
    ): Result<String> {
        val createdRes = adminCreateStaffByGmailAndPin(
            staffEmail = app.email,
            displayName = app.fullName,
            pin6Digits = pin6Digits
        )
        return createdRes.fold(
            onSuccess = { staffUsername ->
                runCatching {
                    db.collection("listener_applications").document(app.id).update(
                        mapOf(
                            "status" to "approved",
                            "assignedStaffUsername" to staffUsername,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                    val actorUid = Firebase.auth.currentUser?.uid ?: "owner_admin"
                    db.collection("notifications").document(UUID.randomUUID().toString()).set(
                        mapOf(
                            "recipientUid" to app.applicantUid,
                            "actorUid" to actorUid,
                            "actorName" to "Dil Suno Team",
                            "type" to "creator_approved",
                            "message" to "Congratulations! Your Listener application is Final Approved. Staff ID: $staffUsername",
                            "isRead" to false,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
                Result.success(staffUsername)
            },
            onFailure = { Result.failure(it) }
        )
    }

    suspend fun rejectListenerApplication(applicationId: String): Result<Unit> {
        val docRef = db.collection("listener_applications").document(applicationId)
        return try {
            docRef.update(
                mapOf(
                    "status" to "rejected",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun adminUpdatePayoutStatus(payoutId: String, status: String): Result<Unit> {
        return try {
            db.collection("payout_requests").document(payoutId).update(
                mapOf("status" to status, "updatedAt" to FieldValue.serverTimestamp())
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "payout_requests/$payoutId")
            Result.failure(e)
        }
    }

    suspend fun adminToggleCallPickupOnline(online: Boolean): Result<Unit> {
        val docRef = db.collection("app_config").document("settings")
        return try {
            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(
                    mapOf(
                        "adminCallPickupOnline" to online,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.set(
                    mapOf(
                        "dilSeCallRateInr" to 100L,
                        "viewBonusPer1000Inr" to 25L,
                        "globalMonetizationEnabled" to true,
                        "adminCallPickupOnline" to online,
                        "ownerCallEarningsInr" to 0L,
                        "ownerCallsCompleted" to 0L,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun adminToggleReviewerDemoEnabled(enabled: Boolean): Result<Unit> {
        val docRef = db.collection("app_config").document("settings")
        return try {
            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(
                    mapOf(
                        "reviewerDemoEnabled" to enabled,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.set(
                    mapOf(
                        "dilSeCallRateInr" to 100L,
                        "viewBonusPer1000Inr" to 25L,
                        "globalMonetizationEnabled" to true,
                        "adminCallPickupOnline" to false,
                        "reviewerDemoEnabled" to enabled,
                        "ownerCallEarningsInr" to 0L,
                        "ownerCallsCompleted" to 0L,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun adminSaveBusinessConfig(
        callRateInr: Long,
        viewBonusPer1000Inr: Long,
        globalMonetizationEnabled: Boolean,
        supportEmail: String? = null,
        announcementBannerEn: String? = null,
        announcementBannerHi: String? = null,
        announcementActive: Boolean = false,
        adminCallPickupOnline: Boolean? = null,
        agoraAppId: String? = null,
        latestAppVersionName: String? = null,
        latestAppVersionCode: Long? = null,
        appUpdateUrl: String? = null,
        forceUpdate: Boolean? = null,
        reviewerDemoEnabled: Boolean? = null,
        customMusicTracksJson: String? = null
    ): Result<Unit> {
        val docRef = db.collection("app_config").document("settings")
        return try {
            val existing = docRef.get().await()
            val payload = mutableMapOf<String, Any>(
                "dilSeCallRateInr" to callRateInr.coerceAtLeast(1L),
                "viewBonusPer1000Inr" to viewBonusPer1000Inr.coerceAtLeast(0L),
                "globalMonetizationEnabled" to globalMonetizationEnabled,
                "announcementActive" to announcementActive,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (adminCallPickupOnline != null) payload["adminCallPickupOnline"] = adminCallPickupOnline
            if (!agoraAppId.isNullOrBlank()) payload["agoraAppId"] = SecurityUtils.sanitizeInput(agoraAppId, 120)
            if (!supportEmail.isNullOrBlank()) payload["supportEmail"] = SecurityUtils.sanitizeInput(supportEmail, 160)
            if (!announcementBannerEn.isNullOrBlank()) payload["announcementBannerEn"] = SecurityUtils.sanitizeInput(announcementBannerEn, 300)
            if (!announcementBannerHi.isNullOrBlank()) payload["announcementBannerHi"] = SecurityUtils.sanitizeInput(announcementBannerHi, 300)
            if (!latestAppVersionName.isNullOrBlank()) payload["latestAppVersionName"] = SecurityUtils.sanitizeInput(latestAppVersionName, 32)
            if (latestAppVersionCode != null && latestAppVersionCode >= 1L) payload["latestAppVersionCode"] = latestAppVersionCode
            if (!appUpdateUrl.isNullOrBlank()) payload["appUpdateUrl"] = SecurityUtils.sanitizeInput(appUpdateUrl, 300)
            if (forceUpdate != null) payload["forceUpdate"] = forceUpdate
            if (reviewerDemoEnabled != null) payload["reviewerDemoEnabled"] = reviewerDemoEnabled
            if (customMusicTracksJson != null) payload["customMusicTracksJson"] = customMusicTracksJson.take(8000)

            if (existing.exists()) {
                docRef.update(payload).await()
            } else {
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    // =========================================================================
    // SINGLE-DEVICE SESSION LOCK, LISTENER RULES & 3-VIDEO PROMO WORKFLOW
    // =========================================================================

    suspend fun updateStaffSessionToken(staffUsername: String, sessionToken: String): Result<Unit> {
        val ref = db.collection("staff_accounts").document(staffUsername)
        return try {
            if (ref.get().await().exists()) {
                ref.update(
                    mapOf(
                        "activeSessionToken" to sessionToken,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
            Result.failure(e)
        }
    }

    suspend fun markStaffRulesAcceptance(
        staffUsername: String,
        rulesBannerAccepted: Boolean? = null,
        goldenRulesAccepted: Boolean? = null,
        promoVideosCompletedCount: Long? = null,
        promoVideosSharedCount: Long? = null
    ): Result<Unit> {
        val ref = db.collection("staff_accounts").document(staffUsername)
        return try {
            if (ref.get().await().exists()) {
                val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
                if (rulesBannerAccepted != null) updates["rulesBannerAccepted"] = rulesBannerAccepted
                if (goldenRulesAccepted != null) updates["goldenRulesAccepted"] = goldenRulesAccepted
                if (promoVideosCompletedCount != null) updates["promoVideosCompletedCount"] = promoVideosCompletedCount
                if (promoVideosSharedCount != null) updates["promoVideosSharedCount"] = promoVideosSharedCount
                ref.update(updates).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
            Result.failure(e)
        }
    }

    suspend fun saveListenerPromoVideo(
        videoId: String,
        staffUsername: String,
        staffDisplayName: String,
        title: String,
        caption: String,
        videoUri: String
    ): Result<String> {
        val uid = Firebase.auth.currentUser?.uid ?: "local_$staffUsername"
        val docRef = db.collection("listener_promo_videos").document(videoId)
        return try {
            docRef.set(
                mapOf(
                    "staffUsername" to staffUsername,
                    "staffDisplayName" to SecurityUtils.sanitizeInput(staffDisplayName, 100),
                    "uploaderUid" to uid,
                    "title" to SecurityUtils.sanitizeInput(title, 120).ifBlank { "Dil Suno Promo Video" },
                    "caption" to SecurityUtils.sanitizeInput(caption, 400),
                    "videoUri" to videoUri.take(600),
                    "sharedPlatforms" to emptyList<String>(),
                    "isShared" to false,
                    "adminReviewStatus" to "pending_review",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun markListenerPromoVideoShared(
        videoId: String,
        platformLabel: String
    ): Result<Unit> {
        val docRef = db.collection("listener_promo_videos").document(videoId)
        return try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                docRef.update(
                    mapOf(
                        "sharedPlatforms" to FieldValue.arrayUnion(platformLabel),
                        "isShared" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeMyPromoVideos(staffUsername: String): Flow<List<ListenerPromoVideo>> = callbackFlow {
        val uid = Firebase.auth.currentUser?.uid
        if (uid == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val listener = db.collection("listener_promo_videos")
            .whereEqualTo("uploaderUid", uid)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snap?.documents
                    ?.mapNotNull { it.toObject(ListenerPromoVideo::class.java) }
                    ?.filter { it.staffUsername == staffUsername }
                    ?.sortedByDescending { it.createdAt?.seconds ?: 0L }
                    ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun observeAllPromoVideosForAdmin(): Flow<List<ListenerPromoVideo>> = callbackFlow {
        val listener = db.collection("listener_promo_videos")
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snap?.documents
                    ?.mapNotNull { it.toObject(ListenerPromoVideo::class.java) }
                    ?.sortedByDescending { it.createdAt?.seconds ?: 0L }
                    ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun adminUploadPromoAsset(
        title: String,
        caption: String,
        mediaType: String,
        mediaUri: String
    ): Result<Unit> {
        val docRef = db.collection("admin_promo_assets").document()
        return try {
            docRef.set(
                mapOf(
                    "title" to SecurityUtils.sanitizeInput(title, 120).ifBlank { "Official Dil Suno Promo" },
                    "caption" to SecurityUtils.sanitizeInput(caption, 400),
                    "mediaType" to if (mediaType == "poster") "poster" else "video",
                    "mediaUri" to mediaUri.take(600),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeAdminPromoAssets(): Flow<List<AdminPromoAsset>> = callbackFlow {
        val listener = db.collection("admin_promo_assets")
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snap?.documents
                    ?.mapNotNull { it.toObject(AdminPromoAsset::class.java) }
                    ?.sortedByDescending { it.createdAt?.seconds ?: 0L }
                    ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    // =========================================================================
    // EMERGENCY / SUICIDE ALERT + LEGAL AUTO-RECORDING + SUPER ADMIN LIVE JOIN
    // =========================================================================

    suspend fun triggerEmergencySuicideAlert(
        call: DilSeCallSession,
        staffUsername: String,
        staffDisplayName: String,
        recordingPath: String?
    ): Result<String> {
        val callRef = db.collection("dil_se_calls").document(call.id)
        val roomId = call.zegoRoomId?.ifBlank { null } ?: com.dilsuno.app.core.ZegoCallManager.buildEmergencyRoomId(call.id)
        val nowMs = System.currentTimeMillis()
        return try {
            val callUpdates = mutableMapOf<String, Any>(
                "emergencyAlertActive" to true,
                "emergencyTriggeredAtMillis" to nowMs,
                "emergencyHelplineShown" to true,
                "zegoRoomId" to roomId,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!recordingPath.isNullOrBlank()) {
                callUpdates["emergencyRecordingUri"] = recordingPath.take(600)
            }
            callRef.update(callUpdates).await()

            val logRef = db.collection("emergency_legal_logs").document()
            val logPayload = mutableMapOf<String, Any>(
                "callId" to call.id,
                "callerUid" to call.callerUid,
                "listenerStaffId" to staffUsername,
                "listenerDisplayName" to SecurityUtils.sanitizeInput(staffDisplayName, 100),
                "helplineDisplayed" to DilSePolicyText.TELE_MANAS_HELPLINE,
                "adminJoined" to false,
                "zegoRoomId" to roomId,
                "notes" to "Free Override active. Emergency helpline & live safety alert active.",
                "createdAt" to FieldValue.serverTimestamp()
            )
            if (!recordingPath.isNullOrBlank()) {
                logPayload["recordingUri"] = recordingPath.take(600)
            }
            logRef.set(logPayload).await()
            Result.success(roomId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, callRef.path)
            Result.failure(e)
        }
    }

    suspend fun dismissEmergencyAlert(callId: String): Result<Unit> {
        val callRef = db.collection("dil_se_calls").document(callId)
        return try {
            callRef.update(
                mapOf(
                    "emergencyAlertActive" to false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, callRef.path)
            Result.failure(e)
        }
    }

    suspend fun markAdminJoinedEmergencyCall(callId: String): Result<Unit> {
        val callRef = db.collection("dil_se_calls").document(callId)
        return try {
            callRef.update(
                mapOf(
                    "adminJoinedEmergencyCall" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            val logs = runCatching {
                db.collection("emergency_legal_logs").whereEqualTo("callId", callId).get().await()
            }.getOrNull()
            logs?.documents?.forEach { doc ->
                runCatching { doc.reference.update("adminJoined", true).await() }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, callRef.path)
            Result.failure(e)
        }
    }

    fun observeActiveEmergencyCallsForAdmin(): Flow<List<DilSeCallSession>> = callbackFlow {
        val listener = db.collection("dil_se_calls")
            .whereEqualTo("emergencyAlertActive", true)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snap?.documents
                    ?.mapNotNull { it.toObject(DilSeCallSession::class.java) }
                    ?.filter { it.status == "active" || it.status == "waiting" }
                    ?.sortedByDescending { it.emergencyTriggeredAtMillis ?: 0L }
                    ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun observeEmergencyLegalLogsForAdmin(): Flow<List<EmergencyLegalLog>> = callbackFlow {
        val listener = db.collection("emergency_legal_logs")
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snap?.documents
                    ?.mapNotNull { it.toObject(EmergencyLegalLog::class.java) }
                    ?.sortedByDescending { it.createdAt?.seconds ?: 0L }
                    ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    // =========================================================================
    // REAL-TIME PHONE NUMBER & CONTACT LEAK DETECTION + AUTO-BLOCK
    // =========================================================================

    suspend fun reportContactLeakViolation(
        call: DilSeCallSession,
        offenderUid: String,
        offenderRole: String,
        category: String,
        transcriptSnippet: String
    ): Result<Long> {
        val callRef = db.collection("dil_se_calls").document(call.id)
        return try {
            val newStrikes = (call.contactLeakWarnings + 1L).coerceAtLeast(1L)
            val isSecondViolation = newStrikes >= 2L
            val updates = mutableMapOf<String, Any>(
                "contactLeakWarnings" to newStrikes,
                "lastLeakWarningText" to com.dilsuno.app.core.ContactLeakDetector.WARNING_BANNER_TEXT,
                "lastLeakOffenderRole" to offenderRole,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (isSecondViolation && !call.emergencyAlertActive) {
                updates["status"] = "blocked_abuse"
            }
            callRef.update(updates).await()

            db.collection("contact_leak_alerts").document().set(
                mapOf(
                    "callId" to call.id,
                    "offenderUid" to offenderUid,
                    "offenderRole" to offenderRole,
                    "category" to category,
                    "transcriptSnippet" to SecurityUtils.sanitizeInput(transcriptSnippet, 220),
                    "strikeCount" to newStrikes,
                    "actionTaken" to if (isSecondViolation) "auto_disconnected_frozen" else "red_warning_flashed",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()

            Result.success(newStrikes)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, callRef.path)
            Result.failure(e)
        }
    }

    fun observeContactLeakAlertsForAdmin(): Flow<List<ContactLeakAlert>> = callbackFlow {
        val listener = db.collection("contact_leak_alerts")
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snap?.documents
                    ?.mapNotNull { it.toObject(ContactLeakAlert::class.java) }
                    ?.sortedByDescending { it.createdAt?.seconds ?: 0L }
                    ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    // =========================================================================
    // GOOGLE PLAY BILLING FIREBASE TOKEN VERIFICATION (SINGLE-CREDIT LEDGER)
    // =========================================================================

    suspend fun verifyAndRecordPlayBillingPurchase(
        uid: String,
        productId: String,
        creditsInr: Long,
        purchaseToken: String,
        orderId: String
    ): Result<Long> {
        val tokenHash = com.dilsuno.app.core.DilSunoBillingRules.buildPurchaseTokenHash(purchaseToken, productId)
        val purchaseRef = db.collection("play_billing_purchases").document(tokenHash)
        val accountRef = db.collection("users").document(uid).collection("private").document("account")
        return try {
            val updatedBalance = db.runTransaction { tx ->
                val existingReceipt = tx.get(purchaseRef)
                if (existingReceipt.exists()) {
                    throw IllegalStateException("This Google Play purchase token was already verified and credited.")
                }
                val acctSnap = tx.get(accountRef)
                val currentBal = acctSnap.getLong("walletBalance") ?: 0L
                val nextBal = currentBal + creditsInr

                tx.set(
                    purchaseRef,
                    mapOf(
                        "purchaseTokenHash" to tokenHash,
                        "uid" to uid,
                        "productId" to productId,
                        "creditsInr" to creditsInr,
                        "orderId" to SecurityUtils.sanitizeInput(orderId, 128),
                        "verified" to true,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                if (acctSnap.exists()) {
                    tx.update(
                        accountRef,
                        mapOf(
                            "walletBalance" to nextBal,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                nextBal
            }.await()
            Result.success(updatedBalance)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, purchaseRef.path)
            Result.failure(e)
        }
    }

    // =========================================================================
    // TRUSTED STAFF MANAGER ROLE MANAGEMENT & 1-TAP MODERATION QUEUE ACTIONS
    // =========================================================================

    suspend fun adminSetStaffRole(staffUsername: String, staffRole: String): Result<Unit> {
        val safeRole = if (staffRole == "trusted_staff_manager") "trusted_staff_manager" else "listener"
        val acctRef = db.collection("staff_accounts").document(staffUsername)
        val dirRef = db.collection("staff_directory").document(staffUsername)
        return try {
            val updates = mapOf(
                "staffRole" to safeRole,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (acctRef.get().await().exists()) {
                acctRef.update(updates).await()
            }
            if (dirRef.get().await().exists()) {
                dirRef.update(updates).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, acctRef.path)
            Result.failure(e)
        }
    }

    /**
     * Executes one of the 3 Google Play compliant 1-tap Moderation Queue actions:
     *  - `approve_ignore`: Marks report dismissed, leaves content visible, logs audit record.
     *  - `delete_warn`: Immediately removes reported video/post/comment from public feed,
     *    sends warning notification to author, marks report resolved, logs audit record.
     *  - `delete_ban`: Immediately removes reported video/post/comment, permanently bans user
     *    account/profile (`isBanned = true`), logs employee ID + timestamp to `staff_audit_logs`.
     */
    suspend fun resolveModerationReportAction(
        report: ModerationReport,
        action: String,
        employeeStaffId: String,
        employeeDisplayName: String
    ): Result<Unit> {
        val actorUid = Firebase.auth.currentUser?.uid ?: "owner_admin"
        val reportRef = db.collection("moderation_reports").document(report.id)
        return try {
            val auditActionType = when (action) {
                "approve_ignore" -> "report_approved_ignored"
                "delete_ban" -> "report_deleted_banned"
                else -> "report_deleted_warned"
            }

            if (action == "delete_warn" || action == "delete_ban") {
                when (report.targetType) {
                    "post", "reel", "video" -> {
                        val ref = db.collection("posts").document(report.targetId)
                        if (ref.get().await().exists()) {
                            ref.update(
                                mapOf(
                                    "moderationStatus" to "removed",
                                    "updatedAt" to FieldValue.serverTimestamp()
                                )
                            ).await()
                        }
                    }
                    "story" -> {
                        val ref = db.collection("stories").document(report.targetId)
                        if (ref.get().await().exists()) {
                            ref.update("moderationStatus", "removed").await()
                        }
                    }
                    "live" -> {
                        val ref = db.collection("live_streams").document(report.targetId)
                        if (ref.get().await().exists()) {
                            ref.update(
                                mapOf(
                                    "moderationStatus" to "removed",
                                    "status" to "removed",
                                    "updatedAt" to FieldValue.serverTimestamp()
                                )
                            ).await()
                        }
                    }
                    "comment" -> {
                        val parent = report.parentPostId
                        if (!parent.isNullOrBlank()) {
                            val ref = db.collection("posts").document(parent)
                                .collection("comments").document(report.targetId)
                            if (ref.get().await().exists()) {
                                ref.update("moderationStatus", "removed").await()
                            }
                        }
                    }
                }
            }

            if (action == "delete_ban" && !report.targetAuthorUid.isNullOrBlank()) {
                val targetUid = report.targetAuthorUid
                val acctRef = db.collection("users").document(targetUid).collection("private").document("account")
                val pubRef = db.collection("public_profiles").document(targetUid)
                runCatching {
                    if (acctRef.get().await().exists()) {
                        acctRef.update(
                            mapOf("isBanned" to true, "updatedAt" to FieldValue.serverTimestamp())
                        ).await()
                    }
                }
                runCatching {
                    if (pubRef.get().await().exists()) {
                        pubRef.update(
                            mapOf("isBanned" to true, "updatedAt" to FieldValue.serverTimestamp())
                        ).await()
                    }
                }
            }

            if ((action == "delete_warn" || action == "delete_ban") && !report.targetAuthorUid.isNullOrBlank()) {
                val warnMsg = if (action == "delete_ban") {
                    "Your content was removed and your account permanently banned for violating Dil Suno safety guidelines (${report.reportType})."
                } else {
                    "Warning: Your ${report.targetType} was removed by Dil Suno Safety Team for violating Community Guidelines (${report.reportType}). Repeated violations will result in a permanent ban."
                }
                runCatching {
                    db.collection("notifications").document(UUID.randomUUID().toString()).set(
                        mapOf(
                            "recipientUid" to report.targetAuthorUid,
                            "actorUid" to actorUid,
                            "actorName" to "Dil Suno Safety Team",
                            "type" to "moderation",
                            "message" to SecurityUtils.sanitizeInput(warnMsg, 300),
                            "targetId" to report.targetId,
                            "isRead" to false,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }

            val nextStatus = if (action == "approve_ignore") "dismissed" else "resolved"
            reportRef.update(
                mapOf(
                    "status" to nextStatus,
                    "resolutionAction" to action,
                    "resolvedByStaffId" to employeeStaffId.take(60),
                    "resolvedByName" to SecurityUtils.sanitizeInput(employeeDisplayName, 100),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            // Permanent Google Play Audit Log with Employee ID & Timestamp
            runCatching {
                db.collection("staff_audit_logs").document(UUID.randomUUID().toString()).set(
                    mapOf(
                        "staffUsername" to employeeStaffId.take(60),
                        "staffDisplayName" to SecurityUtils.sanitizeInput(employeeDisplayName, 100),
                        "actorUid" to actorUid,
                        "actionType" to auditActionType,
                        "targetId" to report.targetId.take(128),
                        "targetAuthorName" to report.targetAuthorName?.let { SecurityUtils.sanitizeInput(it, 100) },
                        "contentPreview" to report.targetCaption?.let { SecurityUtils.sanitizeInput(it, 400) },
                        "reason" to SecurityUtils.sanitizeInput("${report.reportType}: ${report.reason}", 300),
                        "createdAt" to FieldValue.serverTimestamp()
                    ).filterValues { it != null } as Map<String, Any>
                ).await()
            }

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, reportRef.path)
            Result.failure(e)
        }
    }
}

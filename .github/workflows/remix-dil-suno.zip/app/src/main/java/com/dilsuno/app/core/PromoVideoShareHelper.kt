package com.dilsuno.app.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import java.io.File

enum class PromoSharePlatform(val label: String, val packageName: String) {
    WHATSAPP("WhatsApp", "com.whatsapp"),
    INSTAGRAM("Instagram", "com.instagram.android"),
    FACEBOOK("Facebook", "com.facebook.katana")
}

object PromoVideoShareHelper {
    private const val TAG = "PromoVideoShareHelper"
    const val DEFAULT_APP_DOWNLOAD_LINK = "https://dilsuno.app/download"

    fun buildPromoCaption(appDownloadUrl: String? = null): String {
        val link = appDownloadUrl?.trim()?.ifBlank { DEFAULT_APP_DOWNLOAD_LINK } ?: DEFAULT_APP_DOWNLOAD_LINK
        return "❤️ दिल सुनो (Dil Suno) — जब दिल भारी हो, किसी से 100% गुमनाम और सुरक्षित बात करें। 24x7 हमदर्द Listeners उपलब्ध हैं!\n" +
            "Feel heard with 100% anonymous, safe emotional audio support on Dil Suno.\n" +
            "Download now: $link"
    }

    /**
     * Copies a picked or recorded video URI into app-private `filesDir/promo_videos` so it can be
     * reliably shared via FileProvider with WhatsApp, Instagram, and Facebook.
     */
    fun copyVideoToPromoStorage(context: Context, sourceUri: Uri, videoId: String): String? {
        return try {
            val dir = File(context.filesDir, "promo_videos").apply { mkdirs() }
            val safeId = videoId.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(32).ifBlank { "promo" }
            val destFile = File(dir, "dilsuno_promo_${safeId}.mp4")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return sourceUri.toString()
            destFile.absolutePath
        } catch (e: Exception) {
            runCatching { Log.w(TAG, "Falling back to original promo video URI: ${e.message}") }
            sourceUri.toString()
        }
    }

    /**
     * Launches a native Android ACTION_SEND intent directly from Dil Suno to WhatsApp, Instagram,
     * or Facebook carrying the video file (via FileProvider) + pre-written caption + app link.
     * Falls back cleanly to Android's native chooser if the target social app isn't installed.
     */
    fun sharePromoVideoToPlatform(
        context: Context,
        videoPathOrUri: String,
        caption: String,
        platform: PromoSharePlatform
    ): Boolean {
        val shareUri = resolveShareableUri(context, videoPathOrUri)
        val baseIntent = Intent(Intent.ACTION_SEND).apply {
            if (shareUri != null) {
                type = "video/*"
                putExtra(Intent.EXTRA_STREAM, shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } else {
                type = "text/plain"
            }
            putExtra(Intent.EXTRA_TEXT, caption)
            putExtra(Intent.EXTRA_SUBJECT, "❤️ Dil Suno • दिल सुनो")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        val targetedIntent = Intent(baseIntent).apply { setPackage(platform.packageName) }
        return try {
            if (targetedIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(targetedIntent)
            } else {
                val chooser = Intent.createChooser(baseIntent, "Share via ${platform.label}").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            }
            true
        } catch (e: Exception) {
            runCatching { Log.e(TAG, "Share to ${platform.label} failed: ${e.message}", e) }
            false
        }
    }

    private fun resolveShareableUri(context: Context, videoPathOrUri: String): Uri? {
        val trimmed = videoPathOrUri.trim()
        if (trimmed.isBlank()) return null
        if (trimmed.startsWith("/")) {
            val file = File(trimmed)
            if (file.exists()) {
                return runCatching {
                    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                }.getOrNull()
            }
        }
        val parsed = Uri.parse(trimmed)
        return when (parsed.scheme?.lowercase()) {
            "content" -> parsed
            "file" -> parsed.path?.let { File(it) }?.takeIf { it.exists() }?.let { file ->
                runCatching {
                    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                }.getOrNull()
            }
            else -> null
        }
    }
}

package com.dilsuno.app.core

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.FragmentActivity
import com.dilsuno.app.data.model.StaffDirectoryEntry
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.zegocloud.uikit.ZegoUIKit
import com.zegocloud.uikit.prebuilt.call.ZegoUIKitPrebuiltCallConfig
import com.zegocloud.uikit.prebuilt.call.ZegoUIKitPrebuiltCallFragment
import com.zegocloud.uikit.prebuilt.call.config.ZegoBottomMenuBarConfig
import com.zegocloud.uikit.prebuilt.call.config.ZegoCallDurationConfig
import com.zegocloud.uikit.prebuilt.call.config.ZegoMenuBarButtonName
import com.zegocloud.uikit.prebuilt.call.config.ZegoNotificationConfig
import com.zegocloud.uikit.prebuilt.call.invite.ZegoUIKitPrebuiltCallInvitationConfig
import com.zegocloud.uikit.prebuilt.call.invite.ZegoUIKitPrebuiltCallInvitationService
import com.zegocloud.uikit.prebuilt.call.invite.internal.ZegoUIKitPrebuiltCallConfigProvider
import com.zegocloud.uikit.prebuilt.call.invite.widget.ZegoSendCallInvitationButton
import com.zegocloud.uikit.service.defines.ZegoUIKitUser
import com.zegocloud.uikit.service.express.IExpressEngineEventHandler
import im.zego.zegoexpress.ZegoExpressEngine
import im.zego.zegoexpress.constants.ZegoAECMode
import im.zego.zegoexpress.constants.ZegoANSMode
import im.zego.zegoexpress.constants.ZegoAudioConfigPreset
import im.zego.zegoexpress.constants.ZegoPublisherState
import im.zego.zegoexpress.constants.ZegoRoomStateChangedReason
import im.zego.zegoexpress.constants.ZegoVoiceChangerPreset
import im.zego.zegoexpress.entity.ZegoAudioConfig
import org.json.JSONObject

data class WarmStudioAudioProfile(
    val sampleRateHz: Int = 48_000,
    val ansEnabled: Boolean = true,
    val aecEnabled: Boolean = true,
    val agcEnabled: Boolean = true,
    val voiceChangerDisabled: Boolean = true,
    val equalizerBandGainsDb: Map<Int, Float> = mapOf(
        2 to 2.0f,  // 125 Hz subtle body warmth
        3 to 2.5f,  // 250 Hz calm low-mid richness
        4 to 1.5f,  // 500 Hz natural vocal presence
        7 to -1.5f, // 4 kHz gentle harshness control
        8 to -2.5f, // 8 kHz smooth high-frequency de-essing
        9 to -2.0f  // 16 kHz soft treble roll-off
    )
)

object ZegoCallManager {
    private const val TAG = "ZegoCallManager"
    const val ZEGO_APP_ID: Long = 908504858L
    const val ZEGO_APP_SIGN: String =
        "7f9d8b99148b54d4fde61d8a55e37d833d5e9a55fc80a12e9effb0768009a236"

    const val ANONYMOUS_CALLER_LABEL = "Caller"
    const val ANONYMOUS_LISTENER_LABEL = "Listener"
    const val EMERGENCY_SUPERVISOR_LABEL = "Emergency Supervisor"

    val WARM_STUDIO_3A_PROFILE = WarmStudioAudioProfile()

    @Volatile
    private var activeUserId: String? = null

    @Volatile
    private var pendingOutgoingListenerStaffId: String? = null

    @Volatile
    private var pendingOutgoingListenerName: String? = null

    @Volatile
    private var currentCallBilledSlots: Long = 0L

    @Volatile
    private var emergencyFreeOverrideActive: Boolean = false

    @Volatile
    private var eventHandlerRegistered: Boolean = false

    @Volatile
    private var onCallSlotConnected: ((listenerStaffId: String?, listenerName: String?, slotIndex: Long) -> Boolean)? = null

    private val expressAudioEventHandler = object : IExpressEngineEventHandler() {
        override fun onRoomStateChanged(
            roomID: String?,
            reason: ZegoRoomStateChangedReason?,
            errorCode: Int,
            extendedData: JSONObject?
        ) {
            super.onRoomStateChanged(roomID, reason, errorCode, extendedData)
            if (errorCode == 0) {
                applyAutomatic3AWarmStudioAudio()
            }
        }

        override fun onPublisherStateUpdate(
            streamID: String?,
            state: ZegoPublisherState?,
            errorCode: Int,
            extendedData: JSONObject?
        ) {
            super.onPublisherStateUpdate(streamID, state, errorCode, extendedData)
            if (errorCode == 0) {
                applyAutomatic3AWarmStudioAudio()
            }
        }
    }

    /**
     * Automatically configures ZegoCloud 48kHz HD Audio + 3A Processing (ANS, AEC, AGC)
     * and subtle warm studio equalization (low-mid richness + smooth de-essing) with ZERO manual buttons.
     */
    fun applyAutomatic3AWarmStudioAudio() {
        if (isRobolectricRuntime()) return
        runCatching {
            val engine = ZegoExpressEngine.getEngine() ?: return
            val profile = WARM_STUDIO_3A_PROFILE
            engine.setAudioConfig(ZegoAudioConfig(ZegoAudioConfigPreset.HIGH_QUALITY))
            engine.enableANS(profile.ansEnabled)
            engine.setANSMode(ZegoANSMode.AI_BALANCED)
            engine.enableAEC(profile.aecEnabled)
            engine.setAECMode(ZegoAECMode.AI_BALANCED)
            engine.enableAGC(profile.agcEnabled)
            if (profile.voiceChangerDisabled) {
                engine.setVoiceChangerPreset(ZegoVoiceChangerPreset.NONE)
            }
            profile.equalizerBandGainsDb.forEach { (bandIndex, gainDb) ->
                engine.setAudioEqualizerGain(bandIndex, gainDb)
            }
            Log.d(TAG, "Applied automatic Zego 3A (ANS+AEC+AGC @ 48kHz) & warm studio EQ")
        }
    }

    private fun ensureExpressAudioHandlerRegistered() {
        if (isRobolectricRuntime() || eventHandlerRegistered) return
        runCatching {
            ZegoUIKit.addEventHandler(expressAudioEventHandler)
            eventHandlerRegistered = true
        }
    }

    fun registerBillingCallback(
        callback: ((listenerStaffId: String?, listenerName: String?, slotIndex: Long) -> Boolean)?
    ) {
        onCallSlotConnected = callback
    }

    fun setEmergencyFreeOverride(active: Boolean) {
        emergencyFreeOverrideActive = active
    }

    fun setPendingOutgoingListener(listenerStaffId: String, listenerName: String) {
        pendingOutgoingListenerStaffId = listenerStaffId
        pendingOutgoingListenerName = ANONYMOUS_LISTENER_LABEL
        currentCallBilledSlots = 0L
        emergencyFreeOverrideActive = false
    }

    fun buildEmergencyRoomId(callId: String): String {
        val clean = callId.trim().replace(Regex("[^a-zA-Z0-9_]"), "_").take(40).ifBlank { "live" }
        return "dilsuno_call_$clean"
    }

    /**
     * Launches the 100% audio-only ZegoCloud group voice room so Super Admin can tap
     * "Join Live Call" during an active Emergency / Suicide Alert (or Caller/Listener can join
     * the shared emergency bridge).
     */
    fun launchEmergencyVoiceRoom(
        context: Context,
        callId: String,
        rawUserId: String,
        anonymousRoleLabel: String
    ): Boolean {
        if (isRobolectricRuntime()) return true
        return runCatching {
            val intent = Intent(context, ZegoEmergencyVoiceRoomActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(ZegoEmergencyVoiceRoomActivity.EXTRA_CALL_ROOM_ID, buildEmergencyRoomId(callId))
                putExtra(ZegoEmergencyVoiceRoomActivity.EXTRA_USER_ID, sanitizeUserId(rawUserId))
                putExtra(ZegoEmergencyVoiceRoomActivity.EXTRA_USER_NAME, anonymousRoleLabel.ifBlank { ANONYMOUS_CALLER_LABEL })
            }
            context.startActivity(intent)
            true
        }.getOrElse { err ->
            runCatching { Log.e(TAG, "Failed to launch emergency voice room: ${err.message}", err) }
            false
        }
    }

    private fun isRobolectricRuntime(): Boolean {
        return Build.FINGERPRINT.equals("robolectric", ignoreCase = true)
    }

    fun sanitizeUserId(rawId: String): String {
        val cleaned = rawId.trim().replace(Regex("[^a-zA-Z0-9_]"), "_")
        return cleaned.take(64).ifBlank { "dilsuno_user" }
    }

    fun resolveListenerTargetId(listener: StaffDirectoryEntry): String {
        val raw = listener.assignedUid?.takeIf { it.isNotBlank() } ?: listener.staffUsername
        return sanitizeUserId(raw)
    }

    fun initCallInvitation(
        application: Application,
        rawUserId: String,
        rawUserName: String
    ) {
        if (isRobolectricRuntime()) return
        try {
            val safeUserId = sanitizeUserId(rawUserId)
            // Enforce 100% anonymous call labels (never leak real names, phone numbers, or emails to Zego UI)
            val safeUserName = when {
                rawUserName.equals(ANONYMOUS_LISTENER_LABEL, ignoreCase = true) -> ANONYMOUS_LISTENER_LABEL
                rawUserName.equals(EMERGENCY_SUPERVISOR_LABEL, ignoreCase = true) -> EMERGENCY_SUPERVISOR_LABEL
                else -> ANONYMOUS_CALLER_LABEL
            }

            if (activeUserId == safeUserId) return
            if (activeUserId != null) {
                unInitCallInvitation()
            }

            val callInvitationConfig = ZegoUIKitPrebuiltCallInvitationConfig().apply {
                showDeclineButton = true
                endCallWhenInitiatorLeave = true
                notificationConfig = ZegoNotificationConfig().apply {
                    channelID = "DilSunoVoiceCall"
                    channelName = "Dil Suno Anonymous Voice Calls"
                    channelDesc = "Incoming 100% anonymous audio-only calls"
                }
                provider = ZegoUIKitPrebuiltCallConfigProvider { _ ->
                    currentCallBilledSlots = 0L
                    applyAutomatic3AWarmStudioAudio()
                    ZegoUIKitPrebuiltCallConfig.oneOnOneVoiceCall().apply {
                        turnOnCameraWhenJoining = false
                        turnOnMicrophoneWhenJoining = true
                        useSpeakerWhenJoining = true
                        durationConfig = ZegoCallDurationConfig().apply {
                            isVisible = true
                            durationUpdateListener = com.zegocloud.uikit.prebuilt.call.config.DurationUpdateListener { seconds ->
                                if (seconds <= 2L) {
                                    applyAutomatic3AWarmStudioAudio()
                                }
                                if (emergencyFreeOverrideActive) return@DurationUpdateListener
                                val expectedSlot = (seconds / DilSunoBillingRules.CALL_SLOT_DURATION_SECONDS) + 1L
                                if (seconds >= 1L && expectedSlot > currentCallBilledSlots) {
                                    currentCallBilledSlots = expectedSlot
                                    val listenerId = pendingOutgoingListenerStaffId
                                    val listenerName = pendingOutgoingListenerName
                                    val extendedOk = onCallSlotConnected?.invoke(listenerId, listenerName, expectedSlot) ?: true
                                    if (!extendedOk && !emergencyFreeOverrideActive) {
                                        runCatching { ZegoUIKitPrebuiltCallInvitationService.endCall() }
                                    }
                                }
                            }
                        }
                        bottomMenuBarConfig = ZegoBottomMenuBarConfig().apply {
                            // Audio-only controls: camera/video & manual voice filter buttons completely excluded
                            buttons = listOf(
                                ZegoMenuBarButtonName.TOGGLE_MICROPHONE_BUTTON,
                                ZegoMenuBarButtonName.HANG_UP_BUTTON,
                                ZegoMenuBarButtonName.SWITCH_AUDIO_OUTPUT_BUTTON
                            )
                        }
                    }
                }
            }

            ZegoUIKitPrebuiltCallInvitationService.init(
                application,
                ZEGO_APP_ID,
                ZEGO_APP_SIGN,
                safeUserId,
                safeUserName,
                callInvitationConfig
            )
            ensureExpressAudioHandlerRegistered()
            applyAutomatic3AWarmStudioAudio()
            activeUserId = safeUserId
            Log.d(TAG, "Zego CallInvitationService initialized anonymously for userID=$safeUserId as $safeUserName")
        } catch (t: Throwable) {
            Log.w(TAG, "Zego CallInvitationService init failed safely: ${t.localizedMessage}", t)
        }
    }

    fun unInitCallInvitation() {
        pendingOutgoingListenerStaffId = null
        pendingOutgoingListenerName = null
        currentCallBilledSlots = 0L
        emergencyFreeOverrideActive = false
        if (isRobolectricRuntime()) {
            activeUserId = null
            return
        }
        if (activeUserId == null) return
        try {
            if (eventHandlerRegistered) {
                runCatching { ZegoUIKit.removeEventHandler(expressAudioEventHandler) }
                eventHandlerRegistered = false
            }
            ZegoUIKitPrebuiltCallInvitationService.unInit()
            Log.d(TAG, "Zego CallInvitationService unInitialized")
        } catch (t: Throwable) {
            Log.w(TAG, "Zego CallInvitationService unInit failed safely: ${t.localizedMessage}", t)
        }
        activeUserId = null
    }
}

/**
 * Audio-only ZegoCloud group voice room Activity used for Super Admin "Join Live Call"
 * emergency intervention alongside Caller & Listener. Camera/video is strictly disabled
 * and FLAG_SECURE blocks screenshots/screen recordings.
 */
class ZegoEmergencyVoiceRoomActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!com.dilsuno.app.BuildConfig.DEBUG && !DeviceSecurityGuard.detectEmulator()) {
            runCatching {
                window.setFlags(
                    WindowManager.LayoutParams.FLAG_SECURE,
                    WindowManager.LayoutParams.FLAG_SECURE
                )
            }
        }

        val containerId = View.generateViewId()
        val container = FrameLayout(this).apply { id = containerId }
        setContentView(container)

        val callRoomId = intent.getStringExtra(EXTRA_CALL_ROOM_ID) ?: "dilsuno_emergency_room"
        val userId = intent.getStringExtra(EXTRA_USER_ID) ?: "dilsuno_supervisor"
        val userName = intent.getStringExtra(EXTRA_USER_NAME) ?: ZegoCallManager.EMERGENCY_SUPERVISOR_LABEL

        if (savedInstanceState == null) {
            try {
                val config = ZegoUIKitPrebuiltCallConfig.groupVoiceCall().apply {
                    turnOnCameraWhenJoining = false
                    turnOnMicrophoneWhenJoining = true
                    useSpeakerWhenJoining = true
                    bottomMenuBarConfig = ZegoBottomMenuBarConfig().apply {
                        buttons = listOf(
                            ZegoMenuBarButtonName.TOGGLE_MICROPHONE_BUTTON,
                            ZegoMenuBarButtonName.HANG_UP_BUTTON,
                            ZegoMenuBarButtonName.SWITCH_AUDIO_OUTPUT_BUTTON
                        )
                    }
                }
                val fragment = ZegoUIKitPrebuiltCallFragment.newInstance(
                    ZegoCallManager.ZEGO_APP_ID,
                    ZegoCallManager.ZEGO_APP_SIGN,
                    userId,
                    userName,
                    callRoomId,
                    config
                )
                supportFragmentManager.beginTransaction()
                    .replace(containerId, fragment)
                    .commitNow()
                ZegoCallManager.applyAutomatic3AWarmStudioAudio()
            } catch (t: Throwable) {
                Log.w("ZegoEmergencyRoom", "Failed to start Zego room safely: ${t.message}", t)
                finish()
            }
        }
    }

    companion object {
        const val EXTRA_CALL_ROOM_ID = "extra_call_room_id"
        const val EXTRA_USER_ID = "extra_user_id"
        const val EXTRA_USER_NAME = "extra_user_name"
    }
}

@Composable
fun ZegoVoiceCallInviteButton(
    targetUserId: String,
    targetUserName: String,
    buttonLabel: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    containerColor: Color = CrimsonPrimary,
    testTag: String = "zego_voice_call_button",
    listenerStaffId: String? = null
) {
    val safeTargetId = ZegoCallManager.sanitizeUserId(targetUserId)
    // Always display anonymous "Listener" label inside Zego call UI
    val safeTargetName = ZegoCallManager.ANONYMOUS_LISTENER_LABEL
    val resolvedStaffId = listenerStaffId ?: safeTargetId
    val isPreviewOrRobolectric = LocalInspectionMode.current ||
        Build.FINGERPRINT.equals("robolectric", ignoreCase = true)

    if (isPreviewOrRobolectric) {
        Button(
            onClick = {
                ZegoCallManager.setPendingOutgoingListener(resolvedStaffId, safeTargetName)
            },
            enabled = enabled,
            colors = ButtonDefaults.buttonColors(
                containerColor = containerColor,
                contentColor = Color.White
            ),
            modifier = modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
                .testTag(testTag)
        ) {
            Text(
                text = buttonLabel,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
        }
        return
    }

    val colorInt = (if (enabled) containerColor else containerColor.copy(alpha = 0.55f)).toArgb()

    AndroidView<ZegoSendCallInvitationButton>(
        modifier = modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 48.dp)
            .testTag(testTag),
        factory = { ctx ->
            val density = ctx.resources.displayMetrics.density
            fun dp(v: Int): Int = (v * density).toInt()
            ZegoSendCallInvitationButton(ctx).apply {
                setIsVideoCall(false)
                setInvitees(listOf(ZegoUIKitUser(safeTargetId, safeTargetName)))
                showErrorToast(true)
                setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0)
                text = buttonLabel
                setTextColor(android.graphics.Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                isAllCaps = false
                minHeight = dp(48)
                setPadding(dp(16), dp(12), dp(16), dp(12))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(14).toFloat()
                    setColor(colorInt)
                }
                setOnTouchListener { _, event ->
                    if (event.action == android.view.MotionEvent.ACTION_DOWN && isEnabled) {
                        ZegoCallManager.setPendingOutgoingListener(resolvedStaffId, safeTargetName)
                    }
                    false
                }
                isEnabled = enabled
            }
        },
        update = { btn ->
            val density = btn.resources.displayMetrics.density
            fun dp(v: Int): Int = (v * density).toInt()
            btn.setIsVideoCall(false)
            btn.setInvitees(listOf(ZegoUIKitUser(safeTargetId, safeTargetName)))
            btn.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0)
            btn.text = buttonLabel
            btn.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(14).toFloat()
                setColor(colorInt)
            }
            btn.setOnTouchListener { _, event ->
                if (event.action == android.view.MotionEvent.ACTION_DOWN && btn.isEnabled) {
                    ZegoCallManager.setPendingOutgoingListener(resolvedStaffId, safeTargetName)
                }
                false
            }
            btn.isEnabled = enabled
        }
    )
}

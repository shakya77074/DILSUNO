package com.dilsuno.app.ui.screens

import androidx.compose.animation.animateColor
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.updateTransition
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dilsuno.app.ui.theme.PureWhiteBackground
import com.dilsuno.app.ui.theme.RoyalBluePrimary
import com.dilsuno.app.ui.theme.SlateMutedFooter
import kotlinx.coroutines.launch

@Composable
fun SplashScreen() {
    var startReveal by remember { mutableStateOf(false) }
    val heartScale = remember { Animatable(0.22f) }
    val footerAlpha = remember { Animatable(0f) }

    val colorTransition = updateTransition(
        targetState = startReveal,
        label = "splash_heart_color"
    )
    val heartTint by colorTransition.animateColor(
        transitionSpec = { tween(durationMillis = 950, easing = FastOutSlowInEasing) },
        label = "heart_tint_anim"
    ) { revealed ->
        if (revealed) RoyalBluePrimary else Color(0xFF93C5FD)
    }

    LaunchedEffect(Unit) {
        startReveal = true
        launch {
            footerAlpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 700, delayMillis = 120, easing = LinearOutSlowInEasing)
            )
        }
        heartScale.animateTo(
            targetValue = 1.14f,
            animationSpec = tween(durationMillis = 680, easing = FastOutSlowInEasing)
        )
        heartScale.animateTo(
            targetValue = 0.96f,
            animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing)
        )
        heartScale.animateTo(
            targetValue = 1.06f,
            animationSpec = tween(durationMillis = 240, easing = FastOutSlowInEasing)
        )
        heartScale.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhiteBackground)
            .systemBarsPadding()
            .testTag("splash_screen")
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .scale(heartScale.value),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(124.dp)
                    .alpha(0.22f * footerAlpha.value)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(heartTint.copy(alpha = 0.35f), PureWhiteBackground)
                        ),
                        shape = CircleShape
                    )
            )
            Icon(
                imageVector = Icons.Filled.Favorite,
                contentDescription = "Dil Suno",
                tint = heartTint,
                modifier = Modifier
                    .size(84.dp)
                    .testTag("splash_heart_icon")
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 36.dp)
                .alpha(footerAlpha.value)
                .testTag("splash_branding_footer"),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "from",
                style = MaterialTheme.typography.bodySmall,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = SlateMutedFooter,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "SHAKYA",
                style = MaterialTheme.typography.titleMedium,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 3.sp,
                color = RoyalBluePrimary,
                textAlign = TextAlign.Center
            )
        }
    }
}

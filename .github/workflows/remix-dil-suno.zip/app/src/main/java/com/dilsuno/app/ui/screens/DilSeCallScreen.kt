package com.dilsuno.app.ui.screens

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dilsuno.app.R
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.ContactLeakDetector
import com.dilsuno.app.core.DilSePolicyText
import com.dilsuno.app.core.DilSunoBillingRules
import com.dilsuno.app.core.LiveSpeechLeakMonitor
import com.dilsuno.app.core.LiveWebRtcAudioBridge
import com.dilsuno.app.core.PlayBillingManager
import com.dilsuno.app.core.ZegoCallManager
import com.dilsuno.app.core.ZegoVoiceCallInviteButton
import com.dilsuno.app.core.tr
import com.dilsuno.app.ui.components.ExplicitEmergencyRecordingNoticeBanner
import com.dilsuno.app.ui.components.FreeAiVoiceListenerDialog
import com.dilsuno.app.ui.components.HealthDisclaimerAndHelplineCard
import com.dilsuno.app.ui.components.ProminentPermissionDisclosureDialog
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.RoyalNavy
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.VelvetIndigo
import com.dilsuno.app.viewmodel.MainAppViewModel
import kotlinx.coroutines.delay

@Composable
fun DilSeCallScreen(
    viewModel: MainAppViewModel,
    lang: AppLang,
    autoPromptRechargeOnOpen: Boolean = false,
    onConsumeAutoRechargePrompt: () -> Unit = {}
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val appConfig by viewModel.appConfig.collectAsStateWithLifecycle()
    val activeListeners by viewModel.activeListeners.collectAsStateWithLifecycle()
    val onlineStaffCount by viewModel.onlineStaffCount.collectAsStateWithLifecycle()
    val activeCall by viewModel.activeCall.collectAsStateWithLifecycle()
    val pendingRatingCall by viewModel.pendingCallForRating.collectAsStateWithLifecycle()
    val walletBalance by viewModel.walletBalance.collectAsStateWithLifecycle()
    val isVerifyingPlayPurchase by viewModel.isVerifyingPlayPurchase.collectAsStateWithLifecycle()
    val isReviewerDemoAccount = viewModel.isReviewerDemoAccount
    val activeBilledSlots by viewModel.activeBilledSlotsCount.collectAsStateWithLifecycle()

    var showWarningDialog by remember { mutableStateOf(false) }
    var showSmartRechargePopup by remember { mutableStateOf(false) }
    var showMicDisclosureDialog by remember { mutableStateOf(false) }
    var showFreeAiListenerDialog by remember { mutableStateOf(false) }
    var agreedChecked by remember { mutableStateOf(false) }
    var isMuted by remember { mutableStateOf(false) }
    var isSpeaker by remember { mutableStateOf(true) }
    var callSeconds by remember { mutableLongStateOf(0L) }
    val hasMicPermission = remember(context, activeCall?.status) {
        runCatching {
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
    }

    val hasCallBalance = walletBalance >= DilSunoBillingRules.CALL_CHARGE_INR

    // Google Play Billing client for consumable digital call credit packs (pack_100..pack_400)
    val playBillingManager = remember(context) {
        PlayBillingManager(
            context = context,
            onPurchaseVerifiedForFirebase = { verifiedPurchase ->
                viewModel.creditVerifiedPlayBillingPurchase(verifiedPurchase)
            },
            onBillingMessage = { msg ->
                viewModel.reportSecurityError(msg)
            }
        )
    }
    val playBillingReady by playBillingManager.isPlayBillingReady.collectAsStateWithLifecycle()
    val playDisplayPrices by playBillingManager.displayPrices.collectAsStateWithLifecycle()

    DisposableEffect(playBillingManager) {
        runCatching { playBillingManager.startConnection() }
        onDispose { runCatching { playBillingManager.endConnection() } }
    }

    LaunchedEffect(autoPromptRechargeOnOpen, walletBalance) {
        if (autoPromptRechargeOnOpen) {
            if (!hasCallBalance) {
                showSmartRechargePopup = true
            }
            onConsumeAutoRechargePrompt()
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.startWalletDilSeCall()
    }

    // Active call duration ticker & automatic seamless slot extension when slot finishes
    LaunchedEffect(activeCall?.id, activeCall?.status) {
        if (activeCall?.status == "active") {
            callSeconds = 0L
            while (activeCall?.status == "active") {
                delay(1000L)
                callSeconds++
                if (callSeconds > 0L && callSeconds % DilSunoBillingRules.CALL_SLOT_DURATION_SECONDS == 0L) {
                    val nextSlot = (callSeconds / DilSunoBillingRules.CALL_SLOT_DURATION_SECONDS) + 1L
                    viewModel.autoExtendActiveCallIfEligible(
                        nextSlotIndex = nextSlot,
                        elapsedSeconds = callSeconds
                    )
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .widthIn(max = 600.dp)
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Banner
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = RoyalNavy),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Image(
                    painter = painterResource(id = R.drawable.img_dil_se_banner),
                    contentDescription = "Dil Se Baat Emotional Support Banner",
                    modifier = Modifier.fillMaxWidth().height(160.dp),
                    contentScale = ContentScale.Crop
                )
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.Favorite, null, tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "दिल से बात करें • Dil Se Call",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White
                        )
                    }
                    Text(
                        text = "मन का बोझ हल्का करें...",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "ज़िंदगी में कई बातें ऐसी होती हैं जिन्हें हम न तो ऑफिस में बॉस से कह पाते हैं, और न ही घर में अपनों से—कभी ज़िम्मेदारियों के डर से, तो कभी इस सोच से कि कोई क्या कहेगा। जो बात या घुटन सालों से आपके सीने में दबी है, उसे आज बिना किसी डर या संकोच के खुलकर कह दीजिए। यहाँ कोई आपको परखेगा नहीं, बस सुनेगा—और आपकी पहचान 100% गुप्त रहेगी।",
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        color = Color.White.copy(alpha = 0.94f)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "⚠️ ज़रूरी नियम (सही मानसिकता रखें):",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "दोस्ती (Friendship) या प्यार-मोहब्बत की बातें करने के लिए कृपया कॉल न करें—ऐसा करने पर कॉल तुरंत काट दी जाएगी। कृपया केवल सम्मान और सही मानसिकता के साथ ही कॉल करें।",
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        color = Color.White.copy(alpha = 0.94f)
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = "(कॉल जुड़ने पर ही वॉलेट से ₹100 कटेंगे, कॉल न उठने पर ₹0)",
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        color = Color.White.copy(alpha = 0.92f)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        val effectiveListeners = onlineStaffCount + if (appConfig.adminCallPickupOnline) 1 else 0
                        Surface(color = SafeEmerald, shape = RoundedCornerShape(10.dp)) {
                            Text(
                                text = when {
                                    effectiveListeners > 0 -> tr(
                                        "$effectiveListeners Listeners Online",
                                        "$effectiveListeners श्रोता ऑनलाइन",
                                        lang
                                    )
                                    else -> tr(
                                        "Owner Backup Ready",
                                        "ओनर बैकअप उपलब्ध",
                                        lang
                                    )
                                },
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                        Surface(color = CrimsonPrimary, shape = RoundedCornerShape(10.dp)) {
                            Text(
                                text = "₹${DilSunoBillingRules.CALL_CHARGE_INR} / 30-Min Call",
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }

        // Google Play Health & Suicide Prevention Disclaimer + Permanent 1-Tap Tele-MANAS (14416)
        HealthDisclaimerAndHelplineCard(lang = lang)

        // Google Play Billing Compliant Wallet Recharge Card (pack_100 .. pack_400 verified in Firebase)
        Card(
            modifier = Modifier.fillMaxWidth().testTag("wallet_recharge_card"),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(CrimsonPrimary.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Filled.AccountBalanceWallet,
                                contentDescription = "Wallet Balance",
                                tint = CrimsonPrimary
                            )
                        }
                        Column {
                            Text(
                                text = tr("Dil Suno Wallet Balance", "दिल सुनो वॉलेट बैलेंस", lang),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "₹$walletBalance",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (hasCallBalance) SafeEmerald else CrimsonPrimary,
                                modifier = Modifier.testTag("wallet_balance_text")
                            )
                        }
                    }
                    Surface(
                        color = if (hasCallBalance) SafeEmerald.copy(alpha = 0.14f) else CrimsonPrimary.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (hasCallBalance) {
                                tr("Ready to Talk", "कॉल के लिए तैयार", lang)
                            } else {
                                tr("Min ₹100 Needed", "न्यूनतम ₹100 आवश्यक", lang)
                            },
                            color = if (hasCallBalance) SafeEmerald else CrimsonPrimary,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                Text(
                    text = tr(
                        "Buy Call Credits via Google Play Billing",
                        "Google Play Billing द्वारा कॉल क्रेडिट्स खरीदें",
                        lang
                    ),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                // 5 Official Google Play Billing In-App Products: wallet_100..wallet_500
                PlayBillingManager.PLAY_BILLING_PACKS.chunked(3).forEach { rowPacks ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowPacks.forEach { pack ->
                            val priceLabel = playDisplayPrices[pack.productId] ?: pack.fallbackPriceLabel
                            Button(
                                onClick = {
                                    playBillingManager.launchPackPurchase(
                                        activity = activity,
                                        pack = pack,
                                        isReviewerDemoAccount = isReviewerDemoAccount
                                    )
                                },
                                enabled = !isVerifyingPlayPurchase,
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (pack.productId == PlayBillingManager.WALLET_100_ID) CrimsonPrimary else RoyalNavy,
                                    contentColor = Color.White
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("play_billing_${pack.productId}")
                            ) {
                                Text(
                                    text = priceLabel,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                }

                if (isVerifyingPlayPurchase) {
                    Surface(
                        color = SafeEmerald.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("play_billing_verifying_banner")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = SafeEmerald)
                            Text(
                                text = tr(
                                    "Verifying Google Play purchase token securely in Firebase...",
                                    "Firebase में Google Play खरीद टोकन की सुरक्षित पुष्टि हो रही है...",
                                    lang
                                ),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = SafeEmerald
                            )
                        }
                    }
                }

                // Mandatory Non-Refundable Wallet Note
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Filled.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = DilSunoBillingRules.NON_REFUNDABLE_WALLET_NOTE,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.testTag("wallet_non_refundable_note")
                            )
                            if (lang == AppLang.HI) {
                                Text(
                                    text = "वॉलेट बैलेंस पूरी तरह से नॉन-रिफंडेबल है।",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }
                }

                // Google Play Billing Compliance & Verification Status
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (playBillingReady) Icons.Filled.CheckCircle else Icons.Filled.ShoppingBag,
                            contentDescription = "Google Play Billing",
                            tint = if (playBillingReady) SafeEmerald else VelvetIndigo,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (isReviewerDemoAccount) {
                                tr(
                                    "Play Reviewer Demo Mode • Pre-funded ₹500 credits + Play Billing test packs enabled.",
                                    "प्ले रिव्यूअर डेमो मोड • ₹500 टेस्ट क्रेडिट्स सक्रिय।",
                                    lang
                                )
                            } else if (playBillingReady) {
                                tr(
                                    "Google Play Billing connected (wallet_100..wallet_500) • Tokens verified in Firebase.",
                                    "Google Play Billing सक्रिय (₹100–₹500) • सभी खरीद टोकन Firebase में सत्यापित।",
                                    lang
                                )
                            } else {
                                tr(
                                    "Secured by Google Play Billing • Digital call credits verified in Firebase.",
                                    "Google Play Billing द्वारा सुरक्षित • डिजिटल कॉल क्रेडिट्स।",
                                    lang
                                )
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        if (activeCall == null) {
            // Direct 1-on-1 Voice Call Listener Cards powered by ZegoSendCallInvitationButton (Wallet-Gated ≥ ₹100)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.HeadsetMic, contentDescription = null, tint = CrimsonPrimary)
                            Text(
                                text = tr(
                                    "Instant 1-on-1 Voice Listeners",
                                    "तुरंत 1-ऑन-1 वॉइस श्रोता चुनें",
                                    lang
                                ),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            color = if (onlineStaffCount > 0) SafeEmerald.copy(alpha = 0.14f)
                            else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = tr("$onlineStaffCount Online", "$onlineStaffCount ऑनलाइन", lang),
                                color = if (onlineStaffCount > 0) SafeEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (activeListeners.isEmpty() || onlineStaffCount == 0) {
                        Surface(
                            color = VelvetIndigo.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().testTag("zero_listeners_ai_fallback_card")
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = tr(
                                        "All human Listeners are currently offline or busy. Talk instantly with our 100% Free AI Voice Listener (₹0) right now, or tap 'Talk Now' to ring Owner Backup.",
                                        "अभी कोई ह्यूमन श्रोता ऑनलाइन नहीं है। तुरंत हमारे 100% मुफ़्त AI वॉइस लिसनर (₹0) से बात करें या ओनर बैकअप के लिए नीचे 'Talk Now' दबाएं।",
                                        lang
                                    ),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Button(
                                    onClick = { showFreeAiListenerDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = VelvetIndigo, contentColor = Color.White),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .testTag("open_free_ai_listener_button")
                                ) {
                                    Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        tr("Talk to Free AI Voice Listener (₹0)", "मुफ़्त AI वॉइस लिसनर से बात करें (₹0)", lang),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    if (activeListeners.isNotEmpty()) {
                        activeListeners.forEachIndexed { idx, listener ->
                            val targetId = ZegoCallManager.resolveListenerTargetId(listener)
                            // Strict 100% anonymity: never show real listener names, friend links, or phone numbers
                            val anonymousLabel = tr("Verified Listener #${idx + 1}", "प्रमाणित श्रोता #${idx + 1}", lang)
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("listener_profile_card_${listener.staffUsername}")
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        if (listener.isOnline) CrimsonPrimary
                                                        else MaterialTheme.colorScheme.outline
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    Icons.Filled.HeadsetMic,
                                                    contentDescription = "Anonymous Listener",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(22.dp)
                                                )
                                            }
                                            Column {
                                                Text(
                                                    text = anonymousLabel,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = tr(
                                                        "${listener.totalCalls} anonymous calls • 100% Audio-Only • ₹100 on connect",
                                                        "${listener.totalCalls} गुमनाम कॉल • केवल ऑडियो • जुड़ने पर ₹100",
                                                        lang
                                                    ),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        Surface(
                                            color = if (listener.isOnline) SafeEmerald else MaterialTheme.colorScheme.surfaceVariant,
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text(
                                                text = if (listener.isOnline) tr("Online", "ऑनलाइन", lang)
                                                else tr("Offline", "ऑफलाइन", lang),
                                                color = if (listener.isOnline) Color.White
                                                else MaterialTheme.colorScheme.onSurfaceVariant,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }

                                    if (hasCallBalance) {
                                        ZegoVoiceCallInviteButton(
                                            targetUserId = targetId,
                                            targetUserName = ZegoCallManager.ANONYMOUS_LISTENER_LABEL,
                                            buttonLabel = "🎧 Talk Now • प्राइवेट ऑडियो कॉल (₹${DilSunoBillingRules.CALL_CHARGE_INR})",
                                            enabled = true,
                                            containerColor = if (listener.isOnline) CrimsonPrimary else RoyalNavy,
                                            testTag = "zego_call_listener_${listener.staffUsername}",
                                            listenerStaffId = listener.staffUsername
                                        )
                                    } else {
                                        OutlinedButton(
                                            onClick = {
                                                viewModel.reportSecurityError(
                                                    "Minimum ₹${DilSunoBillingRules.CALL_CHARGE_INR} wallet balance required before starting a call. Please recharge above."
                                                )
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .heightIn(min = 48.dp)
                                                .testTag("zego_call_locked_${listener.staffUsername}")
                                        ) {
                                            Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text(
                                                tr(
                                                    "Recharge ₹100+ to Talk Now",
                                                    "कॉल के लिए वॉलेट में ₹100+ रिचार्ज करें",
                                                    lang
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (onlineStaffCount > 0) {
                        OutlinedButton(
                            onClick = { showFreeAiListenerDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("open_free_ai_listener_optional_button")
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = VelvetIndigo)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                tr("Or try Free AI Voice Listener (₹0)", "या मुफ़्त AI वॉइस लिसनर (₹0) से बात करें", lang),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Primary Talk Now Queue Card (Wallet-Backed ₹100 on connect, ₹0 if unanswered, seamless auto-extend)
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.Shield, null, tint = MaterialTheme.colorScheme.primary)
                        Text(tr("Strict Anti-Abuse & Wallet Billing Policy", "सख्त सुरक्षा व वॉलेट बिलिंग नीति", lang), style = MaterialTheme.typography.titleMedium)
                    }
                    Text(
                        text = tr(
                            "• Minimum ₹100 wallet balance required to start.\n• ₹100 is deducted ONLY when a Listener answers (₹0 if unanswered).\n• Each session runs up to 30 minutes (30:00 countdown to 00:00) and completes automatically unless extended with wallet balance ≥ ₹100.",
                            "• कॉल शुरू करने के लिए वॉलेट में कम से कम ₹100 होना आवश्यक है।\n• ₹100 केवल कॉल जुड़ने पर ही कटेंगे (कॉल न उठने पर ₹0)।\n• प्रत्येक कॉल सत्र 30 मिनट (30:00 से 00:00 काउंटडाउन) का होता है और समय पूरा होने पर स्वतः समाप्त होता है।",
                            lang
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = DilSePolicyText.MANDATORY_WARNING_BILINGUAL,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = {
                            if (!hasCallBalance) {
                                viewModel.reportSecurityError(
                                    "Minimum ₹${DilSunoBillingRules.CALL_CHARGE_INR} wallet balance required before calling. Recharge your wallet above."
                                )
                            } else {
                                agreedChecked = false
                                showWarningDialog = true
                            }
                        },
                        enabled = hasCallBalance,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CrimsonPrimary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth().height(56.dp).testTag("start_dil_se_call_button")
                    ) {
                        Icon(if (hasCallBalance) Icons.Filled.Call else Icons.Filled.Lock, null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (hasCallBalance) {
                                tr(
                                    "Talk Now • दिल से बात करें (₹100 on connect)",
                                    "Talk Now • दिल से बात करें (जुड़ने पर ₹100)",
                                    lang
                                )
                            } else {
                                tr(
                                    "Recharge ₹100+ to Talk Now",
                                    "Talk Now के लिए ₹100+ रिचार्ज करें",
                                    lang
                                )
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        } else {
            val call = activeCall!!
            val currentSlot = activeBilledSlots.coerceAtLeast(if (call.status == "active") 1L else 0L)
            val slotElapsed = callSeconds % DilSunoBillingRules.CALL_SLOT_DURATION_SECONDS
            val slotRemaining = (DilSunoBillingRules.CALL_SLOT_DURATION_SECONDS - slotElapsed).coerceAtLeast(0L)
            val slotTimerStr = DilSunoBillingRules.formatCountdownMmSs(slotRemaining)

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (call.status == "blocked_abuse") MaterialTheme.colorScheme.errorContainer
                    else MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(22.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier.size(76.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.HeadsetMic, null, tint = Color.White, modifier = Modifier.size(38.dp))
                    }
                    Text(
                        text = when (call.status) {
                            "waiting" -> tr("Ringing Online Staff Listener... (₹0 charged yet)", "ऑनलाइन श्रोता को कॉल जा रही है... (अभी ₹0 कटा है)", lang)
                            "active" -> tr("Live Anonymous Call Connected", "लाइव गुमनाम कॉल जुड़ा है", lang)
                            "blocked_abuse" -> tr("CALL DISCONNECTED — BLOCKED FOR ABUSE (NO REFUND)", "अभद्र व्यवहार के कारण कॉल काटी गई और अकाउंट ब्लॉक किया गया!", lang)
                            else -> tr("Call Ended", "कॉल समाप्त", lang)
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    if (call.status == "active") {
                        Surface(
                            color = RoyalNavy,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.testTag("active_call_30min_countdown")
                        ) {
                            Text(
                                text = "⏱ $slotTimerStr / 30:00",
                                color = Color.White,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                            )
                        }
                    }
                    Text(
                        text = if (call.status == "active") {
                            "Caller ↔ Listener (100% Anonymous) • Session $currentSlot ($slotTimerStr left) • Wallet: ₹$walletBalance"
                        } else {
                            "Caller ↔ Listener (100% Anonymous) • Wallet: ₹$walletBalance • ₹0 if unanswered"
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )

                    // Explicit Recording Consent Notice on Call Waiting / Connecting Screen
                    if (call.status == "waiting") {
                        ExplicitEmergencyRecordingNoticeBanner(lang = lang)
                    }

                    // Real-time On-Device Contact Leak Protection (never saves regular audio)
                    LiveSpeechLeakMonitor(
                        active = call.status == "active",
                        hasAudioPermission = hasMicPermission,
                        onContactLeakDetected = { leak ->
                            viewModel.onLiveContactLeakDetected(leak.category, leak.matchedSnippet)
                        }
                    )

                    // Flashing Contact Leak Warning Banner on BOTH screens
                    if (call.contactLeakWarnings >= 1L) {
                        Surface(
                            color = Color(0xFFB91C1C),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("caller_contact_leak_warning_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Filled.Warning, contentDescription = null, tint = Color.White)
                                Text(
                                    text = call.lastLeakWarningText ?: ContactLeakDetector.WARNING_BANNER_TEXT,
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    // Emergency / Suicide Alert Free Override & Tele-MANAS Helpline Banner
                    if (call.emergencyAlertActive) {
                        Surface(
                            color = Color(0xFF991B1B),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().testTag("caller_emergency_helpline_banner")
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = tr(
                                        "🆘 Free Emergency Support Active — Call Will NEVER Disconnect (₹0)",
                                        "🆘 मुफ़्त आपातकालीन सहायता सक्रिय — कॉल कभी नहीं कटेगी (₹0)",
                                        lang
                                    ),
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "You are not alone. India 24x7 Mental Health Helpline: ${DilSePolicyText.TELE_MANAS_HELPLINE}",
                                    color = Color(0xFFFDE047),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                                if (!call.zegoRoomId.isNullOrBlank()) {
                                    Button(
                                        onClick = {
                                            ZegoCallManager.launchEmergencyVoiceRoom(
                                                context = context,
                                                callId = call.id,
                                                rawUserId = call.callerUid,
                                                anonymousRoleLabel = ZegoCallManager.ANONYMOUS_CALLER_LABEL
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color.White,
                                            contentColor = Color(0xFF991B1B)
                                        ),
                                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                                    ) {
                                        Icon(Icons.Filled.Call, contentDescription = null)
                                        Spacer(Modifier.width(6.dp))
                                        Text(tr("Join 3-Way Crisis Support Audio Room", "3-वे क्राइसिस सपोर्ट ऑडियो रूम जुड़ें", lang), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    } else if (call.status == "active") {
                        Surface(
                            color = if (hasCallBalance) SafeEmerald.copy(alpha = 0.16f) else MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (hasCallBalance) {
                                    tr(
                                        "Auto-Extend ON: ₹100 will extend seamlessly after current slot",
                                        "ऑटो-एक्सटेंड चालू: स्लॉट के बाद ₹100 से कॉल जारी रहेगी",
                                        lang
                                    )
                                } else {
                                    tr(
                                        "Wallet < ₹100: Call will end cleanly after current slot",
                                        "वॉलेट < ₹100: स्लॉट समाप्त होने पर कॉल बंद हो जाएगी",
                                        lang
                                    )
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }

                    if (call.status == "waiting" || call.status == "active") {
                        LiveWebRtcAudioBridge(
                            callId = call.id,
                            localRole = "caller",
                            isCallActive = call.status == "active",
                            isMuted = isMuted,
                            isSpeaker = isSpeaker,
                            agoraAppId = appConfig.agoraAppId,
                            signalsFlow = viewModel.observeWebRtcSignals(call.id),
                            onSendSignal = { sigType, payload ->
                                viewModel.sendWebRtcSignal(call.id, "caller", sigType, payload)
                            },
                            lang = lang
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedButton(
                                onClick = { isMuted = !isMuted },
                                modifier = Modifier.heightIn(min = 48.dp).testTag("caller_mute_button")
                            ) {
                                Icon(if (isMuted) Icons.Filled.MicOff else Icons.Filled.Mic, null)
                                Spacer(Modifier.width(4.dp))
                                Text(if (isMuted) "Muted" else "Mic On")
                            }
                            OutlinedButton(
                                onClick = { isSpeaker = !isSpeaker },
                                modifier = Modifier.heightIn(min = 48.dp).testTag("caller_speaker_button")
                            ) {
                                Icon(Icons.Filled.VolumeUp, null)
                                Spacer(Modifier.width(4.dp))
                                Text(if (isSpeaker) "Speaker" else "Earpiece")
                            }
                        }
                        Button(
                            onClick = { viewModel.endActiveDilSeCall(callSeconds) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("caller_end_call_button")
                        ) {
                            Icon(Icons.Filled.CallEnd, null)
                            Spacer(Modifier.width(6.dp))
                            Text(tr("End Call", "कॉल समाप्त करें", lang))
                        }
                    } else {
                        Button(
                            onClick = { viewModel.endActiveDilSeCall(callSeconds) },
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text(tr("Done", "ठीक है", lang))
                        }
                    }
                }
            }
        }
    }

    if (showFreeAiListenerDialog) {
        FreeAiVoiceListenerDialog(
            viewModel = viewModel,
            lang = lang,
            onDismiss = { showFreeAiListenerDialog = false }
        )
    }

    // Mandatory Pre-Call Warning Pop-up (Deducts ₹100 from Wallet ONLY on Connect)
    if (showWarningDialog) {
        AlertDialog(
            onDismissRequest = { showWarningDialog = false },
            icon = { Icon(Icons.Filled.Warning, null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("सख्त चेतावनी / Strict Warning") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = DilSePolicyText.MANDATORY_WARNING_BILINGUAL,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = tr(
                            "Wallet Balance: ₹$walletBalance. ₹100 will be deducted ONLY when the Listener answers (₹0 if unanswered).",
                            "वॉलेट बैलेंस: ₹$walletBalance। ₹100 केवल श्रोता के कॉल उठाने पर ही कटेंगे (न उठने पर ₹0)।",
                            lang
                        ),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = SafeEmerald
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = agreedChecked,
                            onCheckedChange = { agreedChecked = it },
                            modifier = Modifier.testTag("dil_se_agree_checkbox")
                        )
                        Text("I Agree / मैं सहमत हूँ", fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showWarningDialog = false
                        if (hasMicPermission) {
                            viewModel.startWalletDilSeCall()
                        } else {
                            showMicDisclosureDialog = true
                        }
                    },
                    enabled = agreedChecked && hasCallBalance,
                    modifier = Modifier.testTag("confirm_dil_se_call_button")
                ) {
                    Text(tr("Talk Now (₹100 on Connect)", "अभी कॉल करें (जुड़ने पर ₹100)", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showWarningDialog = false }) {
                    Text(tr("Cancel", "रद्द करें", lang))
                }
            }
        )
    }

    // Prominent Permission Disclosure shown BEFORE native Microphone prompt
    if (showMicDisclosureDialog) {
        ProminentPermissionDisclosureDialog(
            lang = lang,
            onContinue = {
                showMicDisclosureDialog = false
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            },
            onNotNow = {
                showMicDisclosureDialog = false
            }
        )
    }

    // Post-Call 1-to-5 Star Staff Rating Prompt
    pendingRatingCall?.let { call ->
        var selectedStars by remember { mutableIntStateOf(5) }
        var ratingComment by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { viewModel.dismissStaffRating() },
            title = { Text(tr("Rate Your Listener • श्रोता को रेटिंग दें", "अपने श्रोता को रेटिंग दें", lang)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        tr(
                            "Call Duration: ${call.durationSeconds}s. How helpful was the Listener?",
                            "कॉल अवधि: ${call.durationSeconds} सेकंड। श्रोता का व्यवहार कैसा रहा?",
                            lang
                        ),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(horizontalArrangement = Arrangement.Center) {
                        (1..5).forEach { star ->
                            IconButton(
                                onClick = { selectedStars = star },
                                modifier = Modifier.testTag("rate_star_$star")
                            ) {
                                Icon(
                                    imageVector = if (star <= selectedStars) Icons.Filled.Star else Icons.Filled.StarBorder,
                                    contentDescription = "$star Stars",
                                    tint = if (star <= selectedStars) Color(0xFFF59E0B) else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                        }
                    }
                    OutlinedTextField(
                        value = ratingComment,
                        onValueChange = { ratingComment = it },
                        label = { Text(tr("Short feedback (optional)", "टिप्पणी (वैकल्पिक)", lang)) },
                        modifier = Modifier.fillMaxWidth().testTag("rating_comment_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.submitStaffRating(selectedStars, ratingComment) },
                    modifier = Modifier.testTag("submit_staff_rating_button")
                ) {
                    Text(tr("Submit Rating ($selectedStars★)", "रेटिंग भेजें ($selectedStars★)", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissStaffRating() }) {
                    Text(tr("Skip", "छोड़ें", lang))
                }
            }
        )
    }

    if (showSmartRechargePopup && !hasCallBalance) {
        AlertDialog(
            onDismissRequest = { showSmartRechargePopup = false },
            icon = { Icon(Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = CrimsonPrimary) },
            title = {
                Text(
                    text = tr("Recharge Wallet to Call Listener", "कॉल के लिए वॉलेट रिचार्ज करें", lang),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = tr(
                            "Your current balance is ₹$walletBalance. Minimum ₹100 (for a 30-min anonymous audio support call) is needed. Choose a Google Play Billing pack:",
                            "आपका वर्तमान बैलेंस ₹$walletBalance है। 30-मिनट ऑडियो कॉल के लिए कम से कम ₹100 आवश्यक हैं। पैक चुनें:",
                            lang
                        ),
                        style = MaterialTheme.typography.bodySmall
                    )
                    PlayBillingManager.PLAY_BILLING_PACKS.forEach { pack ->
                        Button(
                            onClick = {
                                showSmartRechargePopup = false
                                playBillingManager.launchPackPurchase(
                                    activity = activity,
                                    pack = pack,
                                    isReviewerDemoAccount = isReviewerDemoAccount
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (pack.productId == PlayBillingManager.WALLET_100_ID) CrimsonPrimary else RoyalNavy,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("smart_popup_${pack.productId}")
                        ) {
                            Text("${pack.fallbackPriceLabel} • ₹${pack.creditsInr} Call Credits", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showSmartRechargePopup = false }) {
                    Text(tr("Close", "बंद करें", lang))
                }
            }
        )
    }
}

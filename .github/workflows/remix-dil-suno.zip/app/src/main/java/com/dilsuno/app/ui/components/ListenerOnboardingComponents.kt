package com.dilsuno.app.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.PromoSharePlatform
import com.dilsuno.app.core.PromoVideoShareHelper
import com.dilsuno.app.core.tr
import com.dilsuno.app.data.model.AdminPromoAsset
import com.dilsuno.app.data.model.ListenerPromoVideo
import com.dilsuno.app.ui.theme.CrimsonPrimary
import com.dilsuno.app.ui.theme.RoyalNavy
import com.dilsuno.app.ui.theme.SafeEmerald
import com.dilsuno.app.ui.theme.VelvetIndigo

/**
 * Full-screen mandatory post-login welcome & rules banner shown the exact moment
 * any Staff Listener logs in. "I Agree & Continue" stays disabled until the Listener
 * explicitly checks the acknowledgment box.
 */
@Composable
fun MandatoryListenerRulesBanner(
    listenerName: String,
    lang: AppLang,
    onAcceptAndContinue: () -> Unit
) {
    var isAgreed by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("mandatory_listener_rules_banner"),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(listOf(CrimsonPrimary, VelvetIndigo, RoyalNavy)),
                        RoundedCornerShape(22.dp)
                    )
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.VerifiedUser,
                            contentDescription = "Listener Code of Conduct",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = "❤️ दिल सुनो • Dil Suno",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White.copy(alpha = 0.9f),
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Welcome to Dil Suno — Listener Rules & Code of Conduct",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = tr(
                            "Hello $listenerName! Please read these mandatory rules before entering your Listener Dashboard.",
                            "नमस्ते $listenerName! अपने Listener डैशबोर्ड में जाने से पहले इन अनिवार्य नियमों को ध्यान से पढ़ें।",
                            lang
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.92f)
                    )
                }
            }

            // WHAT TO DO
            Card(
                colors = CardDefaults.cardColors(containerColor = SafeEmerald.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SafeEmerald.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "✅ WHAT TO DO (क्या करें):",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = SafeEmerald
                    )
                    RuleBullet(
                        num = "1.",
                        en = "Listen patiently with empathy; never interrupt or give unsolicited lectures.",
                        hi = "धैर्य और सहानुभूति के साथ सुनें; कभी बीच में न टोकें या बिना मांगे उपदेश न दें।"
                    )
                    RuleBullet(
                        num = "2.",
                        en = "Give warmth and emotional encouragement so the caller feels heard.",
                        hi = "अपनापन और भावनात्मक संबल दें ताकि कॉलर को लगे कि कोई उन्हें सच में सुन रहा है।"
                    )
                    RuleBullet(
                        num = "3.",
                        en = "You may share only your first name or nickname.",
                        hi = "आप केवल अपना पहला नाम या उपनाम (Nickname) बता सकते हैं।"
                    )
                    RuleBullet(
                        num = "4.",
                        en = "If a caller mentions self-harm or suicide, stay calm and tap \"Emergency / Suicide Alert\" immediately.",
                        hi = "यदि कोई कॉलर खुद को नुकसान पहुँचाने या आत्महत्या की बात करे, तो शांत रहें और तुरंत \"Emergency / Suicide Alert\" दबाएं।"
                    )
                }
            }

            // WHAT NOT TO DO
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f)),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "❌ WHAT NOT TO DO (क्या बिल्कुल न करें):",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.error
                    )
                    RuleBullet(
                        num = "1.",
                        en = "NEVER share mobile numbers, WhatsApp, UPI IDs, or Instagram/Facebook handles (AI detection will auto-disconnect the call and block your ID).",
                        hi = "कभी भी मोबाइल नंबर, WhatsApp, UPI ID या Instagram/Facebook हैंडल साझा न करें (AI डिटेक्शन कॉल को तुरंत काट देगा और आपकी ID ब्लॉक कर देगा)।"
                    )
                    RuleBullet(
                        num = "2.",
                        en = "Never judge, blame, or mock the caller.",
                        hi = "कॉलर को कभी जज न करें, दोष न दें या उनका मज़ाक न उड़ाएं।"
                    )
                    RuleBullet(
                        num = "3.",
                        en = "Never ask for or share the caller's personal identity, address, or phone number.",
                        hi = "कॉलर की निजी पहचान, पता या फ़ोन नंबर कभी न मांगें और न साझा करें।"
                    )
                    RuleBullet(
                        num = "4.",
                        en = "Never tolerate abuse — tap \"Report & Block Abuse\" immediately if a caller misbehaves.",
                        hi = "दुर्व्यवहार कभी सहन न करें — यदि कॉलर बदतमीज़ी करे तो तुरंत \"Report & Block Abuse\" दबाएं।"
                    )
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = isAgreed,
                        onCheckedChange = { isAgreed = it },
                        colors = CheckboxDefaults.colors(checkedColor = CrimsonPrimary),
                        modifier = Modifier.testTag("listener_rules_agree_checkbox")
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "I have read and agree to strictly follow all Do's and Don'ts.",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Button(
                onClick = onAcceptAndContinue,
                enabled = isAgreed,
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .testTag("listener_rules_continue_button")
            ) {
                Text(
                    text = "I Agree & Continue",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun RuleBullet(num: String, en: String, hi: String) {
    Row(verticalAlignment = Alignment.Top) {
        Text(num, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.width(6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(en, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Text(hi, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/**
 * Step A (5 Golden Rules) + Step B (In-App 3-Video Creation & Direct Native Sharing to
 * WhatsApp / Instagram / Facebook via FileProvider) required before unlocking Go Online.
 */
@Composable
fun ListenerGoOnlineGateCard(
    hasAcceptedGoldenRules: Boolean,
    myPromoVideos: List<ListenerPromoVideo>,
    adminPromoAssets: List<AdminPromoAsset>,
    canGoOnline: Boolean,
    appDownloadUrl: String?,
    lang: AppLang,
    onAcceptGoldenRules: () -> Unit,
    onAddPromoVideo: (title: String, caption: String, videoUri: String) -> Unit,
    onMarkVideoShared: (ListenerPromoVideo, String) -> Unit
) {
    val context = LocalContext.current
    val sharedCount = myPromoVideos.count { it.isShared }
    val createdCount = myPromoVideos.size
    val defaultCaption = remember(appDownloadUrl) {
        PromoVideoShareHelper.buildPromoCaption(appDownloadUrl)
    }

    val promoVideoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val idx = createdCount + 1
            val storedPath = PromoVideoShareHelper.copyVideoToPromoStorage(
                context = context,
                sourceUri = uri,
                videoId = "v${idx}_${System.currentTimeMillis()}"
            ) ?: uri.toString()
            onAddPromoVideo(
                "Dil Suno Promo Video #$idx",
                defaultCaption,
                storedPath
            )
        }
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (canGoOnline) {
                SafeEmerald.copy(alpha = 0.08f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
            }
        ),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (canGoOnline) SafeEmerald.copy(alpha = 0.5f) else CrimsonPrimary.copy(alpha = 0.35f),
                RoundedCornerShape(18.dp)
            )
            .testTag("listener_go_online_gate_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (canGoOnline) Icons.Filled.LockOpen else Icons.Filled.Lock,
                    contentDescription = null,
                    tint = if (canGoOnline) SafeEmerald else CrimsonPrimary
                )
                Spacer(Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (canGoOnline) {
                            tr("Go Online UNLOCKED! Ready for Calls", "Go Online अनलॉक हो गया! कॉल के लिए तैयार", lang)
                        } else {
                            tr("Unlock 'Go Online' (2 Mandatory Steps)", "'Go Online' अनलॉक करें (2 अनिवार्य चरण)", lang)
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (canGoOnline) SafeEmerald else CrimsonPrimary
                    )
                    Text(
                        text = tr(
                            "Golden Rules: ${if (hasAcceptedGoldenRules) "Done" else "Pending"} • Promo Videos: $createdCount/3 Created • $sharedCount/3 Shared",
                            "5 सुनहरे नियम: ${if (hasAcceptedGoldenRules) "पूर्ण" else "शेष"} • प्रोमो वीडियो: $createdCount/3 बनाए • $sharedCount/3 शेयर किए",
                            lang
                        ),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider()

            // STEP A: 5 Golden Rules
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = if (hasAcceptedGoldenRules) SafeEmerald else MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = tr("Step A: Confirm 5 Golden Listener Rules", "चरण A: 5 सुनहरे Listener नियम स्वीकार करें", lang),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (!hasAcceptedGoldenRules) {
                    Text(
                        text = "1) Patient empathy without lectures  2) Zero judgement  3) Warm encouragement  4) Zero personal contact leaks  5) Instant Emergency Alert on self-harm cues.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = onAcceptGoldenRules,
                        colors = ButtonDefaults.buttonColors(containerColor = VelvetIndigo),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("accept_golden_rules_button")
                    ) {
                        Text(tr("Confirm 5 Golden Rules", "5 सुनहरे नियम कन्फर्म करें", lang), fontWeight = FontWeight.Bold)
                    }
                }
            }

            HorizontalDivider()

            // STEP B: Create 3 Promotional Videos inside Dil Suno & Share Directly
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.Videocam,
                        contentDescription = null,
                        tint = if (createdCount >= 3 && sharedCount >= 3) SafeEmerald else CrimsonPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = tr(
                            "Step B: Create 3 'Dil Suno' Promo Videos & Share ($sharedCount/3)",
                            "चरण B: ऐप के अंदर 3 'दिल सुनो' प्रोमो वीडियो बनाएं और शेयर करें ($sharedCount/3)",
                            lang
                        ),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = {
                        promoVideoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("create_promo_video_button")
                ) {
                    Icon(Icons.Filled.VideoCall, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = tr(
                            "Create / Upload Promo Video (${createdCount}/3)",
                            "प्रोमो वीडियो बनाएं / चुनें (${createdCount}/3)",
                            lang
                        ),
                        fontWeight = FontWeight.Bold
                    )
                }

                // Super Admin ready-made promotional posters/videos listeners can also use
                if (adminPromoAssets.isNotEmpty() && createdCount < 3) {
                    Text(
                        text = tr("Or use Official Dil Suno Promo Templates:", "या आधिकारिक दिल सुनो प्रोमो टेम्पलेट चुनें:", lang),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = VelvetIndigo
                    )
                    adminPromoAssets.take(3).forEach { asset ->
                        OutlinedButton(
                            onClick = {
                                onAddPromoVideo(
                                    asset.title.ifBlank { "Official Dil Suno Promo" },
                                    asset.caption.ifBlank { defaultCaption },
                                    asset.mediaUri
                                )
                            },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        ) {
                            Text("Use Template: ${asset.title}", maxLines = 1)
                        }
                    }
                }

                myPromoVideos.forEachIndexed { index, video ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${index + 1}. ${video.title}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (video.isShared) {
                                        "✅ Shared (${video.sharedPlatforms.joinToString(", ")})"
                                    } else {
                                        "Tap Share Below"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (video.isShared) SafeEmerald else CrimsonPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                SharePlatformButton(
                                    label = "WhatsApp",
                                    color = Color(0xFF16A34A),
                                    modifier = Modifier.weight(1f).testTag("share_whatsapp_$index")
                                ) {
                                    PromoVideoShareHelper.sharePromoVideoToPlatform(
                                        context = context,
                                        videoPathOrUri = video.videoUri,
                                        caption = video.caption.ifBlank { defaultCaption },
                                        platform = PromoSharePlatform.WHATSAPP
                                    )
                                    onMarkVideoShared(video, PromoSharePlatform.WHATSAPP.label)
                                }
                                SharePlatformButton(
                                    label = "Instagram",
                                    color = Color(0xFFE11D48),
                                    modifier = Modifier.weight(1f).testTag("share_instagram_$index")
                                ) {
                                    PromoVideoShareHelper.sharePromoVideoToPlatform(
                                        context = context,
                                        videoPathOrUri = video.videoUri,
                                        caption = video.caption.ifBlank { defaultCaption },
                                        platform = PromoSharePlatform.INSTAGRAM
                                    )
                                    onMarkVideoShared(video, PromoSharePlatform.INSTAGRAM.label)
                                }
                                SharePlatformButton(
                                    label = "Facebook",
                                    color = Color(0xFF1D4ED8),
                                    modifier = Modifier.weight(1f).testTag("share_facebook_$index")
                                ) {
                                    PromoVideoShareHelper.sharePromoVideoToPlatform(
                                        context = context,
                                        videoPathOrUri = video.videoUri,
                                        caption = video.caption.ifBlank { defaultCaption },
                                        platform = PromoSharePlatform.FACEBOOK
                                    )
                                    onMarkVideoShared(video, PromoSharePlatform.FACEBOOK.label)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SharePlatformButton(
    label: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = color),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier.heightIn(min = 48.dp)
    ) {
        Icon(Icons.Filled.Share, contentDescription = "Share on $label", modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

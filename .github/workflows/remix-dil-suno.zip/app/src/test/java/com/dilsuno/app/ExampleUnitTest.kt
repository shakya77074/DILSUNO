package com.dilsuno.app

import com.dilsuno.app.core.AppLang
import com.dilsuno.app.core.DilSePolicyText
import com.dilsuno.app.core.RoyaltyFreeMusicLibrary
import com.dilsuno.app.core.SecurityUtils
import com.dilsuno.app.core.tr
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun staffPinAndEmailValidation_checksDigitLength() {
    assertTrue(SecurityUtils.isValidStaffPin("12345678"))
    assertFalse(SecurityUtils.isValidStaffPin("12345"))
    assertFalse(SecurityUtils.isValidStaffPin("abcdefgh"))
  }

  @Test
  fun bilingualPoliciesAndTracks_presentInBothLanguages() {
    assertTrue(DilSePolicyText.PRIVACY_POLICY_EN.contains("Zero Data Selling"))
    assertTrue(DilSePolicyText.PRIVACY_POLICY_HI.contains("गोपनीयता"))
    assertTrue(DilSePolicyText.TERMS_FULL_EN.contains("Google Play Billing"))
    assertTrue(DilSePolicyText.TERMS_FULL_HI.contains("Google Play Billing"))
    assertTrue(DilSePolicyText.CHILD_SAFETY_POLICY_EN.contains("CSAM"))
    assertTrue(DilSePolicyText.CHILD_SAFETY_POLICY_HI.contains("CSAM"))
    assertTrue(DilSePolicyText.MEDICAL_DISCLAIMER_EN.contains("Tele-MANAS"))
    assertTrue(DilSePolicyText.MEDICAL_DISCLAIMER_HI.contains("14416"))
    assertTrue(RoyaltyFreeMusicLibrary.tracks.any { it.id == "shayari_dastaan" })
    assertTrue(RoyaltyFreeMusicLibrary.sfxTracks.size >= 3)
    assertEquals("गोपनीयता नीति", tr("Privacy Policy", "गोपनीयता नीति", AppLang.HI))
  }

  @Test
  fun musicLibrary_hasFiveMoodCategoriesAndCopyrightFreeBuiltinTracks() {
    assertEquals(5, RoyaltyFreeMusicLibrary.moodCategories.size)
    assertTrue(RoyaltyFreeMusicLibrary.tracks.all { it.isBuiltinSafe })
    RoyaltyFreeMusicLibrary.moodCategories.forEach { category ->
      assertTrue(
          "Missing built-in tracks for ${category.combinedLabel}",
          RoyaltyFreeMusicLibrary.tracks.any { it.mood == category.combinedLabel }
      )
    }

    val customTracks = listOf(
        com.dilsuno.app.core.MusicTrackOption(
            id = "owner_track_1",
            titleEn = "Moonlight Flute",
            titleHi = "चांदनी बांसुरी",
            mood = RoyaltyFreeMusicLibrary.moodCategories.first().combinedLabel,
            baseFreqHz = 261.63,
            scaleOffsets = listOf(1.0, 1.25, 1.5),
            audioUrl = "https://cdn.dilsuno.example/moonlight.mp3",
            isBuiltinSafe = true,
            isAdminCurated = true
        ),
        com.dilsuno.app.core.MusicTrackOption(
            id = "owner_track_2",
            titleEn = "HTTP Rejected Track",
            titleHi = "एचटीटीपी ट्रैक",
            mood = RoyaltyFreeMusicLibrary.moodCategories.last().combinedLabel,
            baseFreqHz = 261.63,
            scaleOffsets = listOf(1.0, 1.25, 1.5),
            audioUrl = "http://insecure.example/track.mp3",
            isBuiltinSafe = true,
            isAdminCurated = true
        )
    )
    val json = RoyaltyFreeMusicLibrary.serializeCustomTracks(customTracks)
    val parsed = RoyaltyFreeMusicLibrary.parseCustomTracks(json)
    assertEquals(2, parsed.size)
    assertEquals("https://cdn.dilsuno.example/moonlight.mp3", parsed[0].audioUrl)
    assertEquals(null, parsed[1].audioUrl)
    val merged = RoyaltyFreeMusicLibrary.allTracksWithCustom(json)
    assertTrue(merged.any { it.id == "owner_track_1" && it.isAdminCurated })
    assertTrue(RoyaltyFreeMusicLibrary.parseCustomTracks("not-json").isEmpty())
  }
}

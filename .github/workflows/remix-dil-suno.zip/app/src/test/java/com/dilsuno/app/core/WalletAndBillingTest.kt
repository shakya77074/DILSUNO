package com.dilsuno.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WalletAndBillingTest {

    @Test
    fun playBillingPacks_matchExactGooglePlaySkusAndCredits() {
        val ids = PlayBillingManager.PLAY_BILLING_PACKS.map { it.productId }
        val credits = PlayBillingManager.PLAY_BILLING_PACKS.map { it.creditsInr }
        assertEquals(listOf("wallet_100", "wallet_200", "wallet_300", "wallet_400", "wallet_500"), ids)
        assertEquals(listOf(100L, 200L, 300L, 400L, 500L), credits)
        assertEquals(100L, PlayBillingManager.creditsForProductId("wallet_100"))
        assertEquals(200L, PlayBillingManager.creditsForProductId("wallet_200"))
        assertEquals(300L, PlayBillingManager.creditsForProductId("wallet_300"))
        assertEquals(400L, PlayBillingManager.creditsForProductId("wallet_400"))
        assertEquals(500L, PlayBillingManager.creditsForProductId("wallet_500"))
        assertNull(PlayBillingManager.creditsForProductId("invalid_pack"))
    }

    @Test
    fun callDuration_isThirtyMinutesWithCountdownFormatter() {
        assertEquals(1800L, DilSunoBillingRules.CALL_SLOT_DURATION_SECONDS)
        assertEquals("30:00", DilSunoBillingRules.formatCountdownMmSs(1800L))
        assertEquals("05:09", DilSunoBillingRules.formatCountdownMmSs(309L))
        assertEquals("00:00", DilSunoBillingRules.formatCountdownMmSs(0L))
        assertEquals("00:00", DilSunoBillingRules.formatCountdownMmSs(-15L))
    }

    @Test
    fun callSplit_is30Listener70AdminAnd100PercentForOwnerBackup() {
        val (listenerShare, adminShare) = DilSunoBillingRules.computeCallSplit(
            chargeInr = 100L,
            isOwnerBackupCall = false
        )
        assertEquals(30L, listenerShare)
        assertEquals(70L, adminShare)

        val (ownerListenerShare, ownerAdminShare) = DilSunoBillingRules.computeCallSplit(
            chargeInr = 100L,
            isOwnerBackupCall = true
        )
        assertEquals(0L, ownerListenerShare)
        assertEquals(100L, ownerAdminShare)
    }

    @Test
    fun playBillingProductIds_enforceFixedPacksAndPurchaseHashDeduplication() {
        assertEquals(listOf(100L, 200L, 300L, 400L, 500L), DilSunoBillingRules.FIXED_RECHARGE_PACKS)
        val hashA = DilSunoBillingRules.buildPurchaseTokenHash("token_abc_123", "wallet_100")
        val hashB = DilSunoBillingRules.buildPurchaseTokenHash("token_abc_123", "wallet_100")
        assertEquals(hashA, hashB)
    }

    @Test
    fun listenerWithdrawalValidation_enforcesMinimum500AndAvailableBalance() {
        assertNotNull(
            DilSunoBillingRules.validateListenerWithdrawal(
                availableEarningsInr = 800L,
                requestedAmountInr = 500L,
                payoutAccount = "ac"
            )
        )
        assertEquals(
            "Minimum ₹500 earnings required before requesting withdrawal.",
            DilSunoBillingRules.validateListenerWithdrawal(
                availableEarningsInr = 450L,
                requestedAmountInr = 450L,
                payoutAccount = "HDFC-XXXX1234"
            )
        )
        assertEquals(
            "Withdrawal amount must be at least ₹500.",
            DilSunoBillingRules.validateListenerWithdrawal(
                availableEarningsInr = 800L,
                requestedAmountInr = 400L,
                payoutAccount = "HDFC-XXXX1234"
            )
        )
        assertNotNull(
            DilSunoBillingRules.validateListenerWithdrawal(
                availableEarningsInr = 500L,
                requestedAmountInr = 600L,
                payoutAccount = "HDFC-XXXX1234"
            )
        )
        assertNull(
            DilSunoBillingRules.validateListenerWithdrawal(
                availableEarningsInr = 500L,
                requestedAmountInr = 500L,
                payoutAccount = "HDFC-XXXX1234"
            )
        )
        assertEquals("Pending", DilSunoBillingRules.formatPayoutStatusLabel("pending"))
        assertEquals("Paid / Approved", DilSunoBillingRules.formatPayoutStatusLabel("paid"))
    }

    @Test
    fun reviewerDemoAccount_verifiesExactCredentialsAndPreFundedCredits() {
        assertEquals(500L, SecurityUtils.REVIEWER_INITIAL_CREDITS_INR)
        assertTrue(SecurityUtils.isReviewerDemoEmail("reviewer@dilsuno.com"))
        assertTrue(SecurityUtils.isReviewerDemoEmail("  REVIEWER@DILSUNO.COM "))
        assertTrue(SecurityUtils.verifyReviewerDemoCredentials("reviewer@dilsuno.com", "ReviewUser@2026"))
        assertFalse(SecurityUtils.verifyReviewerDemoCredentials("reviewer@dilsuno.com", "wrong-pass"))
        assertFalse(SecurityUtils.verifyReviewerDemoCredentials("other@gmail.com", "ReviewUser@2026"))
    }

    @Test
    fun playPolicyRequiredCopy_matchesExactComplianceStrings() {
        assertEquals(
            "Dil Suno needs Microphone access to connect your live audio support calls, and Camera/Storage access only when you choose to record or upload videos. We never record audio in the background.",
            DilSePolicyText.PROMINENT_PERMISSION_DISCLOSURE_EN
        )
        assertEquals(
            "Your support call is 100% private and NOT recorded. Audio is never recorded in the background; 24x7 crisis escalation and Tele-MANAS (14416) remain available.",
            DilSePolicyText.EXPLICIT_EMERGENCY_RECORDING_NOTICE_EN
        )
        assertEquals(
            "Dil Suno provides anonymous peer emotional support, not medical or psychiatric treatment.",
            DilSePolicyText.HEALTH_DISCLAIMER_EN
        )
        assertEquals("Emergency Help: Call Tele-MANAS (14416)", DilSePolicyText.TELE_MANAS_BUTTON_LABEL_EN)
        assertEquals("https://dilsuno.app/delete-account", DilSePolicyText.WEB_ACCOUNT_DELETION_URL)
        assertEquals("supportdilsuno@gmail.com", DilSePolicyText.OFFICIAL_SUPPORT_EMAIL)
        assertEquals("https://shakya77074.github.io/DIL-SUNO/privacy.html", DilSePolicyText.PRIVACY_POLICY_URL)
        assertEquals(
            listOf("Nudity", "Harassment", "Spam", "Child Safety"),
            DilSePolicyText.REPORT_CONTENT_REASONS.map { it.first }
        )
    }
}

package com.dilsuno.app.data.repository

import com.dilsuno.app.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class DilSunoRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun signUpAndObserveAccount_validUser_succeedsAndPreventsCrossUserAccess() = runBlocking {
        val aliceUid = signInTestUser("alice_${UUID.randomUUID()}@test.com")
        val repo = AccountAndSocialRepository(firestore)

        val accountResult = withTimeout(5000L) {
            repo.createOrUpdateUserOnSignUp(
                fullName = "Alice Sharma",
                email = "alice@test.com",
                phone = null,
                passwordHash = "hash123",
                passwordSalt = "salt123",
                termsAccepted = true,
                currentCity = "Jaipur",
                hometown = "Kota",
                schoolCollege = "MNIT Jaipur"
            )
        }
        assertTrue("createOrUpdateUserOnSignUp failed: ${accountResult.exceptionOrNull()}", accountResult.isSuccess)
        assertEquals("user", accountResult.getOrThrow().role)
        assertEquals(0L, accountResult.getOrThrow().walletBalance)

        // Bob tries to read Alice's private account -> PERMISSION_DENIED
        signInTestUser("bob_${UUID.randomUUID()}@test.com")
        val bobRepo = AccountAndSocialRepository(firestore)
        val crossRead = withTimeout(5000L) { bobRepo.getMyAccount(aliceUid) }
        assertTrue(crossRead.isFailure)
        val fsEx = crossRead.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull(fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun cleanSignUpAndProfileUpdate_syncsFullNameToPublicProfileAndStoresOptionalPhonePrivately() = runBlocking {
        val uid = signInTestUser("priya_${UUID.randomUUID()}@test.com")
        val repo = AccountAndSocialRepository(firestore)

        // 1. Clean Sign-Up with ONLY Full Name, Email & Password (optional profile fields empty)
        val signUpRes = withTimeout(5000L) {
            repo.createOrUpdateUserOnSignUp(
                fullName = "Priya Tiwari",
                email = "priya@test.com",
                phone = null,
                passwordHash = "hashAbc123",
                passwordSalt = "saltAbc123",
                termsAccepted = true
            )
        }
        assertTrue("Sign-Up failed: ${signUpRes.exceptionOrNull()}", signUpRes.isSuccess)
        val initialProfiles = withTimeout(4000L) {
            repo.observeCommunityProfiles().first { list -> list.any { it.uid == uid } }
        }
        assertEquals("Priya Tiwari", initialProfiles.first { it.uid == uid }.fullName)

        // 2. Edit Profile later: update Full Name + optional Phone, City, Hometown, School, Workplace, Bio
        val updateRes = withTimeout(5000L) {
            repo.updateProfileDetails(
                fullName = "Priya Tiwari Verma",
                phone = "9876543210",
                avatarUri = null,
                currentCity = "Lucknow",
                hometown = "Ayodhya",
                schoolCollege = "Lucknow University",
                workplace = "Radio Artist",
                bio = "Connecting with hometown friends",
                isProfileLocked = false
            )
        }
        assertTrue("Profile update failed: ${updateRes.exceptionOrNull()}", updateRes.isSuccess)

        val updatedAcct = withTimeout(4000L) { repo.getMyAccount(uid).getOrThrow() }
        assertEquals("Priya Tiwari Verma", updatedAcct?.fullName)
        assertEquals("9876543210", updatedAcct?.phone)

        val updatedPublic = withTimeout(4000L) {
            repo.observeCommunityProfiles().first { list ->
                list.any { it.uid == uid && it.fullName == "Priya Tiwari Verma" }
            }
        }.first { it.uid == uid }
        assertEquals("Lucknow", updatedPublic.currentCity)
        assertEquals("Ayodhya", updatedPublic.hometown)
        assertEquals("Lucknow University", updatedPublic.schoolCollege)

        // 3. Clearing optional Phone succeeds via FieldValue.delete()
        val clearPhoneRes = withTimeout(5000L) {
            repo.updateProfileDetails(
                fullName = "Priya Tiwari Verma",
                phone = "",
                avatarUri = null,
                currentCity = "Lucknow",
                hometown = "Ayodhya",
                schoolCollege = "Lucknow University",
                workplace = "Radio Artist",
                bio = "Connecting with hometown friends",
                isProfileLocked = true
            )
        }
        assertTrue("Clearing optional phone failed: ${clearPhoneRes.exceptionOrNull()}", clearPhoneRes.isSuccess)
        val clearedAcct = withTimeout(4000L) { repo.getMyAccount(uid).getOrThrow() }
        assertEquals(null, clearedAcct?.phone)
    }

    @Test
    fun publishPostAndObserveFeed_authenticatedUser_emitsNewPost() = runBlocking {
        signInTestUser("creator_${UUID.randomUUID()}@test.com")
        val feedRepo = FeedModerationAndCallRepository(firestore)

        val uniqueCaption = "Community cleanup ${UUID.randomUUID()}"
        val postIdResult = withTimeout(5000L) {
            feedRepo.publishApprovedPost(
                authorName = "Rohan Verma",
                authorAvatar = null,
                postType = "news",
                title = "Jaipur Clean Drive",
                caption = uniqueCaption,
                city = "Jaipur",
                mediaUri = null,
                musicTrack = null
            )
        }
        assertTrue(postIdResult.isSuccess)
        val postId = postIdResult.getOrThrow()

        val posts = withTimeout(4000L) {
            feedRepo.observeActivePosts().first { list -> list.any { it.id == postId } }
        }
        assertTrue(posts.any { it.id == postId && it.caption == uniqueCaption })
    }

    @Test
    fun observeActivePosts_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val feedRepo = FeedModerationAndCallRepository(firestore)

        var caught: Throwable? = null
        try {
            withTimeout(3000L) { feedRepo.observeActivePosts().first() }
        } catch (t: Throwable) {
            caught = t
        }
        val fsEx = caught?.unwrapFirestoreException()
        assertNotNull("Expected FirebaseFirestoreException, got $caught", fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun dilSeCallAndWebRtcSignaling_callerSignalsAndOutsiderDenied() = runBlocking {
        val callerUid = signInTestUser("caller_${UUID.randomUUID()}@test.com")
        val callerRepo = FeedModerationAndCallRepository(firestore)

        val billingRes = withTimeout(5000L) {
            callerRepo.verifyAndRecordPlayBillingPurchase(
                uid = callerUid,
                productId = "wallet_100",
                creditsInr = 100L,
                purchaseToken = "gpa.test-${UUID.randomUUID()}",
                orderId = "GPA.TEST-ORDER-1"
            )
        }
        assertTrue("billingRes failed: ${billingRes.exceptionOrNull()}", billingRes.isSuccess)
        val callRes = withTimeout(5000L) {
            callerRepo.initiateDilSeCall("Anonymous-RIYA", 100L, "play_wallet_${System.currentTimeMillis()}")
        }
        assertTrue("callRes failed: ${callRes.exceptionOrNull()}", callRes.isSuccess)
        val callId = callRes.getOrThrow()

        val sigRes = withTimeout(5000L) {
            callerRepo.sendWebRtcSignal(callId, "caller", "offer", "{\"type\":\"offer\",\"sdp\":\"test\"}")
        }
        assertTrue("sigRes failed: ${sigRes.exceptionOrNull()}", sigRes.isSuccess)

        val signals = withTimeout(4000L) {
            callerRepo.observeWebRtcSignals(callId).first { it.isNotEmpty() }
        }
        assertEquals(1, signals.size)
        assertEquals("offer", signals.first().signalType)

        // Outsider cannot read WebRTC signals or send spoofed signals
        signInTestUser("outsider_${UUID.randomUUID()}@test.com")
        val outsiderRepo = FeedModerationAndCallRepository(firestore)
        val spoofRes = withTimeout(5000L) {
            outsiderRepo.sendWebRtcSignal(callId, "listener", "answer", "{\"type\":\"answer\",\"sdp\":\"spoof\"}")
        }
        assertTrue("spoofRes should fail: $spoofRes", spoofRes.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            spoofRes.exceptionOrNull()?.unwrapFirestoreException()?.code
        )
    }

    @Test
    fun staffAuditAndAdminConfig_nonAdminUserDenied() = runBlocking {
        signInTestUser("author_${UUID.randomUUID()}@test.com")
        val authorRepo = FeedModerationAndCallRepository(firestore)
        val postId = withTimeout(5000L) {
            authorRepo.publishApprovedPost(
                authorName = "Author One",
                authorAvatar = null,
                postType = "reel",
                title = null,
                caption = "Nice poetry reel ${UUID.randomUUID()}",
                city = "Delhi",
                mediaUri = null,
                musicTrack = null
            )
        }.getOrThrow()

        // Normal user tries to enable owner call pickup or delete another user's post as moderator -> DENIED
        signInTestUser("random_${UUID.randomUUID()}@test.com")
        val randomRepo = FeedModerationAndCallRepository(firestore)

        val toggleRes = withTimeout(5000L) { randomRepo.adminToggleCallPickupOnline(true) }
        assertTrue(toggleRes.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            toggleRes.exceptionOrNull()?.unwrapFirestoreException()?.code
        )

        val modDeleteRes = withTimeout(5000L) {
            randomRepo.moderatorDeleteContentWithAudit(
                targetType = "reel",
                targetId = postId,
                moderatorStaffUsername = "fake_staff",
                moderatorDisplayName = "Fake"
            )
        }
        assertTrue(modDeleteRes.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            modDeleteRes.exceptionOrNull()?.unwrapFirestoreException()?.code
        )

        var auditReadErr: Throwable? = null
        try {
            withTimeout(3000L) { randomRepo.observeStaffAuditLogsForAdmin().first() }
        } catch (t: Throwable) {
            auditReadErr = t
        }
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            auditReadErr?.unwrapFirestoreException()?.code
        )
    }

    @Test
    fun malwareUploadBlockingAndOwnerLock_enforcedByRepoAndFirestoreRules() = runBlocking {
        signInTestUser("security_user_${UUID.randomUUID()}@test.com")
        val feedRepo = FeedModerationAndCallRepository(firestore)
        val socialRepo = AccountAndSocialRepository(firestore)

        // Dangerous .apk / .exe / .zip / .html media URIs rejected cleanly before & at Firestore rules
        val apkPostRes = withTimeout(5000L) {
            feedRepo.publishApprovedPost(
                authorName = "Tester",
                authorAvatar = null,
                postType = "news",
                title = "Update",
                caption = "Safe caption",
                city = "Delhi",
                mediaUri = "https://cdn.example.com/bad/app.apk",
                musicTrack = null
            )
        }
        assertTrue("APK upload must fail", apkPostRes.isFailure)

        val zipChatRes = withTimeout(5000L) {
            socialRepo.sendChatMessage(
                otherUid = "other_uid_123",
                senderName = "Tester",
                messageType = "image",
                text = "Archive",
                mediaUri = "file:///storage/emulated/0/Download/payload.zip"
            )
        }
        assertTrue("ZIP chat attachment must fail", zipChatRes.isFailure)

        // Non-owner cannot write to admin_secrets or admins collection directly in Firestore
        var secretWriteError: Throwable? = null
        try {
            withTimeout(5000L) {
                firestore.collection("admin_secrets").document("owner_auth")
                    .set(mapOf("ownerPasswordHash" to "hacked", "ownerSalt" to "hacked"))
                    .await()
            }
        } catch (t: Throwable) {
            secretWriteError = t
        }
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            secretWriteError?.unwrapFirestoreException()?.code
        )
        val adminSaveRes = withTimeout(5000L) {
            feedRepo.adminSaveBusinessConfig(
                callRateInr = 100L,
                viewBonusPer1000Inr = 25L,
                globalMonetizationEnabled = true
            )
        }
        assertTrue("Non-owner admin config/secret write must fail", adminSaveRes.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            adminSaveRes.exceptionOrNull()?.unwrapFirestoreException()?.code
        )
    }

    @Test
    fun passwordlessCustomerSignup_persistsAgeGenderCityAvatarAndAllowsLoginRead() = runBlocking {
        val uid = signInTestUser("new_customer_${UUID.randomUUID()}@gmail.com")
        val repo = AccountAndSocialRepository(firestore)

        val res = withTimeout(5000L) {
            repo.createOrUpdateUserOnSignUp(
                fullName = "Aarav Patel",
                email = "aarav.patel@gmail.com",
                phone = null,
                termsAccepted = true,
                currentCity = "Indore",
                hometown = "Indore",
                age = 26L,
                gender = "Male",
                avatarUri = "https://cdn.example.com/aarav.jpg"
            )
        }
        assertTrue("Passwordless customer create account failed: ${res.exceptionOrNull()}", res.isSuccess)
        val created = res.getOrThrow()
        assertEquals("Aarav Patel", created.fullName)
        assertEquals(26L, created.age)
        assertEquals("Male", created.gender)
        assertEquals("aarav.patel@gmail.com", created.email)
        assertEquals(null, created.passwordHash)

        val fetched = withTimeout(4000L) { repo.getMyAccount(uid).getOrThrow() }
        assertNotNull(fetched)
        assertEquals(26L, fetched?.age)
        assertEquals("Male", fetched?.gender)

        val profiles = withTimeout(4000L) {
            repo.observeCommunityProfiles().first { list -> list.any { it.uid == uid } }
        }
        val publicProfile = profiles.first { it.uid == uid }
        assertEquals("Indore", publicProfile.currentCity)
        assertEquals("https://cdn.example.com/aarav.jpg", publicProfile.avatarUri)
    }
}


package com.dilsuno.app.core

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
class SecurityProtectionTest {

    @Test
    fun sanitizeInput_stripsScriptsHtmlEventHandlersAndMaliciousLinks() {
        val xss = "<script>alert('xss')</script>Namaste <iframe src='evil'></iframe><img src=x onerror=steal()>"
        val cleaned = SecurityUtils.sanitizeInput(xss)
        assertFalse(cleaned.contains("<script", ignoreCase = true))
        assertFalse(cleaned.contains("<iframe", ignoreCase = true))
        assertFalse(cleaned.contains("onerror=", ignoreCase = true))
        assertFalse(cleaned.contains("<"))
        assertFalse(cleaned.contains(">"))
        assertTrue(cleaned.contains("Namaste"))

        val badLink = "Install this javascript:alert(1) https://evil.example.com/app.apk and https://bad.test/run.exe"
        val cleanedLink = SecurityUtils.sanitizeInput(badLink)
        assertFalse(cleanedLink.contains("javascript:", ignoreCase = true))
        assertFalse(cleanedLink.contains(".apk", ignoreCase = true))
        assertFalse(cleanedLink.contains(".exe", ignoreCase = true))
        assertTrue(cleanedLink.contains("[blocked-link]"))
    }

    @Test
    fun validateMediaDescriptor_allowsSafeFormatsUpTo25Mb_andBlocksDangerousOrOversizeFiles() {
        val allowedImages = listOf("photo.jpg", "pic.JPEG", "avatar.png", "banner.webp")
        for (file in allowedImages) {
            val res = SecurityUtils.validateMediaDescriptor(
                fileNameOrUri = file,
                mimeType = "image/${file.substringAfterLast('.').lowercase().let { if (it == "jpg") "jpeg" else it }}",
                sizeBytes = 5L * 1024L * 1024L,
                allowVideo = false
            )
            assertTrue("Expected $file to succeed, got ${res.exceptionOrNull()}", res.isSuccess)
        }

        val allowedVideos = listOf(
            "reel.mp4" to "video/mp4",
            "clip.mov" to "video/quicktime"
        )
        for ((file, mime) in allowedVideos) {
            val ok = SecurityUtils.validateMediaDescriptor(
                fileNameOrUri = file,
                mimeType = mime,
                sizeBytes = SecurityUtils.MAX_MEDIA_UPLOAD_BYTES,
                allowVideo = true
            )
            assertTrue("Expected $file at 25MB to succeed", ok.isSuccess)

            val imageOnlyFail = SecurityUtils.validateMediaDescriptor(
                fileNameOrUri = file,
                mimeType = mime,
                sizeBytes = 1024L,
                allowVideo = false
            )
            assertTrue("Expected video $file to fail when allowVideo=false", imageOnlyFail.isFailure)
        }

        val dangerousFiles = listOf(
            "virus.apk" to "application/vnd.android.package-archive",
            "trojan.exe" to "application/x-msdownload",
            "hack.sh" to "text/x-shellscript",
            "script.bat" to "application/bat",
            "payload.js" to "application/javascript",
            "phish.html" to "text/html",
            "bundle.zip" to "application/zip",
            "archive.rar" to "application/x-rar-compressed"
        )
        for ((name, mime) in dangerousFiles) {
            val res = SecurityUtils.validateMediaDescriptor(
                fileNameOrUri = name,
                mimeType = mime,
                sizeBytes = 1024L,
                allowVideo = true
            )
            assertTrue("Expected dangerous file $name to be blocked", res.isFailure)
        }

        val overLimit = SecurityUtils.validateMediaDescriptor(
            fileNameOrUri = "huge_video.mp4",
            mimeType = "video/mp4",
            sizeBytes = SecurityUtils.MAX_MEDIA_UPLOAD_BYTES + 1L,
            allowVideo = true
        )
        assertTrue("Expected >25MB file to be rejected", overLimit.isFailure)
    }

    @Test
    fun mediaUploadValidator_validatesLocalFileUriExtensionAndSizeLimit() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        val safeImage = File(context.cacheDir, "safe_test_photo.jpg").apply {
            writeBytes(ByteArray(1024) { 1 })
        }
        val safeResult = MediaUploadValidator.validatePickedMedia(
            context = context,
            uri = Uri.fromFile(safeImage),
            allowVideo = false
        )
        assertTrue("Safe local jpg should succeed: ${safeResult.exceptionOrNull()}", safeResult.isSuccess)
        assertFalse(safeResult.getOrThrow().isVideo)

        val dangerousApk = File(context.cacheDir, "malicious_test.apk").apply {
            writeBytes(ByteArray(512) { 2 })
        }
        val apkResult = MediaUploadValidator.validatePickedMedia(
            context = context,
            uri = Uri.fromFile(dangerousApk),
            allowVideo = true
        )
        assertTrue("Local .apk file must be rejected", apkResult.isFailure)

        val badScheme = MediaUploadValidator.validatePickedMedia(
            context = context,
            uri = Uri.parse("javascript:alert(1)"),
            allowVideo = true
        )
        assertTrue("javascript: URI must be rejected", badScheme.isFailure)

        safeImage.delete()
        dangerousApk.delete()
    }

    @Test
    fun singleOwnerLock_verifiesOnlyVerifiedOwnerEmailAndIdentifier() {
        assertTrue(SecurityUtils.isVerifiedOwnerEmail("anoopshakya0563@gmail.com", true))
        assertTrue(SecurityUtils.isVerifiedOwnerEmail("  ANOOPSHAKYA0563@GMAIL.COM ", true))
        assertFalse(SecurityUtils.isVerifiedOwnerEmail("anoopshakya0563@gmail.com", false))
        assertFalse(SecurityUtils.isVerifiedOwnerEmail("hacker@gmail.com", true))
        assertFalse(SecurityUtils.isVerifiedOwnerEmail(null, true))

        // Owner identifiers: email OR mobile 8076451007
        assertTrue(SecurityUtils.isOwnerIdentifier("anoopshakya0563@gmail.com"))
        assertTrue(SecurityUtils.isOwnerIdentifier("8076451007"))
        assertTrue(SecurityUtils.isOwnerIdentifier("+918076451007"))
        assertTrue(SecurityUtils.isOwnerIdentifier("+91 80764 51007"))
        assertFalse(SecurityUtils.isOwnerIdentifier("9876543210"))
        assertFalse(SecurityUtils.isOwnerIdentifier("other@gmail.com"))
        assertEquals(3, SecurityUtils.MAX_OWNER_FAILED_ATTEMPTS)
    }

    @Test
    fun isSafeMediaUri_permitsM4aVoiceNotesOnlyWhenExplicitlyAllowed() {
        assertFalse(SecurityUtils.isSafeMediaUri("/data/user/0/com.dilsuno.app/cache/voice.m4a", allowVideo = true, allowVoiceNotePath = false))
        assertTrue(SecurityUtils.isSafeMediaUri("/data/user/0/com.dilsuno.app/cache/voice.m4a", allowVideo = true, allowVoiceNotePath = true))
        assertFalse(SecurityUtils.isSafeMediaUri("/data/user/0/../../evil.apk", allowVideo = true, allowVoiceNotePath = true))
        assertFalse(SecurityUtils.isSafeMediaUri("https://cdn.example.com/file.exe", allowVideo = true))
        assertTrue(SecurityUtils.isSafeMediaUri("https://cdn.example.com/photo.png", allowVideo = false))
    }

    @Test
    fun staffPinAndEmailDocId_enforcesEightToTwelveOrCustomSixToSixteenDigitsAndSafeIds() {
        assertTrue(SecurityUtils.isValidStaffPin("12345678"))
        assertTrue(SecurityUtils.isValidStaffPin("987654321012"))
        assertTrue(SecurityUtils.isValidStaffPin("123456"))
        assertTrue(SecurityUtils.isValidStaffPin("004299"))
        assertFalse(SecurityUtils.isValidStaffPin("12345"))
        assertFalse(SecurityUtils.isValidStaffPin("12345678901234567"))
        assertFalse(SecurityUtils.isValidStaffPin("12a45678"))
        assertFalse(SecurityUtils.isValidStaffPin(""))

        assertTrue(SecurityUtils.isAcceptablePassword("123456"))
        assertTrue(SecurityUtils.isAcceptablePassword("DilSuno2026"))
        assertFalse(SecurityUtils.isAcceptablePassword("12345"))
        assertEquals("Rahul Sharma", SecurityUtils.deriveDisplayNameFromEmail("rahul.sharma@gmail.com"))
        assertFalse(SecurityUtils.deriveDisplayNameFromEmail("a@b.com").contains("@"))

        val docA = SecurityUtils.staffDocIdFromEmail("  Priya.Sharma@GMAIL.COM ")
        val docB = SecurityUtils.staffDocIdFromEmail("priya.sharma@gmail.com")
        assertEquals(docA, docB)
        assertTrue(docA.matches(Regex("^[a-z0-9_]{1,40}$")))
        assertEquals("priya@gmail.com", SecurityUtils.normalizeEmail(" PRIYA@GMAIL.COM "))
    }

    @Test
    fun phoneLoginAliasEmail_generatesValidAliasAndDetectsInternalDomain() {
        val e164 = SecurityUtils.normalizeIndianPhoneE164("9876543210")!!
        val alias = SecurityUtils.phoneLoginAliasEmail(e164)
        assertEquals("u919876543210@phone.dilsuno.app", alias)
        assertTrue(SecurityUtils.isValidEmail(alias))
        assertTrue(SecurityUtils.isPhoneLoginAliasEmail(alias))
        assertFalse(SecurityUtils.isPhoneLoginAliasEmail("anoopshakya0563@gmail.com"))
        assertFalse(SecurityUtils.isPhoneLoginAliasEmail(null))
    }
}

package com.dilsuno.app.core

import com.dilsuno.app.data.model.ListenerPromoVideo
import com.dilsuno.app.viewmodel.StaffAndAdminViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MasterSecurityAndLeakTest {

    @Test
    fun contactLeakDetector_catchesDigitsSpacedSpokenHindiUpiAndSocial_allowsNormalNames() {
        // Direct 10-digit & spaced phone numbers
        assertTrue(ContactLeakDetector.detectContactLeak("Call me on 9876543210 later").isLeakDetected)
        assertTrue(ContactLeakDetector.detectContactLeak("My number is +91 98765 43210").isLeakDetected)
        assertTrue(ContactLeakDetector.detectContactLeak("Note down 9 8 7 6 5 4 3 2 1 0").isLeakDetected)

        // Spoken English phone numbers
        assertTrue(
            ContactLeakDetector.detectContactLeak(
                "nine eight seven six five four three two one zero"
            ).isLeakDetected
        )

        // Spoken Hindi / Hinglish & Devanagari phone numbers
        assertTrue(
            ContactLeakDetector.detectContactLeak(
                "nau aath saat che paanch char teen do ek shunya"
            ).isLeakDetected
        )
        assertTrue(
            ContactLeakDetector.detectContactLeak(
                "नौ आठ सात छह पांच चार तीन दो एक शून्य"
            ).isLeakDetected
        )
        assertTrue(
            ContactLeakDetector.detectContactLeak("मेरा नंबर ९८७६५४३२१० है").isLeakDetected
        )

        // UPI IDs & social media handles
        assertTrue(ContactLeakDetector.detectContactLeak("Send money to rahul123@okicici").isLeakDetected)
        assertTrue(ContactLeakDetector.detectContactLeak("Message me on WhatsApp please").isLeakDetected)
        assertTrue(ContactLeakDetector.detectContactLeak("Follow my insta @rohan_vibes").isLeakDetected)

        // Allowed normal conversation & first names / nicknames (ZERO false positives)
        assertFalse(ContactLeakDetector.detectContactLeak("Hi, my name is Priya, I am feeling stressed today").isLeakDetected)
        assertFalse(ContactLeakDetector.detectContactLeak("You can call me Sonu, I just needed someone to listen").isLeakDetected)
        assertFalse(ContactLeakDetector.detectContactLeak("I slept only 4 hours last night and have 2 exams tomorrow").isLeakDetected)
        assertFalse(ContactLeakDetector.detectContactLeak("नमस्ते, मेरा नाम अमित है, आज मन बहुत भारी लग रहा है").isLeakDetected)
    }

    @Test
    fun sha256AndPhoneNormalization_hashesDeterministicallyWithoutPlaintextLeak() {
        val normalizedA = SecurityUtils.normalizeIndianPhoneE164("+91 98765 43210")!!
        val normalizedB = SecurityUtils.normalizeIndianPhoneE164("9876543210")!!
        val normalizedC = SecurityUtils.normalizeIndianPhoneE164("9123456789")!!
        val hashA = SecurityUtils.sha256Hex(normalizedA)
        val hashB = SecurityUtils.sha256Hex(normalizedB)
        val hashC = SecurityUtils.sha256Hex(normalizedC)

        assertEquals(hashA, hashB)
        assertEquals(64, hashA.length)
        assertFalse(hashA.contains("9876543210"))
        assertNotEquals(hashA, hashC)
    }

    @Test
    fun appVersionCheck_detectsNewerRemoteVersionOrBuildCode() {
        assertTrue(
            SecurityUtils.isNewerVersionAvailable(
                currentVersionCode = 1,
                currentVersionName = "1.0.0",
                latestVersionCode = 2L,
                latestVersionName = "1.0.1"
            )
        )
        assertTrue(
            SecurityUtils.isNewerVersionAvailable(
                currentVersionCode = 1,
                currentVersionName = "1.0.0",
                latestVersionCode = 1L,
                latestVersionName = "1.0.1"
            )
        )
        assertFalse(
            SecurityUtils.isNewerVersionAvailable(
                currentVersionCode = 1,
                currentVersionName = "1.0.0",
                latestVersionCode = 1L,
                latestVersionName = "1.0.0"
            )
        )
    }

    @Test
    fun listenerGoOnlineGate_requiresGoldenRulesAndThreeCreatedAndSharedPromoVideos() {
        val twoShared = listOf(
            ListenerPromoVideo(id = "v1", sharedPlatforms = listOf("WhatsApp"), isShared = true),
            ListenerPromoVideo(id = "v2", sharedPlatforms = listOf("Instagram"), isShared = true)
        )
        val threeCreatedTwoShared = twoShared + ListenerPromoVideo(id = "v3", sharedPlatforms = emptyList(), isShared = false)
        val threeCreatedThreeShared = twoShared + ListenerPromoVideo(id = "v3", sharedPlatforms = listOf("Facebook"), isShared = true)

        assertFalse(StaffAndAdminViewModel.isListenerEligibleToGoOnline(false, threeCreatedThreeShared))
        assertFalse(StaffAndAdminViewModel.isListenerEligibleToGoOnline(true, twoShared))
        assertFalse(StaffAndAdminViewModel.isListenerEligibleToGoOnline(true, threeCreatedTwoShared))
        assertTrue(StaffAndAdminViewModel.isListenerEligibleToGoOnline(true, threeCreatedThreeShared))
    }

    @Test
    fun playBillingPurchaseTokenHash_deduplicatesIdenticalTokensAcrossProducts() {
        val hash1 = DilSunoBillingRules.buildPurchaseTokenHash(
            purchaseToken = "gpa.1234-5678-9012-34567",
            productId = "pack_100"
        )
        val hash2 = DilSunoBillingRules.buildPurchaseTokenHash(
            purchaseToken = "  gpa.1234-5678-9012-34567 ",
            productId = "pack_100"
        )
        val hashDifferent = DilSunoBillingRules.buildPurchaseTokenHash(
            purchaseToken = "gpa.1234-5678-9012-99999",
            productId = "pack_200"
        )
        assertEquals(hash1, hash2)
        assertNotEquals(hash1, hashDifferent)
    }
}

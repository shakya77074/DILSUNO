package com.dilsuno.app.core

import com.dilsuno.app.data.model.StaffDirectoryEntry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ZegoCallManagerTest {
    @Test
    fun zegoCredentials_matchConfiguredValues() {
        assertEquals(908504858L, ZegoCallManager.ZEGO_APP_ID)
        assertEquals(
            "7f9d8b99148b54d4fde61d8a55e37d833d5e9a55fc80a12e9effb0768009a236",
            ZegoCallManager.ZEGO_APP_SIGN
        )
    }

    @Test
    fun warmStudioAudioProfile_enables3A48kHzAndDisablesVoiceChanger() {
        val profile = ZegoCallManager.WARM_STUDIO_3A_PROFILE
        assertEquals(48_000, profile.sampleRateHz)
        assertTrue(profile.ansEnabled)
        assertTrue(profile.aecEnabled)
        assertTrue(profile.agcEnabled)
        assertTrue(profile.voiceChangerDisabled)
        assertTrue((profile.equalizerBandGainsDb[2] ?: 0f) > 0f)
        assertTrue((profile.equalizerBandGainsDb[3] ?: 0f) > 0f)
        assertTrue((profile.equalizerBandGainsDb[8] ?: 0f) < 0f)
    }

    @Test
    fun sanitizeUserId_keepsFirebaseUidAndReplacesUnsafeChars() {
        assertEquals("uidAbc123XYZ", ZegoCallManager.sanitizeUserId("uidAbc123XYZ"))
        assertEquals("listener_1_gmail_com", ZegoCallManager.sanitizeUserId("listener-1@gmail.com"))
        assertEquals("dilsuno_user", ZegoCallManager.sanitizeUserId("   "))
    }

    @Test
    fun resolveListenerTargetId_prefersAssignedUidThenStaffUsername() {
        val onlineStaff = StaffDirectoryEntry(
            staffUsername = "priya_listener",
            displayName = "Priya",
            assignedUid = "firebaseUid999",
            isOnline = true,
            isActive = true
        )
        val unassignedStaff = StaffDirectoryEntry(
            staffUsername = "rahul_listener",
            displayName = "Rahul",
            assignedUid = null,
            isOnline = false,
            isActive = true
        )
        assertEquals("firebaseUid999", ZegoCallManager.resolveListenerTargetId(onlineStaff))
        assertEquals("rahul_listener", ZegoCallManager.resolveListenerTargetId(unassignedStaff))
    }
}

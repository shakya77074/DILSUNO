package com.dilsuno.app

import android.content.Context
import android.view.WindowManager
import androidx.test.core.app.ApplicationProvider
import com.dilsuno.app.core.PlayBillingManager
import com.dilsuno.app.core.ZegoCallManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Dil Suno", appName)
  }

  @Test
  fun `main activity launches without FLAG_SECURE or startup crash`() {
    val controller = Robolectric.buildActivity(MainActivity::class.java).create().start().resume()
    val activity = controller.get()
    val flags = activity.window.attributes.flags
    assertEquals(0, flags and WindowManager.LayoutParams.FLAG_SECURE)
    assertEquals(908504858L, ZegoCallManager.ZEGO_APP_ID)
    assertTrue(ZegoCallManager.ZEGO_APP_SIGN.isNotBlank())
    controller.pause().stop().destroy()
  }

  @Test
  fun `play billing manager handles unavailable play store safely`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val manager = PlayBillingManager(
      context = context,
      onPurchaseVerifiedForFirebase = {},
      onBillingMessage = {}
    )
    manager.startConnection()
    manager.endConnection()
  }
}

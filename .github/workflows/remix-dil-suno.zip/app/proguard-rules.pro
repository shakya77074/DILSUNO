# Keep Firestore models and all fields/constructors for reflection deserialization
-keepclassmembers class com.dilsuno.app.data.model.** { *; }
-keep class com.dilsuno.app.data.model.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,SourceFile,LineNumberTable

# Kotlin Coroutines & Serialization
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }
-keepattributes RuntimeVisibleAnnotations,AnnotationDefault
-keepclassmembers class ** {
    @kotlinx.serialization.* <fields>;
}

# ZegoCloud & WebRTC native JNI interfaces
-keep class im.zego.** { *; }
-keep class com.zegocloud.** { *; }
-keep class org.webrtc.** { *; }
-dontwarn im.zego.**
-dontwarn com.zegocloud.**

# Google Play Billing Library
-keep class com.android.billingclient.api.** { *; }
-dontwarn com.android.billingclient.**

# Firebase, App Check & Credential Manager
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }
-keep class androidx.credentials.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn org.codehaus.mojo.animal_sniffer.**
